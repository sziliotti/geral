
from __future__ import print_function

import sys
import collections
from pyspark import SparkContext, SparkConf
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
from pyspark.sql import *

from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext, Row

from pyspark.sql.types import *
import json
from collections import OrderedDict 
from pyspark.sql import HiveContext 

import datetime
from pyspark.sql.functions import * 

from datetime import datetime, date, time

def getSparkSessionInstance(sparkConf):
    if ('sparkSessionSingletonInstance' not in globals()):
        globals()['sparkSessionSingletonInstance'] = SparkSession\
            .builder\
            .config(conf=sparkConf)\
            .enableHiveSupport()\
            .getOrCreate()
    return globals()['sparkSessionSingletonInstance']



def error_file_handle(mensagem):


        try:

           f = open('/tmp/consumer_skyline.log', 'w')
           f.write( datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
           f.write(' An exceptional thing happed: ' +  mensagem)
           f.close()


        except:
            pass





def  refresh_improvement():



                       df_refresh = spark_skl.sql("select " +
" a.eccode, " +
" a.nsu, " +
" a.posrequestamount, " +
" a.operationamount, " +
" b.nm_bandeira, " +
" a.issuerid, " +
" c.nm_banco, " +
" d.nm_ec, " +
" d.nm_fantasia, " +
" d.nm_cadeia_forcada, " +
" a.produtocompleto, " +
" g.dc_produto_completo, " +
" h.dc_forma_pgto as dc_tipo_transacao, " +
" a.statusgeraltransacao, " +
" a.shortresponsemessage, " +
" case a.saletype " +
" when 'single' then 'A VISTA' " +
" when 'installment'then 'PARCELADO' " +
" when 'recurring' then 'RECORRENTE' " +
" else a.saletype end as dc_forma_pagamento, " +
" a.installments as QT_PARCELAS, " +
" a.binnumber as bin, " +
" a.notecode, " +
" i.dc_obs_sol_aut, " +
" CAST(from_utc_timestamp(from_unixtime(unix_timestamp(a.datehoursale, 'yyyyMMddHHmmss')), 'America/Sao_Paulo') AS TIMESTAMP) AS DT_AUTORIZACAO, " +
" from_unixtime(unix_timestamp(cast(from_utc_timestamp(from_unixtime(unix_timestamp(a.datehoursale, 'yyyyMMddHHmmss')), 'America/Sao_Paulo') as string), 'yyyy-MM-dd HH:mm')) AS DT_AUTORIZACAO_MINUTO,  " +
" d.NM_Ramo_Atividade, " +
" d.NM_DIRETORIA, " +
" cast(TO_DATE(CAST(from_utc_timestamp(from_unixtime(unix_timestamp(a.datehoursale, 'yyyyMMddHHmmss')), 'America/Sao_Paulo') AS TIMESTAMP)) as string) AS DT_AUTORIZACAO_DIA " +
" FROM " +
" temp_ecom_skyline a  " +
" left join stage.online_tbdwr_bandeira b on " +
" cast(a.associationid as int) = b.cd_so_bandeira " +
" left join stage.online_tbdwr_banco c on " +
" cast(a.issuerid as int) = c.nu_banco " +
" left join stage.online_tbdwr_ec_cadeia_mcc_diretoria d on " +
" cast(a.eccode as int) = d.nu_so_ec  " +
" left join stage.online_tbbamr_produto_completo g on " +
" a.produtocompleto = g.cd_produto_completo " +
" left join stage.online_tbbamr_forma_pagamento h on " +
" g.cd_forma_pgto = h.cd_forma_pgto " +
" left join stage.online_tbdwr_obs_sol_aut i on " +
" a.notecode = i.cd_so_obs_sol_aut where a.eccode is not null " )


                       #result_df_ecom1 = spark_skl.sql("create table if not exists  online.tbauth_skyline_v1  stored as parquet select * from temp_ecom_skyline")




                       df_refresh.repartition(1).write.format("parquet").mode("append").insertInto("online.tbauth_skyline_refresh")










def  insert_tbauth_skyline():



                       df_skl = spark_skl.sql("select  " +
                                         "    associationid        ,    " +
                                         "    authorizationcode,    " +
                                         "    binnumber            ,    " +
                                         "    breadcrumbid      ,    " +
                                         "    cardnumber         ,    " +
                                         "    city                        ,    " +
                                         "    codgrupoec         ,    " +
                                         "    communicationnode,    " +
                                         "    communicationsecundarynode ,    " +
                                         "    datehoursale               ,    " +
                                         "    eccode                        ,    " +
                                         "    idecommerce             ,    " +
                                         "    indictransacaotoken   ,    " +
                                         "    installments                 ,    " +
                                         "    issuerauthorizationsource  ,    " +
                                         "    issuerid                  ,    " +
                                         "    notecode               ,    " +
                                         "    nsu                         ,    " +
                                         "    nsuauthorization    ,    " +
                                         "    operationamount   ,    " +
                                         "    operationtype        ,    " +
                                         "    origintransactionip ,    " +
                                         "    posrequestamount,    " +
                                         "    productcodeprimary,    " +
                                         "    productcodesecondary,    " +
                                         "    produtocompleto      ,    " +
                                         "    responsecode          ,    " +
                                         "    responsetime           ,    " +
                                         "    salestatus                 ,    " +
                                         "    saletype                   ,    " +
                                         "    shortresponsemessage ,    " +
                                         "    site                       ,    " +
                                         "    solutiontype         ,    " +
                                         "    source                  ,    " +
                                         "    state                     ,    " +
                                         "    status                   ,    " +
                                         "    statusgeraltransacao,    " +
                                         "    storeid                    ,    " +
                                         "    terminalid                ,    " +
                                         "    tokentype                ,    " +
                                         "    wallet                     ,    " +
                                         "    zipcode                  ,    " +
                                      "    from_unixtime(unix_timestamp(dateHourSale,'yyyyMMddHHmmss'),'yyyy')  year, " +
                                      "    from_unixtime(unix_timestamp(dateHourSale,'yyyyMMddHHmmss'),'MM')  month,  " +
                                      "    from_unixtime(unix_timestamp(dateHourSale,'yyyyMMddHHmmss'),'dd')  day     " +
                                      " from temp_ecom_skyline " +
                                      " where idEcommerce is not null")

                       result_df_ecom = spark_skl.sql("create table if not exists  online.tbauth_skyline  stored as parquet select * from temp_ecom_skyline")


                       #df_skl.coalesce(1).write.format("parquet").mode("append").insertInto("online.tbauth_skyline")
                       df_skl.repartition(1).write.format("parquet").mode("append").insertInto("online.tbauth_skyline")









 # Convert RDDs of the words DStream to DataFrame and run SQL query
def process(time, rdd):
        print("========= %s =========" % str(time))

        try:

             # spark = getSparkSessionInstance(rdd.context.getConf())


              #spark = SparkSession.builder.enableHiveSupport().getOrCreate()

              print('##############################   JSON  ##########################################################')

              warehouse_location = 'file:${system:user.dir}/spark-warehouse'

              print(warehouse_location)
             


              schema = StructType([])

              #spark = SQLContext(sc)
              #spark = HiveContext(sc)
 

              if rdd.isEmpty():

                # df = spark.createDataFrame(rdd,schema)

                 print('#####     RDD is empty #####'  )

              else:



                 json_struct = StructType([StructField('json', StringType(), True)])



                 #parsed_rdd_json = rdd.map(lambda x: json.loads(x))


                 df_json_skl  = spark_skl.read.json(rdd)

                 #schema = rdd.map(lambda x: Row(**x))
                 #schema1 =  rdd.map(lambda l: ("StructField(" + l.name + "," + l.type + ",true)"))


                 #y=json.dumps(rdd.collect(),sort_keys=True).encode('utf-8')

                 #df_json_skl = spark_skl.createDataFrame(parsed_rdd_json,samplingRatio=90.2)


                 print(df_json_skl.columns)



                 if 'idEcommerce' in df_json_skl.columns:

                       print('############################################ RDD SKYLINE ###########################################################'  )


                       df_json_skl.show()

                       df_json_skl.registerTempTable("temp_ecom_skyline")

		       #insert_tbauth_skyline()
 
 		       refresh_improvement()


                 parsed_rdd_json=""

        except Exception, e:
            error_file_handle(e.message)
            pass







if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: direct_kafka_Mlib.py <broker_list> <topic>", file=sys.stderr)
        exit(-1)


    sc = SparkContext(appName="PythonStreamingDirectKafkaMlib")
    ssc = StreamingContext(sc, 60)






    spark_skl= SparkSession.builder.appName("Bigdata Online Skyline")\
          .enableHiveSupport()\
          .config("hive.exec.dynamic.partition", "true") \
          .config("hive.exec.dynamic.partition.mode","nonstrict") \
          .getOrCreate()
  #         .config("hive.exec.dynamic.partition.mode","nonstrict") \
  #         .config("hive.metastore.warehouse.dir", "hdfs://10.150.85.2:/user/hive/warehouse" )\
  #$         .config("spark.metastore.warehouse.dir", "hdfs://10.150.85.2:/user/hive/warehouse" )\
   #        .config("spark.sql.warehouse.dir", "hdfs://10.150.85.2:/user/hive/warehouse"  )\
   #        .getOrCreate()






    #spark = HiveContext(sc)
    #spark.setConf("hive.metastore.uris", "thrift://slplprdbden01.cielo.int:9083")
    #spark.setConf("hive.metastore.warehouse.dir", "hdfs://10.150.85.2:/user/hive/warehouse" )




    brokers, topic = sys.argv[1:]
    kvs = KafkaUtils.createDirectStream(ssc, [topic], {"metadata.broker.list": brokers,"auto.offset.reset":'largest' })


    lines = kvs.map(lambda x: x[1])


    lines.foreachRDD(process)


    ssc.start()
    ssc.awaitTermination()




