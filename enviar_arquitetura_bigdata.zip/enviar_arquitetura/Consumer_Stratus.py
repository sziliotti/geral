
from __future__ import print_function

import sys
import collections
from pyspark import SparkContext, SparkConf
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
from pyspark.sql import *

from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext, Row

from pyspark.sql.types import *
import json
from collections import OrderedDict 
from pyspark.sql import HiveContext 

import datetime
from pyspark.sql.functions import * 

from datetime import datetime, date, time

from pyspark.sql.functions import from_json
import traceback

###############  VARIAVEIS GLOBAIS ###########################
v_freq_insert=0


def getSparkSessionInstance(sparkConf):
    if ('sparkSessionSingletonInstance' not in globals()):
        globals()['sparkSessionSingletonInstance'] = SparkSession\
            .builder\
            .config(conf=sparkConf)\
            .enableHiveSupport()\
            .getOrCreate()
    return globals()['sparkSessionSingletonInstance']


def error_handle(mensagem):


        try:
            #var = traceback.format_exc()


            msg = str(mensagem)

            stmt  = " insert into online.tbauth_error_log (dh_erro,dc_sistema,dc_erro) values ("
            stmt += "'" + datetime.now().strftime('%Y-%m-%d %H:%M:%S')  + "'," + "'Stratus', '" + msg.replace("'","") + "')"  

            df_error = spark.sql(stmt) 

        except:
            pass


def error_file_handle(mensagem):


        try:

           f = open('/tmp/consumer_stratus.txt', 'w')
           f.write( datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
           f.write(' An exceptional thing happened: ' +  mensagem)
           f.close()


        except:
            pass



def insert_stratus_refresh():
     
     print ("###################################### PASSOU NO INSERT ###################################################################")

     df_insert   = spark.sql("insert into online.tbauth_stratus_refresh                         " +   
                        "     partition(data_formatada_particao)                                " + 
                        "         SELECT                                                        " +
                        "        data_formatada_segundo,                                        " +
                        "        codigoestabelecimento,                                         " +
                        "        valorvenda,                                                    " +
                        "        dc_forma_pgto,                                                 " +
                        "        NM_BANDEIRA,                                                   " +
                        "        NM_BANCO,                                                      " +
                        "        nm_ec,                                                         " +
                        "        nm_fantasia,                                                   " +
                        "        nm_cadeia_forcada,                                             " +
                        "        idstatus,                                                      " +
                        "        data_formatada_particao                                        " +
                        "        from online.tbauth_stratus_refresh_temp  " )



     df_truncate = spark.sql("truncate table online.tbauth_stratus_refresh_temp ")



def  refresh_improvement():



                    df_refresh = spark.sql(" SELECT from_utc_timestamp(from_unixtime(CAST(a.datahorainputterminal / 1000 as BIGINT), " +
                                            " 'yyyy-MM-dd HH:mm:ss'), 'America/Sao_Paulo') as data_formatada_segundo, " +
                                            " a.codigoestabelecimento, " +
                                            " a.valorvenda, " +
                                            " g.dc_forma_pgto, " +
                                            " E.NM_BANDEIRA, " +
                                            " F.NM_BANCO, " +
                                            " b.nm_ec, " +
                                            " b.nm_fantasia, " +
                                            " b.nm_cadeia_forcada, " +
                                            " a.idstatus, " +
                                            " a.bin, " +
                                            " a.codmultivan, " +
                                            " a.codigoerro, " +
                                            " a.codigooperadoragprs, " +
                                            " a.dadosversaoterminal, " +
                                            " a.indicadorlio, " +
                                            " a.mcc, " +
                                            " a.idmensagem, " +
                                            " a.mensagem, " +
                                            " a.modeloterminal, " +
                                            " a.modoconexao, " +
                                            " a.nsu, " +
                                            " a.nsuconfirmacaoautorizacaopos, " +
                                            " a.observacao, " +
                                            " j.DC_OBS_SOL_AUT, " +
                                            " a.quemrespondeu, " +
                                            " i.DS_DESCRICAO, " +
                                            " a.releaseespecificacao, " +
                                            " a.produto, " +
                                            " a.subproduto, " +
                                            " a.terminal, " +
                                            " a.tiptra, " +
                                            " a.tiposolucaocapturamodoentrada, " +
                                            " a.tipotecnologia, " +
                                            " a.versaoaplicativo, " +
                                            " a.versaosolucaocapturampos, " +
					                        " a.quantidadeparcelas, " +
                                            " case a.quantidadeparcelas when 0 then 'A VISTA' ELSE 'PARCELADO' " +
                                            " 	END AS dc_tipo_pagamento, " +
                                            " a.produtocompleto, " +
                                            " h.dc_produto_completo, " +
                                            " k.NM_TIPO_EQUIPAMENTO, " +
                                            " k.NM_SLC_CAPT, " +
                                            " k.NM_SGRP_SLC_CAPT, " +
                                            " k.NM_GRP_SLC_CAPT, " +
                                            " k.NM_TIPO_TECNOLOGIA, " +
                                            " a.nomeoperadoragprs, " +
                                            " b.NM_Ramo_Atividade, " +
                                            " b.NM_DIRETORIA, " +
                                            " cast(to_date(from_utc_timestamp(from_unixtime(CAST(a.datahorainputterminal / 1000 as BIGINT), " +
                                            " 'yyyy-MM-dd HH:mm:ss'), 'America/Sao_Paulo')) as string) as data_formatada_particao " +
                                            " FROM  temp_stratus  a left join stage.online_tbdwr_ec_cadeia_mcc_diretoria b " +
                                            " on cast(a.codigoestabelecimento as bigint) = b.nu_so_ec " +
                                            " left join stage.online_tbdwr_bandeira e on " +
                                            " CAST(A.BANDEIRA AS INT) = E.CD_SO_BANDEIRA " +
                                            " left join stage.online_tbdwr_banco f on " +
                                            " CAST(A.BANCO AS INT) = F.NU_BANCO " +
                                            " left join stage.online_tbbamr_forma_pagamento g on " +
                                            " CAST(A.FORMAPAGAMENTO AS INT) = G.CD_FORMA_PGTO " +
                                            " left join stage.online_tbbamr_produto_completo h on " +
                                            " a.produtocompleto = h.cd_produto_completo " +
                                            " left join stage.online_tbbamr_quem_responde i on " +
                                            " a.quemrespondeu = i.DC_CHAVE " +
                                            " left join stage.ONLINE_TBDWR_OBS_SOL_AUT j on " +
                                            " a.observacao = j.CD_SO_OBS_SOL_AUT"
                                            " left join stage.ONLINE_TBDWR_EQUIP_SLC_CAPT k on +"
                                            " cast(a.tipotecnologia as bigint) = k.NU_LOGICO_EQUIP ")


                    df_refresh.repartition(1).write.format("parquet").mode("append").insertInto("online.tbauth_stratus_refresh")



def  insert_tbauth_stratus():




                    df = spark.sql("select   " +
                                "      autorizacaoparcial                  , " +
                                "      banco                               , " +
                                "      bandeira                            , " +
                                "      bin                                 , " +
                                "      cep                                 , " +
                                "      chavemaquina                        , " +
                                "      cidade                              , " +
                                "      ciersmonitoracao                    , " +
                                "      'Nao Disponivel'                    , " +
                                "      codmultivan                         , " +
                                "      codsolcaptura                       , " +
                                "      codigoautorizacao                   , " +
                                "      codigocompletelocalidade            , " +
                                "      codigoerro                          , " +
                                "      codigoestabelecimento               , " +
                                "      codigolocalidade                    , " +
                                "      codigoloja                          , " +
                                "      codigono                            , " +
                                "      codigonosecundario                  , " +
                                "      codigooperadoragprs                 , " +
                                "      codigoprocessamento                 , " +
                                "      codigoservicopos                    , " +
                                "      dadosversaoterminal                 , " +
                                "      datahoraentradastratussaidapos      , " +
                                "      datahorainputterminal               , " +
                                "      datahoraminutostr                   , " +
                                "      datahoraretornoaopos                , " +
                                "      datahoraretornobandeira             , " +
                                "      datahoraretornohsm                  , " +
                                "      datahorasaidastratusentradabandeira , " +
                                "      datahorasaidastratusentradahsm      , " +
                                "      datahorastratus                     , " +
                                "      datahorastratusalterada             , " +
                                "      dcc                                 , " +
                                "      flagcielopromo                      , " +
                                "      formadeentrada                      , " +
                                "      formapagamento                      , " +
                                "      horainput                           , " +
                                "      horaoutput                          , " +
                                "      idmensagem                          , " +
                                "      idstatus                            , " +
                                "      indictransacaotoken                 , " +
                                "      indicadorlio                        , " +
                                "      indicadorskyline                    , " +
                                "      indicativoautorizacaoparcial        , " +
                                "      informacoeslynx                     , " +
                                "      informacoesstandin                  , " +
                                "      lynx                                , " +
                                "      mcc                                 , " +
                                "      mensagem                            , " +
                                "      modeloterminal                      , " +
                                "      modoconexao                         , " +
                                "      nomeoperadoragprs                   , " +
                                "      nsu                                 , " +
                                "      nsucanref                           , " +
                                "      nsuconfirmacaoautorizacaopos        , " +
                                "      numcartaomascarado                  , " +
                                "      numerocelularsms                    , " +
                                "      obs                                 , " +
                                "      observacao                          , " +
                                "      produto                             , " +
                                "      produtocompleto                     , " +
                                "      quantidadeparcelas                  , " +
                                "      quemrespondeu                       , " +
                                "      recorrente                          , " +
                                "      releaseespecificacao                , " +
                                "      resolutor                           , " +
                                "      sourcecode                          , " +
                                "      standin                             , " +
                                "      subproduto                          , " +
                                "      switchvisa                          , " +
                                "      terminal                            , " +
                                "      tiptra                              , " +
                                "      tiposolucaocapturamodoentrada       , " +
                                "      tipotecnologia                      , " +
                                "      tpsdatahoratrans                    , " +
                                "      transacaopos                        , " +
                                "      uf                                  , " +
                                "      uuidmessageadapter                  , " +
                                "      valorcancelamento                   , " +
                                "      valorvenda                          , " +
                                "      versaoaplicativo                    , " +
                                "      versaoecommerce                     , " +
                                "      versaosolucaocapturampos            , " +
                                "     cast(from_unixtime(CAST(datahorainputterminal/1000 as BIGINT), 'yyyy') as int) as year, " +
                                "     cast(from_unixtime(CAST(datahorainputterminal/1000 as BIGINT), 'MM') as int) as month, " +
                                "     cast(from_unixtime(CAST(datahorainputterminal/1000 as BIGINT), 'dd')  as int) as day " +
                                " from temp_stratus " +
                                " where dataHoraStratus is not null")


                    result_df_stratus = spark.sql("create table if not exists online.tbauth_stratus stored as parquet select * from temp_stratus")

                    df.show()

                    spark.sql("set hive.merge.mapfiles=true")
                    spark.sql("set hive.merge.sparkfiles=false")
                    spark.sql("set hive.merge.smallfiles.avgsize=16000000")
                    spark.sql("set hive.merge.size.per.task=256000000")

                    df.repartition(1).write.format("parquet").mode("append").insertInto("online.tbauth_stratus")




 # Convert RDDs of the words DStream to DataFrame and run SQL query
def process(time, rdd):
        print("========= %s =========" % str(time))

        try:

             # spark = getSparkSessionInstance(rdd.context.getConf())


              #spark = SparkSession.builder.enableHiveSupport().getOrCreate()

              print('##############################   JSON  ##########################################################')

              warehouse_location = 'file:${system:user.dir}/spark-warehouse'

              print(warehouse_location)
             


              schema = StructType([])

              #spark = SQLContext(sc)
              #spark = HiveContext(sc)
 

              if rdd.isEmpty():

                # df = spark.createDataFrame(rdd,schema)

                 print('########################################################     RDD is empty ###################################################'  )

              else:



                 #print(rdd.collect())

                 json_struct = StructType([StructField('json', StringType(), True)])


                 df_json  = spark.read.json(rdd) 
                 print(df_json.first())
                 print('########################################## PARSE JSON  PARSE ##############################################################')
               

                 #parsed_rdd_json = rdd.map(lambda x: json.loads( x ))


                 print(df_json.columns)
		 df_json.printSchema()




                 if 'codMultivan' in df_json.columns:

                    print('################################################ RDD  STRATUS  ##############################################################'  )
	            print('################################################ REGISTRANDO A TEMP TABLE ###################################################'  ) 
                    print (len(df_json.columns))
                    df_json.registerTempTable("temp_stratus")
                    print('################################################ ENTRANDO NO INSERT DA STRATUS################################################'  )
                    #insert_tbauth_stratus()

		    refresh_improvement()


                 parsed_rdd_json=""
                 y = ""

        except Exception, e:
            error_file_handle(e.message)
            pass



if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: direct_kafka_Mlib.py <broker_list> <topic>", file=sys.stderr)
        exit(-1)


    sc = SparkContext(appName="PythonStreamingDirectKafkaMlib")
    ssc = StreamingContext(sc, 120)






    spark= SparkSession.builder.appName("Bigdata Online")\
          .enableHiveSupport()\
          .config("hive.exec.dynamic.partition", "true") \
          .config("hive.exec.dynamic.partition.mode","nonstrict") \
          .getOrCreate()


  #         .config("hive.exec.dynamic.partition.mode","nonstrict") \
  #         .config("hive.metastore.warehouse.dir", "hdfs://10.150.85.2:/user/hive/warehouse" )\
  #$         .config("spark.metastore.warehouse.dir", "hdfs://10.150.85.2:/user/hive/warehouse" )\
   #        .config("spark.sql.warehouse.dir", "hdfs://10.150.85.2:/user/hive/warehouse"  )\
   #        .getOrCreate()






    #spark = HiveContext(sc)
    #spark.setConf("hive.metastore.uris", "thrift://slplprdbden01.cielo.int:9083")
    #spark.setConf("hive.metastore.warehouse.dir", "hdfs://10.150.85.2:/user/hive/warehouse" )




    brokers, topic = sys.argv[1:]
    kvs = KafkaUtils.createDirectStream(ssc, [topic], {"metadata.broker.list": brokers,"auto.offset.reset":'largest'})

    lines = kvs.map(lambda x: x[1])


    lines.foreachRDD(process)


    ssc.start()
    ssc.awaitTermination()




