/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.dispatcher.model.test;

import br.com.cielo.dispatcher.model.CanonicalTransactionVO;
import br.com.cielo.dispatcher.model.TransactionStatus;
import br.com.cielo.dispatcher.model.TransactionType;
import java.io.IOException;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author nemer
 */
public class NewEmptyJUnitTest {
    
    public NewEmptyJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
     public void testGenerateCanonicalJSon() throws IOException {
         CanonicalTransactionVO vo = new CanonicalTransactionVO();
         vo.setAssociationId("001");
         vo.setAuthorizationCode("00");
         vo.setBin("123456");
         vo.setCaptureSolutionDescription("LIO Wifi");
         vo.setCaptureSolutionId("113");
         vo.setCardNumber("123456******3456");
         vo.setDateHourGmt0("24012017210159001");
         vo.setDateHourPOS("24012017210159");
         vo.setInstallments(2);
         vo.setIssuerCode("001");
         vo.setMerchantId("100001290");
         vo.setMerchantOwnerId("100001290");
         vo.setNsu("12345");
         vo.setNsuAuthorization("12344");
         vo.setNsuPOSConfirmation(null);
         vo.setProductCode("1001");
         vo.setSaleAmount("912.91");
         vo.setSalesTypeDescription("CREDITO A PARCELADO");
         vo.setStatus(TransactionStatus.PENDING);
         vo.setTID(null);
         vo.setTerminalId("1234567890");
         vo.setTransactionType(TransactionType.INSTALLMENT);
         ObjectMapper mapper = new ObjectMapper();
         String jsonInString = mapper.writeValueAsString(vo);
         System.out.print(jsonInString);
         
     }
}
