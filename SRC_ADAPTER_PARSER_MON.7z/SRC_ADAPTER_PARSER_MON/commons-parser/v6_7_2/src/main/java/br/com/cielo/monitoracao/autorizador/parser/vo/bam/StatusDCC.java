package br.com.cielo.monitoracao.autorizador.parser.vo.bam;

/**
 *<B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * <br>
 * Enumeration responsável por descrever os status da Transação do tipo DCC.
 *	 
 *<DL><DT><B>Criada em:</B><DD>14/04/2014</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public enum StatusDCC {
	ELEGIVEL(1), NAO_ELEGIVEL(2), DCC(3), NEGADO_PELA_PLANET(4), NAO_SELECIONADO_DCC_CLIENTE(5), TIMEOUT_PLANET(6);
	
	private int idStatusDCC;
	
	/**
	 * Construtor
	 * 
	 * @param idStatusDCC
	 */
	StatusDCC(int idStatusDCC) {
		this.idStatusDCC= idStatusDCC;
	}
	
	/**
	 * Retornar o valor do status.
	 * 
	 * @return
	 */
	public int getValue(){
		return idStatusDCC;
	}
	
	/**
	 * Retorna enum corresponde ao status da transação do tipo DCC.
	 * 
	 * @param idStatusDCC
	 * @return
	 */
	public static StatusDCC statusOf(int idStatusDCC) {
		switch (idStatusDCC) {			
			case 1:
				return ELEGIVEL;
			case 2:
				return NAO_ELEGIVEL;
			case 3:
				return DCC;
			case 4:
				return NEGADO_PELA_PLANET;
			case 5:
				return NAO_SELECIONADO_DCC_CLIENTE;
			case 6:
				return TIMEOUT_PLANET;
			default:
				return null;
		} 
	}

}
