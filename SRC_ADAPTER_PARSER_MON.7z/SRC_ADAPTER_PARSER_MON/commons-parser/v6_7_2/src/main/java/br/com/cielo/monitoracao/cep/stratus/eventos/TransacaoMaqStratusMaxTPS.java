package br.com.cielo.monitoracao.cep.stratus.eventos;

import br.com.cielo.monitoracao.DateUtils;
import java.util.Date;

public class TransacaoMaqStratusMaxTPS {

    private Long timestampTranYmDh;
    private Long qtdTransacoes;
    private String chaveMaquina;
    private Long qtdCredito;
    private Long qtdDebito;
    private Long qtdPrivate;
    private Long qtdNenhum;
    private Date dataPicoTps;

    public Date getDataPicoTps() {
        return dataPicoTps;
    }

    public void setDataPicoTps(Date dataPicoTps) {
        this.dataPicoTps = dataPicoTps;
    }

    public Long getQtdCredito() {
        return qtdCredito;
    }

    public void setQtdCredito(Long qtdCredito) {
        this.qtdCredito = qtdCredito;
    }

    public Long getQtdDebito() {
        return qtdDebito;
    }

    public void setQtdDebito(Long qtdDebito) {
        this.qtdDebito = qtdDebito;
    }

    public Long getQtdNenhum() {
		return qtdNenhum;
	}

	public void setQtdNenhum(Long qtdNenhum) {
		this.qtdNenhum = qtdNenhum;
	}

	public Long getQtdPrivate() {
        return qtdPrivate;
    }

    public void setQtdPrivate(Long qtdPrivate) {
        this.qtdPrivate = qtdPrivate;
    }

    public String getChaveMaquina() {
        return chaveMaquina;
    }

    public String getCacheKey() {
        return chaveMaquina + getTimestampTranYmDh();
    }

    public void setChaveMaquina(String chaveMaquina) {
        this.chaveMaquina = chaveMaquina;
    }

    public Long getTimestampTranYmDh() {
        return timestampTranYmDh;
    }

    public Date getDateTranYmDh() {
        return new Date(getTimestampTranYmDh());
    }

    public void setTimestampTranYmDh(Long timestampTranYmDh) {
        this.timestampTranYmDh = timestampTranYmDh;
    }

    public Long getQtdTransacoes() {
        return qtdTransacoes;
    }

    public void setQtdTransacoes(Long qtdTransacoes) {
        this.qtdTransacoes = qtdTransacoes;
    }

    public int getHora() {
        return DateUtils.getHourOfDay(getTimestampTranYmDh());
    }

    public void sumQtdDebito(Long qtd) {
        if (this.qtdDebito == null) {
            qtdDebito = qtd;
        } else {
            qtdDebito += qtd;
        }
    }

    public void sumQtdCredito(Long qtd) {
        if (this.qtdCredito == null) {
            qtdCredito = qtd;
        } else {
            qtdCredito += qtd;
        }
    }
    
    public void sumQtdNenhum(Long qtd) {
        if (this.qtdNenhum == null) {
            qtdNenhum = qtd;
        } else {
            qtdNenhum += qtd;
        }
    }

    public void sumQtdPrivate(Long qtd) {
        if (this.qtdPrivate == null) {
            qtdPrivate = qtd;
        } else {
            qtdPrivate += qtd;
        }
    }
}
