package br.com.cielo.monitoracao.cep.eventos;

import java.io.Serializable;

public interface XMLable extends Serializable {
	
	public String toXML();

}
