package br.com.cielo.monitoracao.cep.stratus.eventos;

import br.com.cielo.monitoracao.DateUtils;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class TransacaoStarSchema {

    public static final List<String> TIPOS_ROTA_SKYLINE = Arrays.asList(new String[]{"S", "X", "Y", "W", "Z", "K"});

    public enum IndicadorCaminhoTransacao {

        SKYLINE("S"), STRATUS("N"), BYPASS("F5-BP");
        String value;

        IndicadorCaminhoTransacao(String path) {
            value = path;
        }

        public String getValue() {
            return value;
        }
    }
    protected static final long serialVersionUID = 1L;
    protected transient static final DateTimeFormatter dtfDataHoraMinuto = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm");
    protected transient static final DateTimeFormatter dtfHrMin = DateTimeFormat.forPattern("HH:mm");
    protected static final BigDecimal milBigDecimal = new BigDecimal("1000");
    protected static final List<String> codProdutoPay = Arrays.asList(new String[]{"00260000", "00270000", "00620000", "00630000", "00640000", "00650000", "00760000", "01000007", "01000008",
        "01000009", "01000010", "01000011", "01000012", "01000013", "03100007", "03100008", "03100009", "03100010",
        "03100011", "03100017", "07300000", "07310000", "07320000", "07330000", "07340000", "07380000", "07390000",
        "07400000", "60000001", "60000002", "60000003", "60000006", "60000007", "60000008", "70000001", "70000002",
        "70000003", "70000004", "70000005"});
    protected String codProdutoCompleto;
    protected Integer codBandeira;
    protected Integer codBanco;
    protected Integer codNoTelefonico;
    protected Integer codSolCapt;
    protected Date dataHoraAut;
    protected Integer codEntryMode;
    protected Integer codRespAut;
    protected Integer codVersaoSfw;
    protected Integer codRamoAtividade;
    protected String siglaUf;
    protected Integer valorSolicitacao;
    protected Integer qtdAprovadas;
    protected Integer qtdNegadas;
    protected Integer qtdDesfazimentos;
    protected Integer qtdCanceladas;
    protected String tipoSkyline;
    protected Integer horaMinAgrupado;
    protected Long timestampTrans;
    protected String tipoTransacao;
    protected Long qtdTransacoes;
    protected Long tempoTransacao;
    protected String chaveMaquina;
    protected String mensagem;
    protected String quemResp;
    protected String codigoOperadoraGPRS;
    protected String modoConexao;
    protected String codigoErro;
    protected boolean indLynx;
    protected boolean indStandin;
    protected Integer qtdTimeoutLynx;    
    protected static final List<String> MAQ_SP = Arrays.asList(new String[]{"MA", "MC", "M9"});
    protected static final List<String> MAQ_RIO = Arrays.asList(new String[]{"MB", "ME"});
    
    /* Atributos relacionados ao DCC */
    public Integer codDCC;
	public long qtdElegivelDCC;
	public long qtdNaoElegivelDCC;
	public long qtdNegadaPlanet;
	public long qtdTimeoutPlanet;
	public long tempoRespostaPlanet;
	
	
	public Integer getCodDCC() {
		return codDCC;
	}

	public void setCodDCC(Integer codDCC) {
		this.codDCC = codDCC;
	}

	public long getQtdElegivelDCC() {
		return qtdElegivelDCC;
	}

	public void setQtdElegivelDCC(long qtdElegivelDCC) {
		this.qtdElegivelDCC = qtdElegivelDCC;
	}

	public long getQtdNaoElegivelDCC() {
		return qtdNaoElegivelDCC;
	}

	public void setQtdNaoElegivelDCC(long qtdNaoElegivelDCC) {
		this.qtdNaoElegivelDCC = qtdNaoElegivelDCC;
	}

	public long getQtdNegadaPlanet() {
		return qtdNegadaPlanet;
	}

	public void setQtdNegadaPlanet(long qtdNegadaPlanet) {
		this.qtdNegadaPlanet = qtdNegadaPlanet;
	}

	public long getQtdTimeoutPlanet() {
		return qtdTimeoutPlanet;
	}

	public void setQtdTimeoutPlanet(long qtdTimeoutPlanet) {
		this.qtdTimeoutPlanet = qtdTimeoutPlanet;
	}

	public long getTempoRespostaPlanet() {
		return tempoRespostaPlanet;
	}

	public void setTempoRespostaPlanet(long tempoRespostaPlanet) {
		this.tempoRespostaPlanet = tempoRespostaPlanet;
	}
    
    public String getCodigoErro() {
		return codigoErro;
	}

	public void setCodigoErro(String codigoErro) {
		this.codigoErro = codigoErro;
	}

	public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getQuemResp() {
        return quemResp;
    }

    public void setQuemResp(String quemResp) {
        this.quemResp = quemResp;
    }

    public String getChaveMaquina() {
        return chaveMaquina;
    }

    public void setChaveMaquina(String chaveMaquina) {
        this.chaveMaquina = chaveMaquina;
    }

    public Long getQtdTransacoes() {
        return qtdTransacoes;
    }

    public void setQtdTransacoes(Long qtdTransacoes) {
        this.qtdTransacoes = qtdTransacoes;
    }

    public Long getTimestampTrans() {
        return timestampTrans;
    }

    public void setTimestampTrans(Long timestampTrans) {
        this.timestampTrans = timestampTrans;
        this.setDataHoraAut(new Date(timestampTrans));
    }

    public String getCodProdutoCompleto() {
        return codProdutoCompleto;
    }

    public Integer getCodSolCapt() {
        return codSolCapt;
    }

    public void setCodSolCapt(Integer codSolCapt) {
        this.codSolCapt = codSolCapt;
    }

    public void setCodProdutoCompleto(String codProdutoCompleto) {
        this.codProdutoCompleto = codProdutoCompleto;
    }

    public Integer getCodBandeira() {
        return codBandeira;
    }

    public void setCodBandeira(Integer codBandeira) {
        this.codBandeira = codBandeira;
    }

    public Integer getCodBanco() {
        return codBanco;
    }

    public void setCodBanco(Integer codBanco) {
        this.codBanco = codBanco;
    }

    public Integer getCodNoTelefonico() {
        return codNoTelefonico;
    }

    public void setCodNoTelefonico(Integer codNoTelefonico) {
        this.codNoTelefonico = codNoTelefonico;
    }

    public Date getDataHoraAut() {
        return dataHoraAut;
    }

    public void setDataHoraAut(Date dataHoraAut) {
        this.dataHoraAut = dataHoraAut;
    }

    public Integer getCodEntryMode() {
        return codEntryMode;
    }

    public String getTipoTransacao() {
        return codProdutoPay.contains(getCodProdutoCompleto()) ? "PAY" : "MAINFRAME";
    }

    public void setTipoTransacao(String tipoTransacao) {
        this.tipoTransacao = tipoTransacao;
    }

    public void setCodEntryMode(Integer codEntryMode) {
        this.codEntryMode = codEntryMode;
    }

    public Integer getCodRespAut() {
        return codRespAut;
    }

    public void setCodRespAut(Integer codRespAut) {
        this.codRespAut = codRespAut;
    }

    public Integer getCodVersaoSfw() {
        return codVersaoSfw;
    }

    public void setCodVersaoSfw(Integer codVersaoSfw) {
        this.codVersaoSfw = codVersaoSfw;
    }

    public Integer getCodRamoAtividade() {
        return codRamoAtividade;
    }

    public void setCodRamoAtividade(Integer codRamoAtividade) {
        this.codRamoAtividade = codRamoAtividade;
    }

    public String getSiglaUf() {
        return siglaUf;
    }

    public void setSiglaUf(String siglaUf) {
        this.siglaUf = siglaUf;
    }

    public Integer getValorSolicitacao() {
        return valorSolicitacao;
    }

    public void setValorSolicitacao(Integer valorSolicitacao) {
        this.valorSolicitacao = valorSolicitacao;
    }

    public Integer getQtdAprovadas() {
        return qtdAprovadas;
    }

    public void setQtdAprovadas(Integer qtdAprovadas) {
        this.qtdAprovadas = qtdAprovadas;
    }

    public Integer getQtdNegadas() {
        return qtdNegadas;
    }

    public void setQtdNegadas(Integer qtdNegadas) {
        this.qtdNegadas = qtdNegadas;
    }

    public Integer getQtdDesfazimentos() {
        return qtdDesfazimentos;
    }

    public void setQtdDesfazimentos(Integer qtdDesfazimentos) {
        this.qtdDesfazimentos = qtdDesfazimentos;
    }

    public Integer getQtdCanceladas() {
        return qtdCanceladas;
    }

    public void setQtdCanceladas(Integer qtdCanceladas) {
        this.qtdCanceladas = qtdCanceladas;
    }

    public Long getTempoTransacao() {
        return tempoTransacao;
    }

    public void setTempoTransacao(Long tempoTransacao) {
        this.tempoTransacao = tempoTransacao;
    }

    public String getTipoSkyline() {
        return tipoSkyline;
    }

    public void setTipoSkyline(String tp) {
        this.tipoSkyline = tp;
    }

    public void setStatusProcSkyline(String st) {
        this.tipoSkyline = st;
    }

    public String getIndicSkyline() {
        return TIPOS_ROTA_SKYLINE.contains(getTipoSkyline()) ? "S" : "N";
    }

    public Integer getCodSite() {
        return MAQ_RIO.contains(chaveMaquina) ? 2 : 1;
    }

    protected String getCodSubProduto() {
        // TODO Auto-generated method stub
        return codProdutoCompleto == null || codProdutoCompleto.length() < 8 ? null
                : codProdutoCompleto.substring(codProdutoCompleto.length() - 4);
    }

    public String getCodigoOperadoraGPRS() {
        return codigoOperadoraGPRS;
    }

    public void setCodigoOperadoraGPRS(String codigoOperadoraGPRS) {
        this.codigoOperadoraGPRS = codigoOperadoraGPRS;
    }

    public String getModoConexao() {
        return modoConexao;
    }

    public void setModoConexao(String modoConexao) {
        this.modoConexao = modoConexao;
    }
    
    public boolean getIndLynx() {
        return indLynx;
    }

    public void setIndLynx(boolean indLynx) {
        this.indLynx = indLynx;
    }
    
    public Integer getQtdTimeoutLynx() {
        return qtdTimeoutLynx;
    }

    public void setQtdTimeoutLynx(Integer qtdTimeoutLynx) {
        this.qtdTimeoutLynx = qtdTimeoutLynx;
    }

    public boolean getIndStandin() {
        return indStandin;
    }

    public void setIndStandin(boolean indStandin) {
        this.indStandin = indStandin;
    }    

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((codBanco == null) ? 0 : codBanco.hashCode());
        result = prime * result
                + ((codBandeira == null) ? 0 : codBandeira.hashCode());
        result = prime * result
                + ((codEntryMode == null) ? 0 : codEntryMode.hashCode());
        result = prime * result
                + ((codNoTelefonico == null) ? 0 : codNoTelefonico.hashCode());
        result = prime * result
                + ((codProdutoCompleto == null) ? 0 : codProdutoCompleto.hashCode());
        result = prime
                * result
                + ((codRamoAtividade == null) ? 0 : codRamoAtividade.hashCode());
        result = prime * result
                + ((codRespAut == null) ? 0 : codRespAut.hashCode());
        result = prime * result
                + ((codVersaoSfw == null) ? 0 : codVersaoSfw.hashCode());
        result = prime * result
                + ((dataHoraAut == null) ? 0 : dataHoraAut.hashCode());
        result = prime * result
                + ((horaMinAgrupado == null) ? 0 : horaMinAgrupado.hashCode());
        result = prime * result
                + ((tipoSkyline == null) ? 0 : tipoSkyline.hashCode());
        result = prime * result + ((siglaUf == null) ? 0 : siglaUf.hashCode());
        result = prime
                * result
                + ((valorSolicitacao == null) ? 0 : valorSolicitacao.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        TransacaoStarSchema other = (TransacaoStarSchema) obj;
        if (codBanco == null) {
            if (other.codBanco != null) {
                return false;
            }
        } else if (!codBanco.equals(other.codBanco)) {
            return false;
        }
        if (codBandeira == null) {
            if (other.codBandeira != null) {
                return false;
            }
        } else if (!codBandeira.equals(other.codBandeira)) {
            return false;
        }
        if (codEntryMode == null) {
            if (other.codEntryMode != null) {
                return false;
            }
        } else if (!codEntryMode.equals(other.codEntryMode)) {
            return false;
        }
        if (codNoTelefonico == null) {
            if (other.codNoTelefonico != null) {
                return false;
            }
        } else if (!codNoTelefonico.equals(other.codNoTelefonico)) {
            return false;
        }
        if (codProdutoCompleto == null) {
            if (other.codProdutoCompleto != null) {
                return false;
            }
        } else if (!codProdutoCompleto.equals(other.codProdutoCompleto)) {
            return false;
        }
        if (codRamoAtividade == null) {
            if (other.codRamoAtividade != null) {
                return false;
            }
        } else if (!codRamoAtividade.equals(other.codRamoAtividade)) {
            return false;
        }
        if (codRespAut == null) {
            if (other.codRespAut != null) {
                return false;
            }
        } else if (!codRespAut.equals(other.codRespAut)) {
            return false;
        }
        if (codVersaoSfw == null) {
            if (other.codVersaoSfw != null) {
                return false;
            }
        } else if (!codVersaoSfw.equals(other.codVersaoSfw)) {
            return false;
        }
        if (dataHoraAut == null) {
            if (other.dataHoraAut != null) {
                return false;
            }
        } else if (!dataHoraAut.equals(other.dataHoraAut)) {
            return false;
        }
        if (horaMinAgrupado == null) {
            if (other.horaMinAgrupado != null) {
                return false;
            }
        } else if (!horaMinAgrupado.equals(other.horaMinAgrupado)) {
            return false;
        }
        if (tipoSkyline == null) {
            if (other.tipoSkyline != null) {
                return false;
            }
        } else if (!tipoSkyline.equals(other.tipoSkyline)) {
            return false;
        }
        if (siglaUf == null) {
            if (other.siglaUf != null) {
                return false;
            }
        } else if (!siglaUf.equals(other.siglaUf)) {
            return false;
        }
        if (valorSolicitacao == null) {
            if (other.valorSolicitacao != null) {
                return false;
            }
        } else if (!valorSolicitacao.equals(other.valorSolicitacao)) {
            return false;
        }
        return true;
    }

    public String getDataHoraAgrupado() {
        return dataHoraAut == null ? null : DateUtils.getDateTimeGrouped(5, dataHoraAut, dtfHrMin);
    }

	@Override
	public String toString() {
		String saida = "TransacaoStarSchema [codProdutoCompleto=" + codProdutoCompleto
		+ ", codBandeira=" + codBandeira 
		+ ", codBanco=" + codBanco
		+ ", codNoTelefonico=" + codNoTelefonico 
		+ ", codSolCapt=" + codSolCapt 
		+ ", dataHoraAut=" + dataHoraAut
		+ ", codEntryMode=" + codEntryMode 
		+ ", codRespAut=" + codRespAut 
		+ ", codVersaoSfw=" + codVersaoSfw
		+ ", codRamoAtividade=" + codRamoAtividade 
		+ ", siglaUf=" + siglaUf 
		+ ", valorSolicitacao=" + valorSolicitacao
		+ ", qtdAprovadas=" + qtdAprovadas 
		+ ", qtdNegadas=" + qtdNegadas 
		+ ", qtdDesfazimentos=" + qtdDesfazimentos
		//+ ", qtdElegivel=" + qtdElegivel
	    //+ ", qtdNaoElegivel=" + qtdNaoElegivel
		//+ ", qtdNegadoPelaPlanet=" + qtdNegadoPelaPlanet
		//+ ", qtdTimeOutPlanet=" + qtdTimeOutPlanet
		//+ ", qtdCanceladas=" + qtdCanceladas 
		//+ ", idStatusDCC=" + idStatusDCC
		+ ", tipoSkyline=" + tipoSkyline 
		+ ", horaMinAgrupado=" + horaMinAgrupado
		+ ", timestampTrans=" + timestampTrans 
		+ ", tipoTransacao=" + tipoTransacao 
		+ ", qtdTransacoes=" + qtdTransacoes
		+ ", tempoTransacao=" + tempoTransacao 
		+ ", chaveMaquina=" + chaveMaquina 
		+ ", mensagem=" + mensagem 
		+ ", quemResp=" + quemResp 
		+ ", codigoOperadoraGPRS=" + codigoOperadoraGPRS
		+ ", modoConexao=" + modoConexao 
		+ ", indLynx=" + indLynx
		+ ", indStandin=" + indStandin 
		+ ", qtdTimeoutLynx=" + qtdTimeoutLynx
		+ "]";
		return saida;
	}	

}
