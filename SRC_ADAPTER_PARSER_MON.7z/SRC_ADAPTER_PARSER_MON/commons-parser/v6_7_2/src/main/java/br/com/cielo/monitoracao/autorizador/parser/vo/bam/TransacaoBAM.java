package br.com.cielo.monitoracao.autorizador.parser.vo.bam;

import java.io.Serializable;

public interface TransacaoBAM extends Serializable {

}
