/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.monitoracao.cep.stratus.eventos;

import br.com.cielo.monitoracao.DateUtils;
import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Conversor de Transacao Stratus de XML -> OBJ e OBJ -> XML
 *
 * @author nemer
 */
public class TransacaoStarSchemaConverter implements Converter {

    @Override
    public void marshal(Object o, HierarchicalStreamWriter writer, MarshallingContext mc) {
        TransacaoStarSchema t = (TransacaoStarSchema) o;
        writer.startNode("Transacao");
        writer.startNode("Mainframe");
        nvlNodeAndValue(writer, "CodProdutoCompleto", t.getCodProdutoCompleto());
        nvlNodeAndValue(writer, "CodSubProduto", t.getCodSubProduto());
        nvlNodeAndValue(writer, "ChaveMaquina", t.chaveMaquina);
        nvlNodeAndValue(writer, "CodBandeira", t.codBandeira);
        nvlNodeAndValue(writer, "CodBanco", t.codBanco);
        nvlNodeAndValue(writer, "CodNoTelefonico", t.codNoTelefonico);
        nvlNodeAndValue(writer, "CodSolCapt", t.codSolCapt);
        nvlNodeAndValue(writer, "DataHoraAut", DateUtils.printDateTimeForXML(t.getDataHoraAut(), TransacaoStarSchema.dtfDataHoraMinuto));
        nvlNodeAndValue(writer, "CodEntryMode", t.codEntryMode);
        nvlNodeAndValue(writer, "CodRespAut", t.codRespAut);
        nvlNodeAndValue(writer, "CodVersaoSfw", t.codVersaoSfw);
        nvlNodeAndValue(writer, "CodRamoAtividade", t.codRamoAtividade);
        nvlNodeAndValue(writer, "SiglaUf", t.siglaUf);
        nvlNodeAndValue(writer, "CodSite", t.getCodSite());
        nvlNodeAndValue(writer, "QtdAutorizacao", t.qtdTransacoes);
        nvlNodeAndValue(writer, "ValorSolicitacao", t.valorSolicitacao);
        nvlNodeAndValue(writer, "QtdAprovadas", t.qtdAprovadas);
        nvlNodeAndValue(writer, "QtdNegadas", t.qtdNegadas);
        nvlNodeAndValue(writer, "CodigoOperadoraGPRS", t.codigoOperadoraGPRS);
        nvlNodeAndValue(writer, "ModoConexao", t.modoConexao);
        nvlNodeAndValue(writer, "IndLynx", t.indLynx);
        nvlNodeAndValue(writer, "IndStandin", t.indStandin);
        nvlNodeAndValue(writer, "QtdTimeoutLynx", t.qtdTimeoutLynx);
        //nvlNodeAndValue(writer, "TempoMedioTranSeg", new BigDecimal(t.getTempoTransacao()).divide(t.milBigDecimal, 2, BigDecimal.ROUND_UP));
        nvlNodeAndValue(writer, "QtdDesfazimento", t.qtdDesfazimentos);
        nvlNodeAndValue(writer, "TipoTransacao", t.getTipoTransacao());
        nvlNodeAndValue(writer, "QtdCanceladas", t.qtdCanceladas);
        writer.endNode();

        /*
         * "<Transacao>" + "<Mainframe>"
         + nvlTag("CodProdutoCompleto", getCodProdutoCompleto())
         + nvlTag("CodSubProduto", getCodSubProduto())
         + nvlTag("ChaveMaquina", chaveMaquina)
         + nvlTag("CodBandeira", codBandeira)
         + nvlTag("CodBanco", codBanco)
         + nvlTag("CodNoTelefonico", codNoTelefonico)
         + nvlTag("CodSolCapt", codSolCapt)
         + nvlTag("DataHoraAut", sdfDataHoraMinuto.format(getDataHoraAut()) + ":59")
         + nvlTag("CodEntryMode", codEntryMode)
         + nvlTag("CodRespAut", codRespAut)
         + nvlTag("CodVersaoSfw", codVersaoSfw)
         + nvlTag("CodRamoAtividade", codRamoAtividade)
         + nvlTag("SiglaUf", siglaUf)
         + nvlTag("CodSite", getCodSite())
         + nvlTag("QtdAutorizacao", qtdTransacoes)
         + nvlTag("ValorSolicitacao", valorSolicitacao)
         + nvlTag("QtdAprovadas", qtdAprovadas)
         + nvlTag("QtdNegadas", qtdNegadas)
         + nvlTag("CodigoOperadoraGPRS", codigoOperadoraGPRS)
         + nvlTag("ModoConexao", modoConexao)
         + nvlTag("TempoMedioTranSeg", new BigDecimal(getTempoTransacao()).divide(milBigDecimal, 2, BigDecimal.ROUND_UP))
         + nvlTag("QtdDesfazimento", qtdDesfazimentos)
         + nvlTag("TipoTransacao", getTipoTransacao())
         + nvlTag("QtdCanceladas", qtdCanceladas)
         // so vai fazer sentido enviar mensagem e quemResp se for negada. Para as demais qtdade de estado, ignorar
         + (qtdNegadas == 0 ? "" : nvlTag("Mensagem", getMensagem())
         + nvlTag("QuemResp", getQuemResp()))
         + nvlTag("IndicSkyline", TIPOS_ROTA_SKYLINE.contains(getTipoSkyline()) ? "S" : "N")
         + nvlTag("TipoSkyline", getTipoSkyline())
         + nvlTag("HoraMinAgrupado", DateUtils.getDateTimeGrouped(5, dataHoraAut, sdfHrMin)) + "</Mainframe>"
         + "</Transacao>";
         */
    }

    private void nvlNodeAndValue(HierarchicalStreamWriter writer, String tag, Object value) {
        if (value != null) {
            writer.startNode(tag);
            writer.setValue(value.toString());
            writer.endNode();
        }
    }

    @Override
    public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext uc) {
        TransacaoStarSchema t = new TransacaoStarSchema();
        
        while (reader.hasMoreChildren()) {
            reader.moveDown();
            if (reader.getNodeName().equals("CodProdutoCompleto")) {
                t.setCodProdutoCompleto(reader.getValue());
            } else if (reader.getNodeName().equals("ChaveMaquina")) {
                t.setChaveMaquina(reader.getValue());
            } else if (reader.getNodeName().equals("CodBandeira")) {
                t.setCodBandeira(new Integer(reader.getValue()));
            } else if (reader.getNodeName().equals("CodBanco")) {
                t.setCodBanco(new Integer(reader.getValue()));
            } else if (reader.getNodeName().equals("CodNoTelefonico")) {
                t.setCodNoTelefonico(new Integer(reader.getValue()));
            } else if (reader.getNodeName().equals("CodSolCapt")) {
                t.setCodSolCapt(new Integer(reader.getValue()));
            } else if (reader.getNodeName().equals("DataHoraAut"))  {
                String dataHoraAutStr = reader.getValue();
                try {
                    t.setDataHoraAut(dataHoraAutStr == null ? null : TransacaoStarSchema.dtfDataHoraMinuto.parseDateTime(dataHoraAutStr).toDate());
                } catch (RuntimeException ex) {
                    Logger.getLogger(TransacaoStarSchemaConverter.class.getName()).log(Level.SEVERE, null, ex);
                    throw new IllegalArgumentException("Erro convertendo a data de autorizacao da transacao:[" + dataHoraAutStr + "]", ex);
                }
            } else if (reader.getNodeName().equals("CodEntryMode"))  {
                t.setCodEntryMode(getNvlInteger(reader.getValue()));
            } else if (reader.getNodeName().equals("CodRespAut"))  {
                t.setCodRespAut(getNvlInteger(reader.getValue()));
            } else if (reader.getNodeName().equals("CodVersaoSfw"))  {
                t.setCodVersaoSfw(getNvlInteger(reader.getValue()));
            } else if (reader.getNodeName().equals("CodRamoAtividade"))  {
                t.setCodRamoAtividade(getNvlInteger(reader.getValue()));
            } else if (reader.getNodeName().equals("SiglaUf"))  {
                t.setSiglaUf(reader.getValue());
            } else if (reader.getNodeName().equals("QtdAutorizacao"))  {
                t.setQtdTransacoes(getNvlLong(reader.getValue()));
            } else if (reader.getNodeName().equals("ValorSolicitacao"))  {
                t.setValorSolicitacao(getNvlInteger(reader.getValue()));
            } else if (reader.getNodeName().equals("QtdAprovadas"))  {
                t.setQtdAprovadas(getNvlInteger(reader.getValue()));
            } else if (reader.getNodeName().equals("QtdNegadas"))  {
                t.setQtdNegadas(getNvlInteger(reader.getValue()));
            } else if (reader.getNodeName().equals("CodigoOperadoraGPRS"))  {
                t.setCodigoOperadoraGPRS(reader.getValue());
            } else if (reader.getNodeName().equals("ModoConexao"))  {
                t.setModoConexao(reader.getValue());
            } else if (reader.getNodeName().equals("TempoMedioTranSeg"))  {
                t.setTempoTransacao(getNvlLong(reader.getValue()));
            } else if (reader.getNodeName().equals("QtdDesfazimento"))  {
                t.setQtdDesfazimentos(getNvlInteger(reader.getValue()));
            } else if (reader.getNodeName().equals("TipoTransacao"))  {
                t.setTipoTransacao(reader.getValue());
            } else if (reader.getNodeName().equals("QtdCanceladas"))  {
                t.setQtdCanceladas(getNvlInteger(reader.getValue()));
            } else if (reader.getNodeName().equals("Mensagem"))  {
                t.setMensagem(reader.getValue());
            } else if (reader.getNodeName().equals("QuemResp"))  {
                t.setQuemResp(reader.getValue());
            } else if (reader.getNodeName().equals("IndLynx"))  {
                t.setIndLynx(reader.getValue()== "S" ? true : false);
            } else if (reader.getNodeName().equals("IndStandin"))  {
                t.setIndStandin(reader.getValue()== "S" ? true : false);
            } else if (reader.getNodeName().equals("QtdTimeoutLynx"))  {
                t.setQtdTimeoutLynx(getNvlInteger(reader.getValue()));
            }
            reader.moveUp();
        }
        return t;
    }

    private Integer getNvlInteger(String value) {
        return value == null ? null : new Integer(value.replace(".",""));
    }

    private Long getNvlLong(String value) {
        return value == null ? null : new Long(value.replace(".",""));
    }

    @Override
    public boolean canConvert(Class type) {
        return type.isAssignableFrom(TransacaoStarSchema.class);
    }
}
