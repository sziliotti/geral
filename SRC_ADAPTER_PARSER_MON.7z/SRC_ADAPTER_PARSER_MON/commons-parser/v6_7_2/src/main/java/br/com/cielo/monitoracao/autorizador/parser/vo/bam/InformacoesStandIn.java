package br.com.cielo.monitoracao.autorizador.parser.vo.bam;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 *<B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * <br>
 * Objeto responsavel em armazenar as insformações das transações com STAND-IN, utilizadas na Monitoração de Negocio. 
 *	 
 *<DL><DT><B>Criada em:</B><DD>16/04/2014</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class InformacoesStandIn implements Serializable {
	private static final long serialVersionUID = 1L;	
	
	//Atributo responsavel em verificar se a transação do tipo StandIn, foi enviado ou não. Atributo "standInFlag" da Classe CPO_040.
	private boolean isEnviado;
	
	//Atributo responsavel em verificar se a transação do tipo StandIn, é do tipo emergencial ou não. Atributo "standInEmergencia" da Classe CPO_040.
	private boolean isEmergencial;
	
	//Atributo responsavel em verificar se a transação do tipo StandIn, foi programado ou não. Atributo "standInProgramado" da Classe CPO_040.
	private boolean isProgramado;

	//Atributo responsavel em verificar se a transação do tipo StandIn, ocorreu timeout ou não. Atributo "standInTimeOut" da Classe CPO_040.
	private boolean isTimeout;
		
	//Atributo responsavel em verificar se o motivo do timeout da transação do tipo StandIn, foi queda de link ou não. Atributo "standInQueda" da Classe CPO_040.
	private boolean isQuedaLink;
	
	
	/**
	 * Construtor padrão.
	 */
	public InformacoesStandIn() {	
	}	
	
	
	/**
	 * Retorna se a transação do tipo StandIn, já foi enviada ou não.
	 * <br><br>
	 * Campo Stratus: CPO-040 (ACTR-STAND-IN-FLAG).
	 * 
	 * @return the isEnviado
	 */
	public boolean isEnviado() {
		return isEnviado;
	}
	/**
	 * @param isEnviado the isEnviado to set
	 */
	public void setEnviado(boolean isEnviado) {
		this.isEnviado = isEnviado;
	}
	/**
	 * Define o valor da transação StandIn, e a mesma já foi enviada ou não.
	 * <br><br>
	 * Possiveis valores: 
	 *  	<DD>1 - sim
	 * 		<DD>0 - nao
	 * 
	 * @param isEnviado the isEnviado to set
	 */
	public void setEnviado(String isEnviado) {		
		this.isEnviado= ("1".equals(isEnviado) ? true: false);
	}

	/**
	 * Retorna se a transação do tipo StandIn, é do tipo emergencial ou não.
	 * <br><br>
	 * Campo Stratus: CPO-040 (ACTR-STAND-IN-EMERGENCIA).
	 * 
	 * @return the isEmergencial
	 */
	public boolean isEmergencial() {
		return isEmergencial;
	}
	/**
	 * @param isEmergencial the isEmergencial to set
	 */
	public void setEmergencial(boolean isEmergencial) {
		this.isEmergencial = isEmergencial;
	}
	/**
	 * Define o valor da transação StandIn, é do tipo emergencial ou não.
	 * <br><br>
	 * Possiveis valores: 
	 *  	<DD>S - sim
	 * 		<DD>N - nao
	 * 
	 * @param isEmergencial the isEmergencial to set
	 */
	public void setEmergencial(String isEmergencial) {
		this.isEmergencial = ("S".equals(isEmergencial.toUpperCase()) ? true: false);
	}

	/**
	 * Retorna se a transação do tipo StandIn, foi programado ou não.
	 * <br><br>
	 * Campo Stratus: CPO-040 (ACTR-STAND-IN-PROGRAMADO).
	 * 
	 * @return the isProgramado
	 */
	public boolean isProgramado() {
		return isProgramado;
	}
	/**
	 * @param isProgramado the isProgramado to set
	 */
	public void setProgramado(boolean isProgramado) {
		this.isProgramado = isProgramado;
	}
	/**
	 *  Define o valor da transação StandIn, foi programado ou não.
	 * <br><br>
	 * Possiveis valores: 
	 *  	<DD>S - sim
	 * 		<DD>N - nao
	 * 
	 * @param isProgramado the isProgramado to set
	 */
	public void setProgramado(String isProgramado) {
		this.isProgramado = ("S".equals(isProgramado.toUpperCase()) ? true: false);
	}

	/**
	 * Retorna se a transação do tipo StandIn, ocorreu timeout ou não.
	 * <br><br>
	 * Campo Stratus: CPO-040 (ACTR-STAND-IN-TIME-OUT).
	 * 
	 * @return the isTimeout
	 */
	public boolean isTimeout() {
		return isTimeout;
	}
	/**
	 * @param isTimeout the isTimeout to set
	 */
	public void setTimeout(boolean isTimeout) {
		this.isTimeout = isTimeout;
	}
	/**
	 * Define o valor da transação StandIn, ocorreu timeout ou não.
	 * <br><br>
	 * Possiveis valores: 
	 *  	<DD>S - sim
	 * 		<DD>N - nao
	 * 
	 * @param isTimeout the isTimeout to set
	 */
	public void setTimeout(String isTimeout) {
		this.isTimeout = ("S".equals(isTimeout.toUpperCase()) ? true: false);
	}

	/**
	 * Retorna se o motivo do timeout da transação do tipo StandIn, foi queda de link ou não.
	 * <br><br>
	 * Campo Stratus: CPO-040 (ACTR-STAND-IN-QUEDA).
	 * 
	 * @return the isQuedaLink
	 */
	public boolean isQuedaLink() {
		return isQuedaLink;
	}
	/**
	 * @param isQuedaLink the isQuedaLink to set
	 */
	public void setQuedaLink(boolean isQuedaLink) {
		this.isQuedaLink = isQuedaLink;
	}
	/**
	 * Define o valor do motivo do timeout da transação do tipo StandIn, foi queda de link ou não.
	 * <br><br>
	 * Possiveis valores: 
	 *  	<DD>S - sim
	 * 		<DD>N - nao
	 * 
	 * @param isQuedaLink the isQuedaLink to set
	 */
	public void setQuedaLink(String isQuedaLink) {
		this.isQuedaLink = ("S".equals(isQuedaLink.toUpperCase()) ? true: false);
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
