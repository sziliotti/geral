/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.monitoracao.cep.stratus.eventos;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;


/**
 * Conversor de Transacao Stratus de XML -> OBJ e OBJ -> XML
 *
 * @author nemer
 */
public class TransacaoMaqStratusTPSConverter implements Converter {

    private static final Logger LOGGER = Logger.getLogger(TransacaoMaqStratusTPSConverter.class.getName());
    private final DateTimeFormatter dtf = DateTimeFormat.forPattern("yyyy/MM/dd HH:mm:ss");

    @Override
    public void marshal(Object o, HierarchicalStreamWriter writer, MarshallingContext mc) {
        throw new UnsupportedOperationException("Metodo marshal nao implementado");
    }

    @Override
    public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext uc) {
        TransacaoMaqStratusMaxTPS t = new TransacaoMaqStratusMaxTPS();

        while (reader.hasMoreChildren()) {
            reader.moveDown();
            if (reader.getNodeName().equals("DataAut")) {
                try {
                    t.setTimestampTranYmDh(dtf.parseMillis(reader.getValue()));
                } catch (Exception ex) {
                    LOGGER.log(Level.SEVERE,"Mensagem vinda com data autorizacao invalida para transacao maquina stratus TPS:[" + reader.getValue()
                            + "]", ex);
                    return null;
                }
            } else if (reader.getNodeName().equals("TimestampPico")) {
                try {
                    t.setDataPicoTps(dtf.parseDateTime(reader.getValue()).toDate());
                } catch (Exception ex) {
                    LOGGER.log(Level.SEVERE,"Mensagem vinda com data pico invalida para transacao maquina stratus TPS:[" + reader.getValue()
                            + "]", ex);
                    return null;
                }
            } else if (reader.getNodeName().equals("ChaveMaquina")) {
                t.setChaveMaquina(reader.getValue());
            } else if (reader.getNodeName().equals("QtdTps")) {
                try {
                    t.setQtdTransacoes(new Long(reader.getValue()));
                } catch (Exception ex) {
                    LOGGER.log(Level.SEVERE,"Mensagem vinda com qtdTps invalido para transacao maquina stratus TPS:[" + reader.getValue()
                            + "]", ex);
                    return null;
                }
            } else if (reader.getNodeName().equals("QtdCredito")) {
                try {
                    t.setQtdCredito(new Long(reader.getValue()));
                } catch (Exception ex) {
                    LOGGER.log(Level.SEVERE,"Mensagem vinda com qtdCredito invalido para transacao maquina stratus TPS:[" + reader.getValue()
                            + "]", ex);
                    return null;
                }
            } else if (reader.getNodeName().equals("QtdDebito")) {
                try {
                    t.setQtdDebito(new Long(reader.getValue()));
                } catch (Exception ex) {
                    LOGGER.log(Level.SEVERE,"Mensagem vinda com qtdDebito invalido para qtdDebito maquina stratus TPS:[" + reader.getValue()
                            + "]", ex);
                    return null;
                }
            } else if (reader.getNodeName().equals("QtdPrivate")) {
                try {
                    t.setQtdPrivate(new Long(reader.getValue()));
                } catch (Exception ex) {
                    LOGGER.log(Level.SEVERE,"Mensagem vinda com qtdPrivate invalido para qtdprivate maquina stratus TPS:[" + reader.getValue()
                            + "]", ex);
                    return null;
                }
            }
            reader.moveUp();
        }
        return t;
    }

    @Override
    public boolean canConvert(Class type) {
        return type.isAssignableFrom(TransacaoMaqStratusMaxTPS.class);
    }
}
