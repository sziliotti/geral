package br.com.cielo.monitoracao.cep.eventos.ext;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import br.com.cielo.monitoracao.DateUtils;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.StatusTransacao;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.InformacoesLynx;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/** 
 *<B>Projeto: commons-parser</B><BR>
 *
 * Classe responsável pelo mapeamento do objeto de evento MonitoracaoTransacaoAutorizadorVO, a ser usado como entrada pelo Oracle CEP.
 *	 
 *<DL><DT><B>Criada em:</B><DD>26/03/2014</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class MonitoracaoTransacaoCEP extends MonitoracaoTransacaoAutorizadorVO{
        private static final Log logger = LogFactory
			.getLog(MonitoracaoTransacaoCEP.class);
	private Long timestampTransSemSegundo;
	private String tipoSkyline;
	private boolean indicadorByPassSkyline = false;
	
	private Long aprovado = 0L;
	private Long cancelado = 0L;
	private Long negado = 0L;
	private Long desfazimento = 0L;
	private int codigoSite;	

        private int timeoutLynx;

	
	public static final List<String> TIPOS_ROTA_SKYLINE = Arrays.asList(new String[]{"S","X","Y","W","Z","K"});
	
	/** 
	 * Enum contendo os possiveis valores da Rota da Transação.
	 */
	public enum IndicadorRotaTransacao {
		SKYLINE("S"), STRATUS("N"), BYPASS("F5-BP");
		String value;
		IndicadorRotaTransacao(String path) {
			value = path;
		}
		public String getValue() {
			return value;
		}
	}
	
	/**
	 * @return
	 */
	public boolean isByPassSkyline() {
		return indicadorByPassSkyline;
	}

	/**
	 * @param indicadorByPassSkyline
	 */
	public void setIndicadorByPassSkyline(boolean indicadorByPassSkyline) {
		this.indicadorByPassSkyline = indicadorByPassSkyline;
	}

	/**
	 * Retorna o estado do processamento skyline. Para isso, utiliza o indicadorSkyline que define se a transacao passou
	 * ou nao pelo Skyline e o indicadorByPassSkyline que indica se a transacao eh do skyline mas foi bypassada par ao stratus
	 * 
	 * @return 
	 * 		F5-BP se for bypass, S se for skyline e N se nao for skyline (entao eh stratus)
	 */
	public String getTipoSkyline(){	
		return tipoSkyline; 
	}
	
	/**
	 * 
	 * @param tp
	 */
	public void setTipoSkyline(String tp) {
		// normaliza o tipo do skyline se for bypass
		tipoSkyline = isByPassSkyline() ? IndicadorRotaTransacao.BYPASS.getValue() : tp;
	}

	/**
	 * Método responsável em retornar o código do site(formato numerico), conforme código da máquina vinda na transação.
	 * 
	 * @return
	 */
	public Integer getCodigoSite() {
		if (codigoSite == 0) {
			if (getChaveMaquina().equals("MA")) {
				codigoSite = 1; // SP
			} else if (getChaveMaquina().equals("MB")) {
				codigoSite = 1; // SP
			} else {
				codigoSite = 2; // RJ
			}
		}
		return codigoSite;
	}
	
	/**
	 * Método que recupera e retorna o timestamp da transação sem os segundos.
	 * 
	 * @return 
	 * 			Timestamp da transação sem os segundos.
	 */
	public Long getTimestampTransSemSegundo() {
		if (timestampTransSemSegundo == null) {
			try {
				timestampTransSemSegundo = DateUtils.getDateTimeHourMinute(getDataHoraStratus()).getTime();
			} catch (NullPointerException ex) {
				throw new IllegalArgumentException(
						"Data/Hora Stratus esta vindo nula", ex);
			} catch (Exception ex) {
				throw new IllegalArgumentException(
						"Data/Hora Stratus esta vindo invalida:["
								+ getDataHoraMinutoStr() + "]", ex);
			}
		}
		return timestampTransSemSegundo;
	}
	
	/**
	 * @param timestampTransSemSegundo
	 */
	public void setTimestampTransSemSegundo(Long timestampTransSemSegundo) {
		// faz nada pois a este atributo eh obtido automaticamente a partir da data/hora stratus
		return;
	}

	/* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO#getDataHoraStratus()
	 */
	@Override
	public Date getDataHoraStratus() {
		if (super.getDataHoraStratus() == null) {
			logger.error("Transacao (uuid:"+getUuidMessageAdapter()+") veio com DataHoraStratus nula. Ajustando para data/hora corrente");
			setDataHoraStratus(new Date());
		} else if (super.getDataHoraStratus().getTime() > (System.currentTimeMillis()+300000 /* 5 min */)) {
			logger.error("Transacao (uuid:"+getUuidMessageAdapter()+") veio com data futura ("+super.getDataHoraStratus()+"). Ajustando para data/hora corrente ");
			Date now = new Date();
			setDataHoraStratus(now);
		} else if (super.getDataHoraStratus().getTime() + 86400000 /* 1 dia */ < System.currentTimeMillis()) {
			//System.out.println("Data/Hora stratus veio muito passada:["+super.getDataHoraStratus()+"] ajustando para agora.");
                        logger.error("Transacao (uuid:"+getUuidMessageAdapter()+") veio com data muito passada ("+super.getDataHoraStratus()+"). Ajustando para data/hora corrente ");
			Date now = new Date();
			setDataHoraStratus(now);
		}
		return super.getDataHoraStratus();
	}
	
	/**
	 * Método que retorna o tempo de execução da transação, calculado entra a hora de entrada e hora de saida do autorizador.
	 * 
	 * @return
	 * 			Tempo de execução da transação em milisegundos.
	 */
	public Long getTempoTransacao() {
		return (getHoraOutput() == null || getHoraInput() == null) ? null
				: getHoraOutput().getTime() - getHoraInput().getTime();
	}
	

	/**
	 * @return
	 */
	public Long getAprovado() {
		return aprovado;
	}

	/**
	 * @param aprovado
	 */
	public void setAprovado(Long aprovado) {
		this.aprovado = aprovado;
	}

	/**
	 * @return
	 */
	public Long getCancelado() {
		return cancelado;
	}

	/**
	 * @param cancelado
	 */
	public void setCancelado(Long cancelado) {
		this.cancelado = cancelado;
	}

	/**
	 * @return
	 */
	public Long getNegado() {
		return negado;
	}

	/**
	 * @param negado
	 */
	public void setNegado(Long negado) {
		this.negado = negado;
	}

	/**
	 * @return
	 */
	public Long getDesfazimento() {
		return desfazimento;
	}

	/**
	 * @param desfazimento
	 */
	public void setDesfazimento(Long desfazimento) {
		this.desfazimento = desfazimento;
	}

	/* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO#setIdStatus(br.com.cielo.monitoracao.autorizador.parser.vo.bam.StatusTransacao)
	 */
	@Override
	public void setIdStatus(StatusTransacao idStatus) {
		super.setIdStatus(idStatus);
		
		if (getIdStatus() == null)
			return;

		switch (getIdStatus().getValue()) {
		case 0:
			this.cancelado = 1L;
			break;
		case 1:
			this.desfazimento = 1L;
			break;
		case 2:
			this.aprovado = 1L;
			break;
		case 3:
			this.negado = 1L;
			break;
		}
	}
	
	/**
	 * Método que retorna o valor do Status(em formato numerico) da transação.
	 * 
	 * @return
	 * 		O valor do status da transação, em valor numérico.
	 */
	public int getStatusValue() {
		return getIdStatus().getValue();
	}
        
	/* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO#setIdStatus(br.com.cielo.monitoracao.autorizador.parser.vo.bam.StatusTransacao)
	 */
	@Override
	public void setInformacoesLynx(InformacoesLynx informacoesLynx) {
		super.setInformacoesLynx(informacoesLynx);
		
		if (getInformacoesLynx() == null)
			return;

		if (getInformacoesLynx().isTimeout() == true ){ 
			timeoutLynx = 1;
		} else {
			timeoutLynx = 0;
		}	

	}
	
	/**
	 * @return timeoutLynx
	 */
	public int getTimeoutLynx() {
		return timeoutLynx;
	}

	/**
	 * @param timeoutLynx
	 */
	public void setTimeoutLynx(int timeoutLynx) {
		this.timeoutLynx = timeoutLynx;
	}		
	
	/**
	 * Método que recupera e retorna o timestamp da transação, agrupado em Ano-Mes-Dia-Hora-Minuto.
	 * 
	 * @return
	 * 		Timestamp da transação, agrupado em Ano-Mes-Dia-Hora-Minuto.
	 */
	public Long getTimestampTranYmDhMAgrupado() {
		try {
			return DateUtils.getDateTimeGrouped(5, getDataHoraStratus());
		} catch (Throwable ex) {
			ex.printStackTrace();
			throw new RuntimeException(ex);
		}
	}
	
	
	/* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO#toString()
	 */
	public String toString(){
                // Inclusao de informacoes do Bit47 para GPRS e DIAL
                List<String> TP_TEC_BIT47 = Arrays.asList(new String[]{"01", "02", "03", "04", "14", "23"});
                String bit = "";
                if (TP_TEC_BIT47.contains(getTipoTecnologia())) {
                    if(getInformacoesBIT47()!=null ){
                        bit = getModeloTerminal()+";"+getVersaoAplicativo()+";"+getReleaseEspecificacao()
                             +";"+getCep()+";"+getCodigoCompleteLocalidade()
                             +";"+getInformacoesBIT47();
                    }
                }               
		String result = getNSU()+";"+getChaveMaquina()+";"+getBin()+";"+getCodigoProcessamento()+";"+getHoraInput()+";"+getIdStatus()+";"
		                +getHoraOutput()+";"+getResolutor()+";"+getSourceCode()+";"+getMensagem()+";"+getTerminal()+";"
		                +getIdMensagem()+";"+getValorVenda()+";"+getTipoTecnologia()+";"+getCodigoEstabelecimento()+";"
		                +getCodigoNo()+";"+getMcc()+";"+getUf()+";"+getCidade()+";"+getObservacao()+";"+getDadosVersaoTerminal()+";"
		                +";"+getBandeira()+";"+getBanco()+";"
		                +getProduto()+";"+getSubProduto()+";"+getTipTra()+";"+getCiersMonitoracao()+";"+isSwitchVisa()
		                +";"+getDataHoraMinutoStr()+";"+isIndicadorSkyLine()+";"+getModoConexao()+";"
		                +getCodigoErro()+";"+getQuemRespondeu()+";"+getDataHoraStratus()+";"+getDataHoraEntradaStratusSaidaPOS()+";"
		                +getDataHoraRetornoAoPOS()+";"+getDataHoraSaidaStratusEntradaBandeira()+";"+getDataHoraRetornoBandeira()+";"
		                +getDataHoraSaidaStratusEntradaHSM()+";"+getDataHoraRetornoHSM()+";"+getCodigoOperadoraGPRS()+";"+getCodigoServicoPOS()
		                +";"+getVersaoEcommerce()+";"+isDCC()+";"
		                +(getInformacoesDCC()!=null?getInformacoesDCC().getTipoTransacao():"null")+";"
		                +(getInformacoesDCC()!=null?getInformacoesDCC().getStatusDCC():"null")
                                +";"+isLynx()+";"+isStandIn()+";"+getTimeoutLynx()+";"
                                +bit;
		return result;
	}
}
