package br.com.cielo.monitoracao.cep.stratus.eventos;

/** 
*<B>Projeto: MonitoracaoTransacaoDCC</B><BR>
*
* Classe com as informações de uma transação DCC.
*	 
*<DL><DT><B>Criada em:</B><DD>23/04/2014</DD></DL>
*
* @author Ari Vieira.
* @version 1.0
*
*/
public class TransacaoDCCStarSchema extends TransacaoStarSchema{

    // campos da transação DCC
    protected Integer qtdElegivel;
    protected Integer qtdNaoElegivel;
    protected Integer qtdNegadoPelaPlanet;
    protected Integer qtdTimeOutPlanet;
    protected Integer idStatusDCC;
    protected Boolean isDCC;
    
    /**
	 * @return the qtdElegivel
	 */
	public Integer getQtdElegivel() {
		return qtdElegivel;
	}

	/**
	 * @param qtdElegivel the qtdElegivel to set
	 */
	public void setQtdElegivel(Integer qtdElegivel) {
		this.qtdElegivel = qtdElegivel;
	}

	/**
	 * @return the qtdNaoElegivel
	 */
	public Integer getQtdNaoElegivel() {
		return qtdNaoElegivel;
	}

	/**
	 * @param qtdNaoElegivel the qtdNaoElegivel to set
	 */
	public void setQtdNaoElegivel(Integer qtdNaoElegivel) {
		this.qtdNaoElegivel = qtdNaoElegivel;
	}

	/**
	 * @return the qtdNegadoPelaPlanet
	 */
	public Integer getQtdNegadoPelaPlanet() {
		return qtdNegadoPelaPlanet;
	}

	/**
	 * @param qtdNegadoPelaPlanet the qtdNegadoPelaPlanet to set
	 */
	public void setQtdNegadoPelaPlanet(Integer qtdNegadoPelaPlanet) {
		this.qtdNegadoPelaPlanet = qtdNegadoPelaPlanet;
	}

	/**
	 * @return the qtdTimeOutPlanet
	 */
	public Integer getQtdTimeOutPlanet() {
		return qtdTimeOutPlanet;
	}

	/**
	 * @param qtdTimeOutPlanet the qtdTimeOutPlanet to set
	 */
	public void setQtdTimeOutPlanet(Integer qtdTimeOutPlanet) {
		this.qtdTimeOutPlanet = qtdTimeOutPlanet;
	}

	/**
	 * @return the idStatusDCC
	 */
	public Integer getIdStatusDCC() {
		return idStatusDCC;
	}

	/**
	 * @param idStatusDCC the idStatusDCC to set
	 */
	public void setIdStatusDCC(Integer idStatusDCC) {
		this.idStatusDCC = idStatusDCC;
	}

	/**
	 * @return the isDCC
	 */
	public Boolean getIsDCC() {
		return isDCC;
	}

	/**
	 * @param isDCC the isDCC to set
	 */
	public void setIsDCC(Boolean isDCC) {
		this.isDCC = isDCC;
	}

	/* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.cep.stratus.eventos.TransacaoStarSchema#toString()
	 */
	@Override
	public String toString() {
		return "TransacaoStarSchema [codProdutoCompleto=" + codProdutoCompleto
				+ ", codBandeira=" + codBandeira 
				+ ", codBanco=" + codBanco
				+ ", codNoTelefonico=" + codNoTelefonico 
				+ ", codSolCapt=" + codSolCapt 
				+ ", dataHoraAut=" + dataHoraAut
				+ ", codEntryMode=" + codEntryMode 
				+ ", codRespAut=" + codRespAut 
				+ ", codVersaoSfw=" + codVersaoSfw
				+ ", codRamoAtividade=" + codRamoAtividade 
				+ ", siglaUf=" + siglaUf 
				+ ", valorSolicitacao=" + valorSolicitacao
				+ ", qtdAprovadas=" + qtdAprovadas 
				+ ", qtdNegadas=" + qtdNegadas 
				+ ", qtdDesfazimentos=" + qtdDesfazimentos
				+ ", qtdElegivel=" + qtdElegivel
				+ ", qtdNaoElegivel=" + qtdNaoElegivel
				+ ", qtdNegadoPelaPlanet=" + qtdNegadoPelaPlanet
				+ ", qtdTimeOutPlanet=" + qtdTimeOutPlanet
				+ ", qtdCanceladas=" + qtdCanceladas
				+ ", idStatusDCC=" + idStatusDCC
				+ ", tipoSkyline=" + tipoSkyline
				+ ", horaMinAgrupado=" + horaMinAgrupado
				+ ", timestampTrans=" + timestampTrans
				+ ", tipoTransacao=" + tipoTransacao
				+ ", qtdTransacoes=" + qtdTransacoes
				+ ", tempoTransacao=" + tempoTransacao
				+ ", chaveMaquina=" + chaveMaquina
				+ ", mensagem=" + mensagem
				+ ", quemResp=" + quemResp
				+ ", codigoOperadoraGPRS=" + codigoOperadoraGPRS
				+ ", modoConexao=" + modoConexao + "]";
	}


}
