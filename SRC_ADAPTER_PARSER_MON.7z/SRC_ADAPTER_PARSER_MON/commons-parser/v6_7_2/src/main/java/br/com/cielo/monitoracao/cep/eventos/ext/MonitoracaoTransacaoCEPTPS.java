package br.com.cielo.monitoracao.cep.eventos.ext;

import br.com.cielo.monitoracao.autorizador.parser.vo.bam.StatusTransacao;
import java.util.Date;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 *
 * @author fernando.moraes
 * @version $Id: MonitoracaoTransacaoCEPTPS.java 1955 2017-08-07 11:53:35Z fernando.moraes $
 */
public class MonitoracaoTransacaoCEPTPS {

    //Atributo "dataHoraHost" da Classe CPO_001. Data e hora do sistema operacional de quando a transacao entrou no Stratus.
    private Date dataHoraStratus;
    //Atributo que define o status da transacao
    private StatusTransacao idStatus;
    //Atributo com o valor do codigo da Localidade.
    private String codigoLocalidade;
    //Atributo "bancoEmissor" da Classe CPO_040.
    private String banco;
    //Atributo "bandeira" da Classe CPO_040.
    private String bandeira;
    //Atributo com o valor da forma de pagamento.
    private String formaPagamento;
    //Atributo "maquina" da Classe CPO_001. 
    private String chaveMaquina;
    //Atributo "codigoResposta" da Classe CPO_027.
    private String codigoErro;
    //Atributo "quemRespondeu" da Classe CPO_027.
    private String quemRespondeu;
    //Atributo com o valor do codigo do Grupo EC.    
    private String codGrupoEC;
    //Atributo "uf" da Classe CPO_012.
    private String uf;
    //Atributo "monTecnologia" da Classe CPO_040.
    private String tipoTecnologia;
    //Atributo "modoEntrada" da Classe CPO_032. Item ZZ.
    private String modoConexao;
    //Atributo "codigoOperadora" da Classe CPO_047.
    private String codigoOperadoraGPRS;
    //Atributo com o valor do nome da operadora.
    private String nomeOperadoraGPRS;
    private String tipoSolucaoCapturaModoEntrada;
    private String codMultivan;

    private Long aprovado = 0L;
    private Long cancelado = 0L;
    private Long negado = 0L;
    private Long desfazimento = 0L;

    public String getCodMultivan() {
        return codMultivan;
    }

    public void setCodMultivan(String codMultivan) {
        this.codMultivan = codMultivan;
    }

    
    
    public Date getDataHoraStratus() {
        return dataHoraStratus;
    }

    public void setDataHoraStratus(Date dataHoraStratus) {
        this.dataHoraStratus = dataHoraStratus;
    }

    public StatusTransacao getIdStatus() {
        return idStatus;
    }

    public void setIdStatus(StatusTransacao idStatus) {
        this.idStatus = idStatus;
        if (idStatus == null) {
            return;
        }
        switch (idStatus.getValue()) {
            case 0:
                this.cancelado = 1L;
                break;
            case 1:
                this.desfazimento = 1L;
                break;
            case 2:
                this.aprovado = 1L;
                break;
            case 3:
                this.negado = 1L;
                break;
        }
    }

    public String getCodigoLocalidade() {
        return codigoLocalidade;
    }

    public void setCodigoLocalidade(String codigoLocalidade) {
        this.codigoLocalidade = codigoLocalidade;
    }

    public String getBanco() {
        return banco;
    }

    public void setBanco(String banco) {
        this.banco = banco;
    }

    public String getBandeira() {
        return bandeira;
    }

    public void setBandeira(String bandeira) {
        this.bandeira = bandeira;
    }

    /**
     * @return 
     * @see MonitoracaoTransacaoCEP#getFormaPagamento() 
     */
    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public String getChaveMaquina() {
        return chaveMaquina;
    }

    public void setChaveMaquina(String chaveMaquina) {
        this.chaveMaquina = chaveMaquina;
    }

    public String getCodigoErro() {
        return codigoErro;
    }

    public void setCodigoErro(String codigoErro) {
        this.codigoErro = codigoErro;
    }

    public String getQuemRespondeu() {
        return quemRespondeu;
    }

    public void setQuemRespondeu(String quemRespondeu) {
        this.quemRespondeu = quemRespondeu;
    }

    /**
     * 
     * @return 
     * @see MonitoracaoTransacaoCEP#getCodGrupoEC() 
     */
    public String getCodGrupoEC() {
        return codGrupoEC;
    }

    public void setCodGrupoEC(String codGrupoEC) {
        this.codGrupoEC = codGrupoEC;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    /**
     * 
     * @return 
     * @see MonitoracaoTransacaoCEP#getTipoTecnologia() 
     */
    public String getTipoTecnologia() {
        return tipoTecnologia;
    }

    public void setTipoTecnologia(String tipoTecnologia) {
        this.tipoTecnologia = tipoTecnologia;
    }

    /**
     * 
     * @return 
     * @see MonitoracaoTransacaoCEP#getModoConexao() 
     */
    public String getModoConexao() {
        return modoConexao;
    }

    public void setModoConexao(String modoConexao) {
        this.modoConexao = modoConexao;
    }

    /**
     * 
     * @return 
     * @see MonitoracaoTransacaoCEP#getCodigoOperadoraGPRS() 
     */
    public String getCodigoOperadoraGPRS() {
        return codigoOperadoraGPRS;
    }

    public void setCodigoOperadoraGPRS(String codigoOperadoraGPRS) {
        this.codigoOperadoraGPRS = codigoOperadoraGPRS;
    }

    /**
     * 
     * @return 
     * @see MonitoracaoTransacaoCEP#getNomeOperadoraGPRS() 
     */
    public String getNomeOperadoraGPRS() {
        return nomeOperadoraGPRS;
    }

    public void setNomeOperadoraGPRS(String nomeOperadoraGPRS) {
        this.nomeOperadoraGPRS = nomeOperadoraGPRS;
    }

    /**
     * 
     * @return 
     * @see MonitoracaoTransacaoCEP#getTipoSolucaoCapturaModoEntrada() 
     */
    public String getTipoSolucaoCapturaModoEntrada() {
        return tipoSolucaoCapturaModoEntrada;
    }

    public void setTipoSolucaoCapturaModoEntrada(String tipoSolucaoCapturaModoEntrada) {
        this.tipoSolucaoCapturaModoEntrada = tipoSolucaoCapturaModoEntrada;
    }

    public Long getAprovado() {
        return aprovado;
    }

    public void setAprovado(Long aprovado) {
        this.aprovado = aprovado;
    }

    public Long getCancelado() {
        return cancelado;
    }

    public void setCancelado(Long cancelado) {
        this.cancelado = cancelado;
    }

    public Long getNegado() {
        return negado;
    }

    public void setNegado(Long negado) {
        this.negado = negado;
    }

    public Long getDesfazimento() {
        return desfazimento;
    }

    public void setDesfazimento(Long desfazimento) {
        this.desfazimento = desfazimento;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.DEFAULT_STYLE);
    }
}
