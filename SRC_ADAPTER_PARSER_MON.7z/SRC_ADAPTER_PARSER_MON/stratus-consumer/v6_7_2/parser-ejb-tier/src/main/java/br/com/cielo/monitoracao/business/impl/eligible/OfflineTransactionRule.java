/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.monitoracao.business.impl.eligible;

import br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO;
import br.com.cielo.monitoracao.business.MatchRule;

/**
 * Regra que define se uma transação é um resultado offline (Normalmente uma aprovação que é forçada, ou após um timeout do terminal) ou não.
 * Para a monitoração ela é ignorada, mas para o propagador, deve continuar.
 * @author nemer
 */
public class OfflineTransactionRule implements MatchRule<MonitoracaoTransacaoAutorizadorVO>{

    @Override
    public boolean match(MonitoracaoTransacaoAutorizadorVO transaction) {
            	
    	// REGRA 2: Transações do tipo Off line(1204 e 1104); Confirmação de transações na plataforma 2000-01 (Cod: 0202); 
    	// ou Resposta de sonda na plataforma 20000-01 (Cod: 0610)
    	return "1204".equals(transaction.getTransacaoPOS()) || "1104".equals(transaction.getTransacaoPOS()); 
    		
    }
    
}
