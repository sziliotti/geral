package br.com.cielo.monitoracao.business;

import br.com.cielo.monitoracao.autorizador.parser.vo.bam.TransacaoBAM;

public interface BusinessValidatorChain {
	
	public void doValidation(TransacaoBAM transacao);

}
