/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.monitoracao.business.impl;

import br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO;
import br.com.cielo.monitoracao.business.TransformationRule;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author nemer
 */
public class LioComboTransformationRule extends TransformationRule<LioComboMatchRule, MonitoracaoTransacaoAutorizadorVO> {
    private static final List<String> NOS_LOGICOS_COMBO_WIFI = Arrays.asList(new String[]{"WIFIC","WIFIO","WIFIT","WIFIV"});
    private static final String SOL_CAPT_COMBO_WIFI="102";
    private static final String SOL_CAPT_COMBO_3G_CLARO="103";
    private static final String SOL_CAPT_COMBO_3G_VIVO="104";
    private static final String SOL_CAPT_COMBO_3G_TIM="105";
    private static final String SOL_CAPT_COMBO_3G_OI="106";
    private static final String SOL_CAPT_COMBO_3G_INDEFINIDO="107";
    private static final String SOL_CAPT_LIO="108";
    
    public LioComboTransformationRule(LioComboMatchRule matchInstance) {
        super(matchInstance);
    }

    @Override
    protected MonitoracaoTransacaoAutorizadorVO transform(MonitoracaoTransacaoAutorizadorVO transaction) {
        switch (getMatchRule().getType()) {
            case COMBO:
                if ((Integer.valueOf(transaction.getModoConexao()) == 1) && NOS_LOGICOS_COMBO_WIFI.contains(transaction.getCodigoNo())) {
                    transaction.setTipoTecnologia(SOL_CAPT_COMBO_WIFI);
                } else if (Integer.valueOf(transaction.getModoConexao()) == 71)  {
                    switch(transaction.getCodigoNo()) {
                        case "CLASC" :
                            transaction.setTipoTecnologia(SOL_CAPT_COMBO_3G_CLARO);
                            break;
                        case "VIV32":
                            transaction.setTipoTecnologia(SOL_CAPT_COMBO_3G_VIVO);
                            break;
                        case "TIM32":
                            transaction.setTipoTecnologia(SOL_CAPT_COMBO_3G_TIM);
                            break;    
                        case "OIV32":
                            transaction.setTipoTecnologia(SOL_CAPT_COMBO_3G_OI);
                            break;    
                        default:
                            transaction.setTipoTecnologia(SOL_CAPT_COMBO_3G_INDEFINIDO);
                    }   
                } 
                break;
            case LIO:
                // Lio é resolvido via modo conexao e operadora, diferente de COMBO que precisa verificar o no logico. Assim a tabela de thresholds deve resolver.
                transaction.setTipoTecnologia(SOL_CAPT_LIO);
                break;
            default:
                throw new IllegalStateException("Erro inesperado: para chegar a transformacao LIO ou COMBO, a MatchRule deve retornar LIO ou COMBO");
        }
        return transaction;
        
    }
    
}
