package br.com.cielo.monitoracao.stratus;

import javax.ejb.Singleton;
import javax.ejb.Startup;

import br.com.cielo.monitoracao.jmx.AbstractMessageStatistics;
import br.com.cielo.monitoracao.jmx.MessageStatisticsMXBean;

/**
 * Implementacao de MXBean de Monitoramento JMX.
 * @author fernando.moraes
 * @version $Id: ConsumidorTransacoesStratusMessageStatisticsLocal.java 2098 2017-09-18 22:13:27Z isaac.silva $
 */
@Startup
@Singleton(name = "consumidorTransacoesStratusMessageStatistics")
public class ConsumidorTransacoesStratusMessageStatisticsLocal extends AbstractMessageStatistics implements MessageStatisticsMXBean {

    @Override
    public String getBeanName() {
        return ConsumidorTransacoesStratusMDBLocal.class.getSimpleName();
    }
}
