/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.monitoracao.stratus;

import br.com.cielo.dispatcher.model.CanonicalTransactionVO;
import br.com.cielo.dispatcher.model.TransactionStatus;
import br.com.cielo.dispatcher.model.TransactionType;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.StatusTransacao;
import br.com.cielo.monitoracao.business.MatchRule;
import br.com.cielo.monitoracao.business.impl.eligible.OfflineTransactionRule;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 * Classe Helper para montar o objeto canônico do Propagador com transacao
 * origem do Stratus (ACTR)
 *
 * @author nemer
 */
public class DispatcherHelper {

    private static final DateTimeFormatter formatter = DateTimeFormat.forPattern("ddMMyyyyHHmmssSSS").withZoneUTC();
    private static final DateTimeFormatter formatterDateHourPOS = DateTimeFormat.forPattern("ddMMyyyyHHmmss");
    private static final Logger LOGGER = Logger.getLogger(DispatcherHelper.class.getName());
    private static final char CARD_CHIP_FEATURED = 'C';
    private static final MatchRule offlineMatchRule = new OfflineTransactionRule();
    private static ObjectMapper mapper = new ObjectMapper();

    public static CanonicalTransactionVO translateToCanonicalTransaction(MonitoracaoTransacaoAutorizadorVO dto) {

        CanonicalTransactionVO vo = new CanonicalTransactionVO();
        vo.setAuthorizationCode(dto.getCodigoAutorizacao());
        vo.setCardNumber(dto.getNumCartaoMascarado());
        if (dto.getDataHoraStratus() != null) {
            try {
                vo.setDateHourGmt0(formatter.print(dto.getDataHoraStratus().getTime()));
            } catch (Exception ex) {
                LOGGER.log(Level.SEVERE, "Erro realizando parser de data do stratus:", ex);
            }
        }
        vo.setInstallments(dto.getQuantidadeParcelas());
        vo.setTransactionType(dto.isRecorrente() ? TransactionType.RECURRING : dto.getQuantidadeParcelas() <= 1 ? TransactionType.SINGLE : TransactionType.INSTALLMENT);
        vo.setIssuerCode(dto.getBanco());
        vo.setNsu(dto.getNSU());
        vo.setProductCode(dto.getProdutoCompleto());
        vo.setSaleAmount(String.valueOf(dto.getValorVenda()));

        vo.setStatus(translateStratusStatus(dto.getIdStatus()));
        // ajustar a terceira perna
        if (dto.getFormaDeEntrada() != null && CARD_CHIP_FEATURED == dto.getFormaDeEntrada() && TransactionStatus.APPROVED == vo.getStatus()) {
            // Cartao CHIP nunca é definitivamente aprovado para uma liquidação pelo Autorizador. A confirmação precisa vir do POS
            // alterar o Status para Pendente de aprovação
            vo.setStatus(TransactionStatus.PENDING);
        }

        // ajusta o NSU autorizado confirmado pelo POS 
        vo.setNsuPOSConfirmation(dto.getNsuConfirmacaoAutorizacaoPOS());
        vo.setTID(""); // Stratus nao tem TID
        vo.setAssociationId(dto.getBandeira());
        vo.setTerminalId(dto.getTerminal());
        vo.setMerchantId(dto.getCodigoEstabelecimento());
        if (dto.getDataHoraInputTerminal() != null) {
            vo.setDateHourPOS(formatterDateHourPOS.print(dto.getDataHoraInputTerminal().getTime()));
        }
        if (dto.getDataHoraEntradaStratusSaidaPOS() != null) {
            DateTime dateTimeAuthIn = new DateTime(dto.getDataHoraEntradaStratusSaidaPOS().getTime(), DateTimeZone.UTC);
            vo.setDateHourGmt0(formatter.print(dateTimeAuthIn));
        }
        if (TransactionStatus.CANCELED.equals(vo.getStatus())) {
            // quando a transação for de cancelamento, existe o NSU referido da transacao de aprovação a qual foi cancelada.
            vo.setNsuAuthorization(dto.getNsuCanRef());
            // também ajustar o valor de cancelamento no lugar do valor da venda.
            vo.setSaleAmount(String.valueOf(dto.getValorCancelamento()));
        }
        // ajusta o numero celular para envio SMS
        vo.setSmsPhoneNumber(dto.getNumeroCelularSms());
        vo.setCaptureSolutionId(dto.getTipoTecnologia()!=null ? ""+dto.getTipoTecnologia(): null);
        // verifica, no final, se a transação é offline. Caso seja, ajusta o NSU da mesma para p NSU de sua confirmação de aprovação
        if (offlineMatchRule.match(dto) && vo.getNsuPOSConfirmation() != null) {
            vo.setNsu(vo.getNsuPOSConfirmation());
        }
        //LOGGER.log(Level.SEVERE, ToStringBuilder.reflectionToString(vo));
        return vo;
    }

    private static TransactionStatus translateStratusStatus(StatusTransacao status) {
        switch (status) {
            case APROVADO:
                return TransactionStatus.APPROVED;
            case CANCELAMENTO:
                return TransactionStatus.CANCELED;
            case CAPTURADO:
                return TransactionStatus.CAPTURED;
            case DESFAZIMENTO:
                return TransactionStatus.UNDONE;
            case INDEFINIDO:
                return TransactionStatus.UNDEFINED;
            case NEGADO:
                return TransactionStatus.DENIED;
            default:
                return TransactionStatus.UNDEFINED;

        }
    }

    public static String canonicalTransactionToJSon(CanonicalTransactionVO dto) throws JsonProcessingException {
        ObjectWriter writer = mapper.writer();
        return writer.writeValueAsString(dto);
    }
    
    public static String monitorTransactionToJSon(MonitoracaoTransacaoAutorizadorVO vo) throws JsonProcessingException {
        ObjectWriter writer = mapper.writer();
        return writer.writeValueAsString(vo);
    }
}
