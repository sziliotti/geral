package br.com.cielo.monitoracao.stratus;

import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;

import org.apache.commons.collections.map.LRUMap;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.xml.DOMConfigurator;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import br.com.cielo.dispatcher.model.CanonicalTransactionVO;
import br.com.cielo.dispatcher.model.TransactionStatus;
import br.com.cielo.monitoracao.MessageSourceConstants;
import br.com.cielo.monitoracao.autorizador.parser.ParserConverterUtils;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoMonitoracaoParser;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoMonitoracaoTPSParser;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoParserBuilder;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoStratusParser;
// Novo BIT
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.StatusTransacao;
import br.com.cielo.monitoracao.business.MatchRule;
import br.com.cielo.monitoracao.business.impl.StratusOthersDispacher;
import br.com.cielo.monitoracao.business.impl.eligible.Match2001_01Rule;
import br.com.cielo.monitoracao.business.impl.eligible.OfflineTransactionRule;
import br.com.cielo.monitoracao.business.impl.eligible.SondaMatchRule;
import br.com.cielo.monitoracao.cep.eventos.ext.MonitoracaoTransacaoCEPTPS;
import br.com.cielo.monitoracao.consumer.cache.ProdutoCompletoDePara;
import br.com.cielo.monitoracao.consumer.cache.regraonline.script.RegraOnlineScriptMatchTransformation;
import br.com.cielo.monitoracao.consumer.cache.remote.CacheServiceBeanRemote;
import br.com.cielo.monitoracao.consumer.cache.util.RegraOnlineUtils;
import br.com.cielo.monitoracao.jmx.MessageStatisticsCountController;
import br.com.cielo.monitoracao.jmx.MessageStatisticsMXBean;
import br.com.cielo.monitoracao.jmx.MessageStatisticsUtils;

/**
 * <B>Projeto: parser-ejb-tier</B><BR><BR>
 *
 * Message-Driven Bean responsavel em capturar as mensagens enviadas pelo
 * Stratus, através do Adapter, efetuar o Parser(utilizando framework) da
 * mensagem(bytes[]); aplicar as regras de elegibilidade e encaminhar para o
 * Topic(MonitoracaoObjTopic) onde os fluxos do OEP(CEP) capturarão e
 * processarão as mensagens; e para a Queue(MonitoracaoNegadasDesfeitasQueue)
 * especifica de Negadas e Desfeitas, e Topic(cepEcommerceTopic) especifico de
 * eCommerce.
 *
 * <DL><DT><B>Criada em:</B><DD>04/09/2014</DD></DL>
 *
 * @author Nemer Daud - Oracle (version 1) Sergio Ziliotti da Silva - Cielo S.A.
 * (version 2)
 * @version 2.0
 *
 */
public abstract class ConsumidorTransacoesStratusMDBBase implements MessageListener {

    //** Caches
    @EJB(mappedName = "monitoracao-cache-service-CacheServiceBeanRemote")
    private CacheServiceBeanRemote cacheService;

    @EJB
    private StratusOthersDispacher stratusDispatcher;

    private static final List<String> TP_TEC_ECOMMERCE = Arrays.asList(new String[]{"08", "09"});
    private static final List<Integer> STATUS_NEGADA_DESFEITA = Arrays.asList(new Integer[]{1, 3});
    // BIT 47
    private static final List<String> TP_TEC_BIT47 = Arrays.asList(new String[]{"01", "02", "03", "04", "14", "23"});

    //private static final Log LOGGER = LogFactory.getLog(ConsumidorTransacoesStratusMDB.class);    
    private static final Logger LOGGER = Logger.getLogger(ConsumidorTransacoesStratusMDBBase.class.getName());

    // Gerador de estatisticas
    private static final String STATISTIC_LOCK = "STATISTIC_LOCK";
    private static Long count = 0L;

    private static Long countStat = 0L;
    private static Long lastTimeStat = System.currentTimeMillis();

    // ============================================================================================================
    // Contadores para Estatisticas de mensagens Não Elegiveis.    
    private static Long lastTimeStatMsgsNaoElegiveis = System.currentTimeMillis();

    // Logger responsavel em gerar o trace para Estatisticas de mensagens Não Elegiveis.
    private static final org.apache.log4j.Logger loggerStatMsgsNaoElegiveis = org.apache.log4j.Logger.getLogger("StatMsgsNaoElegiveisLogger");
    // Logger responsavel em gerar o trace das mensagem recebida em duplicidade.
    private static final org.apache.log4j.Logger loggerDuplicityTransactions = org.apache.log4j.Logger.getLogger("DuplicityTransactionsLogger");

    // Logger responsavel em gerar o trace de todas mensagem recebida do Stratus, para controle e auditoria futura.
    private static final org.apache.log4j.Logger loggerAuditoria = org.apache.log4j.Logger.getLogger("AllTransactionsAuditoriaLogger");
    private static final DateTimeFormatter dateHourFormatAuditoria = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSSSSS");
    private static final DateTimeFormatter dateFormatAuditoria = DateTimeFormat.forPattern("yyyy-MM-dd");
    private static List<String> DATAS_PARA_AUDITORIA_COMPLETA = Arrays.asList();

    //---------------------------------------------------------------------------------------------------------------
    @Resource(mappedName = "jms.MonitoracaoStratusProducerLocalConnFactory")  //wls
    private ConnectionFactory connectionFactory;

    @Resource(mappedName = "jms.RemoteDispatcherConnFactory") //activemq
    private ConnectionFactory dispatcherConnectionFactoryRemoto;

    @Resource(mappedName = "jms.cepEcommerceTopic")
    private Topic ecommerceTopic;

    @Resource(mappedName = "jms.MonitoracaoNegadasDesfeitasQueue") //wls
    private Queue monitoracaoNegDesfQueue;

    @Resource(mappedName = "jms.DispatcherQueueRemote")
    private Queue remoteDispatcherQueue;

    @Resource(mappedName = "jms.DispatcherBigDataTopicRemote")
    private Topic remoteDispatcherBigDataTopic;

    @Resource(mappedName = "jms.MonitoracaoObjTopic") //wls
    private Topic monitoracaoTopic;

    @Resource(mappedName = "jms.MonitoracaoTPSTopic") //wls
    private Topic monitoracaoTPSTopic;

    // BIT 47 - Inclusão do Topico para ser consumido pelos processos do BIT 47
    @Resource(mappedName = "jms.MonitoracaoBitTopic") //wls 
    private Topic monitoracaoBitTopic;
    // BIT 47 - Inclusão do Topico para ser consumido pelos processos do BIT 47
    @Resource(mappedName = "jms.MonitoracaoBitAnaliticoQueue") //wls
    private Queue monitoracaoBitAnaliticoQueue;

    @Resource(mappedName = "jms.RecargaCartaoTopic") //wls
    private Topic monitoracaoRecargaCartaoTopic;

    private Connection connection;
    private Connection connectionDispatcherRemoto; // propagador

    private Session session;
    private Session sessionDispatcherRemoto; // propagador

    private MessageProducer messageProducer;
    private MessageProducer messageTPSProducer;
    private MessageProducer ecommerceProduce;
    private MessageProducer negDesfProducer;
    private MessageProducer bitProducer; //Novo Producer - BIT 47
    private MessageProducer bitAnaliticoProducer; //Novo Producer - BIT 47
    private MessageProducer recargaCartaoProducer;
    private MessageProducer messageProducerDispatcherRemoto; // fila propagador
    private MessageProducer messageProducerDispatcherBigDataRemoto; // topico BigData do propagador
    
    BytesMessage bm = null;

    private static AtomicInteger countMessagesOUT = new AtomicInteger(0);
    private static final MessageStatisticsCountController countController = new MessageStatisticsCountController();
    private static boolean counterStarted = false;

    private String uuidMessageAdapter;
    private static final DateTimeFormatter dateHourFormat = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss,SSS");

    private static Map<String, MonitoracaoTransacaoAutorizadorVO> lruMapTransacoes;
    private boolean isTransacoesDuplicadasSomenteLog;
    private boolean isTransacoesDuplicadasLogAtivo;

    private boolean isEnviaTudoPropagador;
    private long lastRetryDispacher = System.currentTimeMillis();
    private static final int TEMPO_RETENTATIVA_PROPAGADOR = 30 * 1000;
    private final Object lastRetryDispacherSyncCtrl = new Object();

    @EJB(beanName = "consumidorTransacoesStratusMessageStatistics")
    private MessageStatisticsMXBean messageStatisticsBean;
    private MessageStatisticsUtils msgUtils;

    /**
     * Regras usadas por esta classe
     */
    private MatchRule offlineMatchRule = new OfflineTransactionRule();
    private MatchRule sondaMatchRule = new SondaMatchRule();
    private MatchRule match2001_01Rule = new Match2001_01Rule();
    private final RegraOnlineUtils regraOnlineUtils = RegraOnlineUtils.getInstance();

    /**
     * Inicializa os objetos e recursos utilizados no processo.
     */
    @PostConstruct
    public void init() {
        try {
            // Le o arquivo de configuracao do Log4j.	    	
            DOMConfigurator.configure(getClass().getResource("/log4j-consumidor-stratus.xml"));

            // Recupera as datas elegiveis para gerar o arquivo completo(contendo o valor hexadecimal da transação vinda do Stratus) no arquivo de 
            // auditoria. As datas serão capturadas da variavel de inicialização da JVM "-DdatasParaAuditoriaCompleta", e estara no formato "yyyy-MM-dd;yyyy-MM-dd".
            String datasParaAuditoriaCompleta = System.getProperty("datasParaAuditoriaCompleta");
            if (datasParaAuditoriaCompleta != null) {
                String[] datas = datasParaAuditoriaCompleta.split(";");
                DATAS_PARA_AUDITORIA_COMPLETA = Arrays.asList(datas);
            }

            isTransacoesDuplicadasLogAtivo = Boolean.parseBoolean(System.getProperty("transacoesDuplicadasLogAtivo", Boolean.TRUE.toString()));
            if (isTransacoesDuplicadasLogAtivo) {
                isTransacoesDuplicadasSomenteLog = Boolean.parseBoolean(System.getProperty("transacoesDuplicadasSomenteLog", Boolean.FALSE.toString()));
                int lru = 15000;
                String lruStr = System.getProperty("transacoesDuplicadasTamanhoCache", Integer.toString(lru));
                try {
                    lru = Integer.parseInt(lruStr);
                } catch (NumberFormatException ex) {
                    LOGGER.log(Level.WARNING, "Parametro 'transacoesDuplicadasTamanhoCache' deve ser um inteiro. Valor {0} assumido.", lru);
                }
                lruMapTransacoes = Collections.synchronizedMap(new LRUMap(lru));
            }
            connection = connectionFactory.createConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            messageProducer = session.createProducer(monitoracaoTopic);
            messageProducer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

            messageTPSProducer = session.createProducer(monitoracaoTPSTopic);
            messageTPSProducer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

            ecommerceProduce = session.createProducer(ecommerceTopic);
            ecommerceProduce.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

            negDesfProducer = session.createProducer(monitoracaoNegDesfQueue);
            negDesfProducer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

            //Novo - BIT 47
            bitProducer = session.createProducer(monitoracaoBitTopic);
            bitProducer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

            //Novo - BIT 47
            bitAnaliticoProducer = session.createProducer(monitoracaoBitAnaliticoQueue);
            bitAnaliticoProducer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

            recargaCartaoProducer = session.createProducer(monitoracaoRecargaCartaoTopic);
            recargaCartaoProducer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

            this.initDispacher();

            msgUtils = new MessageStatisticsUtils(messageStatisticsBean, LOGGER, false);
            if (!counterStarted) {
                counterStarted = true;
                new Thread() {
                    @Override
                    public void run() {
                        int lastCountIN = 0;
                        int lastCountOUT = 0;
                        while (true) {
                            try {
                                if (lastCountIN != countController.getCountMessages().intValue() || lastCountOUT != countMessagesOUT.intValue()) {
                                    LOGGER.log(Level.SEVERE, " Contador de Mensagens : IN [" + countController.getCountMessages().intValue() + "] | OUT [" + countMessagesOUT.intValue() + "] ");
                                    lastCountIN = countController.getCountMessages().intValue();
                                    lastCountOUT = countMessagesOUT.intValue();
                                }
                                Thread.sleep(10000);

                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }.start();
            }
        } catch (Exception e) {
            this.closeAll();
            throw new EJBException(e);
        }

    }

    /**
     * Configura fila de integração com Propagador
     */
    private void initDispacher() {

        if (messageProducerDispatcherRemoto != null) {
            return;
        }

        try {
            isEnviaTudoPropagador = Boolean.getBoolean("enviaTudoPropagador");

            Integer retryTime = Integer.getInteger("tempoRetentativaPropagador");
            retryTime = retryTime != null ? retryTime : TEMPO_RETENTATIVA_PROPAGADOR;
            long currentTimeMillis = System.currentTimeMillis();
            if (currentTimeMillis <= (this.lastRetryDispacher + retryTime)) {
                synchronized (this.lastRetryDispacherSyncCtrl) {
                    if (this.messageProducerDispatcherRemoto == null || messageProducerDispatcherBigDataRemoto==null) {
                        this.lastRetryDispacher = currentTimeMillis;
                        connectionDispatcherRemoto = dispatcherConnectionFactoryRemoto.createConnection();
                        sessionDispatcherRemoto = connectionDispatcherRemoto.createSession(false, Session.AUTO_ACKNOWLEDGE);
                        messageProducerDispatcherRemoto = sessionDispatcherRemoto.createProducer(remoteDispatcherQueue);
                        messageProducerDispatcherRemoto.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
                        messageProducerDispatcherBigDataRemoto = sessionDispatcherRemoto.createProducer(remoteDispatcherBigDataTopic);
                        messageProducerDispatcherBigDataRemoto.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
                    }
                }
            }

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Erro abrindo transação com o Propagador:", e);

            this.closeDispacher();
        }
    }

    /**
     * Finaliza os objetos e recursos utilizados no processo.
     */
    @PreDestroy
    public void destroy() {
        this.closeAll();
    }

    protected void onMessageInternal(Message message) {
        msgUtils.startTimerCount(countController);
        byte[] payload = null;

        // Propriedades para Estatisticas de mensagens Não Elegiveis.
        boolean isToReportStatsMensagensNaoElegiveis = false;
        long currentWatchMsStatsMensagensNaoElegiveis = System.currentTimeMillis();

        long startWatchMs = 0;
        long currentWatchMs = 0;
        boolean isToReportPerformance = false;
        try {
            synchronized (STATISTIC_LOCK) {
                count++;
                countStat++;
                if (count % 10000 == 0) {
                    isToReportPerformance = true;
                    startWatchMs = System.currentTimeMillis();
                    LOGGER.log(Level.SEVERE, "===========================================================");
                }

                // Verifica disponibilidade para gerar relatorio de Estatisticas de mensagens Não Elegiveis (A cada 60segundos).
                if ((currentWatchMsStatsMensagensNaoElegiveis - lastTimeStatMsgsNaoElegiveis) >= 60000) {
                    isToReportStatsMensagensNaoElegiveis = true;
                }
            }

            String uuid = message.getJMSMessageID();
            long timeMsgParser = System.currentTimeMillis();
            payload = this.obterPayload(message);

            //Descompactando a mensagem recebida.
            byte[] xPayloadDescompress = ParserConverterUtils.unzipMessage(payload);
            //Aplicando Parser mensagem Stratus.
            MonitoracaoTransacaoAutorizadorVO monTran = this.parserTransacaoStratus(xPayloadDescompress);

            msgUtils.registryParseLatency(timeMsgParser);

            //Atribui identificador uuid da mensagem recebida pelo Stratus-Monitoracao-Adapter ao objeto VO.
            uuidMessageAdapter = message.getStringProperty("BAM_UUID");
            if (monTran != null) {
                monTran.setUuidMessageAdapter(uuidMessageAdapter);
            }

            if (isToReportPerformance) {
                this.reportPerformance("[Performance Parser Stratus] tempo de parser (ms):", startWatchMs);
            }
            currentWatchMs = System.currentTimeMillis();

            // Enriquece a mensagem com os caches
            monTran = this.loadCacheValues(monTran);
            // Verifica critérios de alteração do tipo de tecnologia (CHIP_AND_PIN, TEFIP, etc.)
            monTran = aplicarRegrasTransformacaoTipoTecnologia(monTran);
            sendTransactionToDispatcher(monTran);

            // Aplica regra de verificação dos tipos de mensagens a serem enviados para a monitoração. Aplicando as mesmas regras de elegibilidade
            // existente na monitoração do Mainframe.            
            if (this.isElegivelParaMonitoracao(monTran)) {

                if ("robo".equals(monTran.getCodigoLoja())) {
                    LOGGER.log(Level.SEVERE, "ROBO - : DH_AUT {0}, isToken: {1}, isAutParc: {2}, isDCC: {3}, isFinDCC: {4}",
                            new Object[]{
                                monTran.getDataHoraStratus(),
                                monTran.isIndicTransacaoToken(),
                                monTran.isAutorizacaoParcial(),
                                monTran.isDCC(),
                                (monTran.getInformacoesDCC() != null && "F".equals(monTran.getInformacoesDCC().getTipoTransacao()))
                            });
                }

                ObjectMessage om = session.createObjectMessage();
                om.setJMSMessageID(uuid);
                om.setObject(monTran);
                om.setStringProperty(MessageSourceConstants.TYPE_KEY, MessageSourceConstants.TYPE_VALUE_STRATUS);

                TextMessage tm = null;
                if (this.isElegivelParaMonitoracaoTPS(monTran)) {
                    TransacaoMonitoracaoTPSParser transacaoMonitoracaoTPSParser = TransacaoParserBuilder.getTransacaoMonitoracaoTPSParser();
                    MonitoracaoTransacaoCEPTPS tps = transacaoMonitoracaoTPSParser.convert(monTran);
                    tm = session.createTextMessage();
                    tm.setJMSMessageID(uuid);
                    tm.setText(transacaoMonitoracaoTPSParser.parser(tps));
                    tm.setStringProperty(MessageSourceConstants.TYPE_KEY, MessageSourceConstants.TYPE_VALUE_STRATUS);
                }

                long timeMsgProducer = System.currentTimeMillis();

                messageProducer.send(om);

                if (tm != null) {
                    messageTPSProducer.send(tm);
                }
                msgUtils.registryPostLatency(timeMsgProducer);
                msgUtils.incrementMessageStatisticsBean(countController);

                // Verifica se envia para ecommerce
                if (TP_TEC_ECOMMERCE.contains(monTran.getTipoTecnologia())) {
                    // envia copia para topico do Ecommerce
                    ecommerceProduce.send(om);
                }

                // Verifica se envia para negdesf
                // if (monTran.getIdStatus().getValue() == 1 || monTran.getIdStatus().getValue() == 3) {
                if (STATUS_NEGADA_DESFEITA.contains(monTran.getIdStatus().getValue())) {
                    negDesfProducer.send(om);
                }

                // Verifica se envia para Bit47
                if (TP_TEC_BIT47.contains(monTran.getTipoTecnologia())) {
                    if ((monTran.getInformacoesBIT47() != null) && (monTran.getInformacoesBIT47().getInformacoesDiscagem() != null)) {
                        // Envia para Fila e Topic do Bit47
                        bitProducer.send(om);
                        bitAnaliticoProducer.send(om);
                    }
                }

                // Verifica se envia para RecargaCartao
                if (StringUtils.isNotBlank(monTran.getCodigoServicoPOS())) {
                    try {
                        String descricao = cacheService.getDescricaoServicoRecarga(new Long(monTran.getCodigoServicoPOS()));
                        if (StringUtils.isNotBlank(descricao)) {
                            recargaCartaoProducer.send(om);
                        }
                    } catch (Exception ex) {
                    }
                }
                // dispacha para subsistemas de monitoracao stratus
                stratusDispatcher.dispatch(monTran);
                try {
                    countMessagesOUT.addAndGet(1);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            // Emite relatorio de performance.
            if (isToReportPerformance) {
                this.reportPerformance("[Performance Parser Stratus] tempo para submeter mensagem ao topico CEP (ms):", currentWatchMs);
            }

            // Registra log com informações(NSU, terminal, DataHora, Bandeira, Emissor, Produto Completo, etc) de todas as transações recebidas do Stratus, para auditoria.
            //this.gravarMensagemStratusAuditoria(monTran, payload);            
        } catch (JMSException e) {
            LOGGER.log(Level.SEVERE, "Erro realizando leitura da mensagem JMS. A mensagem[uuid=" + uuidMessageAdapter + "] será descartada.", e);

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Erro realizando parser da mensagem JMS. Erro [" + ExceptionUtils.getStackTrace(e) + "]. "
                    + "Mensagem compactada[" + ParserConverterUtils.bytesToHex(payload) + "]. A mensagem[uuid=" + uuidMessageAdapter + "] será descartada.", e);

        } finally {
            synchronized (STATISTIC_LOCK) {
                if (isToReportPerformance) {
                    LOGGER.log(Level.SEVERE, "[Performance Parser Stratus] Performance geral: " + (10000 * countStat / (System.currentTimeMillis() - lastTimeStat)) + " mensagens/s");
                    LOGGER.log(Level.SEVERE, "===========================================================");
                    lastTimeStat = System.currentTimeMillis();
                    countStat = 0L;
                }
            }
        }
    }

    private void sendTransactionToDispatcher(MonitoracaoTransacaoAutorizadorVO monVo ){
        // envia para propagador
        try {
            // verifica se transação é elegível para ir ao propagador
            CanonicalTransactionVO canonicalVo = DispatcherHelper.translateToCanonicalTransaction(monVo);
            applyDispatcherExtraFields(canonicalVo);
            boolean elegivelPropagador = isElegivelPropagador(canonicalVo, monVo);
            if (isEnviaTudoPropagador) {
                LOGGER.log(Level.INFO, "isElegivelPropagador(vo): {0}, Parametro 'enviaTudoPropagador': {1}", new Object[]{elegivelPropagador, isEnviaTudoPropagador});
            }
            this.initDispacher();
            if (this.messageProducerDispatcherRemoto == null || messageProducerDispatcherBigDataRemoto == null) {
                    return;
            }
            if (elegivelPropagador && (isEnviaTudoPropagador || isInEcWhiteList(canonicalVo))) {
                // envia para fila generica (Vendas Online)
                ObjectMessage com = sessionDispatcherRemoto.createObjectMessage();
                com.setObject(canonicalVo);
                messageProducerDispatcherRemoto.send(com);
            }
            // evia para topic do BigData que nao tem filtro
            messageProducerDispatcherBigDataRemoto.send(
                    sessionDispatcherRemoto.createTextMessage(DispatcherHelper.monitorTransactionToJSon(monVo)));

        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Erro convertendo e submentendo transação canônica para o Propagador:", ex);
            this.closeDispacher();
        }
    }

    /**
     * Faz o enriquecimento da mensagem. Acessa os caches e completa o VO com os
     * valores encontrados no cache.
     *
     * @param monTran Objeto representando a transação
     * MonitoracaoTransacaoAutorizadorVO.
     * @return Objeto representando a transação
     * MonitoracaoTransacaoAutorizadorVO enriquecida.
     */
    private MonitoracaoTransacaoAutorizadorVO loadCacheValues(MonitoracaoTransacaoAutorizadorVO monTran) {
        // Grupo EC
        try {
            monTran.setCodGrupoEC(cacheService.getGrupoEc(monTran.getCodigoEstabelecimento()));
        } catch (Exception ex) {
            LOGGER.log(Level.WARNING, "Erro carregando cache GrupoEC no VO {UUID: " + monTran.getUuidMessageAdapter() + "}", ex);
        }

        // Localidade
        try {
            if (StringUtils.isNumeric(monTran.getCep()) && StringUtils.isNotBlank(monTran.getCep())) {
                monTran.setCodigoLocalidade("" + cacheService.getLocalidade(new Long(monTran.getCep())));
            }
        } catch (Exception ex) {
            LOGGER.log(Level.WARNING, "Erro carregando cache Localidade no VO {UUID: " + monTran.getUuidMessageAdapter() + "}", ex);
        }

        // Operadora    
        try {
            if (StringUtils.isNumeric(monTran.getCodigoOperadoraGPRS()) && StringUtils.isNotBlank(monTran.getCodigoOperadoraGPRS())) {
                monTran.setNomeOperadoraGPRS(cacheService.getDescOperadora(new Long(monTran.getCodigoOperadoraGPRS())));
            }
        } catch (Exception ex) {
            LOGGER.log(Level.WARNING, "Erro carregando cache Operadora no VO {UUID: " + monTran.getUuidMessageAdapter() + "}", ex);
        }

        // Produto Completo
        try {
            monTran.setFormaPagamento(cacheService.getFormaPagamento(monTran.getProdutoCompleto()));
        } catch (Exception ex) {
            LOGGER.log(Level.WARNING, "Erro carregando cache Produto Completo no VO {UUID: " + monTran.getUuidMessageAdapter() + "}", ex);
        }

        // Codigo Erro
        try {
            monTran.setCodigoErro(cacheService.getCodErro(monTran.getCodigoErro()));
        } catch (Exception ex) {
            LOGGER.log(Level.WARNING, "Erro carregando cache Codigo de Erro no VO {UUID: " + monTran.getUuidMessageAdapter() + "}", ex);
        }

        // Localidade da Lista Completa  -- Bit 47
        try {
            String[] cacheLocalidadeUf = cacheService.getCompleteLocalidade((monTran.getCep()));
            monTran.setCodigoCompleteLocalidade(cacheLocalidadeUf[0]);
            monTran.setUf(cacheLocalidadeUf[1]);
        } catch (Exception ex) {

            LOGGER.log(Level.WARNING, "Erro carregando cache Localidade no VO {UUID: " + monTran.getUuidMessageAdapter() + "}", ex);
        }

        // Tabela De-Para
        try {
            ProdutoCompletoDePara pcDe
                    = new ProdutoCompletoDePara(monTran.getBandeira(), monTran.getProduto(), monTran.getSubProduto());
            ProdutoCompletoDePara pcPara = cacheService.getProdutoCompletoDePara(pcDe);
            if (pcPara != null) {
                monTran.setProduto(pcPara.getCodProduto());
                monTran.setSubProduto(pcPara.getCodSubProduto());
                //System.out.println(">>>> DE-PARA: [Produto:"+pcDe.getCodProduto()+", subproduto:"+pcDe.getCodSubProduto()+", bandeira:"+pcDe.getCodBandeira()+
                //          			"] =====> [Produto:"+pcDe.getCodProduto()+", subproduto:"+pcDe.getCodSubProduto());
            }
        } catch (Exception ex) {
            LOGGER.log(Level.WARNING, "Erro carregando cache DE-PARA de Produto pela Bandeira {UUID: " + monTran.getUuidMessageAdapter() + "}", ex);
        }

        // Lio
        try {
            if (monTran.getDadosVersaoTerminal() != null) {
                boolean isLio = cacheService.existsLioSourceVersionIgnoreCase(monTran.getDadosVersaoTerminal());
                monTran.setIndicadorLio(isLio);
            }
        } catch (Exception ex) {
            LOGGER.log(Level.WARNING, "Erro carregando cache Versao POS (para Lio) {UUID: " + monTran.getUuidMessageAdapter() + "}", ex);
        }

        return monTran;
    }

    /**
     * Metodo responsavel em logar uma estatistica de performance.
     *
     * @param mensagem Mensagem a ser registrada.
     * @param startMs Tempo em milesegundos do inicio do registro.
     */
    private void reportPerformance(String mensagem, Long startMs) {
        LOGGER.log(Level.SEVERE, mensagem + (System.currentTimeMillis() - startMs));
    }

    /**
     * Método responsavel em filtrar as transações que farão parte da
     * monitoração, seguindo o padrão e regras atuais do sistema de monitoração
     * do MAINFRAME.
     *
     * @param monitoracaoTransacao Objeto representando a transação
     * MonitoracaoTransacaoAutorizadorVO.
     *
     * @return Se a transação irá ou não para a Monitoração.
     */
    private boolean isElegivelParaMonitoracao(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao) {
        // REGRA 1: Desprezar as transações com o status de "CAPTURADO".
        if (monitoracaoTransacao.getIdStatus().equals(StatusTransacao.CAPTURADO)) {
            return false;
        }

        // REGRA 2: Despreza as transações do tipo Off line(1204 e 1104); Confirmação de transações na plataforma 2000-01 (Cod: 0202); 
        // ou Resposta de sonda na plataforma 20000-01 (Cod: 0610)
        if (offlineMatchRule.match(monitoracaoTransacao)
                || match2001_01Rule.match(monitoracaoTransacao)
                || sondaMatchRule.match(monitoracaoTransacao)) {
            return false;
        }

        // REGRA 3: Despreza as transações de charge Back da Mastercard(Cod: 0422); ou Transação de fechamento de lote(Cod: 1500); ou Inicialização POS(Cod: 1800).
        if (("0422".equals(monitoracaoTransacao.getIdMensagem())) || ("1500".equals(monitoracaoTransacao.getIdMensagem())) || ("1800".equals(monitoracaoTransacao.getIdMensagem()))) {
            return false;
        }

        // REGRA 4: Despreza as transações de fechamento de lote(CodTipTra = *01  (provavelmente isto não é mais usado)); 
        // ou Desfazimento de cancelamento(CodTipTra = *02(provavelmente isto não é mais usado)).
        if ("*01".equals(monitoracaoTransacao.getTipTra()) || "*02".equals(monitoracaoTransacao.getTipTra())) {
            return false;
        }

        // REGRA 5: Despreza as transações com erro. ACTR-DESTINO e ACTR-MSG e ACTR-QUEMRESP igual a spaces.
        if ((monitoracaoTransacao.getResolutor() != null && "".equals(monitoracaoTransacao.getResolutor().trim()))
                && (monitoracaoTransacao.getMensagem() != null && "".equals(monitoracaoTransacao.getMensagem().trim()))
                && (monitoracaoTransacao.getQuemRespondeu() != null && "".equals(monitoracaoTransacao.getQuemRespondeu().trim()))) {
            return false;
        }

        // REGRA 6: Despreza as transações quando for diferente de Consulta CDC(Cod.: 380010) e subtipo diferente de Transações de débito(ACTR-COD-PROC(3:2) = 10) 
        // ou Transações de crédito ACTR-COD-PROC(3:2) = 30 ou desconhecida(ACTR-COD-PROC(3:2) = 40).
        if (monitoracaoTransacao.getCodigoProcessamento() != null && !"380010".equals(monitoracaoTransacao.getCodigoProcessamento())) {
            //Verifica tamanho do codigo Processamento, deve ser ou >=4.
            if (monitoracaoTransacao.getCodigoProcessamento().length() >= 4) {
                String subCod = monitoracaoTransacao.getCodigoProcessamento().substring(2, 4);
                if (!"10".equals(subCod) && !"30".equals(subCod) && !"40".equals(subCod)) {
                    return false;
                }
            }
        }

        // REGRA 7: Despreza transações com BIN diferente de valor numerico ou zero; e codigo bandeira igual a zero/nulo. Regra para transações "bichadas".
        /* Ex: Valores validos: 
    	   				Bandeira != 0 AND Banco = 0 AND BIN == 0(nulo) --- Banco Internacional com transações negadas.
    	   				Bandeira != 0 AND Banco = 0 AND BIN != 0(nulo) --- Banco Internacional com transações OK.
    	   				
    	   		Valores invalidos (retornar false):
    	   				Bandeira = 0 AND (BIN = 0(nulo) or BIN != Numerico ) --- Transação Bichada.
         */
        try {
            int valorNumericoBin = Integer.parseInt(monitoracaoTransacao.getBin());
            if (valorNumericoBin == 0
                    && (monitoracaoTransacao.getBandeira() == null || "000".equals(monitoracaoTransacao.getBandeira()) || "".equals(monitoracaoTransacao.getBandeira()))) {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }

        // REGRA 8: Despreza as transações de confirmação Multivan;
        if (("1202".equals(monitoracaoTransacao.getIdMensagem()))) {
            return false;
        }

        if (isTransacoesDuplicadasLogAtivo) {
            StringBuilder sb = new StringBuilder();
            sb.append(monitoracaoTransacao.getNSU()).append("_");
            sb.append(monitoracaoTransacao.getDataHoraStratus()).append("_");
            sb.append(monitoracaoTransacao.getTerminal()).append("_");
            sb.append(monitoracaoTransacao.getCodigoEstabelecimento());
            String lruKey = sb.toString();
            if (lruMapTransacoes.containsKey(lruKey)) {
                StringBuilder sbMensagem = new StringBuilder();
                sbMensagem.append(monitoracaoTransacao.getNSU()).append(";");
                sbMensagem.append(monitoracaoTransacao.getTerminal()).append(";");
                sbMensagem.append(monitoracaoTransacao.getBandeira()).append(";");
                sbMensagem.append(monitoracaoTransacao.getBanco()).append(";");
                sbMensagem.append(monitoracaoTransacao.getProduto()).append(";");
                sbMensagem.append(monitoracaoTransacao.getSubProduto()).append(";");
                sbMensagem.append(monitoracaoTransacao.getIdMensagem()).append(";");
                sbMensagem.append(monitoracaoTransacao.getTipTra()).append(";");
                sbMensagem.append(monitoracaoTransacao.getCodigoProcessamento()).append(";");
                sbMensagem.append(monitoracaoTransacao.getTipoTecnologia()).append(";");
                sbMensagem.append(monitoracaoTransacao.getQuemRespondeu()).append(";");
                sbMensagem.append(monitoracaoTransacao.getCodigoErro()).append(";");
                sbMensagem.append(dateHourFormatAuditoria.print(new DateTime(monitoracaoTransacao.getDataHoraStratus()))).append(";");
                sbMensagem.append(dateHourFormatAuditoria.print(new DateTime(new Date()))).append(";");
                sbMensagem.append(monitoracaoTransacao.getTransacaoPOS()).append(";");
                sbMensagem.append(monitoracaoTransacao.getChaveMaquina()).append(";");
                sbMensagem.append(monitoracaoTransacao.getMensagem()).append(";");
                sbMensagem.append(monitoracaoTransacao.getModoConexao());
                loggerDuplicityTransactions.info(sbMensagem.toString());
                if (isTransacoesDuplicadasSomenteLog) {
                    return false;
                }
            }
            lruMapTransacoes.put(lruKey, monitoracaoTransacao);
        }

        return true;
    }

    /**
     * Método responsável em filtrar das transações eleitas as que devem seguir
     * para a análise de TPS da monitoração.
     *
     * @param monitoracaoTransacao Objeto representando a transação
     * MonitoracaoTransacaoAutorizadorVO.
     *
     * @return Se a transação irá ou não para a Monitoração TPS.
     */
    private boolean isElegivelParaMonitoracaoTPS(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao) {
        // se for nullo, estao nao eh consulta
        if (monitoracaoTransacao.getInformacoesDCC() == null) {
            return true;
        }
        return !"C".equals(monitoracaoTransacao.getInformacoesDCC().getTipoTransacao());
    }


    /**
     * Método responsavel em efetuar o parser do array de bytes
     * recebido(representando a transacao do Stratus), no objeto representando a
     * transação MonitoracaoTransacaoAutorizadorVO.
     *
     * @param payload Array de bytes contendo a transacao vinda do Stratus.
     * @return Objeto representando a transação
     * MonitoracaoTransacaoAutorizadorVO.
     */
    private MonitoracaoTransacaoAutorizadorVO parserTransacaoStratus(byte[] payload) throws Exception {
        MonitoracaoTransacaoAutorizadorVO transacaoMonitoracao = null;

        TransacaoStratusParser stratusParser = TransacaoParserBuilder.getTransacaoStratusParser();
        TransacaoMonitoracaoParser monitoracaoParser = TransacaoParserBuilder.getTransacaoMonitoracaoParser();
        transacaoMonitoracao = monitoracaoParser.converter(stratusParser.converter(payload));

        // Verifica atributos/propriedades de inicialização da JVM, para simular os atributos de maquina, produtos, etc nos ambiente de DEV e HOMOLOG.
        if ("true".equalsIgnoreCase(System.getProperty("simularAtributosStratus"))) {
            simulaAtributosStratus(transacaoMonitoracao);
        }

//        if (LOGGER.isLoggable(Level.FINE)) {
//            String msgDescomp= "[" + dateHourFormat.print(new DateTime()) + "] [MDB] Mensagem(hex) descompactada): " + ParserConverterUtils.bytesToHex(payload);
//            String transacaoMon= "[MDB] TRANSACAO MONITORAÇÃO : \n" + transacaoMonitoracao.toString();
//            LOGGER.log(Level.FINE, "Mensagem Descompactada:" + msgDescomp);
//            LOGGER.log(Level.FINE, "transacaoMon:" + transacaoMon);
//        }
        return transacaoMonitoracao;
    }

    /**
     * Retorna o payload da mensagem como um array de bytes.
     * <br>
     * Suporta mensagem texto, onde o payload deve ser hexadecimal e payload em
     * bytes.
     *
     * @param message Mensagem JMS que pode ser
     * <code>javax.jms.TextMessage</code> ou <code>javax.jms.BytesMessage</code>
     *
     * @return Payload da mensagem como um array de bytes.
     */
    private byte[] obterPayload(Message message) throws JMSException {
        if (message instanceof TextMessage) {
            throw new IllegalArgumentException("Mensagem recebida estah no formato texto. Era esperado no formato binario.");
        } else if (message instanceof BytesMessage) {
            BytesMessage bytesMessage = (BytesMessage) message;

            int tamanhoCorpo = (int) bytesMessage.getBodyLength();
            byte[] buffer = new byte[tamanhoCorpo];

            int bytesLidos = bytesMessage.readBytes(buffer);
            if (bytesLidos != tamanhoCorpo) {
                String msgErro = "Leu uma quantidade diferente de bytes [" + bytesLidos + "] do que o esperado [" + tamanhoCorpo + "]";
                LOGGER.log(Level.SEVERE, msgErro);
                throw new IllegalArgumentException(msgErro);
            }

            return buffer;

        } else {
            LOGGER.log(Level.SEVERE, "Mensagem recebida nao e TextMessage nem BytesMessage, Ignorando. Classe: " + message.getClass() + ". Mensagem: " + message);
            throw new IllegalArgumentException("Mensagem de tipo invalido: " + message);
        }
    }

    /**
     * Metodo responsavel em fechar os recursos(message producer, session,
     * connection, etc) utilizados no processo.
     */
    private void closeAll() {

        this.closeDispacher();

        try {
            if (messageProducer != null) {
                messageProducer.close();
            }
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Erro ao fechar recurso JMS[messageProducer].", ex);
        }
        try {
            if (messageTPSProducer != null) {
                messageTPSProducer.close();
            }
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Erro ao fechar recurso JMS[messageTPSProducer].", ex);
        }
        try {
            if (ecommerceProduce != null) {
                ecommerceProduce.close();
            }
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Erro ao fechar recurso JMS[ecommerceProduce].", ex);
        }
        try {
            if (negDesfProducer != null) {
                negDesfProducer.close();
            }
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Erro ao fechar recurso JMS[negDesfProducer].", ex);
        }
        try {
            if (bitProducer != null) {
                bitProducer.close();
            }
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Erro ao fechar recurso JMS[bitProducer].", ex);
        }
        try {
            if (bitAnaliticoProducer != null) {
                bitAnaliticoProducer.close();
            }
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Erro ao fechar recurso JMS[bitAnaliticoProducer].", ex);
        }
        try {
            if (recargaCartaoProducer != null) {
                recargaCartaoProducer.close();
            }
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Erro ao fechar recurso JMS[recargaCartaoProducer].", ex);
        }
        try {
            if (session != null) {
                session.close();
            }
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Erro ao fechar recurso JMS[session].", ex);
        }
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Erro ao fechar recurso JMS[connection].", ex);
        }
    }

    /**
     * Metodo responsavel em fechar os recursos(messageProducerDispatcherRemoto,
     * etc..) utilizados no processo.
     */
    protected void closeDispacher() {
        try {
            if (messageProducerDispatcherRemoto != null) {
                messageProducerDispatcherRemoto.close();
            }
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Erro ao fechar recurso JMS[messageProducerDispatcherRemoto].", ex);
        }
        try {
            if (sessionDispatcherRemoto != null) {
                sessionDispatcherRemoto.close();
            }
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Erro ao fechar recurso JMS[sessionDispatcherRemoto].", ex);
        }
        try {
            if (connectionDispatcherRemoto != null) {
                connectionDispatcherRemoto.close();
            }
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Erro ao fechar recurso JMS[connectionDispatcherRemoto].", ex);
        }

        this.messageProducerDispatcherRemoto = null;
        this.sessionDispatcherRemoto = null;
        this.connectionDispatcherRemoto = null;
    }

    // ====================================================================================================================
    // Propriedades usadas para utilizar na simulacao dos atributos Stratus(Ambiente de Homologacao e desenvolvimento).
    public static final String[] idProdutos = new String[]{"00800000", "02000001", "07110000",
        "05000028", "00490000", "00480000", "05000014", "07120000",
        "05000029", "00370000", "05000027", "07150000", "05000032",
        "07200000", "05000033", "00620000", "01000009", "01000007",
        "00270000", "01000008", "00650000", "01000012", "00760000",
        "01000013", "00470000", "05000013", "00440000", "05000016",
        "00580000", "05000018", "07060000", "05000024", "00510000",
        "05000009", "00390000", "05000012", "05000003", "00520000",
        "05000010", "07030000", "05000021", "07080000", "00690000",
        "05000005", "07040000", "05000022", "07140000", "05000031",
        "07050000", "05000023", "07090000", "00260000", "00630000",
        "01000010", "07010000", "05000019", "05000017", "00570000",
        "05000007", "07020000", "05000020", "07070000", "05000025",
        "05000026", "07130000", "05000030", "05000002", "00640000",
        "01000011", "00060000", "00820000", "03000001", "00350000",
        "03100001", "00670000", "03200001", "00680000", "03250001",
        "00280000", "04080001", "00610000", "04290001", "00430000",
        "04380001", "07100000", "04580001", "00860000", "05500001",
        "00800000", "02000003", "00820000", "03000002", "00350000",
        "03100003", "00670000", "03200002", "00280000", "04080003",
        "00610000", "04290002", "00430000", "04380002", "07100000",
        "04580002", "00860000", "05500002", "00820000", "03000003",
        "00860000", "05500003", "00810000", "02000002", "00360000",
        "03100002", "00290000", "04080002", "00790000", "07000005",
        "01000014", "00050000", "05000001", "00560000", "06000002",
        "06000003", "06000004", "06000005", "06000006", "06000007",
        "06000008", "05000006", "00870000", "05000008", "00380000"};
    public static final String[] maquinas = new String[]{"MB", "MA", "MC", "ME"};

    /**
     * Metodo responsavel em simular alguns atributos, gerando aleatoriamente,
     * da transação vinda do Stratus. Esse metodo, será apenas utilizado nos
     * ambientes de Desenvolvimento e Homologação, pois necessitamos recuperar e
     * gerar aleatoriamente os valores das maquinas Stratus(MA, MB, MC e ME),
     * e/ou produtos.
     * <br><br>
     * Esse metodo será invocado quando o atributo "simularAtributosStratus" for
     * verdadeiro. Esse atributo é definido nos argumentos de inicialização do
     * server Weblogic(-DsimularAtributosStratus=true).
     *
     * @param vo Objeto representando a transação
     * MonitoracaoTransacaoAutorizadorVO.
     */
    private void simulaAtributosStratus(MonitoracaoTransacaoAutorizadorVO vo) {
        if ("true".equalsIgnoreCase(System.getProperty("chaveMaquinaAleatoriaHom"))) {
            vo.setChaveMaquina(maquinas[getAleatorioGenerico(0, maquinas.length - 1)]);
        }
        if ("true".equalsIgnoreCase(System.getProperty("produtoAleatorioHom"))) {
            vo.setProduto(idProdutos[getAleatorioGenerico(0, idProdutos.length - 1)]);
        }

    }

    /**
     * Paleativo -- EXCLUIR
     */
    private int getAleatorioGenerico(int min, int max) {
        //int r = min + ((int) (Math.random() * 1000000) % (max - min + 1));
        SecureRandom a = new SecureRandom();
        return a.nextInt(max + 1 - min) + min;
        //return r;
    }

    private static final List<String> TP_SOLUCAO_CAPTURA_TEFIP_CD_NO = Arrays
            .asList(new String[]{"TF800", "TFNUN"});
    private static final String TP_TECNOLOGIA_TEFIP = "101";
    private static final String MEIO_CONEXAO_TEFIP = "40";

    /**
     * Define regras para remapeamento do tipoTecnologia (Chip&Pin, TEFIP,
     * etc..)
     */
    private MonitoracaoTransacaoAutorizadorVO aplicarRegrasTransformacaoTipoTecnologia(MonitoracaoTransacaoAutorizadorVO monTran) {
        // Aplica regra do TEFIP 
        if (TP_SOLUCAO_CAPTURA_TEFIP_CD_NO.contains(monTran.getCodigoNo())
                || TP_SOLUCAO_CAPTURA_TEFIP_CD_NO.contains(monTran.getCodigoNoSecundario())) {
            // Nos primario e secundario elencam transacao como TEFIP. Verificar meio de conexao
            if (StringUtils.equals(MEIO_CONEXAO_TEFIP, monTran.getModoConexao())) {
                monTran.setTipoTecnologia(TP_TECNOLOGIA_TEFIP);
            }
        }
        // aplicar regra Lio
        aplicarRegraOnline(monTran, "LIO");
        // aplicar regra Combo
        aplicarRegraOnline(monTran, "COMBO");
        return monTran;
    }

    private void aplicarRegraOnline(MonitoracaoTransacaoAutorizadorVO monTran, String codigo) {
        try {
            RegraOnlineScriptMatchTransformation script = regraOnlineUtils.getScriptRegra(cacheService, codigo, RegraOnlineScriptMatchTransformation.class);
            script.transform(monTran);
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Erro chamando RegraOnline ''{0}'': {1}", new Object[]{codigo, ex.getMessage()});
        }
    }

    /**
     * Regras para o propagaor da consulta online
     *
     * @param canonicalVo VO canonico
     */
    private List<TransactionStatus> statusElegiveis = Arrays.asList(new TransactionStatus[]{TransactionStatus.PENDING, TransactionStatus.APPROVED, TransactionStatus.CANCELED, TransactionStatus.DENIED, TransactionStatus.ERROR,
        TransactionStatus.TIMEOUT, TransactionStatus.UNDONE});
    private List<String> formasPagamentoElegiveis = Arrays.asList(new String[]{"cr\u00E9dito", "d\u00E9bito", "voucher", "private"});

    private boolean isInEcWhiteList(CanonicalTransactionVO canonicalVo) {
                // verifica se o estabelecimento esta cadastrado para consulta online.
        if (StringUtils.isBlank(canonicalVo.getMerchantId()) || !StringUtils.isNumeric(canonicalVo.getMerchantId()) || !cacheService.estabelecimentoIsOnline(new Long(canonicalVo.getMerchantId()))) {
            return false;
        }
        return true;
    }
    
    private boolean isElegivelPropagador(CanonicalTransactionVO canonicalVo, MonitoracaoTransacaoAutorizadorVO monVo) {

        if (!statusElegiveis.contains(canonicalVo.getStatus())) {
            return false;
        }

        if (!formasPagamentoElegiveis.contains(canonicalVo.getSalesTypeDescription() == null ? "" : canonicalVo.getSalesTypeDescription().trim().toLowerCase())) {
            return false;
        }

        // Despreza transaçoes DCC
        if (monVo.getInformacoesDCC() != null && "C".equals(monVo.getInformacoesDCC().getTipoTransacao())) {
            return false;
        }
        return true;
    }

    private void applyDispatcherExtraFields(CanonicalTransactionVO canonicalVo) {
        String cdFormaPagamento = cacheService.getFormaPagamento(canonicalVo.getProductCode());
        try {
            canonicalVo.setSalesTypeDescription(cacheService.getDescricaoFormaPagamento(new Integer(cdFormaPagamento)));
            // Verifica se o produto completo aponta para um voucher. Se sim, sobrescreve de débito para voucher.
            if ("S".equals(cacheService.getFormaPagamentoComIndicVoucher(canonicalVo.getProductCode())[1])) {
                canonicalVo.setSalesTypeDescription("Voucher");
            }
            if (StringUtils.isNotBlank(canonicalVo.getCaptureSolutionId())) {
                canonicalVo.setCaptureSolutionDescription(cacheService.getDescricaoSolucaoCaptura(new Long(canonicalVo.getCaptureSolutionId())));
            }
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Erro convertendo código da forma de pagamento", ex);
        }
    }

}
