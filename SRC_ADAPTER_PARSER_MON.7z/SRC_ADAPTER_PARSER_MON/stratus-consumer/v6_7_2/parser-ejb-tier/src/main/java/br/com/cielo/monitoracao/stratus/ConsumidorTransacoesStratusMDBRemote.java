package br.com.cielo.monitoracao.stratus;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.DependsOn;
import javax.ejb.MessageDriven;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.jms.Message;

/**
 * <B>Projeto: parser-ejb-tier</B><BR>
 * <BR>
 *
 * H.A.
 * 
 * @see ConsumidorTransacoesStratusMDBBase
 * 
 * @author Isaac Silva
 *
 */
@MessageDriven(mappedName = "br.com.cielo.monitoracao.stratus.remote.queue.1.In", activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "connectionFactoryJndiName", propertyValue = "jms.AMQMonitoracaoStratusConsumerRemoteConnFactory") })
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
@DependsOn({"GrupoECLoadFullCache","LocalidadeLoadFullCache","OperadoraLoadFullCache","ProdutoCompletoLoadFullCache","ErroLoadFullCache","DeParaBandeiraProdutoFullCache", "LocalidadeCompleteLoadFullCache", "ServicosRecargaLoadFullCache", "RegraOnlineLoadFullCache"})
public class ConsumidorTransacoesStratusMDBRemote extends ConsumidorTransacoesStratusMDBBase {

	/**
	 * @param message
	 * @see super#onMessageInternal(Message)
	 */
	@Override
	public void onMessage(Message message) {

		super.onMessageInternal(message);
	}

}
