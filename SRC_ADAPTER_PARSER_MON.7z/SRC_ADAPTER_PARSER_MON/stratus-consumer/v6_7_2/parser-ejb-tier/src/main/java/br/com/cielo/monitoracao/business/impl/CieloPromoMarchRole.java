/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.monitoracao.business.impl;

import br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO;
import br.com.cielo.monitoracao.business.MatchRule;
import java.util.Arrays;
import java.util.List;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;
import javax.ejb.Startup;

/**
 *
 * @author nemer
 */
@Startup
@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.CONTAINER) /* default */
@Lock(LockType.READ)
public class CieloPromoMarchRole implements MatchRule<MonitoracaoTransacaoAutorizadorVO> {

    private static final List<String> DOMINIO_FLAG_PROMO = Arrays.asList(new String[] {"S", "P", "T"});
    
    @Override
    @Lock(LockType.READ)
    public boolean match(MonitoracaoTransacaoAutorizadorVO transaction) {
        if (transaction.getFlagCieloPromo() != null && DOMINIO_FLAG_PROMO.contains(transaction.getFlagCieloPromo())) {
            return true;
        }
        return false;
    }
    
}
