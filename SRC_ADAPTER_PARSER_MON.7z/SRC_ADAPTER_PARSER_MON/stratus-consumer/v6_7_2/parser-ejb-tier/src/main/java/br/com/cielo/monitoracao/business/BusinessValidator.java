package br.com.cielo.monitoracao.business;

import br.com.cielo.monitoracao.autorizador.parser.vo.bam.TransacaoBAM;

public abstract class BusinessValidator<T extends TransacaoBAM> {
	/**
	 * Deve retornar o valor do 
	 * @return
	 */
	public abstract boolean validate(T transacao, BusinessValidatorChain chain) throws BusinessValidatorException;
}
