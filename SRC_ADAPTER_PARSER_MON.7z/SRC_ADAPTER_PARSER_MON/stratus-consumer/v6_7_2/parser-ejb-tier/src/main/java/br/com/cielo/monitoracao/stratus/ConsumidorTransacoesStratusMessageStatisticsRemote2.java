package br.com.cielo.monitoracao.stratus;

import javax.ejb.Singleton;
import javax.ejb.Startup;

import br.com.cielo.monitoracao.jmx.AbstractMessageStatistics;
import br.com.cielo.monitoracao.jmx.MessageStatisticsMXBean;

/**
 * Implementacao de MXBean de Monitoramento JMX.
 * @author fernando.moraes
 * @version $Id: ConsumidorTransacoesStratusMessageStatistics.java $
 */
@Startup
@Singleton(name = "consumidorTransacoesStratusMessageStatisticsR2")
public class ConsumidorTransacoesStratusMessageStatisticsRemote2 extends AbstractMessageStatistics implements MessageStatisticsMXBean {

    @Override
    public String getBeanName() {
        return ConsumidorTransacoesStratusMDBRemote_2.class.getSimpleName();
    }
}
