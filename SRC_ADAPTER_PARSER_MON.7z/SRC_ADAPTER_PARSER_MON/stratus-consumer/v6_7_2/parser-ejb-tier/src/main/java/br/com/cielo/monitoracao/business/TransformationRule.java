/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.monitoracao.business;

import br.com.cielo.monitoracao.autorizador.parser.vo.bam.TransacaoBAM;

/**
 * Regra de transformação de transação. Recebe um MatchRule que vai avaliar se a transação em questão irá sofrer a mudança requerida.
 * @author nemer
 */
public abstract class TransformationRule <M extends MatchRule, T extends TransacaoBAM> {
    private final M matchInstance;

    public TransformationRule(M matchInstance) {
        this.matchInstance = matchInstance;
    }
    
    protected final M getMatchRule() {
        return matchInstance;
    }
    /**
     * Metodo que deve ser implementado para transformar a transação caso a mesma passe pela regra de match.
     * @param transaction transação a ser transformada
     * @return transação transformada
     */
    protected abstract T transform(T transaction);
    /**
     * Método publico que deve ser chamado para avaliar a transformação condicional da transação.
     * @param transaction
     * @return transação transformada caso esteja elencada para tal via MatchRule informada
     */
    public final T conditionalTransformation(T transaction) {
        if (!matchInstance.match(transaction)) {
            return transaction;
        } else {
            return transform(transaction);
        }
    }

}
