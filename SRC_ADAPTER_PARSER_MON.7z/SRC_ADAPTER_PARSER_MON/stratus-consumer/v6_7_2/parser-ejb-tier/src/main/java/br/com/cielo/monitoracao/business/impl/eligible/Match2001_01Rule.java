/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.monitoracao.business.impl.eligible;

import br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO;
import br.com.cielo.monitoracao.business.MatchRule;

/**
 *
 * @author nemer
 */
public class Match2001_01Rule implements MatchRule<MonitoracaoTransacaoAutorizadorVO>{

    @Override
    public boolean match(MonitoracaoTransacaoAutorizadorVO transaction) {
        return "0202".equals(transaction.getTransacaoPOS());
    }
    
}
