/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.monitoracao.business.impl;

import br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO;
import br.com.cielo.monitoracao.business.MatchRule;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.EJB;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 * @TODO Esta classe é para destacar do ConsumidorTransacoesStratusMDB a lógica
 * de envio de mensagens para os diversos subsistemas de monitoração do Stratus.
 * Ainda precisa ser finalizado. O Lio o ideal é ficar em uma tabela a parte
 * para não aumentar as dimensões da FATO. No entanto, devido ao baixo volume,
 * provisoriamente ficará como uma nova dimensão.
 * @author nemer
 */
@Startup
@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.CONTAINER) /* default */
@Lock(LockType.READ)
// Evitar problema de 2-phase-commit na JMS pois ela (Nesta conf) nao suporta JTA.
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class StratusOthersDispacher {
    
    protected static final DateTimeFormatter dtfDataHoraMinutoSeg = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");
    
    @EJB
    MatchRule promoMatcher;

    @Resource(mappedName = "jms.MonitoracaoStratusProducerLocalConnFactory")  //wls 
    private ConnectionFactory connectionFactory;
    private Connection connection;
    private Session session;

    @Resource(mappedName = "jms.MonitoracaoPromoQueue") //wls
    private Queue monitoracaoPromoQueue;

    private MessageProducer messagePromoProducer;

    @PostConstruct
    public void init() {
        try {
            connection = connectionFactory.createConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

//            messageLioProducer = session.createProducer(monitoracaoLioQueue);
//            messageLioProducer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

            messagePromoProducer = session.createProducer(monitoracaoPromoQueue);
            messagePromoProducer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

        } catch (JMSException ex) {
            Logger.getLogger(StratusOthersDispacher.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Lock(LockType.READ)
    public void dispatch(MonitoracaoTransacaoAutorizadorVO vo) {
        
        try {
            if (promoMatcher.match(vo)) {
                TextMessage tm = session.createTextMessage(getPromoStringTransaction(vo));
                messagePromoProducer.send(tm);
            }
        } catch (Exception ex) {
            /** @TODO tratar excecao */
            Logger.getLogger(StratusOthersDispacher.class.getName()).log(Level.SEVERE, "Não foi possível submeter transacao CIELO PROMO para fila persistencia", ex);
        }

    }

    private String getPromoStringTransaction(MonitoracaoTransacaoAutorizadorVO vo) {
        br.com.cielo.monitoracao.cep.eventos.ext.MonitoracaoTransacaoCEP tCep = new br.com.cielo.monitoracao.cep.eventos.ext.MonitoracaoTransacaoCEP();
        SimpleDateFormat sdfDataHoraMinuto = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        try {
            PropertyUtils.copyProperties(tCep, vo);
        } catch (Exception ex) {
            Logger.getLogger(StratusOthersDispacher.class.getName()).log(Level.SEVERE, null, ex);
            return "<Transacao> <Promo> "+ExceptionUtils.getStackTrace(ex) +"</Promo></Transacao>";
        } 
        return "<Transacao><Promo>" +
                nvlTag("DataHoraAut", sdfDataHoraMinuto.format(vo.getDataHoraStratus())) +
                nvlTag("CodSite", vo.getChaveMaquina()) +
                nvlTag("CodProdutoCompleto", vo.getProdutoCompleto()) +
                nvlTag("CodStatus", vo.getIdStatus().getValue()) +
                nvlTag("CodSolCapt", vo.getTipoTecnologia()) +
                nvlTag("FlagPP", vo.getFlagCieloPromo())+
                "</Promo></Transacao>";
        
    }
    
    private String nvlTag(String tag, Object valor) {
        return valor == null ? "" : "<" + tag + ">" + valor + "</" + tag + ">";
    }
}
