package br.com.cielo.monitoracao.business;

public class BusinessValidatorException extends Exception {

}
