/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.monitoracao.business;

import br.com.cielo.monitoracao.autorizador.parser.vo.bam.TransacaoBAM;

/**
 *
 * @author nemer
 */
public interface MatchRule <T extends TransacaoBAM> {
    
    public boolean match(T transaction);
    
}
