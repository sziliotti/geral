/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.monitoracao.business.impl;

import br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO;
import br.com.cielo.monitoracao.business.MatchRule;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.lang.StringUtils;

/**
 * Verifica se a transação é LIO e/ou POS COMBO
 * @author nemer
 */
public class LioComboMatchRule implements MatchRule<MonitoracaoTransacaoAutorizadorVO>{

    private static final List<Integer> MODOS_CONEXAO_COMBO = Arrays.asList(new Integer[]{71,01});
    private static final List<String> NOS_LOGICOS_COMBO = Arrays.asList(new String[]{"WIFIC","WIFIO","WIFIT","WIFIV","CLASC","VIV32","TIM32","OIV32"});
    
    protected enum LIOCOMBOTYPE {LIO, COMBO, NONE};
    private LIOCOMBOTYPE type=LIOCOMBOTYPE.NONE;
    @Override
    public boolean match(MonitoracaoTransacaoAutorizadorVO transaction) {
        if ("LIOP0".equalsIgnoreCase(transaction.getCodigoNo())) {
            type = LIOCOMBOTYPE.LIO;
            return true;
        } else if (StringUtils.isNotBlank(transaction.getModoConexao()) && StringUtils.isNumeric(transaction.getModoConexao()) 
                && MODOS_CONEXAO_COMBO.contains(Integer.valueOf(transaction.getModoConexao())) &&
                NOS_LOGICOS_COMBO.contains(transaction.getCodigoNo())) {
            type = LIOCOMBOTYPE.COMBO;
            return true;
        }
        return false;
    }
    
    public LIOCOMBOTYPE getType() {
     return this.type;   
    }
}
