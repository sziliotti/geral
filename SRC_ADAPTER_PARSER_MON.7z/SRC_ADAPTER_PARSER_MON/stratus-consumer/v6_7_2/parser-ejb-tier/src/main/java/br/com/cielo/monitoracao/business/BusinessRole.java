package br.com.cielo.monitoracao.business;

public interface BusinessRole {

}
