package br.com.cielo.monitoracao.autorizador.test;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Test Suite contendo os testes unitarios para as classes do projeto Monitoracao-Parser.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class MonitoracaoParserTestsSuite extends TestCase {

	/**
	 * Metodo contendo as classes de testes unitarios a serem testados.
	 * 
	 * @return
	 */
	public static Test suite() {
		TestSuite suite = new TestSuite(MonitoracaoParserTestsSuite.class.getName());
		//$JUnit-BEGIN$
		suite.addTestSuite(TransacaoStratusParserTest.class);
		suite.addTestSuite(TransacaoMonitoracaoParserTest.class);
		suite.addTestSuite(CompactarMensagemTest.class);
		
		//$JUnit-END$
		return suite;
	}

}
