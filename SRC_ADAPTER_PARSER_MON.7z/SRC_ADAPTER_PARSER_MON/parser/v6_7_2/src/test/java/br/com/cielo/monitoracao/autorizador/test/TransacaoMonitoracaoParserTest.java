package br.com.cielo.monitoracao.autorizador.test;

import java.util.ArrayList;
import java.util.Iterator;

import br.com.cielo.monitoracao.autorizador.parser.ParserConverterUtils;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoMonitoracaoParser;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoParserBuilder;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoStratusParser;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO;
import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.TransacaoStratusVO;

/**
 *<B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 *
 * Classe de Test Case, responsavel pelo parser da mensagem da classe TransacaoMonitoracaoParser.
 *	 
 *<DL><DT><B>Criada em:</B><DD>04/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class TransacaoMonitoracaoParserTest extends TransacaoParseTest {
	TransacaoStratusVO transacaoStratus;
	
	/**
	 * @param name
	 */
	public TransacaoMonitoracaoParserTest(String name) {
		super(name);
	}

	/* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.autorizador.test.TransacaoParseTest#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();	
	}

	/* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.autorizador.test.TransacaoParseTest#tearDown()
	 */
	protected void tearDown() throws Exception {
		super.tearDown();
		
		transacaoStratus= null;
	}

	/**
	 * Test method for {@link br.com.cielo.monitoracao.autorizador.parser.TransacaoMonitoracaoParser#converter(br.com.cielo.monitoracao.autorizador.parser.vo.stratus.TransacaoStratusVO)}.
	 */
	public void testConverter() throws Exception{
		TransacaoStratusParser transacaoStratusParser= TransacaoParserBuilder.getTransacaoStratusParser();
		TransacaoMonitoracaoParser monitoracaoParser= TransacaoParserBuilder.getTransacaoMonitoracaoParser();
				
		ArrayList<String> transacoesStratus= this.retornaTransacoes();
		for (Iterator<String> iterator= transacoesStratus.iterator(); iterator.hasNext();) {
			msgStratus= iterator.next();			
			msgBytes= ParserConverterUtils.hexToBytes(msgStratus);			
			
			transacaoStratus= transacaoStratusParser.converter(msgBytes);						
			MonitoracaoTransacaoAutorizadorVO transacaoMonitoracao= monitoracaoParser.converter(transacaoStratus);
			
			assertNotNull("Objeto não é nulo.", transacaoMonitoracao);
			
			System.out.println("Campos encontrados Transacao Monitoracao: "+ transacaoMonitoracao.toString());
			System.out.println("=====================================================================================================================================");
		}		
	}
	
	/**
	 * Test method for {@link br.com.cielo.monitoracao.autorizador.parser.TransacaoMonitoracaoParser#converter(br.com.cielo.monitoracao.autorizador.parser.vo.stratus.TransacaoStratusVO)}.
	 * Referente a transação do tipo DCC.
	 * 
	 * @throws Exception
	 */
	public void testConverterDCCTransaction() throws Exception{
		TransacaoStratusParser transacaoStratusParser= TransacaoParserBuilder.getTransacaoStratusParser();
		TransacaoMonitoracaoParser monitoracaoParser= TransacaoParserBuilder.getTransacaoMonitoracaoParser();
				
		String arquivoTransacoes= "/transacoes-DCC.txt";
		ArrayList<String> transacoesStratus= this.retornaTransacoes(arquivoTransacoes);
		System.out.println("====================================================== TRANSACOES DCC ===============================================================");
		for (Iterator<String> iterator= transacoesStratus.iterator(); iterator.hasNext();) {
			msgStratus= iterator.next();			
			msgBytes= ParserConverterUtils.hexToBytes(msgStratus);			
			
			transacaoStratus= transacaoStratusParser.converter(msgBytes);						
			MonitoracaoTransacaoAutorizadorVO transacaoMonitoracao= monitoracaoParser.converter(transacaoStratus);
			
			assertNotNull("Objeto não é nulo.", transacaoMonitoracao);
			
			//verificar se contem objeto referente a DCC.
			assertTrue(transacaoMonitoracao.isDCC());
			assertNotNull("Objeto não é nulo.", transacaoMonitoracao.getInformacoesDCC());
			
			System.out.println("Campos encontrados Transacao Monitoracao: "+ transacaoMonitoracao.toString());
			System.out.println("=====================================================================================================================================");
		}
	}
}
