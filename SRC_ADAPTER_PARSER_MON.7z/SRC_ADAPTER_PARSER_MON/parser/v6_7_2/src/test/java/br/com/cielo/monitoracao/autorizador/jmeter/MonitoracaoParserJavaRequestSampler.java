package br.com.cielo.monitoracao.autorizador.jmeter;

import java.io.Serializable;

import org.apache.jmeter.protocol.java.sampler.AbstractJavaSamplerClient;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;

import br.com.cielo.monitoracao.autorizador.parser.ParserConverterUtils;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoMonitoracaoParser;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoParserBuilder;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoStratusParser;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO;

/**
 *<B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 *
 * Classe client responsável para Java Sampler do JMeter. 
 *	 
 *<DL><DT><B>Criada em:</B><DD>14/10/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class MonitoracaoParserJavaRequestSampler extends AbstractJavaSamplerClient implements Serializable {
	private static final long serialVersionUID= 1L;
	
	// set up default arguments for the JMeter GUI
    /* (non-Javadoc)
     * @see org.apache.jmeter.protocol.java.sampler.AbstractJavaSamplerClient#getDefaultParameters()
     */
    @Override
    public Arguments getDefaultParameters() {
        Arguments defaultParameters= new Arguments();
        defaultParameters.addArgument("ValorTransacao", "");
        
        return defaultParameters;
    }

	/* (non-Javadoc)
	 * @see org.apache.jmeter.protocol.java.sampler.JavaSamplerClient#runTest(org.apache.jmeter.protocol.java.sampler.JavaSamplerContext)
	 */	
	@SuppressWarnings("deprecation")
	public SampleResult runTest(JavaSamplerContext context) {
		String valTransacao= context.getParameter("ValorTransacao");
		
		SampleResult result= new SampleResult();
        result.sampleStart(); // start stopwatch
                
        try {        	
        	//Implementa parser.
        	String msgStratus= valTransacao.substring(4);
        	byte[] msgBytes= ParserConverterUtils.hexToBytes(msgStratus);
			
    		TransacaoStratusParser stratusParser= TransacaoParserBuilder.getTransacaoStratusParser();
    		TransacaoMonitoracaoParser monitoracaoParser= TransacaoParserBuilder.getTransacaoMonitoracaoParser();
    		
    		@SuppressWarnings("unused")
			MonitoracaoTransacaoAutorizadorVO transacaoMonitoracao= monitoracaoParser.converter(stratusParser.converter(msgBytes));
        	
        	result.sampleEnd(); // stop stopwatch
            result.setSuccessful(true);
            result.setResponseMessage("Successfully performed action");
            result.setResponseCodeOK(); // 200 code
        	
        }catch (Exception e) {
        	result.sampleEnd(); // stop stopwatch
            result.setSuccessful( false );
            result.setResponseMessage("Exception: " + e);
 
            // get stack trace as a String to return as document data
            java.io.StringWriter stringWriter= new java.io.StringWriter();
            e.printStackTrace(new java.io.PrintWriter(stringWriter));
            result.setResponseData(stringWriter.toString());
            result.setDataType(org.apache.jmeter.samplers.SampleResult.TEXT);
            result.setResponseCode("500");
        }
        
		return result;
	}

	/* (non-Javadoc)
	 * @see org.apache.jmeter.protocol.java.sampler.AbstractJavaSamplerClient#setupTest(org.apache.jmeter.protocol.java.sampler.JavaSamplerContext)
	 */
	@Override
	public void setupTest(JavaSamplerContext context) {
		
	}

	/* (non-Javadoc)
	 * @see org.apache.jmeter.protocol.java.sampler.AbstractJavaSamplerClient#teardownTest(org.apache.jmeter.protocol.java.sampler.JavaSamplerContext)
	 */
	@Override
	public void teardownTest(JavaSamplerContext context) {
		
	}

}
