package br.com.cielo.monitoracao.autorizador.main;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import br.com.cielo.monitoracao.autorizador.parser.ParserConverterUtils;
import br.com.cielo.monitoracao.autorizador.parser.ParserException;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoMonitoracaoParser;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoParserBuilder;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoStratusParser;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO;

/**
 *<B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 *
 * Classe Main para teste de Parser das transações vindas do Stratus, transformando no objeto MonitoracaoTransacaoAutorizadorVO.
 *	 
 *<DL><DT><B>Criada em:</B><DD>03/10/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class VerificarMonitoracaoParserStandInMain {
	private static String fileSamples;

	/**
	 * @param args
	 */
	public static void main(String[] args)throws Exception {
		Map<String, String> params= new HashMap<String, String>();
		for(int i = 0; i < args.length; i++) {
			String[] param = args[i].split("=", 2);
			params.put(param[0], param[1]);
		}
		String value;
		if (null != (value = params.get("--fileSamples"))) {
			fileSamples= value;
		}
		
		
		
		VerificarMonitoracaoParserStandInMain simulador= new VerificarMonitoracaoParserStandInMain();
		
		String nomeArquivo= null;
		File arquivoFisico= null;
		Scanner scanner;
		if(fileSamples != null){
			arquivoFisico= new File(fileSamples);
			scanner= new Scanner(arquivoFisico);
		}else{
			nomeArquivo= "/transacoes_07-10_10-10.txt";
			nomeArquivo= "/transacoesPAY.txt";
			nomeArquivo= "/transacoes-DCC.txt";
			
			scanner= new Scanner(simulador.getClass().getResourceAsStream(nomeArquivo));
		}
				
		int i= 1;
		long inicio= System.currentTimeMillis();
		while(scanner.hasNext()) {
			String msgLine= scanner.next();
			
			if(msgLine != null && !msgLine.equals("")){
				String[] msgQuebrada= msgLine.split(";");
				String msgStratus;
				if(fileSamples == null){
					//Elimina os 4 primeiros caracters, referentes ao tamanho da mensagem.
					msgStratus= msgLine.substring(4);
				}else{
					msgStratus= msgQuebrada[16];
				}				
				/*System.out.println("============================================================================================================================================");
				System.out.println("[TESTE] MENSAGEM ("+i+"): "+msgStratus);*/				
				simulador.montarTransacaoMonitoracao(msgStratus);
				//System.out.println("============================================================================================================================================");
				
				i++;
			}			
		}
		long termino= System.currentTimeMillis();
		long dif= termino - inicio;
		System.out.println("***************************************************************************");		
		System.out.println("TEMPO PROCESSAMENTO: "+ String.format("%02d segundos e %02d milisegundos.", dif/1000, dif%1000));
		System.out.println("***************************************************************************");
	}
		
	/**
	 * @param msg
	 */
	public void montarTransacaoMonitoracao(String msg){
		byte[] msgBytes= ParserConverterUtils.hexToBytes(msg);
				
		TransacaoStratusParser stratusParser= TransacaoParserBuilder.getTransacaoStratusParser();
		TransacaoMonitoracaoParser monitoracaoParser= TransacaoParserBuilder.getTransacaoMonitoracaoParser();
		try {
			MonitoracaoTransacaoAutorizadorVO transacaoMonitoracao= monitoracaoParser.converter(stratusParser.converter(msgBytes));
				
			//Verifica se é StandIn
			if("SI".equalsIgnoreCase(transacaoMonitoracao.getQuemRespondeu()) ){
				System.out.println("============================================================================================================================================");
				System.out.println("Campos Transacao Monitoracao do Tipo STAND-IN: "+ transacaoMonitoracao.toString());
				System.out.println("============================================================================================================================================");
			}
		
		} catch (ParserException e) {			
			e.printStackTrace();
		}	
	}
		
}
