package br.com.cielo.monitoracao.autorizador.test;

import java.util.ArrayList;
import java.util.Scanner;

import junit.framework.TestCase;

/**
 *<B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 *
 * Classe Pai contendo informações da mensagem a ser usada.
 *	 
 *<DL><DT><B>Criada em:</B><DD>dd/mm/aaaa</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class TransacaoParseTest extends TestCase {
	String msgStratus;
	byte[] msgBytes;
	
	/**
	 * @param name
	 */
	public TransacaoParseTest(String name) {
		super(name);
	}

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
	}

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#tearDown()
	 */
	protected void tearDown() throws Exception {
		super.tearDown();
		
		msgStratus= null;
		msgBytes= null;
	}
	
	/**
	 * @throws Exception
	 */
	public void testMethod() throws Exception{
		assertTrue("Metodo Classe Pai.", true);		
	}
	
	/**
	 * Método responsavel em retornar a lista de transações, localizadas no arquivo "transacoes.txt" para teste.
	 * 
	 * @return
	 * 		ArrayList com cada transação gravada no arquivo.
	 */
	protected ArrayList<String> retornaTransacoes(){			
		return this.retornaTransacoes("/transacoes.txt");
	}
	
	/**
	 * Método responsavel em retornar a lista de transações, localizadas no arquivo txt recebido como parametro para teste.
	 * 
	 * 	
	 * @param nomeArquivo
	 * 		Nome do arquivo a ser lido
	 * @return
	 * 		ArrayList com cada transação gravada no arquivo.
	 */
	protected ArrayList<String> retornaTransacoes(String nomeArquivo){
		ArrayList<String> conjuntoTransacoes= new ArrayList<String>();		
		
		Scanner scanner= new Scanner(getClass().getResourceAsStream(nomeArquivo));		
		while (scanner.hasNext()) {
			String msgLine= scanner.next();
			
			if(msgLine != null && !msgLine.equals("")){
				//Elimina os 4 primeiros caracters, referentes ao tamanho da mensagem.
				String msgStratus= msgLine.substring(4);
				
				conjuntoTransacoes.add(msgStratus);
			}
		}		
		return conjuntoTransacoes;
	}

}
