package br.com.cielo.monitoracao.autorizador.main.thread;

import br.com.cielo.monitoracao.autorizador.parser.ParserException;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoMonitoracaoParser;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoParserBuilder;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoStratusParser;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO;
import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.TransacaoStratusVO;

/**
 *<B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 *
 * 
 *	 
 *<DL><DT><B>Criada em:</B><DD>16/10/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class MonitoracaoParserThread implements Runnable{
	
	private byte[] msgBytes;
	private long numeroTran;
	private int id;
	
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @param msgBytes the msgBytes to set
	 */
	public void setMsgBytes(byte[] msgBytes) {
		this.msgBytes = msgBytes;
	}
	/**
	 * @param numeroTran the numeroTran to set
	 */
	public void setNumeroTran(long numeroTran) {
		this.numeroTran = numeroTran;
	}

			
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		long inicioParserStratus= System.currentTimeMillis();
		
		for(long i= 1; i<=numeroTran; i++) {
			TransacaoStratusParser stratusParser= TransacaoParserBuilder.getTransacaoStratusParser();
			TransacaoMonitoracaoParser monitoracaoParser= TransacaoParserBuilder.getTransacaoMonitoracaoParser();
			
			try {				
				TransacaoStratusVO stratusVo= stratusParser.converter(msgBytes);			
				@SuppressWarnings("unused")
				MonitoracaoTransacaoAutorizadorVO transacaoMonitoracao= monitoracaoParser.converter(stratusVo);
										
			} catch (ParserException e) {			
				e.printStackTrace();
			}
		}
		
		long terminoParserMon= System.currentTimeMillis();		
		long difStratMon= terminoParserMon - inicioParserStratus;
		
		System.out.println("*******************************************************************************************************************");	
		System.out.println("		TEMPO PROCESSAMENTO PARSER STRATUS E MONITORACAO id("+id+") Qtde Transações: ("+numeroTran+"): "+ String.format("%02d segundos e %02d milisegundos.", difStratMon/1000, difStratMon%1000));
		System.out.println("*******************************************************************************************************************");
	}
		
}
