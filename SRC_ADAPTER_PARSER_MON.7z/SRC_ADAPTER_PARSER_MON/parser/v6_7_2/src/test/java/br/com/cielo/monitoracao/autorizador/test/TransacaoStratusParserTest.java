package br.com.cielo.monitoracao.autorizador.test;

import java.util.ArrayList;
import java.util.Iterator;

import br.com.cielo.monitoracao.autorizador.parser.ParserConverterUtils;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoParserBuilder;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoStratusParser;
import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.TransacaoStratusVO;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Classe de Test Case, responsavel pelo parser da mensagem da classe TransacaoStratusParser.
 * 
 * <DL><DT><B>Criada em:</B><DD>03/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class TransacaoStratusParserTest extends TransacaoParseTest {	
	
	/**
	 * @param name
	 */
	public TransacaoStratusParserTest(String name) {
		super(name);		
	}

		
	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();		
	}

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#tearDown()
	 */
	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	/**
	 * Método para teste OK do metodo: converter() da classe TransacaoStratusParser.
	 * 
	 * @throws Exception
	 */
	public void testConverter() throws Exception{
		TransacaoStratusParser transacaoStratusParser= TransacaoParserBuilder.getTransacaoStratusParser();
		
		ArrayList<String> transacoesStratus= this.retornaTransacoes();
		for (Iterator<String> iterator= transacoesStratus.iterator(); iterator.hasNext();) {
			msgStratus= iterator.next();
			
			msgBytes= ParserConverterUtils.hexToBytes(msgStratus);			
			TransacaoStratusVO transacaoStratus= transacaoStratusParser.converter(msgBytes);
			
			assertTrue("Quantidade de campos retornados maior que 0.", (transacaoStratus.getNomesCamposLogico().size() > 0));
							
			System.out.println("Campos encontrados Transacao Stratus: "+ transacaoStratus.getNomesCamposLogico());
			System.out.println("=====================================================================================================================================");
		}
	}
	
	/**
	 * Método para teste OK do metodo: converter() da classe TransacaoStratusParser, referente as transações do tipo DCC.
	 * 
	 * @throws Exception
	 */
	public void testConverterDCCTransaction() throws Exception{
		TransacaoStratusParser transacaoStratusParser= TransacaoParserBuilder.getTransacaoStratusParser();
		
		String arquivoTransacoes= "/transacoes-DCC.txt";
		ArrayList<String> transacoesStratus= this.retornaTransacoes(arquivoTransacoes);
		System.out.println("====================================================== TRANSACOES DCC ===============================================================");
		for (Iterator<String> iterator= transacoesStratus.iterator(); iterator.hasNext();) {
			msgStratus= iterator.next();
			
			msgBytes= ParserConverterUtils.hexToBytes(msgStratus);			
			TransacaoStratusVO transacaoStratus= transacaoStratusParser.converter(msgBytes);
			
			assertTrue("Quantidade de campos retornados maior que 0.", (transacaoStratus.getNomesCamposLogico().size() > 0));
			
			//Verificar se contem campos 073 e 901.
			assertNotNull(transacaoStratus.getCampoLogico("CPO_073"));
			assertNotNull(transacaoStratus.getCampoLogico("CPO_901"));
							
			System.out.println("Campos encontrados Transacao Stratus: "+ transacaoStratus.getNomesCamposLogico());
			System.out.println("=====================================================================================================================================");
		}
	}
}
