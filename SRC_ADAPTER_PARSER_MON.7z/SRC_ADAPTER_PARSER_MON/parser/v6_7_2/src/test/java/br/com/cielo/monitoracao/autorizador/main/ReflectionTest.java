package br.com.cielo.monitoracao.autorizador.main;

import java.util.concurrent.ConcurrentHashMap;

import org.reflections.Reflections;

import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.CampoLogicoVO;

public class ReflectionTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ConcurrentHashMap<String, CampoLogicoVO> camposLogicos= new ConcurrentHashMap<String, CampoLogicoVO>();
		try {
	        String packageName= "br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos";        
	        Reflections reflections= new Reflections(packageName);
	
	        System.out.println("QTDE TOTAL DE CAMPOS: "+reflections.getSubTypesOf(CampoLogicoVO.class).size());
	        for(Class<? extends CampoLogicoVO> c : reflections.getSubTypesOf(CampoLogicoVO.class)) {
	        	System.out.println("CLASSE=["+c.getSimpleName()+"] | NOME COMPLETO=["+c.getCanonicalName()+"]");
	        	
	        	camposLogicos.put(c.getSimpleName(), c.newInstance());
	        }
	        System.out.println("QTDE TOTAL DE OBJETOS NO VETOR: "+camposLogicos.size());
	       
        } catch (Exception e) {
            e.printStackTrace();
        }        
	}
}
