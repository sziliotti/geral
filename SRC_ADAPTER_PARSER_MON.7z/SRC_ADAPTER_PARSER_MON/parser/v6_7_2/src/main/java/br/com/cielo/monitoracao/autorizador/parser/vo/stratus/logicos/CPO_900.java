package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_900, sobre Dados do xx.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_900 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String brb01Terminal;
	private String brb01Lote;
	private String brb01Sequencial;
	
	public CPO_900(){		
	}

	/**
	 * @return the brb01Terminal
	 */
	@PositionalField(initialPosition= 1, finalPosition= 8)
	public String getBrb01Terminal() {
		return brb01Terminal;
	}

	/**
	 * @param brb01Terminal the brb01Terminal to set
	 */
	public void setBrb01Terminal(String brb01Terminal) {
		this.brb01Terminal = brb01Terminal;
	}

	/**
	 * @return the brb01Lote
	 */
	@PositionalField(initialPosition= 9, finalPosition= 14)
	public String getBrb01Lote() {
		return brb01Lote;
	}

	/**
	 * @param brb01Lote the brb01Lote to set
	 */
	public void setBrb01Lote(String brb01Lote) {
		this.brb01Lote = brb01Lote;
	}

	/**
	 * @return the brb01Sequencial
	 */
	@PositionalField(initialPosition= 15, finalPosition= 26)
	public String getBrb01Sequencial() {
		return brb01Sequencial;
	}

	/**
	 * @param brb01Sequencial the brb01Sequencial to set
	 */
	public void setBrb01Sequencial(String brb01Sequencial) {
		this.brb01Sequencial = brb01Sequencial;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
