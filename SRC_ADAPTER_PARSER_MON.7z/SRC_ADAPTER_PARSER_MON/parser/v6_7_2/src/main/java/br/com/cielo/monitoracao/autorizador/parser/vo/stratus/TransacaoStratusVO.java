package br.com.cielo.monitoracao.autorizador.parser.vo.stratus;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.CampoLogicoVO;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * <br><br>
 * Classe que representa e contem os campos da Transacao enviada pelo Autorizador Stratus.
 * 
 * <DL><DT><B>Criada em:</B><DD>02/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class TransacaoStratusVO implements Serializable {	
	private static final long serialVersionUID = 1L;
	
	private HashMap<String, CampoLogicoVO> camposLogicos= new HashMap<String, CampoLogicoVO>();
	
	/**
	 * Metodo responsavel em recuperar o campo logico(CampoLogicoVO), atraves do nome informado como parametro.
	 * 
	 * @param nomeCampoLogico
	 * 			Nome do campo que deseja recuperar o objeto CampoLogicoVO.
	 * @return
	 * 		Instancia do objeto CampoLogicoVO, contendo os valores da mensagem.
	 */
	public CampoLogicoVO getCampoLogico(String nomeCampoLogico){
		return this.camposLogicos.get(nomeCampoLogico);
	}
	public void limpaCamposLogicos() {
            camposLogicos.clear();
        }
	/**
	 * Metodo responsavel em adicionar a instancia do campo logico(CampoLogicoVO) a lista de objetos da Transacao Stratus.
	 * 
	 * @param nomeCampoLogico
	 * 			Nome do campo que deseja referenciar o objeto CampoLogicoVO.
	 * @param campoLogico
	 * 			Instancia do objeto CampoLogicoVO, contendo os valores da mensagem. 
	 */
	public void addCampoLogico(String nomeCampoLogico, CampoLogicoVO campoLogico){
		this.camposLogicos.put(nomeCampoLogico, campoLogico);
	}
		
	/**
	 * Metodo responsavel em recuperar os nomes dos campos logicos, contidos e efetuados parser na mensagem
	 * TransacaoStratusVO.
	 * 
	 * @return
	 * 		Lista dos nomes dos campos que foram efetuados parsers.
	 */
	public ArrayList<String> getNomesCamposLogico(){		
		return new ArrayList<String>(camposLogicos.keySet());
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer sb= new StringBuffer();
		sb.append("==================================================================================================================\n");
		sb.append("TransacaoStratusVO {\n");
		
		for (Iterator<String> iterator= this.getNomesCamposLogico().iterator(); iterator.hasNext();) {
			String nomeCampo= iterator.next();
			
			CampoLogicoVO campoLogico= this.getCampoLogico(nomeCampo);
			sb.append("[CAMPO_LOGICO ("+nomeCampo+")==");
			sb.append(campoLogico.toString());
			sb.append("]\n");
		}		
		sb.append("}\n");
		sb.append("==================================================================================================================\n");
		return sb.toString();
	}
	
}
