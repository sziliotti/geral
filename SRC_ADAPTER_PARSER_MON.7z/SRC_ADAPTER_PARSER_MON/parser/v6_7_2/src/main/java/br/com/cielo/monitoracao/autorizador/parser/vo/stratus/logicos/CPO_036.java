package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_036, sobre .
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_036 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String bit53Tipcri;
	private String terminalKsnIndbdk;
	private String terminalKsnIdPin;
	private String terminalKsnCTTR;
	private String terminalChaveMestre;
	
	
	public CPO_036(){		
	}


	/**
	 * @return the bit53Tipcri
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public String getBit53Tipcri() {
		return bit53Tipcri;
	}


	/**
	 * @param bit53Tipcri the bit53Tipcri to set
	 */
	public void setBit53Tipcri(String bit53Tipcri) {
		this.bit53Tipcri = bit53Tipcri;
	}


	/**
	 * @return the terminalKsnIndbdk
	 */
	@PositionalField(initialPosition= 3, finalPosition= 8)
	public String getTerminalKsnIndbdk() {
		return terminalKsnIndbdk;
	}


	/**
	 * @param terminalKsnIndbdk the terminalKsnIndbdk to set
	 */
	public void setTerminalKsnIndbdk(String terminalKsnIndbdk) {
		this.terminalKsnIndbdk = terminalKsnIndbdk;
	}


	/**
	 * @return the terminalKsnIdPin
	 */
	@PositionalField(initialPosition= 9, finalPosition= 14)
	public String getTerminalKsnIdPin() {
		return terminalKsnIdPin;
	}


	/**
	 * @param terminalKsnIdPin the terminalKsnIdPin to set
	 */
	public void setTerminalKsnIdPin(String terminalKsnIdPin) {
		this.terminalKsnIdPin = terminalKsnIdPin;
	}


	/**
	 * @return the terminalKsnCTTR
	 */
	@PositionalField(initialPosition= 15, finalPosition= 20)
	public String getTerminalKsnCTTR() {
		return terminalKsnCTTR;
	}


	/**
	 * @param terminalKsnCTTR the terminalKsnCTTR to set
	 */
	public void setTerminalKsnCTTR(String terminalKsnCTTR) {
		this.terminalKsnCTTR = terminalKsnCTTR;
	}


	/**
	 * @return the terminalChaveMestre
	 */
	@PositionalField(initialPosition= 21, finalPosition= 22)
	public String getTerminalChaveMestre() {
		return terminalChaveMestre;
	}


	/**
	 * @param terminalChaveMestre the terminalChaveMestre to set
	 */
	public void setTerminalChaveMestre(String terminalChaveMestre) {
		this.terminalChaveMestre = terminalChaveMestre;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
