package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 *<B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_029, sobre Dados xxxxx. 
 * 
 * <DL><DT><B>Criada em:</B><DD>23/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
@PositionalRecord
public class CPO_029 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	public static Logger logger= LoggerFactory.getLogger(CPO_029.class);
	
	private String cvvIcvv;
	private String resultArqc;
	private String resultadoCvv2;
	private String resultadoCvs;
	
	
	public CPO_029(){		
	}
	
	/**
	 *  Representa o Campo STRATUS: ACTR-P44-05-CVV-ICVV
	 * 
	 * @return the cvvIcvv
	 */
	@PositionalField(initialPosition= 1, finalPosition= 1)
	public String getCvvIcvv() {
		return cvvIcvv;
	}

	/**
	 * @param cvvIcvv the cvvIcvv to set
	 */
	public void setCvvIcvv(String cvvIcvv) {
		this.cvvIcvv = cvvIcvv;
	}

	/**
	 *  Representa o Campo STRATUS: ACTR-P44-08-RESULT-ARQC
	 * 
	 * @return the resultArqc
	 */
	@PositionalField(initialPosition= 2, finalPosition= 2)
	public String getResultArqc() {
		return resultArqc;
	}

	/**
	 * @param resultArqc the resultArqc to set
	 */
	public void setResultArqc(String resultArqc) {
		this.resultArqc = resultArqc;
	}

	/**
	 *  Representa o Campo STRATUS: ACTR-P44-10-RESULTADO-CVV2
	 * 
	 * @return the resultadoCvv2
	 */
	@PositionalField(initialPosition= 3, finalPosition= 3)
	public String getResultadoCvv2() {
		return resultadoCvv2;
	}

	/**
	 * @param resultadoCvv2 the resultadoCvv2 to set
	 */
	public void setResultadoCvv2(String resultadoCvv2) {
		this.resultadoCvv2 = resultadoCvv2;
	}

	/**
	 *  Representa o Campo STRATUS: ACTR-P44-02-RESULTADO-AVS
	 * 
	 * @return the resultadoCvs
	 */
	@PositionalField(initialPosition= 4, finalPosition= 4)
	public String getResultadoCvs() {
		return resultadoCvs;
	}

	/**
	 * @param resultadoCvs the resultadoCvs to set
	 */
	public void setResultadoCvs(String resultadoCvs) {
		this.resultadoCvs = resultadoCvs;
	}

	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
