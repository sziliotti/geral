package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;


/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_021, referente AVS.
 * 
 * <DL><DT><B>Criada em:</B><DD>19/12/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_021 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String cep;
	private String cpf;
	private String endereco;
	private String filler;
	
	
	public CPO_021(){		
	}
	
	
	/**	 
	 * Representa o Campo STRATUS: ACTR-AVS-CEP
	 *	 
	 * @return the flagFallBack
	 */
	@PositionalField(initialPosition= 1, finalPosition= 8)
	public String getCep() {
		return cep;
	}
	/**
	 * @param cep the cep to set
	 */
	public void setCep(String cep) {
		this.cep = cep;
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-AVS-CPF
	 *	 
	 * @return the flagFallBack
	 */
	@PositionalField(initialPosition= 9, finalPosition= 18)
	public String getCpf() {
		return cpf;
	}
	/**
	 * @param cpf the cpf to set
	 */
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-AVS-ENDERECO
	 *	 
	 * @return the flagFallBack
	 */
	@PositionalField(initialPosition= 19, finalPosition= 26)
	public String getEndereco() {
		return endereco;
	}
	/**
	 * @param endereco the endereco to set
	 */
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	
	/**	 
	 * Representa o Campo STRATUS: FILLER
	 *	 
	 * @return the flagFallBack
	 */
	@PositionalField(initialPosition= 27, finalPosition= 27)
	public String getFiller() {
		return filler;
	}
	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		this.filler = filler;
	}


	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
