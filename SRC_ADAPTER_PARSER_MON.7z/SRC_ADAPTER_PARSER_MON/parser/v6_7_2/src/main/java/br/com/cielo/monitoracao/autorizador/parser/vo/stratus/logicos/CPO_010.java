package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator.YearMonthDecorator;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_010, sobre Dados do Cartao.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_010 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	public static Logger logger= LoggerFactory.getLogger(CPO_010.class);
	
	/*private SimpleDateFormat dateFormat= new SimpleDateFormat("yyMM");*/
	
	private Date dataVencimento;
	private int tamanhoCartao;
	private String numeroCartao;
	private String emvFull;
	private String cashBack;
	private String bloqueado;
	private String flagCartaoTeste;
	private String flagCTF;
	
	public CPO_010(){
		
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-DTA-VENC
	 *
	 * @return the dataVencimento
	 */
	@PositionalField(initialPosition= 1, finalPosition= 4, decorator= YearMonthDecorator.class)
	public Date getDataVencimento() {
		return dataVencimento;
	}
	/**
	 * @param dataVencimento the dataVencimento to set
	 */
	/*public void setDataVencimento(String dataVencimento) {
		try {
			this.dataVencimento = dateFormat.parse(dataVencimento);
		} catch (ParseException e) {
			this.dataVencimento= null;
			logger.warn("Erro realizando parser no objeto [CPO_010], em campo data[dataVencimento]. Valor recebido= '"+dataVencimento+"'");			
		}		
	}*/

	/**
	 * @param dataVencimento the dataVencimento to set
	 */
	public void setDataVencimento(Date dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-CARTAO-TAM 
	 *
	 * @return the tamanhoCartao
	 */
	@PositionalField(initialPosition= 5, finalPosition= 6)
	public int getTamanhoCartao() {
		return tamanhoCartao;
	}
	/**
	 * @param tamanhoCartao the tamanhoCartao to set
	 */
	public void setTamanhoCartao(String tamanhoCartao) {		
		try {
			this.tamanhoCartao= Integer.parseInt(tamanhoCartao);
		} catch (NumberFormatException e) {
			this.tamanhoCartao= 0;
			logger.warn("Erro realizando parser no objeto [CPO_010], em campo N�merico[tamanhoCartao]. Valor recebido= '"+tamanhoCartao+"'");			
		}	
	}
	/**
	 * @param tamanhoCartao the tamanhoCartao to set
	 */
	public void setTamanhoCartao(int tamanhoCartao) {
		this.tamanhoCartao = tamanhoCartao;
	}
	
	/** 
	 * Representa o Campo STRATUS: ACTR-CARTAO-NUM
	 *
	 * @return the numeroCartao
	 */
	@PositionalField(initialPosition= 7, finalPosition= 25)
	public String getNumeroCartao() {
		return numeroCartao;
	}

	/**
	 * @param numeroCartao the numeroCartao to set
	 */
	public void setNumeroCartao(String numeroCartao) {
		this.numeroCartao = numeroCartao;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-EMVFULL 
	 *
	 * @return the emvFull
	 */
	@PositionalField(initialPosition= 26, finalPosition= 26)
	public String getEmvFull() {
		return emvFull;
	}

	/**
	 * @param emvFull the emvFull to set
	 */
	public void setEmvFull(String emvFull) {
		this.emvFull = emvFull;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-CASH-BACK
	 *
	 * @return the cashBack
	 */
	@PositionalField(initialPosition= 27, finalPosition= 27)
	public String getCashBack() {
		return cashBack;
	}

	/**
	 * @param cashBack the cashBack to set
	 */
	public void setCashBack(String cashBack) {
		this.cashBack = cashBack;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-BLOQUEADO
	 *
	 * @return the bloqueado
	 */
	@PositionalField(initialPosition= 28, finalPosition= 28)
	public String getBloqueado() {
		return bloqueado;
	}

	/**
	 * @param bloqueado the bloqueado to set
	 */
	public void setBloqueado(String bloqueado) {
		this.bloqueado = bloqueado;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-FL-CARTAO-TESTE
	 *
	 * @return the flagCartaoTeste
	 */
	@PositionalField(initialPosition= 29, finalPosition= 29)
	public String getFlagCartaoTeste() {
		return flagCartaoTeste;
	}

	/**
	 * @param flagCartaoTeste the flagCartaoTeste to set
	 */
	public void setFlagCartaoTeste(String flagCartaoTeste) {
		this.flagCartaoTeste = flagCartaoTeste;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-FLAG-CTF
	 *
	 * @return the flagCTF
	 */
	@PositionalField(initialPosition= 30, finalPosition= 30)
	public String getFlagCTF() {
		return flagCTF;
	}

	/**
	 * @param flagCTF the flagCTF to set
	 */
	public void setFlagCTF(String flagCTF) {
		this.flagCTF = flagCTF;
	}

	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
