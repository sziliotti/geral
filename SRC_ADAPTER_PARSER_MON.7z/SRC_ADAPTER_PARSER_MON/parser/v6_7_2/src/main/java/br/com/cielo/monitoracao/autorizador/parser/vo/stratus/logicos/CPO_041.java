package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_041, sobre Dados do xx.
 * 
 * <DL><DT><B>Criada em:</B><DD>04/10/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_041 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String estabelecimentoOrigemPDV;
	private String cabecalhoPDV;
	private String filler;
	
	public CPO_041(){		
	}
	

	/**
	 * Representa o Campo STRATUS: ACTR-ESTAB-ORI-PDV
	 * 
	 * @return the estabelecimentoOrigemPDV
	 */
	@PositionalField(initialPosition= 1, finalPosition= 15)
	public String getEstabelecimentoOrigemPDV() {
		return estabelecimentoOrigemPDV;
	}
	/**
	 * @param estabelecimentoOrigemPDV the estabelecimentoOrigemPDV to set
	 */
	public void setEstabelecimentoOrigemPDV(String estabelecimentoOrigemPDV) {
		this.estabelecimentoOrigemPDV = estabelecimentoOrigemPDV;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-CABEC-PDV
	 * 
	 * @return the cabecalhoPDV
	 */
	@PositionalField(initialPosition= 16, finalPosition= 17)
	public String getCabecalhoPDV() {
		return cabecalhoPDV;
	}
	/**
	 * @param cabecalhoPDV the cabecalhoPDV to set
	 */
	public void setCabecalhoPDV(String cabecalhoPDV) {
		this.cabecalhoPDV = cabecalhoPDV;
	}

	
	/**
	 * Representa o Campo STRATUS: FILLER
	 * 
	 * @return the filler
	 */
	@PositionalField(initialPosition= 18, finalPosition= 18)
	public String getFiller() {
		return filler;
	}
	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		this.filler = filler;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
