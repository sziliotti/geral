package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.monitoracao.autorizador.parser.ParserConverterUtils;


/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_035, sobre Dados do campos de comercio eletronico.
 * 
 * <DL><DT><B>Criada em:</B><DD>09/10/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class CPO_035 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	public static Logger logger= LoggerFactory.getLogger(CPO_035.class);
	
	private String numeroCertificadoDigitalPortadorCartao;
	private String tamanhoNumeroCertificadoDigitalEstabelecimento;
	private String numeroCertificadoDigitalEstabelecimento;
	private String transstan;
	private String dadosPrivadoFormatacao;
	private String dadosCAVVCertAut;
	private String tcidPayGateway;
	
	
	public CPO_035(){		
	}
	
	
	/* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.CampoLogicoVO#efetuarParserCampoBinario()
	 */
	@Override
	public void efetuarParserCampoBinario() {
		int idx= 0, tamanho= 0;
		try {			
			tamanho= 32;
			byte[] bbNucert= ParserConverterUtils.subArray(this.getValorCampoBinario(), idx, tamanho);
			this.setNumeroCertificadoDigitalPortadorCartao(ParserConverterUtils.hexToString(bbNucert, "UTF-8"));				
			idx+= tamanho;
				
			tamanho= 4;
			byte[] bbNucertEstTam= ParserConverterUtils.subArray(this.getValorCampoBinario(), idx, tamanho);
			this.setTamanhoNumeroCertificadoDigitalEstabelecimento(ParserConverterUtils.hexToString(bbNucertEstTam, "UTF-8"));				
			idx+= tamanho;
			
			tamanho= 32;
			byte[] bbNucertEst= ParserConverterUtils.subArray(this.getValorCampoBinario(), idx, tamanho);
			this.setNumeroCertificadoDigitalEstabelecimento(ParserConverterUtils.hexToString(bbNucertEst, "UTF-8"));				
			idx+= tamanho;
			
			tamanho= 40;
			byte[] bbTrans= ParserConverterUtils.subArray(this.getValorCampoBinario(), idx, tamanho);
			this.setTransstan(ParserConverterUtils.hexToString(bbTrans, "UTF-8"));
			idx+= tamanho;
			
			tamanho= 6;
			byte[] bbDadosPri= ParserConverterUtils.subArray(this.getValorCampoBinario(), idx, tamanho);
			this.setDadosPrivadoFormatacao(ParserConverterUtils.hexToString(bbDadosPri, "UTF-8"));
			idx+= tamanho;
			
			tamanho= 20;
			byte[] bbDadosCAVV= ParserConverterUtils.subArray(this.getValorCampoBinario(), idx, tamanho);
			this.setDadosCAVVCertAut(ParserConverterUtils.hexToString(bbDadosCAVV, "UTF-8"));				
			idx+= tamanho;
			
			tamanho= 20;
			byte[] bbTcidPay= ParserConverterUtils.subArray(this.getValorCampoBinario(), idx, tamanho);
			this.setTcidPayGateway(ParserConverterUtils.hexToString(bbTcidPay, "UTF-8"));
						
		} catch (Exception e) {
			logger.warn("Erro realizando parser no objeto [CPO_035], no .");
		}		
	}

	
	/**
	 * Representa o Campo STRATUS: ACTR-COEM-NUCEDIPOCA
	 * 
	 * @return the numeroCertificadoDigitalPortadorCartao
	 */	
	public String getNumeroCertificadoDigitalPortadorCartao() {
		return numeroCertificadoDigitalPortadorCartao;
	}
	/**
	 * @param numeroCertificadoDigitalPortadorCartao the numeroCertificadoDigitalPortadorCartao to set
	 */
	public void setNumeroCertificadoDigitalPortadorCartao(String numeroCertificadoDigitalPortadorCartao) {
		this.numeroCertificadoDigitalPortadorCartao = numeroCertificadoDigitalPortadorCartao;
	}

	/**
	 * @return the tamanhaNumeroCertificadoDigitalEstabelecimento
	 */	
	public String getTamanhoNumeroCertificadoDigitalEstabelecimento() {
		return tamanhoNumeroCertificadoDigitalEstabelecimento;
	}

	/**
	 * @param tamanhaNumeroCertificadoDigitalEstabelecimento the tamanhaNumeroCertificadoDigitalEstabelecimento to set
	 */
	public void setTamanhoNumeroCertificadoDigitalEstabelecimento(String tamanhoNumeroCertificadoDigitalEstabelecimento) {
		this.tamanhoNumeroCertificadoDigitalEstabelecimento = tamanhoNumeroCertificadoDigitalEstabelecimento;
	}


	/**
	 * Representa o Campo STRATUS: ACTR-COEM-NUCEDIESTA
	 * 
	 * @return the numeroCertificadoDigitalEstabelecimento
	 */
	public String getNumeroCertificadoDigitalEstabelecimento() {
		return numeroCertificadoDigitalEstabelecimento;
	}
	/**
	 * @param numeroCertificadoDigitalEstabelecimento the numeroCertificadoDigitalEstabelecimento to set
	 */
	public void setNumeroCertificadoDigitalEstabelecimento(String numeroCertificadoDigitalEstabelecimento) {
		this.numeroCertificadoDigitalEstabelecimento = numeroCertificadoDigitalEstabelecimento;
	}

	/**
	 * Representa o Campo STRATUS:  ACTR-COEM-TRANSSTAIN
	 * 
	 * @return the transstan
	 */
	public String getTransstan() {
		return transstan;
	}
	/**
	 * @param transstan the transstan to set
	 */
	public void setTransstan(String transstan) {
		this.transstan = transstan;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-COEM-DADOS-PRIV
	 * 
	 * Formato: IITTTV  -  ONDE:
	 *                  II  - IDENTIFICACAO DA INFORMACAO COM 2 BYTES.
	 *                  TTT - TAMANHO DA INFORMACAO COM 3 BYTES. (CONSIDERAR APENAS O TAMANHO DO CAMPO V)
	 *                  V   - INFORMACAO  IDENTIFICACAO DO VERIFY BY VISA - 3D - SECURE
	 * 
	 * @return the dadosPrivadoFormatacao
	 */
	public String getDadosPrivadoFormatacao() {
		return dadosPrivadoFormatacao;
	}
	/**
	 * @param dadosPrivadoFormatacao the dadosPrivadoFormatacao to set
	 */
	public void setDadosPrivadoFormatacao(String dadosPrivadoFormatacao) {
		this.dadosPrivadoFormatacao = dadosPrivadoFormatacao;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-CAVV-CERTAUT-DADO
	 * 
	 * @return the dadosCAVVCertAut
	 */
	public String getDadosCAVVCertAut() {
		return dadosCAVVCertAut;
	}
	/**
	 * @param dadosCAVVCertAut the dadosCAVVCertAut to set
	 */
	public void setDadosCAVVCertAut(String dadosCAVVCertAut) {
		this.dadosCAVVCertAut = dadosCAVVCertAut;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-TCIDPAYGATEWAY
	 * 
	 * @return the tcidPayGateway
	 */
	public String getTcidPayGateway() {
		return tcidPayGateway;
	}
	/**
	 * @param tcidPayGateway the tcidPayGateway to set
	 */
	public void setTcidPayGateway(String tcidPayGateway) {
		this.tcidPayGateway = tcidPayGateway;
	}


	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
