package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.monitoracao.autorizador.parser.ParserConverterUtils;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_068, sobre Dados referentes aos tempos de entrada e saida do Stratus e comunicação com POS, HSM, Bandeira, Banco .
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class CPO_068 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L; 
	
	public static Logger logger= LoggerFactory.getLogger(CPO_068.class);
	
	private Date adqEntrada;
	private Date adqSaida;
	private Date resEntrada;
	private Date resSaida;
	private Date hsmEntrada;
	private Date hsmSaida;
	
	public CPO_068(){		
	}
	
	/* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.CampoLogicoVO#efetuarParserCampoBinario()
	 */
	@Override
	public void efetuarParserCampoBinario() {
		int idx= 0, tamanho= 8;
		try {
			//Set valor para campo adqEntrada
			byte[] bAdqEntrada= ParserConverterUtils.subArray(this.getValorCampoBinario(), idx, tamanho);
			this.setAdqEntrada(ParserConverterUtils.parseJiffy(bAdqEntrada));
			idx+= tamanho;
			
			//Set valor para campo adqSaida
			byte[] bAdqSaida= ParserConverterUtils.subArray(this.getValorCampoBinario(), idx, tamanho);
			this.setAdqSaida(ParserConverterUtils.parseJiffy(bAdqSaida));
			idx+= tamanho;
			
			//Set valor para campo resEntrada
			byte[] bResEntrada= ParserConverterUtils.subArray(this.getValorCampoBinario(), idx, tamanho);
			this.setResEntrada(ParserConverterUtils.parseJiffy(bResEntrada));
			idx+= tamanho;
			
			//Set valor para campo resSaida
			byte[] bResSaida= ParserConverterUtils.subArray(this.getValorCampoBinario(), idx, tamanho);
			this.setResSaida(ParserConverterUtils.parseJiffy(bResSaida));
			idx+= tamanho;
			
			//Set valor para campo hsmEntrada
			byte[] bHsmEntrada= ParserConverterUtils.subArray(this.getValorCampoBinario(), idx, tamanho);
			this.setHsmEntrada(ParserConverterUtils.parseJiffy(bHsmEntrada));
			idx+= tamanho;
			
			//Set valor para campo hsmSaida
			byte[] bHsmSaida= ParserConverterUtils.subArray(this.getValorCampoBinario(), idx, tamanho);
			this.setHsmSaida(ParserConverterUtils.parseJiffy(bHsmSaida));
						
		} catch (Exception e) {
			logger.warn("Erro realizando parser no objeto [CPO_068], nos campos data.");
		}
	}

	/**
	 * Método responsável em efetuar o parser dos objetos Date, populando o campo binário.
	 */
	public void carregaCampoBinario(){
		byte[] bAdqEntrada= ParserConverterUtils.parseJiffy(this.getAdqEntrada());		
		byte[] bAdqSaida= ParserConverterUtils.parseJiffy(this.getAdqSaida());
		byte[] bResEntrada= ParserConverterUtils.parseJiffy(this.getResEntrada());
		byte[] bResSaida= ParserConverterUtils.parseJiffy(this.getResSaida());
		byte[] bHsmEntrada= ParserConverterUtils.parseJiffy(this.getHsmEntrada());
		byte[] bHsmSaida= ParserConverterUtils.parseJiffy(this.getHsmSaida());
				
		int length= bAdqEntrada.length + bAdqSaida.length + bResEntrada.length + bResSaida.length + bHsmEntrada.length + bHsmSaida.length;  
	    byte[] campoBinarioTotal= new byte[length];
	    
	    int lengthArray= 0;
	    System.arraycopy(bAdqEntrada, 0, campoBinarioTotal, lengthArray, bAdqEntrada.length);
	    lengthArray+= bAdqEntrada.length;
	    System.arraycopy(bAdqSaida,   0, campoBinarioTotal, lengthArray, bAdqSaida.length);
	    lengthArray+= bAdqSaida.length;
	    System.arraycopy(bResEntrada, 0, campoBinarioTotal, lengthArray, bResEntrada.length);
	    lengthArray+= bResEntrada.length;
	    System.arraycopy(bResSaida,   0, campoBinarioTotal, lengthArray, bResSaida.length);
	    lengthArray+= bResSaida.length;
	    System.arraycopy(bHsmEntrada, 0, campoBinarioTotal, lengthArray, bHsmEntrada.length);
	    lengthArray+= bHsmEntrada.length;
	    System.arraycopy(bHsmSaida,   0, campoBinarioTotal, lengthArray, bHsmSaida.length);
	    
	    this.setValorCampoBinario(campoBinarioTotal);
	}
	
	/**
	 * Representa o Campo STRATUS: ACTR-ADQ-ENT
	 * 
	 * @return the adqEntrada
	 */	
	public Date getAdqEntrada() {
		return adqEntrada;
	}
	/**
	 * @param adqEntrada the adqEntrada to set
	 */
	public void setAdqEntrada(Date adqEntrada) {
		this.adqEntrada = adqEntrada;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-ADQ-SAI
	 * 
	 * @return the adqSaida
	 */	
	public Date getAdqSaida() {
		return adqSaida;
	}
	/**
	 * @param adqSaida the adqSaida to set
	 */
	public void setAdqSaida(Date adqSaida) {
		this.adqSaida = adqSaida;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-RES-ENT
	 * 
	 * @return the resEntrada
	 */	
	public Date getResEntrada() {
		return resEntrada;
	}
	/**
	 * @param resEntrada the resEntrada to set
	 */
	public void setResEntrada(Date resEntrada) {
		this.resEntrada = resEntrada;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-RES-SAI
	 * 
	 * @return the resSaida
	 */	
	public Date getResSaida() {
		return resSaida;
	}
	/**
	 * @param resSaida the resSaida to set
	 */
	public void setResSaida(Date resSaida) {
		this.resSaida = resSaida;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-HSM-ENT
	 * 
	 * @return the hsmEntrada
	 */	
	public Date getHsmEntrada() {
		return hsmEntrada;
	}
	/**
	 * @param hsmEntrada the hsmEntrada to set
	 */
	public void setHsmEntrada(Date hsmEntrada) {
		this.hsmEntrada = hsmEntrada;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-HSM-SAI
	 * 
	 * @return the hsmSaida
	 */	
	public Date getHsmSaida() {
		return hsmSaida;
	}
	/**
	 * @param hsmSaida the hsmSaida to set
	 */
	public void setHsmSaida(Date hsmSaida) {
		this.hsmSaida = hsmSaida;
	}

	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
