package br.com.cielo.monitoracao.autorizador.parser;

import br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.StatusTransacao;
import br.com.cielo.monitoracao.cep.eventos.ext.MonitoracaoTransacaoCEPTPS;
import java.beans.PropertyDescriptor;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * <br><br>
 * Classe responsável em efetuar o parser do objeto MonitoracaoTransacaoAutorizadorVO no objeto MonitoracaoTransacaoCEPTPS 
 * que representa a transação recebida do Stratus para tratamento dos TPS do projeto e tambem responsavel pelo
 * parser do objeto MonitoracaoTransacaoCEPTPS em String e vice-versa.
 *
 * <DL><DT><B>Criada em:</B><DD>08/10/2015</DD></DL>
 *
 * @author fernando.moraes
 * @version $Id: TransacaoMonitoracaoTPSParser.java 1957 2017-08-10 11:52:00Z fernando.moraes $
 */
public class TransacaoMonitoracaoTPSParser {

    private static final Log logger = LogFactory.getLog(TransacaoMonitoracaoTPSParser.class);
    private static final Map<String, PropertyDescriptor> propertyDescriptors = new HashMap<String, PropertyDescriptor>();
    private static final String PARSER_TOKEN_ATTR_FIELDS = ";";
    private static final String PARSER_TOKEN_ATTR_VALUE = "=";
    private static final DateTimeFormatter PARSER_DATE_FORMAT = DateTimeFormat.forPattern("yyyy/MM/dd HH:mm:ss.SSS");

    static {
        try {
            PropertyDescriptor[] pds = PropertyUtils.getPropertyDescriptors(MonitoracaoTransacaoCEPTPS.class);
            for (PropertyDescriptor pd : pds) {
                propertyDescriptors.put(pd.getName(), pd);
            }
            propertyDescriptors.remove("class");
            if (logger.isDebugEnabled()) {
                logger.debug("propertyDescriptors: " + propertyDescriptors.keySet().toString());
            }
        } catch (Exception ex) {
            logger.error("Erro obtendo propriedades da classe MonitoracaoTransacaoCEPTPS", ex);
            throw new RuntimeException(ex);
        }
    }

    public MonitoracaoTransacaoCEPTPS convert(MonitoracaoTransacaoAutorizadorVO in) throws ParserException {
        MonitoracaoTransacaoCEPTPS out = new MonitoracaoTransacaoCEPTPS();
        try {
            PropertyUtils.copyProperties(out, in);
        } catch (Exception ex) {
            logger.error("Erro no parser do objeto MonitoracaoTransacaoAutorizadorVO para MonitoracaoTransacaoCEPTPS", ex);
            throw new ParserException(ex);
        }
        return out;
    }

    public String parser(MonitoracaoTransacaoCEPTPS tps) {
        if (logger.isDebugEnabled()) {
            logger.debug("Parser in : " + tps);
        }
        StringBuilder sb = new StringBuilder();
        for (Iterator<PropertyDescriptor> it = propertyDescriptors.values().iterator(); it.hasNext();) {
            PropertyDescriptor pd = it.next();
            Object value = null;
            try {
                value = PropertyUtils.getProperty(tps, pd.getName());
            } catch (Exception ex) {
                logger.error("Erro lendo valor do atributo \"" + pd.getName() + "\" no objeto MonitoracaoTransacaoCEPTPS",  ex);
            }
            if (value != null) {
                sb.append(pd.getName()).append(PARSER_TOKEN_ATTR_VALUE);
                Class<?> type = pd.getPropertyType();
                if (Date.class.equals(type)) {
                    value = PARSER_DATE_FORMAT.print(new DateTime((Date) value));
                } else if (StatusTransacao.class.equals(type)) {
                    value = ((StatusTransacao) value).getValue();
                }
                sb.append(value.toString());
                if (it.hasNext()) {
                    sb.append(PARSER_TOKEN_ATTR_FIELDS);
                }
            }
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Parser out : " + sb.toString());
        }
        return sb.toString();
    }

    public void unparser(String text, MonitoracaoTransacaoCEPTPS tps) {
        if (logger.isDebugEnabled()) {
            logger.debug("Unparser in : " + text);
        }
        String[] properties = text.split(PARSER_TOKEN_ATTR_FIELDS);
        for (String property : properties) {
            String[] prop = property.split(PARSER_TOKEN_ATTR_VALUE);
            Object value = "";
            if (prop.length > 1) {
                value = prop[1];
            }
            PropertyDescriptor pd = propertyDescriptors.get(prop[0]);
            Class<?> type = pd.getPropertyType();
            try {
                if (Number.class.isAssignableFrom(type)) {
                    if (Long.class.equals(type)) {
                        value = Long.valueOf(value.toString());
                    } else {
                        value = ((Number) value).doubleValue();
                    }
                } else if (Date.class.equals(type)) {
                    value = PARSER_DATE_FORMAT.parseDateTime(value.toString()).toDate();
                } else if (StatusTransacao.class.equals(type)) {
                    value = StatusTransacao.statusOf(Integer.parseInt(value.toString()));
                }
                PropertyUtils.setProperty(tps, pd.getName(), value);
            } catch (Exception ex) {
                logger.error("Erro ajustando valor do atributo \"" + pd.getName() + "\" no objeto MonitoracaoTransacaoCEPTPS",  ex);
            }
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Unparser out : " + tps);
        }
    }
}
