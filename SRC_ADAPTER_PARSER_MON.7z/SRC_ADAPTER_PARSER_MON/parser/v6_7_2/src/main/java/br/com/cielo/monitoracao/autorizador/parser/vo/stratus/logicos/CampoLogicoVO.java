package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * VO Pai, representando os campos Logicos das mensagens do Stratus.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/08/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public abstract class CampoLogicoVO {
	
	private String nomeCampo;	
	private byte[] valorCampoBinario;
	
	/**
	 * Construtor Padrão
	 */
	public CampoLogicoVO(){		
	}
	

	/**
	 * @return
	 */
	public String getNomeCampo() {
		return nomeCampo;
	}
	/**
	 * @param nomeCampo
	 */
	public void setNomeCampo(String nomeCampo) {
		this.nomeCampo = nomeCampo;
	}
		
	/**
	 * @return the valorCampoBinario
	 */
	public byte[] getValorCampoBinario() {
		return valorCampoBinario;
	}
	/**
	 * @param valorCampoBinario the valorCampoBinario to set
	 */
	public void setValorCampoBinario(byte[] valorCampoBinario) {
		this.valorCampoBinario = valorCampoBinario;
	}
	
	/**
	 * Método responsavel em efetuar o Parser, seguindo as respectivas regras de conversão de cada campo.
	 */
	public void efetuarParserCampoBinario(){
	}
	
}
