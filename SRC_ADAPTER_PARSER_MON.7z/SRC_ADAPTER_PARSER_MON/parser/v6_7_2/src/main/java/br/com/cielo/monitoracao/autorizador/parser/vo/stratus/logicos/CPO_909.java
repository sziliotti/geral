package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_909, sobre Dados do BIT47.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_909 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String bit47Tipo;
	private String bit47NumeroDocumento;
	private String bit47TsSinal;
	private String bit47EnderecoIP;
	private String bit47FatTach;
	private String bit47FtcpIP;
	private String bit47FallBack;
	private String bit47RTrans;
	private String bit47QuantidadeEnviada;
	private String bit47QuantidadeRecebida;
	private String bit47Filler;
	
	public CPO_909(){		
	}

	/**
	 *  Representa o Campo STRATUS: ADIC-BRB47-5-TIP
	 *  
	 * @return the bit47Tipo
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public String getBit47Tipo() {
		return bit47Tipo;
	}

	/**
	 * @param bit47Tipo the bit47Tipo to set
	 */
	public void setBit47Tipo(String bit47Tipo) {
		this.bit47Tipo = bit47Tipo;
	}

	/**
	 *  Representa o Campo STRATUS: ADIC-BRB47-5-NDOC
	 *  
	 * @return the bit47NumeroDocumento
	 */
	@PositionalField(initialPosition= 3, finalPosition= 8)
	public String getBit47NumeroDocumento() {
		return bit47NumeroDocumento;
	}

	/**
	 * @param bit47NumeroDocumento the bit47NumeroDocumento to set
	 */
	public void setBit47NumeroDocumento(String bit47NumeroDocumento) {
		this.bit47NumeroDocumento = bit47NumeroDocumento;
	}

	/**
	 *  Representa o Campo STRATUS: ADIC-BRB47-5-TSSINAL
	 *  
	 * @return the bit47TsSinal
	 */
	@PositionalField(initialPosition= 9, finalPosition= 10)
	public String getBit47TsSinal() {
		return bit47TsSinal;
	}

	/**
	 * @param bit47TsSinal the bit47TsSinal to set
	 */
	public void setBit47TsSinal(String bit47TsSinal) {
		this.bit47TsSinal = bit47TsSinal;
	}

	/**
	 *  Representa o Campo STRATUS: ADIC-BRB47-5-ENDIP
	 *  
	 * @return the bit47EnderecoIP
	 */
	@PositionalField(initialPosition= 11, finalPosition= 26)
	public String getBit47EnderecoIP() {
		return bit47EnderecoIP;
	}

	/**
	 * @param bit47EnderecoIP the bit47EnderecoIP to set
	 */
	public void setBit47EnderecoIP(String bit47EnderecoIP) {
		this.bit47EnderecoIP = bit47EnderecoIP;
	}

	/**
	 *  Representa o Campo STRATUS: ADIC-BRB47-5-FATTACH
	 *  
	 * @return the bit47FatTach
	 */
	@PositionalField(initialPosition= 27, finalPosition= 28)
	public String getBit47FatTach() {
		return bit47FatTach;
	}

	/**
	 * @param bit47FatTach the bit47FatTach to set
	 */
	public void setBit47FatTach(String bit47FatTach) {
		this.bit47FatTach = bit47FatTach;
	}

	/**
	 *  Representa o Campo STRATUS: ADIC-BRB47-5-FTCPIP
	 *  
	 * @return the bit47FtcpIP
	 */
	@PositionalField(initialPosition= 29, finalPosition= 30)
	public String getBit47FtcpIP() {
		return bit47FtcpIP;
	}

	/**
	 * @param bit47FtcpIP the bit47FtcpIP to set
	 */
	public void setBit47FtcpIP(String bit47FtcpIP) {
		this.bit47FtcpIP = bit47FtcpIP;
	}

	/**
	 *  Representa o Campo STRATUS: ADIC-BRB47-5-FALLBACK
	 *  
	 * @return the bit47FallBack
	 */
	@PositionalField(initialPosition= 31, finalPosition= 31)
	public String getBit47FallBack() {
		return bit47FallBack;
	}

	/**
	 * @param bit47FallBack the bit47FallBack to set
	 */
	public void setBit47FallBack(String bit47FallBack) {
		this.bit47FallBack = bit47FallBack;
	}

	/**
	 *  Representa o Campo STRATUS: ADIC-BRB47-5-RTRANS
	 *  
	 * @return the bit47RTrans
	 */
	@PositionalField(initialPosition= 32, finalPosition= 33)
	public String getBit47RTrans() {
		return bit47RTrans;
	}

	/**
	 * @param bit47rTrans the bit47RTrans to set
	 */
	public void setBit47RTrans(String bit47rTrans) {
		bit47RTrans = bit47rTrans;
	}

	/**
	 *  Representa o Campo STRATUS: ADIC-BRB47-5-QTD-ENV
	 *  
	 * @return the bit47QuantidadeEnviada
	 */
	@PositionalField(initialPosition= 34, finalPosition= 37)
	public String getBit47QuantidadeEnviada() {
		return bit47QuantidadeEnviada;
	}

	/**
	 * @param bit47QuantidadeEnviada the bit47QuantidadeEnviada to set
	 */
	public void setBit47QuantidadeEnviada(String bit47QuantidadeEnviada) {
		this.bit47QuantidadeEnviada = bit47QuantidadeEnviada;
	}

	/**
	 *  Representa o Campo STRATUS: ADIC-BRB47-5-QTD-REC
	 *  
	 * @return the bit47QuantidadeRecebida
	 */
	@PositionalField(initialPosition= 38, finalPosition= 43)
	public String getBit47QuantidadeRecebida() {
		return bit47QuantidadeRecebida;
	}

	/**
	 * @param bit47QuantidadeRecebida the bit47QuantidadeRecebida to set
	 */
	public void setBit47QuantidadeRecebida(String bit47QuantidadeRecebida) {
		this.bit47QuantidadeRecebida = bit47QuantidadeRecebida;
	}

	/**
	 *  Representa o Campo STRATUS: filler
	 *  
	 * @return the bit47Filler
	 */
	@PositionalField(initialPosition= 44, finalPosition= 76)
	public String getBit47Filler() {		
		return bit47Filler;
	}

	/**
	 * @param bit47Filler the bit47Filler to set
	 */
	public void setBit47Filler(String bit47Filler) {
		this.bit47Filler = bit47Filler;
	}
	
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
