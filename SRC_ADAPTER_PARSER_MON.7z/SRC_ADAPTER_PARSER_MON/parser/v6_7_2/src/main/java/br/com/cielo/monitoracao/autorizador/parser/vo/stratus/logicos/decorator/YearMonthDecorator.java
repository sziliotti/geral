package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator;

import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.exception.FieldDecoratorException;
import com.github.ffpojo.metadata.FieldDecorator;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * <br><br>
 * Classe Decorator para formatos do tipo Ano e Mês, do framework FFPOJO.
 * 
 * <DL><DT><B>Criada em:</B><DD>23/10/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class YearMonthDecorator implements FieldDecorator<Date> {    
    public static Logger logger= LoggerFactory.getLogger(YearMonthDecorator.class);
    
    private static final DateTimeFormatter fmt= DateTimeFormat.forPattern("yyMM");

    /* (non-Javadoc)
     * @see org.ffpojo.metadata.FieldDecorator#fromString(java.lang.String)
     */
    public Date fromString(String str) throws FieldDecoratorException {
        try {        	
        	Date d= fmt.parseDateTime(str).toDate();
            return d;
            
        } catch (IllegalArgumentException e) {        	
        	//logger.warn("Erro realizando parser no objeto, em campo data. Valor recebido= '"+str+"'", e);
        	return null;           
        }
    }

    /* (non-Javadoc)
     * @see org.ffpojo.metadata.FieldDecorator#toString(java.lang.Object)
     */
    public String toString(Date date) {
    	return fmt.print(new DateTime(date.getTime()));
    }
}