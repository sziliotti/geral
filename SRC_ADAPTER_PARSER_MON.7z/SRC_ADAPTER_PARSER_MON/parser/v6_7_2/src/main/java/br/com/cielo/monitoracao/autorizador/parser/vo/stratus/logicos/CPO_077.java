package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator.DateDecorator;
import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator.DateHourDecorator;
import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator.Double12PosDecorator;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_077, sobre Campos Complementares Multip Bandeira.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_077 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	public static Logger logger= LoggerFactory.getLogger(CPO_077.class);
	
	/*private SimpleDateFormat dateFormat= new SimpleDateFormat("yyMMdd");	
	private SimpleDateFormat dateHourFormat= new SimpleDateFormat("yyMMddHHmm");*/
	
	private double bit05ValorRealDolar; 
	private double bit06ValorFatura;
	private Date bit07DataHora;
	private double bit09TaxaRealDolar;
	private double bit10TaxaRealPortador;
	private Date bit15DataLiquidacao;
	private Date bit16DataConv;
	private String bit48Categoria;
	private String bit50MoedaFatura;
	private String bit63Rede;
	private String bit48Sub20;
	private String bit37ReferenceNumber;
	private String filler;
	private String codSubProdutoPJ;
	
	
	public CPO_077(){		
	}


	/**
	 * @return the bit05ValorRealDolar
	 */
	@PositionalField(initialPosition= 1, finalPosition= 12, decorator= Double12PosDecorator.class)
	public double getBit05ValorRealDolar() {
		return bit05ValorRealDolar;
	}
	/**
	 * @param bit05ValorRealDolar the bit05ValorRealDolar to set
	 */
	/*public void setBit05ValorRealDolar(String bit05ValorRealDolar) {		
		String valFinal= bit05ValorRealDolar.substring(0, 10)+"."+bit05ValorRealDolar.substring(10);		
		try {
			this.bit05ValorRealDolar= Double.parseDouble(valFinal);
		} catch (NumberFormatException e) {
			this.bit05ValorRealDolar= 0;
			logger.warn("Erro realizando parser no objeto [CPO_077], em campo numerico[bit05ValorRealDolar]. Valor recebido= '"+bit05ValorRealDolar+"'");			
		}
	}*/
	/**
	 * @param bit05ValorRealDolar the bit05ValorRealDolar to set
	 */
	public void setBit05ValorRealDolar(double bit05ValorRealDolar) {
		this.bit05ValorRealDolar = bit05ValorRealDolar;
	}


	/**
	 * @return the bit06ValorFatura
	 */
	@PositionalField(initialPosition= 13, finalPosition= 24, decorator= Double12PosDecorator.class)
	public double getBit06ValorFatura() {
		return bit06ValorFatura;
	}
	/**
	 * @param bit06ValorFatura the bit06ValorFatura to set
	 */
	/*public void setBit06ValorFatura(String bit06ValorFatura) {		
		String valFinal= bit06ValorFatura.substring(0, 10)+"."+bit06ValorFatura.substring(10);		
		try {
			this.bit06ValorFatura= Double.parseDouble(valFinal);
		} catch (NumberFormatException e) {
			this.bit06ValorFatura= 0;
			logger.warn("Erro realizando parser no objeto [CPO_077], em campo numerico[bit06ValorFatura]. Valor recebido= '"+bit06ValorFatura+"'");			
		}
	}*/
	/**
	 * @param bit06ValorFatura the bit06ValorFatura to set
	 */
	public void setBit06ValorFatura(double bit06ValorFatura) {
		this.bit06ValorFatura = bit06ValorFatura;
	}


	/**
	 * @return the bit07DataHora
	 */
	@PositionalField(initialPosition= 25, finalPosition= 34, decorator= DateHourDecorator.class)
	public Date getBit07DataHora() {
		return bit07DataHora;
	}
	/**
	 * @param bit07DataHora the bit07DataHora to set
	 */
	/*public void setBit07DataHora(String bit07DataHora) {		
		try {
			this.bit07DataHora= dateHourFormat.parse(bit07DataHora);
		} catch (ParseException e) {
			this.bit07DataHora= new Date();
			logger.warn("Erro realizando parser no objeto [CPO_077], em campo data[bit07DataHora]. Valor recebido= '"+bit07DataHora+"'");			
		}
	}*/
	/**
	 * @param bit07DataHora the bit07DataHora to set
	 */
	public void setBit07DataHora(Date bit07DataHora) {
		this.bit07DataHora = bit07DataHora;
	}


	/**
	 * @return the bit09TaxaRealDolar
	 */
	@PositionalField(initialPosition= 35, finalPosition= 42)
	public double getBit09TaxaRealDolar() {
		return bit09TaxaRealDolar;
	}
	/**
	 * @param bit09TaxaRealDolar the bit09TaxaRealDolar to set
	 */
	public void setBit09TaxaRealDolar(String bit09TaxaRealDolar) {
		if(bit09TaxaRealDolar!=null && !bit09TaxaRealDolar.equals("")){
			String valFinal= bit09TaxaRealDolar.substring(0, 1)+"."+bit09TaxaRealDolar.substring(1);		
			try {
				this.bit09TaxaRealDolar= Double.parseDouble(valFinal);
			} catch (NumberFormatException e) {
				this.bit09TaxaRealDolar= 0;
				logger.warn("Erro realizando parser no objeto [CPO_077], em campo numerico[bit09TaxaRealDolar]. Valor recebido= '"+bit09TaxaRealDolar+"'");			
			}
		}else{
			this.bit09TaxaRealDolar= 0;
		}
	}
	/**
	 * @param bit09TaxaRealDolar the bit09TaxaRealDolar to set
	 */
	public void setBit09TaxaRealDolar(double bit09TaxaRealDolar) {
		this.bit09TaxaRealDolar = bit09TaxaRealDolar;
	}


	/**
	 * @return the bit10TaxaRealPortador
	 */
	@PositionalField(initialPosition= 43, finalPosition= 50)
	public double getBit10TaxaRealPortador() {
		return bit10TaxaRealPortador;
	}
	/**
	 * @param bit10TaxaRealPortador the bit10TaxaRealPortador to set
	 */
	public void setBit10TaxaRealPortador(String bit10TaxaRealPortador) {
		if(bit10TaxaRealPortador!=null && !bit10TaxaRealPortador.equals("")){
			String valFinal= bit10TaxaRealPortador.substring(0, 1)+"."+bit10TaxaRealPortador.substring(1);		
			try {
				this.bit10TaxaRealPortador= Double.parseDouble(valFinal);
			} catch (NumberFormatException e) {
				this.bit10TaxaRealPortador= 0;
				logger.warn("Erro realizando parser no objeto [CPO_077], em campo numerico[bit10TaxaRealPortador]. Valor recebido= '"+bit10TaxaRealPortador+"'");			
			}
		}else{
			this.bit10TaxaRealPortador= 0;
		}
	}
	/**
	 * @param bit10TaxaRealPortador the bit10TaxaRealPortador to set
	 */
	public void setBit10TaxaRealPortador(double bit10TaxaRealPortador) {
		this.bit10TaxaRealPortador = bit10TaxaRealPortador;
	}


	/**
	 * @return the bit15DataLiquidacao
	 */
	@PositionalField(initialPosition= 51, finalPosition= 54, decorator= DateDecorator.class)
	public Date getBit15DataLiquidacao() {
		return bit15DataLiquidacao;
	}
	/**
	 * @param bit15DataLiquidacao the bit15DataLiquidacao to set
	 */
	/*public void setBit15DataLiquidacao(String bit15DataLiquidacao) {		
		try {
			this.bit15DataLiquidacao= dateFormat.parse(bit15DataLiquidacao);
		} catch (ParseException e) {
			this.bit15DataLiquidacao= new Date();
			logger.warn("Erro realizando parser no objeto [CPO_077], em campo data[bit15DataLiquidacao]. Valor recebido= '"+bit15DataLiquidacao+"'");			
		}
	}*/
	/**
	 * @param bit15DataLiquidacao the bit15DataLiquidacao to set
	 */
	public void setBit15DataLiquidacao(Date bit15DataLiquidacao) {
		this.bit15DataLiquidacao = bit15DataLiquidacao;
	}


	/**
	 * @return the bit16DataConv
	 */
	@PositionalField(initialPosition= 55, finalPosition= 58, decorator= DateDecorator.class)
	public Date getBit16DataConv() {
		return bit16DataConv;
	}
	/**
	 * @param bit16DataConv the bit16DataConv to set
	 */
	/*public void setBit16DataConv(String bit16DataConv) {		
		try {
			this.bit16DataConv= dateFormat.parse(bit16DataConv);
		} catch (ParseException e) {
			this.bit16DataConv= new Date();
			logger.warn("Erro realizando parser no objeto [CPO_077], em campo data[bit16DataConv]. Valor recebido= '"+bit16DataConv+"'");			
		}
	}*/
	/**
	 * @param bit16DataConv the bit16DataConv to set
	 */
	public void setBit16DataConv(Date bit16DataConv) {
		this.bit16DataConv = bit16DataConv;
	}


	/**
	 * @return the bit48Categoria
	 */
	@PositionalField(initialPosition= 59, finalPosition= 59)
	public String getBit48Categoria() {
		return bit48Categoria;
	}


	/**
	 * @param bit48Categoria the bit48Categoria to set
	 */
	public void setBit48Categoria(String bit48Categoria) {
		this.bit48Categoria = bit48Categoria;
	}


	/**
	 * @return the bit50MoedaFatura
	 */
	@PositionalField(initialPosition= 60, finalPosition= 62)
	public String getBit50MoedaFatura() {
		return bit50MoedaFatura;
	}


	/**
	 * @param bit50MoedaFatura the bit50MoedaFatura to set
	 */
	public void setBit50MoedaFatura(String bit50MoedaFatura) {
		this.bit50MoedaFatura = bit50MoedaFatura;
	}


	/**
	 * @return the bit63Rede
	 */
	@PositionalField(initialPosition= 63, finalPosition= 74)
	public String getBit63Rede() {
		return bit63Rede;
	}


	/**
	 * @param bit63Rede the bit63Rede to set
	 */
	public void setBit63Rede(String bit63Rede) {
		this.bit63Rede = bit63Rede;
	}


	/**
	 * @return the bit48Sub20
	 */
	@PositionalField(initialPosition= 75, finalPosition= 75)
	public String getBit48Sub20() {
		return bit48Sub20;
	}


	/**
	 * @param bit48Sub20 the bit48Sub20 to set
	 */
	public void setBit48Sub20(String bit48Sub20) {
		this.bit48Sub20 = bit48Sub20;
	}


	/**
	 * @return the bit37ReferenceNumber
	 */
	@PositionalField(initialPosition= 76, finalPosition= 87)
	public String getBit37ReferenceNumber() {
		return bit37ReferenceNumber;
	}


	/**
	 * @param bit37ReferenceNumber the bit37ReferenceNumber to set
	 */
	public void setBit37ReferenceNumber(String bit37ReferenceNumber) {
		this.bit37ReferenceNumber = bit37ReferenceNumber;
	}

	/**
	 * @return the filler
	 */
	@PositionalField(initialPosition= 88, finalPosition= 96)
	public String getFiller() {
		return filler;
	}

	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		this.filler = filler;
	}

	/**
	 * @return the codSubProdutoPJ
	 */
	@PositionalField(initialPosition= 97, finalPosition= 100)
	public String getCodSubProdutoPJ() {
		return codSubProdutoPJ;
	}

	/**
	 * @param codSubProdutoPJ the codSubProdutoPJ to set
	 */
	public void setCodSubProdutoPJ(String codSubProdutoPJ) {
		this.codSubProdutoPJ = codSubProdutoPJ;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
