package br.com.cielo.monitoracao.jmx;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Classe utilitária para MXBean de Monitoramento JMX.
 *
 * @author fernando.moraes
 * @version $Id: MessageStatisticsUtils.java 1957 2017-08-10 11:52:00Z fernando.moraes $
 */
public class MessageStatisticsUtils {

    private static final String SYNC_MESSAGE_STATISTICS = "SYNC_MESSAGE_STATISTICS";
    private final Logger logger;
    private final MessageStatisticsMXBean messageStatisticsBean;
    private final String beanName;
    private final Map<String, BigDecimal> messageStatisticsLocal = new HashMap<String, BigDecimal>();
    private int countBreakGroup;
    private int countBreakTime;

    public MessageStatisticsUtils(MessageStatisticsMXBean messageStatisticsBean, Logger logger, boolean isOutMessages) {
        this.messageStatisticsBean = messageStatisticsBean;
        this.logger = logger;
        this.beanName = messageStatisticsBean.getBeanName();
        String parCountBreakGroup = isOutMessages ? "out.ems.messages.to.statistic" : "in.stratus.messages.to.statistic";
        String parCountBreakTime = isOutMessages ? "out.ems.minutes.to.statistic" : "in.stratus.minutes.to.statistic";
        countBreakGroup = isOutMessages ? 1000 : 10000;
        countBreakTime = isOutMessages ? 10 : 10;
        try {
            countBreakGroup = Integer.parseInt(System.getProperty(parCountBreakGroup, Integer.toString(countBreakGroup)));
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Parametro '{0}' deve ser um numero inteiro. Usando o padrao: {1}",
                    new Object[]{parCountBreakGroup, countBreakGroup});
        }
        try {
            countBreakTime = Integer.parseInt(System.getProperty(parCountBreakTime, Integer.toString(countBreakTime)));
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "Parametro '{0}' deve ser um numero inteiro. Usando o padrao: {1}",
                    new Object[]{parCountBreakTime, countBreakGroup});
        }
    }

    public void incrementMessageStatisticsBean(final MessageStatisticsCountController countController) {
        synchronized (SYNC_MESSAGE_STATISTICS) {
            final int messages = countController.getCountMessages().incrementAndGet();
            // registra no MXBean caso o contador atual exceda a quantidade de mensagens ou o tempo decorrido chegue ao limite
            if (messages > countBreakGroup) {
                interruptUpdateThread(countController.getThread());
                updateMessageStatisticsBean(messages);
                countController.getCountMessages().set(0);
                startTimerCountAndThread(countController, true);
            }
        }
    }

    public void registryParseLatency(long time) {
        registryValue(MessageStatisticsMXBean.KEY_PARSE_LATENCY_LAST, time);
    }

    public void registryPostLatency(long time) {
        registryValue(MessageStatisticsMXBean.KEY_POST_LATENCY_LAST, time);
    }

    public void registryPersistenceLatency(long time) {
        registryValue(MessageStatisticsMXBean.KEY_PERSISTENCE_LATENCY_LAST, time);
    }

    public void startTimerCount(final MessageStatisticsCountController countController) {
        synchronized (SYNC_MESSAGE_STATISTICS) {
            if (countController.getCountMessages().get() == 0 && countController.getThread() == null) {
                startTimerCountAndThread(countController, true);
            }
        }
    }

    private void registryValue(String key, long time) {
        messageStatisticsLocal.put(key, new BigDecimal(System.currentTimeMillis() - time));
    }

    private void startTimerCountAndThread(final MessageStatisticsCountController countController, boolean startUpdateThread) {
        messageStatisticsBean.startTimeCount();
        countController.getStartTimeMessages().set(messageStatisticsBean.getProperty(MessageStatisticsMXBean.KEY_START_TIME).longValue());
        if (startUpdateThread) {
            final long timeWait = (long) (countBreakTime * 60000.0);
            Thread thread = new Thread(new MessageStatisticsUpdateThread(timeWait, countController), getThreadName());
            thread.setDaemon(true);
            thread.start();
            countController.setThread(thread);
        }
    }

    private void updateMessageStatisticsBean(int messages) {
        try {
            messageStatisticsBean.addMessages(new BigDecimal(messages));
            for (Map.Entry<String, BigDecimal> prop : messageStatisticsLocal.entrySet()) {
                messageStatisticsBean.setProperty(prop.getKey(), prop.getValue());
            }
        } catch (Exception e) {
            logger.log(Level.WARNING, "Erro registrando estatistica das mensagens para JMX", e);
        }
    }

    private void interruptUpdateThread(final Thread thread) {
        if (thread != null && thread.isAlive()) {
            // interrompe uma Thread de atualizacao do MXBean ativa pois a atualizacao ja ocorreu
            try {
                logger.log(Level.FINE, "{0} - interropendo thread", thread.getName());
                thread.interrupt();
                thread.join(100);
            } catch (Exception e) {
                logger.log(Level.WARNING, "Nao foi possivel interromper processo de atualizacao", e);
            }
        }
    }

    private String getThreadName() {
        return MessageStatisticsUpdateThread.class.getSimpleName() + "_" + beanName;
    }

    private class MessageStatisticsUpdateThread implements Runnable {

        private final long timeWait;
        private final MessageStatisticsCountController countController;

        public MessageStatisticsUpdateThread(long timeWait, MessageStatisticsCountController countController) {
            this.timeWait = timeWait;
            this.countController = countController;
        }

        @Override
        public void run() {
            try {
                logger.log(Level.FINE, "{0} - thread aguardando {1} milissegundos", new Object[]{Thread.currentThread().getName(), timeWait});
                Thread.sleep(timeWait);
                logger.log(Level.FINE, "{0} - executando apos {1} milissegundos", new Object[]{Thread.currentThread().getName(), timeWait});
                // apos decorrido o tempo que faltava para o limite, atualiza o MXBean com a
                // quantidade de mensagens processadas e ainda nao registradas
                synchronized (SYNC_MESSAGE_STATISTICS) {
                    updateMessageStatisticsBean(countController.getCountMessages().get());
                    // atualiza os contadores para o proximo ciclo
                    countController.getCountMessages().set(0);
                    countController.setThread(null);
                    startTimerCountAndThread(countController, false);
                }
            } catch (InterruptedException e) {
            }
        }
    }
}
