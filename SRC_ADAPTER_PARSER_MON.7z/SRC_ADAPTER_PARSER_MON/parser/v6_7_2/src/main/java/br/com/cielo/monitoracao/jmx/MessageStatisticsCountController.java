package br.com.cielo.monitoracao.jmx;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Classe controladora dos contares e threads de MXBean de Monitoramento JMX.
 *
 * @author fernando.moraes
 * @version $Id: MessageStatisticsCountController.java 1957 2017-08-10 11:52:00Z fernando.moraes $
 */
public class MessageStatisticsCountController {

    private final AtomicInteger countMessages = new AtomicInteger(0);
    private final AtomicLong startTimeMessages = new AtomicLong(0);
    private Thread thread;

    public AtomicInteger getCountMessages() {
        return countMessages;
    }

    public AtomicLong getStartTimeMessages() {
        return startTimeMessages;
    }

    public Thread getThread() {
        return thread;
    }

    public void setThread(Thread thread) {
        this.thread = thread;
    }
}
