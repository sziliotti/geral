package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_008.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_008 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	public static Logger logger= LoggerFactory.getLogger(CPO_008.class);
	
	private int digitoTr1Tam;
	private String digitoTr1;
	private String tipoBIN;
	
	
	public CPO_008(){		
	}
	
	
	/**
	 * @return the digitoTr1Tam
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public int getDigitoTr1Tam() {
		return digitoTr1Tam;
	}
	/**
	 * @param digitoTr1Tam the digitoTr1Tam to set
	 */
	public void setDigitoTr1Tam(String digitoTr1Tam) {		
		try {
			this.digitoTr1Tam= Integer.parseInt(digitoTr1Tam);
		} catch (NumberFormatException e) {
			this.digitoTr1Tam= 0;
			System.out.println("Erro realizando parser no objeto [CPO_008], em campo N�merico[digitoTr1Tam]. Valor recebido= '"+digitoTr1Tam+"'");			
		}	
	}
	/**
	 * @param digitoTr1Tam the digitoTr1Tam to set
	 */
	public void setDigitoTr1Tam(int digitoTr1Tam) {
		this.digitoTr1Tam = digitoTr1Tam;
	}
	
	/**
	 * @return the digitoTr1
	 */
	@PositionalField(initialPosition= 3, finalPosition= 7)
	public String getDigitoTr1() {
		return digitoTr1;
	}
	/**
	 * @param digitoTr1 the digitoTr1 to set
	 */
	public void setDigitoTr1(String digitoTr1) {
		this.digitoTr1 = digitoTr1;
	}
	
	/**
	 * C - CREDITO
     * D - DEBITO
     * M - MULTIPLO
	 * 
	 * @return the tipoBIN
	 */
	@PositionalField(initialPosition= 8, finalPosition= 8)
	public String getTipoBIN() {
		return tipoBIN;
	}
	/**
	 * @param tipoBIN the tipoBIN to set
	 */
	public void setTipoBIN(String tipoBIN) {
		this.tipoBIN = tipoBIN;
	}

	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
