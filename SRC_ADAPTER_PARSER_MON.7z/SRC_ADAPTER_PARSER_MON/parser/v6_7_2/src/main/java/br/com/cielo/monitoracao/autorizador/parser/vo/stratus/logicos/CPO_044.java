package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator.Double10PosDecorator;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_044, sobre Dados da VALOR COMPRE & SAQUE(EMV = TAG 9F03).
 * 
 * <DL><DT><B>Criada em:</B><DD>16/10/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_044 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	public static Logger logger= LoggerFactory.getLogger(CPO_044.class);
	
	private double valorCompraSaque;
	
	
	public CPO_044(){		
	}
	

	/**
	 * Representa o Campo STRATUS:  ACTR-CASH-VALOR
	 * 
	 * @return the valorCompreSaque
	 */
	@PositionalField(initialPosition= 1, finalPosition= 10, decorator= Double10PosDecorator.class)
	public double getValorCompraSaque() {
		return valorCompraSaque;
	}
	/**
	 * @param valorCompreSaque the valorCompreSaque to set
	 */
	/*public void setValorCompraSaque(String valorCompraSaque) {				
		String valcomSaq= valorCompraSaque.substring(0, 8)+"."+valorCompraSaque.substring(8);		
		try {
			this.valorCompraSaque = Double.parseDouble(valcomSaq);
		} catch (NumberFormatException e) {
			this.valorCompraSaque= 0;
			logger.warn("Erro realizando parser no objeto [CPO_044], em campo numerico[valorCompreSaque]. Valor recebido= '"+valorCompraSaque+"'");			
		}	
	}*/
	/**
	 * @param valorCompreSaque the valorCompreSaque to set
	 */
	public void setValorCompraSaque(double valorCompraSaque) {
		this.valorCompraSaque = valorCompraSaque;
	}

	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
