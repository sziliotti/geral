package br.com.cielo.monitoracao.autorizador.parser;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.MensagemFisicaCtvVO;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * <br><br>
 * Classe responsavel em efetuar o parser do cabecalho da mensagem recebida do Stratus.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/08/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class MensagemFisicaCTVStratusParser {
	public static Logger logger= LoggerFactory.getLogger(MensagemFisicaCTVStratusParser.class);
	
	/**
	 * Lista com os campos do tipo Binario do cabeçalho do Stratus.
	 */
	private static final List<String> CAMPOS_BINARIOS;
	
	/**
	 * Lista com os campos que possuem mais de um mapeamento, baseado na release do POS.
	 */
	private static final List<String> CAMPOS_COM_MULTIPLOS_MAPEAMENTOS;
	
	static {
		CAMPOS_BINARIOS = Arrays.asList("CPO_035", "CPO_068", "CPO_069", "CPO_076", "CPO_079", "CPO_200", "CPO_903");
		
		CAMPOS_COM_MULTIPLOS_MAPEAMENTOS = Arrays.asList("CPO_905", "CPO_909");
	}
	
	
	/**
	 * Método responsável em efetuar o parser da mensagem recebida do stratus, a partir de um array de bytes, e 
	 * retornar uma lista  de objetos MensagemFisicaCtvVO.
	 * <br><br>
	 *  Esse metodo analisa a mensagem recebida(bytes[]), convertendo-a em hexdecimal, e dependendo do campo 
	 *  convertendo em ASCII. Apos a analise de cada campo no formato CTV, o mesmo retorna uma lista de objetos do tipo
	 *  MensagemFisicaCtvVO.
	 *  <br><br>
	 *  O formato da mensagem vinda do Stratus segue o padrao CTV conforme descrito:
	 *  
	 *  	<DD>C (Campo)   - Representado pelos 2 primeiros bytes da mensagem.
	 *  	<DD>T (Tamanho) - Representado pelos 2 bytes seguintes da mensagem.
	 * 	 	<DD>V (Valor)   - Conteudo do campo. 
	 *  <br><br>
	 *  Exemplo de DUMP de Mensagem (ja convertida):
	 *  	<DD>000a001ef1f6f0f7f1f6f4f9f3f1f0f0f4f9f5f0f5f9f5f9f2f4404040e2f0f040f2
	 *  <br><br>
	 *  Onde:
	 *  	<DD>000a - Campo que contem a descricao do campo logico a ser manipulado. (No caso esse seria o campo CPO-010. Convertendo o valor hex em decimal).
	 *  	<DD>0052 - Campo que contem o tamanho da area de dados a ser manipulada. (No caso esse o tamanho seria de 30. Convertendo o valor hex em decimal).
	 *  	<DD>ef1f6f0f7f1f... - Campo que contem a area de dados do campo lógico identificado acima. Efetua conversacao utilizando encode EBCDIC.
	 * <br><br>
	 * 
	 * @param msgBytes
	 * 			Array de bytes da mensagem recebida do Stratus.
	 * @return
	 * 			Array de objetos do tipo MensagemFisicaCtvVO contendo a definicao e conteudo da mensagem recebida. 
	 */
	public ArrayList<MensagemFisicaCtvVO> efetuaParserCabecalhoStratus(byte[] msgBytes){		
		ArrayList<MensagemFisicaCtvVO> camposMensagemFisica= new ArrayList<MensagemFisicaCtvVO>();
		
		try{
			// Converter mensagem recebida em bytes, para manipulacao dos dados.
			int idx= 0;
			while (idx < msgBytes.length) {
				// Recupera o nome do campo fisico nos 2 primeiros bytes.
				byte[] campoNome= ParserConverterUtils.subArray(msgBytes, idx, 2);
				idx+= 2;
				
				//Analise e recupera o tamanho do campo fisico nos 2 bytes seguintes.
				byte[] campoTamanho= ParserConverterUtils.subArray(msgBytes, idx, 2);
				String tamanhoHex= ParserConverterUtils.bytesToHex(campoTamanho);				
				int valueTam= ParserConverterUtils.hexToDecimal(tamanhoHex);
				idx+= 2;
				
				// Recupera o conjunto de bytes correspondete ao valor do campo fisico. Esse campo contem a string dos campos logicos.
				byte[] campoValor= ParserConverterUtils.subArray(msgBytes, idx, valueTam);
				
				// Montagem do VO com os valores ja convertidos do Array de bytes.	
				MensagemFisicaCtvVO mensagemVO= new MensagemFisicaCtvVO();				
				mensagemVO.setNomeCampo(ParserConverterUtils.hexToDecimal(ParserConverterUtils.bytesToHex(campoNome)));
				mensagemVO.setTamanhoCampo(valueTam);
				
				// Verifica se o campo a ser populado é do tipo binario, caso seja atribui valor(bytes[]) ao atributo correspondente 
				// ao bytes[]; caso contrario efetua transformação do valor em String.
				if(CAMPOS_BINARIOS.contains(mensagemVO.getNomeCampo())){
					mensagemVO.setCampoBinario(true);
					mensagemVO.setValorCampoBinario(campoValor);
				}else{
					mensagemVO.setValorCampo(ParserConverterUtils.hexToString(campoValor));
				}
				
				//Verifica se o campo possui multiplos mapeamentos, conforme a release existente no campo CPO_013
				if(CAMPOS_COM_MULTIPLOS_MAPEAMENTOS.contains(mensagemVO.getNomeCampo())){
					mensagemVO.setPossuiMultiplosMapeamento(true);
				}				
				
				camposMensagemFisica.add(mensagemVO);
				
				// Move index para o proximo campo(no array de bytes) da mensagem fisica recebida.
				idx+= valueTam;
			}
		}catch (Exception e) {
			logger.error("ERRO na conversao da mensagem:  ", e);
		}
		if(logger.isDebugEnabled()){
			logger.debug("XML Convertido Campos Fisicos: \n" + this.montarXML(camposMensagemFisica));
		}
		
		return camposMensagemFisica;
	}
	
		
	/**
	 * Metodo responsavel em transformar o conjunto de campos Fisicos(MensagemFisicaCtvVO) recebidos, em um XML.
	 * <br><br>
	 * @param camposMensagemFisica
	 * 			Lista de objetos do tipo MensagemFisicaCtvVO a ser convertido em XML.
	 * @return
	 * 			Retornar uma string, no formato XML da lista de objetos recebidas.
	 */
	public String montarXML(ArrayList<MensagemFisicaCtvVO> camposMensagemFisica){
		StringBuilder xml= new StringBuilder();
				
		// Inicio da montagem da mensagem XML, para os campos convertidos e ja analisados.
		xml.append("<MENSAGEM_CABECALHO_CTV_STRATUS>");
		xml.append("<LISTA_CAMPOS>");
		
		int i= 1;
		for (Iterator<MensagemFisicaCtvVO> iterator= camposMensagemFisica.iterator(); iterator.hasNext();) {
			MensagemFisicaCtvVO mensagemFisicaCtvVO= (MensagemFisicaCtvVO) iterator.next();
						
			xml.append("<CAMPO id='"+i+"'>");
			xml.append("<NOME>"+mensagemFisicaCtvVO.getNomeCampo()+"</NOME>");
			xml.append("<TAMANHO>"+mensagemFisicaCtvVO.getTamanhoCampo()+"</TAMANHO>");
			xml.append("<VALOR>"+mensagemFisicaCtvVO.getValorCampo()+"</VALOR>");
			xml.append("</CAMPO>");
			
			i++;
		}
		xml.append("</LISTA_CAMPOS>");
		xml.append("</MENSAGEM_CABECALHO_CTV_STRATUS>");
		
		return xml.toString();
	}

}
