package br.com.cielo.monitoracao.autorizador.parser;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.monitoracao.autorizador.parser.vo.bam.InformacoesBIT47;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.InformacoesDCC;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.InformacoesDiscagemBIT47;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.InformacoesLynx;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.InformacoesStandIn;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.MonitoracaoTransacaoAutorizadorVO;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.StatusDCC;
import br.com.cielo.monitoracao.autorizador.parser.vo.bam.StatusTransacao;
import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.TransacaoStratusVO;
import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.*;
import org.apache.commons.lang.StringUtils;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * <br><br>
 * Classe responsável em efetuar o parser do objeto que representa a transação recebida do Stratus, e retornar o objeto MonitoracaoTransacaoAutorizadorVO()
 * populado com os campos utilizados para efetuar a Monitoração e disponibilizar ao CEP/BAM.
 *
 * <DL><DT><B>Criada em:</B><DD>04/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class TransacaoMonitoracaoParser {

    public static Logger logger = LoggerFactory.getLogger(TransacaoMonitoracaoParser.class);

    //private static final List<String> MENSAGENS_RETORNO_DESFAZIMENTO;
    private static final List<String> NAO_PODE_RESPONDER_DESFAZIMENTO;
    private static final List<String> CODIGOS_RETORNO_CONSULTA_DCC;    
    private static final List<String> INDICADOR_AUTORIZACAO_PARCIAL;
    
    private static final List<String> MENSAGENS_RETORNO_NEGADA_OFF;
    private static final List<String> MENSAGENS_RETORNO_APROVADA_OFF;

    static {
        //MENSAGENS_RETORNO_DESFAZIMENTO = Arrays.asList("TEMPO EXCEDIDO", "SEM RESPOSTA", "VERIF.CONEX.BRAD", "15BCO.INDISPONIV", "91BCO.FORA DO AR", "58ASS.CONTR.BCO");
        NAO_PODE_RESPONDER_DESFAZIMENTO = Arrays.asList("EL", "S0");
        CODIGOS_RETORNO_CONSULTA_DCC = Arrays.asList("285", "471", "473", "476");        
        INDICADOR_AUTORIZACAO_PARCIAL = Arrays.asList("P", "D");
        
        MENSAGENS_RETORNO_NEGADA_OFF = Arrays.asList("NEGADA OFF1", "NEGADA OFF3");
        MENSAGENS_RETORNO_APROVADA_OFF = Arrays.asList("APROVADA OFF1", "APROVADA OFF3");
    }
    
    
    
    /**
     * Sobrecarga de converter(...) com a opção de não se enviar o VO como parâmetro (sem uso de pool de objetos externo).
     * 
     * @param transacaoStratus Transacao Stratus.
     * 
     * @return retorna MonitoracaoVO
     * 
     * @throws ParserException 
     */
    public MonitoracaoTransacaoAutorizadorVO converter(TransacaoStratusVO transacaoStratus) throws ParserException {
        MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao = new MonitoracaoTransacaoAutorizadorVO();
        return this.converter(transacaoStratus, monitoracaoTransacao);
    }
    
    /**
     * Método responsável em receber o objeto que representa a transação capturada, e já efetuada parser do Stratus, e converter em uma instância
     * da classe MonitoracaoTransacaoAutorizadorVO que será utilizado na solução de Monitoramento CEP/BAM.
     * <br><br>
     *
     * @param transacaoStratus Objeto TransacaoStratusVO que representa a transação vinda do Stratus.
     * 
     * @param monitoracaoTransacao VO de base. Ele será retorna com os devidos valores "parseados" alimentados. Use este método quando deseja-se 
     * 								utilizar um pool de objetos externo
     * @return Objeto MonitoracaoTransacaoAutorizadorVO que representa a transação vinda do Stratus, conforme os campos identificados e recebidos
     * 			pelo método.
     * @throws ParserException
     */
    public MonitoracaoTransacaoAutorizadorVO converter(TransacaoStratusVO transacaoStratus, MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao) throws ParserException {
        /* INICIA MAPEAMENTO DOS CAMPOS USADOS NA MONITORACAO CEP-BAM.
         * CAMPOS NECESSARIOS:
         * 				- CPO_001
         * 				- CPO_006
         * 				- CPO_009
         * 				- CPO_010
         * 				- CPO_012
         * 				- CPO_013
         * 				- CPO_019
         * 				- CPO_027
         * 				- CPO_030
         * 				- CPO_032
         * 				- CPO_040 (Inclui STAND IN).
         *  			- CPO_047
         *                      - CPO_065
         *    		    - CPO_067 (Para LYNX).		 		 
         *  		    - CPO_068
         *    		    - CPO_071 (Para Mobile)
         *    			- CPO_074
         *  			- CPO_035 (Para ecommerce)
         *  			- CPO_073 e CPO_901  (Para DCC)
         */
        CPO_001 campo001 = (CPO_001) transacaoStratus.getCampoLogico("CPO_001");
        if (campo001 != null) {
            this.mapeamentoCampo001(monitoracaoTransacao, campo001);
        }

        CPO_006 campo006 = (CPO_006) transacaoStratus.getCampoLogico("CPO_006");
        if (campo006 != null) {
            this.mapeamentoCampo006(monitoracaoTransacao, campo006);
        }
        CPO_009 campo009 = (CPO_009) transacaoStratus.getCampoLogico("CPO_009");
        if (campo009 != null) {
            this.mapeamentoCampo009(monitoracaoTransacao, campo009);
        }
        
        CPO_010 campo010 = (CPO_010) transacaoStratus.getCampoLogico("CPO_010");
        if (campo010 != null) {
            this.mapeamentoCampo010(monitoracaoTransacao, campo010);
        }

        CPO_012 campo012 = (CPO_012) transacaoStratus.getCampoLogico("CPO_012");
        if (campo012 != null) {
            this.mapeamentoCampo012(monitoracaoTransacao, campo012);
        }

        CPO_013 campo013 = (CPO_013) transacaoStratus.getCampoLogico("CPO_013");
        if (campo013 != null) {
            this.mapeamentoCampo013(monitoracaoTransacao, campo013);
        }
        
        CPO_018 campo018 = (CPO_018) transacaoStratus.getCampoLogico("CPO_018");
        if (campo018 != null) {
            this.mapeamentoCampo018(monitoracaoTransacao, campo018);
        }
        
        CPO_019 campo019 = (CPO_019) transacaoStratus.getCampoLogico("CPO_019");
        if (campo019 != null) {
            this.mapeamentoCampo019(monitoracaoTransacao, campo019);
        }

        CPO_027 campo027 = (CPO_027) transacaoStratus.getCampoLogico("CPO_027");
        if (campo027 != null) {
            this.mapeamentoCampo027(monitoracaoTransacao, campo027);
        }

        CPO_030 campo030 = (CPO_030) transacaoStratus.getCampoLogico("CPO_030");
        if (campo030 != null) {
            this.mapeamentoCampo030(monitoracaoTransacao, campo030);
        }

        CPO_032 campo032 = (CPO_032) transacaoStratus.getCampoLogico("CPO_032");
        if (campo032 != null) {
            this.mapeamentoCampo032(monitoracaoTransacao, campo032);
        }

        CPO_033 campo033 = (CPO_033) transacaoStratus.getCampoLogico("CPO_033");
        if (campo033 != null) {
            this.mapeamentoCampo033(monitoracaoTransacao, campo033);
        }
        
        CPO_040 campo040 = (CPO_040) transacaoStratus.getCampoLogico("CPO_040");
        CPO_071 campo071 = (CPO_071) transacaoStratus.getCampoLogico("CPO_071");
        if (campo040 != null) {
            this.mapeamentoCampo040(monitoracaoTransacao, campo040, campo071);
        }

        //Efetua mapeamento e verificação para transação do tipo STAND IN.
        this.mapeamentoTransacaoStandIn(monitoracaoTransacao, campo040, campo027);

        CPO_047 campo047 = (CPO_047) transacaoStratus.getCampoLogico("CPO_047");
        if (campo047 != null) {
            this.mapeamentoCampo047(monitoracaoTransacao, campo047);
        }

        CPO_065 campo065 = (CPO_065) transacaoStratus.getCampoLogico("CPO_065");
        if (campo065 != null) {
            this.mapeamentoCampo065(monitoracaoTransacao, campo065);
        }
        
        // Efetua mapeamento para transacao que passou pelo LYNX.
        CPO_067 campo067 = (CPO_067) transacaoStratus.getCampoLogico("CPO_067");
        if (campo067 != null) {
            this.mapeamentoCampo067(monitoracaoTransacao, campo067);
        }

        CPO_068 campo068 = (CPO_068) transacaoStratus.getCampoLogico("CPO_068");
        if (campo068 != null) {
            this.mapeamentoCampo068(monitoracaoTransacao, campo068);
        }

        CPO_074 campo074 = (CPO_074) transacaoStratus.getCampoLogico("CPO_074");
        if (campo074 != null) {
            this.mapeamentoCampo074(monitoracaoTransacao, campo074);
        }

		//Definir versão para transacao de ecommerce
		/*CPO_035 campo035= (CPO_035)transacaoStratus.getCampoLogico("CPO_035");
         if(campo035!=null) this.mapeamentoCampo035(monitoracaoTransacao, campo035);*/
        
        // Efetuar mapeamento para transacao do tipo DCC.
        CPO_073 campo073 = (CPO_073) transacaoStratus.getCampoLogico("CPO_073");
        if ((campo073 != null) && !"".equals(campo073.getFlagDCC())) {
            CPO_901 campo901 = (CPO_901) transacaoStratus.getCampoLogico("CPO_901");
            this.mapeamentoTransacaoDCC(monitoracaoTransacao, campo073, campo901, campo027);
        }

		// Define STATUS da Transação.
        // Neste momento verifico se a transação ja possui statusID definido. Se nao possuir, o mesmo é calculado.
        if (monitoracaoTransacao.getIdStatus() == null || monitoracaoTransacao.getIdStatus() == StatusTransacao.INDEFINIDO) {
            monitoracaoTransacao.setIdStatus(this.calculaStatusTransacao(monitoracaoTransacao, transacaoStratus));
        }

        // Identificar e aplicar regra sobre uma transação parcelada crédito/débito onde não houver o subproduto.
        this.identificarSubprodutoTransacaoParcelada(monitoracaoTransacao, campo006, campo074);
        
        
        // Efetua mapeamento das informações referentes ao BIT47. Para os campos CPO_905 e CPO_909, teremos uma mapeamento especifico para o release 6 do POS.
        CPO_904 campo904= (CPO_904) transacaoStratus.getCampoLogico("CPO_904");
        
        String release = monitoracaoTransacao.getReleaseEspecificacao();
        
        CampoLogicoVO campo905= (CampoLogicoVO) transacaoStratus.getCampoLogico(release != null && release.endsWith("6") ? "CPO_905_06" : "CPO_905");
        CampoLogicoVO campo909= (CampoLogicoVO) transacaoStratus.getCampoLogico(release != null && release.endsWith("6") ? "CPO_909_06" : "CPO_909");       
        if (campo905 != null) {
        	this.mapeamentoCamposBIT47(monitoracaoTransacao, campo904, campo905, campo909);	        
        }
        
        
        // Efetua mapeamento das informações referentes a Autorização Parcial.
        CPO_913 campo913 = (CPO_913) transacaoStratus.getCampoLogico("CPO_913");
        if (campo913 != null) {
            this.mapeamentoCampo913(monitoracaoTransacao, campo913);
        }

        return monitoracaoTransacao;
    }

    

    /**
     * Método responsavel em identificar e aplicar a regra sobre uma transação parcelada de crédito ou débito onde não houver o subproduto(NULL)
     * associado.
     * <br><br>
     * Após confirmação que o sub-produto é NULL:
     *
     * <DD>(*) Ao identificar se a transação é parcelada(quantidade de parcelas maior que "1") e Tipo da Transação igual a "101 - VENDA PRAZO FINC.
     * CARTAO":<br><br>
     * 			- Setar o valor "0101" para o campo subProduto do objeto MonitoracaoTransacaoAutorizadorVO. Esse valor estará associado ao dominio
     * 				da tabela "TBBAMR_PRODUTO_COMPLETO", onde a descrição será "PARCELADO EMISSOR".
     *
     * <DD>(*) Ao identificar se a transação é parcelada(quantidade de parcelas maior que "1") e Tipo da Transação igual a "102 - VENDA PRAZO
     * FINC.ESTAB":<br><br>
     * 			- Setar o valor "0102" para o campo subProduto do objeto MonitoracaoTransacaoAutorizadorVO. Esse valor estará associado ao dominio
     * 				da tabela "TBBAMR_PRODUTO_COMPLETO", onde a descrição será "PARCELADO ESTABELECIMENTO".
     *
     * <DD>(*) Ao identificar se a transação é parcelada(quantidade de parcelas maior que "1") e do tipo DESFAZIMENTO(Tipo da Transação) igual a "999 -
     * DESFAZER":<br><br>
     * 			- Setar o valor "0999" para o campo subProduto do objeto MonitoracaoTransacaoAutorizadorVO. Esse valor estará associado ao dominio
     * 				da tabela "TBBAMR_PRODUTO_COMPLETO", onde a descrição será "DESFAZIMENTO DE PARCELADO TEF4.1".
     *
     * <DD>(*) Ao identificar se a transação é parcelada(quantidade de parcelas maior que "1") e do tipo CANCELAMENTO(Tipo da Transação) igual a "103 -
     * CANCELAMENTO ONLINE":<br><br>
     * 			- Setar o valor "0103" para o campo subProduto do objeto MonitoracaoTransacaoAutorizadorVO. Esse valor estará associado ao dominio
     * 				da tabela "TBBAMR_PRODUTO_COMPLETO", onde a descrição será "CANCELAMENTO DE PARCELADO TEF4.1".
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto VO com os dados da transação.
     * 
     * @param campo006 Objeto com as informações referente ao campo CPO_006, contendo as informações referente a quantidade de parcelas, e o tipo da
     * 					transação.
     * @param campo074 Objeto com as informações referente ao campo CPO_074, onde verificamos se o valor do campo Produto secundario(subproduto) é
     * 			null ou não.
     */
    private void identificarSubprodutoTransacaoParcelada(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_006 campo006, CPO_074 campo074) {
        // Verifica se o SubProduto é NULO.
        if (campo074 == null || campo074.getProdutoSecundario() == null || "".equals(campo074.getProdutoSecundario())) {
            // Verificar se é Parcelado.
            if (campo006 != null && campo006.getQuantidadeParcelas() > 1) {
                // Verifica se será parcelado pelo Emissor. (Crédito)
                if ("101".equals(campo006.getTipoTransacao())) {
                    monitoracaoTransacao.setSubProduto("0101");
                } // Verifica se será parcelado pelo Lojista/Estabelecimento. (Crédito)
                else if ("102".equals(campo006.getTipoTransacao())) {
                    monitoracaoTransacao.setSubProduto("0102");
                } // Verifica se será parcelado pelo Emissor. (Debito CDC)
                else if ("118".equals(campo006.getTipoTransacao())) {
                    monitoracaoTransacao.setSubProduto("0118");
                } // Verifica se será parcelado pelo Lojista/Estabelecimento. (Debito CDC)
                else if ("119".equals(campo006.getTipoTransacao())) {
                    monitoracaoTransacao.setSubProduto("0119");
                } // Verifica se será é uma transacao de DESFAZIMENTO.
                else if ("999".equals(campo006.getTipoTransacao())) {
                    monitoracaoTransacao.setSubProduto("0999");
                } // Verifica se será é uma transacao de CANCELAMENTO.
                else if ("103".equals(campo006.getTipoTransacao())) {
                    monitoracaoTransacao.setSubProduto("0103");
                }
            } else {
                // Defini valor "0000" para subProduto Nulo.
                monitoracaoTransacao.setSubProduto("0000");
            }
        }
    }

    /**
     * Método responsável em calcular o Status da Transação.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto VO com os dados da transação.
     * 
     * @param transacaoStratus Objeto contendo os campos logicos do Stratus, utilizado para verificação do status.
     * 
     * @return Enum correspondente ao Status da transação.
     */
    private StatusTransacao calculaStatusTransacao(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, TransacaoStratusVO transacaoStratus) {       
    	// Verificar se CANCELADO
        if ("103".equals(monitoracaoTransacao.getTipTra())) {
            return StatusTransacao.CANCELAMENTO;        
        }  
        
        // Verificar se DESFEITO	
        if ("999".equals(monitoracaoTransacao.getTipTra()) || "607".equals(monitoracaoTransacao.getTipTra()) || "007".equals(monitoracaoTransacao.getTipTra())) {
            return StatusTransacao.DESFAZIMENTO;

        } else if ( ("1420".equals(monitoracaoTransacao.getIdMensagem()))                
        			|| ("1100".equals(monitoracaoTransacao.getIdMensagem()) && 
        					(monitoracaoTransacao.getMensagem().startsWith("TEMPO EXCEDIDO") || monitoracaoTransacao.getMensagem().startsWith("SEM RESPOSTA") ||
        					monitoracaoTransacao.getMensagem().startsWith("VERIF.CONEX.BRAD") || monitoracaoTransacao.getMensagem().startsWith("15BCO.INDISPONIV") || 
        					monitoracaoTransacao.getMensagem().startsWith("91BCO.FORA DO AR") || monitoracaoTransacao.getMensagem().startsWith("58ASS.CONTR.BCO") )        					
        				)
	                || ("1100".equals(monitoracaoTransacao.getIdMensagem()) && monitoracaoTransacao.getMensagem().startsWith("96TENTE DE NOVO") && 
	                	 !NAO_PODE_RESPONDER_DESFAZIMENTO.contains(monitoracaoTransacao.getQuemRespondeu()) ) 
                ) {
            return StatusTransacao.DESFAZIMENTO;
        }
        
        
        if (monitoracaoTransacao.getMensagem() != null) {
        	// Verificar se APROVADO
            if( (monitoracaoTransacao.getMensagem().startsWith("AP") || monitoracaoTransacao.getMensagem().startsWith("00"))
                    && ("1100".equals(monitoracaoTransacao.getIdMensagem()) || "1120".equals(monitoracaoTransacao.getIdMensagem())
                    // Código exclusivo para MULTIVAN
                    || "1200".equals(monitoracaoTransacao.getIdMensagem()))
                    && !"11".equals(monitoracaoTransacao.getCodigoErro()) ) {
                return StatusTransacao.APROVADO;
            }
            
            // Verifica se transação do tipo OFF ou VVP(Visa Vale Pedagio)
            if ( "1220".equals(monitoracaoTransacao.getIdMensagem()) ){
            	// Verifica se APROVADA OFF ou VVP(Visa Vale Pedagio)
            	if ( MENSAGENS_RETORNO_APROVADA_OFF.contains(monitoracaoTransacao.getMensagem())  
            			//Transação VVP
            			|| monitoracaoTransacao.getMensagem().startsWith("APROVADA 000000")) {
            		return StatusTransacao.APROVADO;
            	}
            	
            	// Verificar se NEGADA OFF
            	if ( MENSAGENS_RETORNO_NEGADA_OFF.contains(monitoracaoTransacao.getMensagem()) ) {
    	            if ( monitoracaoTransacao.getMensagem().startsWith("NEGADA OFF1") ){
    	            	monitoracaoTransacao.setCodigoErro("Z1");
    	            }else if ( monitoracaoTransacao.getMensagem().startsWith("NEGADA OFF3") ){
    	            	monitoracaoTransacao.setCodigoErro("Z3");
                        // neste caso, devido definição de Rodrigo Abe, o status deve ser DESFAZIMENTO. Fizemos rollback a pedido do Felipe devido a problemas de alarme no NCC
                        return StatusTransacao.NEGADO;
    	            }
                    return StatusTransacao.NEGADO;
                }
            }
        }        
        
        // Verificar se CAPTURADO, para tipo transacao de eCommerce.        
        if ("0202".equals(monitoracaoTransacao.getIdMensagem()) ){
	        CPO_020 campo020 = (CPO_020) transacaoStratus.getCampoLogico("CPO_020");
	        if (campo020 != null) {
	            if ("00".equals(campo020.getCodigoResposta())) {
	                return StatusTransacao.CAPTURADO;
	            }
	        }
		}

        // Caso nenhum case, entao é NEGADO
        return StatusTransacao.NEGADO;
    }

    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM,do campo logico CPO_001 para os atributos do
     * objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo001 Objeto com as informações referente ao campo CPO_001.
     */
    private void mapeamentoCampo001(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_001 campo001) {
        // Atribui maquina do Stratus, contido no campo logico CPO_001.
        monitoracaoTransacao.setChaveMaquina(campo001.getMaquina());

        // Atribui campo hora input do Stratus, contido no campo logico CPO_001.
        monitoracaoTransacao.setHoraInput(campo001.getDataHoraInput());

        // Atribui campo data hora input do terminal do Stratus, contido no campo logico CPO_001.
        // Se campo for nulo, usar data hora vinda do Stratus
        Date dataHoraInputTerminal = campo001.getDataHoraInputTerminal();
        dataHoraInputTerminal = dataHoraInputTerminal == null ? campo001.getDataHoraHost() : dataHoraInputTerminal;
        monitoracaoTransacao.setDataHoraInputTerminal(dataHoraInputTerminal);

        // Atribui campo valor de venda do Stratus, contido no campo logico CPO_001.
        monitoracaoTransacao.setValorVenda(campo001.getValorVenda());

        // Atribui campo data hora vinda do Stratus, contido no campo logico CPO_001.		
        monitoracaoTransacao.setDataHoraStratus(campo001.getDataHoraHost());
        
        // Atribui campo resolutor(Autorizador) vinda do Stratus, contido no campo logico CPO_001.		
        monitoracaoTransacao.setResolutor(campo001.getAutorizador());

        // Atribui campo referente o codigo da mensagem vinda do POS ou da plataforma, contido no campo logico CPO_001.
        monitoracaoTransacao.setTransacaoPOS(campo001.getTransacaoPOS());
    }

    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM,do campo logico CPO_006 para os atributos do
     * objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo006 Objeto com as informações referente ao campo CPO_006.
     */
    private void mapeamentoCampo006(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_006 campo006) {
        // Atribui campo transacao do Stratus, contido no campo logico CPO_006.
        monitoracaoTransacao.setIdMensagem(campo006.getTransacao());

        // Atribui campo codigo de processamento vindo do Stratus, contido no campo logico CPO_006.		
        monitoracaoTransacao.setCodigoProcessamento(campo006.getCodigoProcessamento());

        // Atribui campo produto vinda do Stratus, contido no campo logico CPO_006.		
        monitoracaoTransacao.setProduto(campo006.getProduto());

        // Atribui campo tipo de transacao vinda do Stratus, contido no campo logico CPO_006.		
        monitoracaoTransacao.setTipTra(campo006.getTipoTransacao());
        
        // Atribui a forma de entrada: Chip, Tarda, etc.. (Ver metodo get para maiores detalhes)
        monitoracaoTransacao.setFormaDeEntrada((campo006.getFormaDeEntrada() !=null && campo006.getFormaDeEntrada().length()==1) 
                ? campo006.getFormaDeEntrada().charAt(0): null);
        
        // Atribui campo NSU vindo do Stratus, contido no campo logico CPO_006.		
        monitoracaoTransacao.setNSU(campo006.getNsu());
        
// ajusta a quantidade de parcelas
        monitoracaoTransacao.setQuantidadeParcelas(campo006.getQuantidadeParcelas());
    }
    
    /**
     * Metodo responsavel em efetuar o mapeamento Roteamento da Transacao. Por enquanto, apenas flagPP esta sendo mapeado
     * devido a necessidade de monitoracao plataforma Promocional da Cielo.
     * do objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo009 Objeto com as informações referente ao campo CPO_010.
     */
    private void mapeamentoCampo009(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_009 campo009) {
        String ppFlag = campo009.getFlagPPOnline();
        monitoracaoTransacao.setFlagCieloPromo(ppFlag);
    }
    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM, do campo logico CPO_010 para os atributos
     * do objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo010 Objeto com as informações referente ao campo CPO_010.
     */
    private void mapeamentoCampo010(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_010 campo010) {
        // Atribui campo bin vinda do Stratus, contido no campo logico CPO_010.
        String bin = "";
        String digFinais="";

        if (campo010.getNumeroCartao() != null && campo010.getNumeroCartao().length() >= 6) {
            bin = campo010.getNumeroCartao().substring(0, 6);
            String numCartao=campo010.getNumeroCartao().trim();
            if (numCartao.length() >=10) {
                digFinais = numCartao.substring(numCartao.length() - 4);
            }
        } else {
            bin = campo010.getNumeroCartao();
        }
        
        monitoracaoTransacao.setBin(bin);
        monitoracaoTransacao.setNumCartaoMascarado(bin+"******"+digFinais);
    }

    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM,do campo logico CPO_012 para os atributos do
     * objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo012 Objeto com as informações referente ao campo CPO_012.
     */
    private void mapeamentoCampo012(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_012 campo012) {
        // Atribui campo codigo estabelecimento vinda do Stratus, contido no campo logico CPO_012.
        String codigoEC = (campo012.getNumeroEstabelecimento() != null && campo012.getNumeroEstabelecimento().length() > 10)
                			? campo012.getNumeroEstabelecimento().substring(1) : campo012.getNumeroEstabelecimento();
        monitoracaoTransacao.setCodigoEstabelecimento(codigoEC);

        // Atribui campo codigo Loja vinda do Stratus, contido no campo logico CPO_012.		
        monitoracaoTransacao.setCodigoLoja(campo012.getNumeroLoja());
        
        // Atribui campo MCC vinda do Stratus, contido no campo logico CPO_012.		
        monitoracaoTransacao.setMcc(String.valueOf(campo012.getNumeroMcc()));

        // Atribui campo UF vinda do Stratus, contido no campo logico CPO_012.		
        monitoracaoTransacao.setUf(campo012.getUf());

        // Atribui campo CEP vinda do Stratus, contido no campo logico CPO_012.		
        monitoracaoTransacao.setCep(campo012.getCep());
    }

    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM,do campo logico CPO_013 para os atributos do
     * objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo013 Objeto com as informações referente ao campo CPO_013.
     */
    private void mapeamentoCampo013(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_013 campo013) {
        // Atribui campo codigo Terminal vinda do Stratus, contido no campo logico CPO_013.		
        monitoracaoTransacao.setTerminal(campo013.getCodigoTerminal());

        // Atribui campo codigo do Nó vinda do Stratus, contido no campo logico CPO_013.		
        monitoracaoTransacao.setCodigoNo(campo013.getCodigoNoTerminal());

        // Atribui campo versao do terminal vinda do Stratus, contido no campo logico CPO_013. Desconsiderar a ultima posicao		
        monitoracaoTransacao.setDadosVersaoTerminal(campo013.getVersaoTerminal());
        
        //Atribui Mapeamento de dado do BIT47, referente a release da especificação usada, o modelo do terminal e a versão do aplicativo instalado.
        if(campo013.getVersaoTerminal() != null && !"".equals(campo013.getVersaoTerminal())){
        	monitoracaoTransacao.setReleaseEspecificacao(campo013.getVersaoTerminal().substring(2, 4));
        	monitoracaoTransacao.setModeloTerminal(campo013.getVersaoTerminal().substring(5, 9));
        	monitoracaoTransacao.setVersaoAplicativo(campo013.getVersaoTerminal().substring(9, 11));
        } else {
            java.util.logging.Logger.getLogger(TransacaoMonitoracaoParser.class.getName()).fine("Versão terminal não reconhecida para CPO_013:"+campo013.toString());
        }       
    }

    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM,do campo logico CPO_019 para os atributos do
     * objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo019 Objeto com as informações referente ao campo CPO_019.
     */
    private void mapeamentoCampo019(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_019 campo019) {
        // Atribui campo Ciers Entrada vinda do Stratus, contido no campo logico CPO_019.		
        monitoracaoTransacao.setCiersMonitoracao(campo019.getCiersMonitoracao());

        // Atribui campo Switch Visa vinda do Stratus, contido no campo logico CPO_019.		
        monitoracaoTransacao.setSwitchVisa((campo019.getSwitchVisa().equals("1") ? true : false));

        // Atribui campo Indicador Skyline vinda do Stratus, contido no campo logico CPO_019.		
        monitoracaoTransacao.setIndicadorSkyLine((campo019.getIndicadorSkyline().equals("1") ? true : false));

        // Atribui campo Codigo do Serviço POS vinda do Stratus, contido no campo logico CPO_019.		
        monitoracaoTransacao.setCodigoServicoPOS(campo019.getCodigoServicoPOS());
    }

    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM,do campo logico CPO_027 para os atributos do
     * objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo027 Objeto com as informações referente ao campo CPO_027.
     */
    private void mapeamentoCampo027(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_027 campo027) {
        // Atribui campo Observacao vinda do Stratus, contido no campo logico CPO_027.		
        monitoracaoTransacao.setObservacao(campo027.getObservacao());

        // Atribui campo Quem Respondeu vinda do Stratus, contido no campo logico CPO_027.		
        monitoracaoTransacao.setQuemRespondeu(campo027.getQuemRespondeu());

        // Atribui campo Mensagem vinda do Stratus, contido no campo logico CPO_027.		
        monitoracaoTransacao.setMensagem(campo027.getMensagem());

        // Atribui campo Codigo Resposta vinda do Stratus, contido no campo logico CPO_027.		
        monitoracaoTransacao.setCodigoErro(campo027.getCodigoResposta());
        
        monitoracaoTransacao.setCodigoAutorizacao(campo027.getCodigoAut());
    }

    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM,do campo logico CPO_030 para os atributos do
     * objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo030 Objeto com as informações referente ao campo CPO_030.
     */
    private void mapeamentoCampo030(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_030 campo030) {
        // Atribui campo Source Code vinda do Stratus, contido no campo logico CPO_030.		
        monitoracaoTransacao.setSourceCode(campo030.getAuthSourceCode());
    }

    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM,do campo logico CPO_032 para os atributos do
     * objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo032 Objeto com as informações referente ao campo CPO_032.
     */
    private void mapeamentoCampo032(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_032 campo032) {
        /* Atribui Modo de conexao vinda do Stratus, contido no campo logico CPO_032. O valor do atributo "modoEntrada" é no formato "PLSCXZZYYYYY", 
         * utilizar os elementos ZZ desse conteudo.
         */
        String modoEntrada = campo032.getModoEntrada();
        if (modoEntrada != null & modoEntrada.length() > 0) {
			try {
				monitoracaoTransacao.setModoConexao(modoEntrada.substring(5, 7).trim());
			} catch (IndexOutOfBoundsException e) {
				if (modoEntrada.length() > 4) {
					monitoracaoTransacao.setModoConexao(modoEntrada.substring(5, 6).trim());
				}
			}
        } 
        
        if (modoEntrada != null & modoEntrada.length() == 12) {
            monitoracaoTransacao.setTipoSolucaoCapturaModoEntrada(modoEntrada.substring(10,11));
        }
    }

    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM,do campo logico CPO_065 para os atributos do
     * objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo065 Objeto com as informações referente ao campo CPO_065.
     */
    private void mapeamentoCampo065(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_065 campo065) {
        /* Atribui Modo de conexao vinda do Stratus, contido no campo logico CPO_065. O valor do atributo "nsuCan" é no formato numerico de 9 posicoes 
         */
        String nsuCan = campo065.getNsuCan();
        if (nsuCan != null & nsuCan.length() > 0) {
            monitoracaoTransacao.setNsuCanRef(nsuCan);
        } 
        // Atribui valor do cancelamento. Se for parcial, então eh o valor aprovado.
        monitoracaoTransacao.setValorCancelamento(campo065.getValorCan());
    }
    
    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM, do campo logico CPO_035 para os atributos
     * do objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo035s Objeto com as informações referente ao campo CPO_035.
     */
    @SuppressWarnings("unused")
    private void mapeamentoCampo035(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_035 campo035) {
		// Atribui a versão do ecommerce onde a transação foi executada, utilizando os valores do atributo "tcidPayGateway" no campo logico CPO_035.
        // Verifica se ao primeiras posições do atributo "tcidPayGateway"(que corresponde ao EC) é igual ao valor do EC contido no atributo 
        // "CodigoEstabelecimento"; se for então a versão é "1.5", caso contrário versão "1.0".		
        String cp35EC = campo035.getTcidPayGateway().substring(0, 10);
        String versaoEcommerce = null;
        if ((monitoracaoTransacao.getTipoTecnologia().equals("08") || monitoracaoTransacao.getTipoTecnologia().equals("09"))
                && cp35EC.equals(monitoracaoTransacao.getCodigoEstabelecimento().substring(1))) {
            versaoEcommerce = "1.5";
        } else {
            versaoEcommerce = "1.0";
        }

        monitoracaoTransacao.setVersaoEcommerce(versaoEcommerce);
    }

    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM, do campo logico CPO_040 para os atributos
     * do objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo040 Objeto com as informações referente ao campo CPO_040.
     * @param campo071 Objeto com as informações referente ao campo CPO_071.
     */
    private void mapeamentoCampo040(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_040 campo040, CPO_071 campo071) {
		// Atribui campo Tipo de Tecnologia vinda do Stratus, contido no campo logico CPO_040.
        // Verifica se o codigo do terminal se inicia com "10" ou "11", caso seja atribuir valor da tecnologia para eCommerce (codigo= 08).
        if (monitoracaoTransacao.getTerminal() != null && (monitoracaoTransacao.getTerminal().startsWith("10") || monitoracaoTransacao.getTerminal().startsWith("11"))) {
            monitoracaoTransacao.setTipoTecnologia("08");

            //Verifica se o conteudo do atributo "indicadorMobile" da classe CPO_071 é igual a "S", caso seja atribuir valor da tecnologia para Mobile (codigo= 13).
        } else if (campo071 != null && "S".equalsIgnoreCase(campo071.getIndicadorMobile())) {
            monitoracaoTransacao.setTipoTecnologia("13");
        } else {
            monitoracaoTransacao.setTipoTecnologia(campo040.getMonTecnologia());
        }

        // Atribui campo Cidade vinda do Stratus, contido no campo logico CPO_040.		
        monitoracaoTransacao.setCidade(campo040.getMonCidade());

        // Atribui campo Bandeira vinda do Stratus, contido no campo logico CPO_040.		
        monitoracaoTransacao.setBandeira(campo040.getBandeira());

        // Atribui campo Banco Emissor vinda do Stratus, contido no campo logico CPO_040.		
        monitoracaoTransacao.setBanco(campo040.getBancoEmissor());
        
        //Atribui campo Codigo Nó Secundario vinda do Stratus, contido no campo logico CPO_040.
        monitoracaoTransacao.setCodigoNoSecundario(campo040.getTerminalCodigoNoSec());
    }

    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM, utilizado para transações STAND IN.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo040 Objeto com as informações referente ao campo CPO_040.
     * @param campo027 Objeto com as informações referente ao campo CPO_027.
     */
    private void mapeamentoTransacaoStandIn(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_040 campo040, CPO_027 campo027) {
        //Verifica se transação é STAND IN, e define as informações.
        if (campo027 != null && "SI".equals(campo027.getQuemRespondeu())) {
            monitoracaoTransacao.setStandIn(true);

            InformacoesStandIn informacoesStandIn = new InformacoesStandIn();

            // Verifica se ja foi enviado.
            if (campo040 != null) {
                informacoesStandIn.setEnviado(campo040.getStandInFlag());
            }

            String condicaoStandIn = campo027.getObservacao();
            if ("400".equals(condicaoStandIn)) {
                informacoesStandIn.setProgramado(true);
            } else if ("401".equals(condicaoStandIn)) {
                informacoesStandIn.setQuedaLink(true);
            } else if ("402".equals(condicaoStandIn)) {
                informacoesStandIn.setEmergencial(true);
            } else if ("407".equals(condicaoStandIn)) {
                informacoesStandIn.setTimeout(true);
            }

            monitoracaoTransacao.setInformacoesStandIn(informacoesStandIn);
        }
    }

    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM, do campo logico CPO_047 para os atributos
     * do objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo047 Objeto com as informações referente ao campo CPO_047.
     */
    private void mapeamentoCampo047(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_047 campo047) {
        // Atribui campo Código Operadora GPRS vindo do Stratus, contido no campo logico CPO_047.		
        monitoracaoTransacao.setCodigoOperadoraGPRS(campo047.getCodigoOperadora());
    }

    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM, do campo logico CPO_067 para os atributos
     * do objeto MonitoracaoTransacaoAutorizadorVO. Informações referentes ao LYNX.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo067 Objeto com as informações referente ao campo CPO_067.
     */
    private void mapeamentoCampo067(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_067 campo067) {
        InformacoesLynx informacoesLynx = new InformacoesLynx();
        // Atribui campo Status vindo do Stratus, contido no campo logico CPO_067.
        informacoesLynx.setStatus(campo067.getStatus());

        // Atribui campo timeout vindo do Stratus, contido no campo logico CPO_067.
        if ("S".equalsIgnoreCase(campo067.getTimeout())) {
            informacoesLynx.setTimeout(true);
        }

        // Atribui campo ação vindo do Stratus, contido no campo logico CPO_067.
        informacoesLynx.setCodigoAcao(campo067.getAcao());

        // Atribui campo regra do filtro vindo do Stratus, contido no campo logico CPO_067.
        informacoesLynx.setRegraFiltro(campo067.getRegraFiltro());

        // Atribui campo regra do Lynx vindo do Stratus, contido no campo logico CPO_067.
        informacoesLynx.setRegraLynx(campo067.getRegraLynx());

        // Atribui campo score neural vindo do Stratus, contido no campo logico CPO_067.
        informacoesLynx.setScoreNeural(campo067.getScoreNeural());

        // Atribui campo score neural vindo do Stratus, contido no campo logico CPO_067.
        informacoesLynx.setScoreRegra(campo067.getScoreRegra());

        // Atribui campo behaviour vindo do Stratus, contido no campo logico CPO_067.
        informacoesLynx.setBehaviour(campo067.getBehaviour());

        // Atribui campo Flag CTF vindo do Stratus, contido no campo logico CPO_067.
        informacoesLynx.setFlagCTF(campo067.getFlagCTFTran());

        monitoracaoTransacao.setLynx(true);
        monitoracaoTransacao.setInformacoesLynx(informacoesLynx);
    }

    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM, do campo logico CPO_068 para os atributos
     * do objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo068 Objeto com as informações referente ao campo CPO_068.
     */
    private void mapeamentoCampo068(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_068 campo068) {
        // Atribui campo Data/hora que a transação sai do POS e entra no Stratus(Stratus recebe a transação do POS), contido no campo logico CPO_068.		
        monitoracaoTransacao.setDataHoraEntradaStratusSaidaPOS(campo068.getAdqEntrada());

        // Atribui campo Data/hora que a transação sai do Stratus e é retornado ao POS, contido no campo logico CPO_068.		
        monitoracaoTransacao.setDataHoraRetornoAoPOS(campo068.getAdqSaida());

        // Atribui campo Data/hora que a transação sai do Stratus e enviada para a Bandeira/Banco, contido no campo logico CPO_068.		
        monitoracaoTransacao.setDataHoraSaidaStratusEntradaBandeira(campo068.getResEntrada());

        // Atribui campo Data/hora que a transação volta da Bandeira/Banco e entra no Stratus novamente, contido no campo logico CPO_068.		
        monitoracaoTransacao.setDataHoraRetornoBandeira(campo068.getResSaida());

        // Atribui campo Data/hora que a transação sai do Stratus e enviada para o HSM, contido no campo logico CPO_068.		
        monitoracaoTransacao.setDataHoraSaidaStratusEntradaHSM(campo068.getHsmEntrada());

        // Atribui campo Data/hora que a transação volta do HSM e entra no Stratus novamente, contido no campo logico CPO_068.		
        monitoracaoTransacao.setDataHoraRetornoHSM(campo068.getHsmSaida());
    }

    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM, do campo logico CPO_040 para os atributos
     * do objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo040 Objeto com as informações referente ao campo CPO_040.
     */
    private void mapeamentoCampo074(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_074 campo074) {
        // Atribui campo Produto secundario vindo do Stratus, contido no campo logico CPO_074.		
        monitoracaoTransacao.setSubProduto(campo074.getProdutoSecundario());
    }
    
    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM, dos campo logicos das tranasações do tipo
     * DCC para os atributos do objeto MonitoracaoTransacaoAutorizadorVO.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo073 Objeto com as informações referente ao campo CPO_073.
     * @param campo901 Objeto com as informações referente ao campo CPO_901.
     * @param campo027 Objeto com as informações referente ao campo CPO_027.
     */
    private void mapeamentoTransacaoDCC(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_073 campo073, CPO_901 campo901, CPO_027 campo027) {
        InformacoesDCC informacoesDCC = new InformacoesDCC();

        // Define Status DCC, e o tipo da transacao(Consulta ou Financeira).
        this.calculaStatusETipoTransacaoDCC(informacoesDCC, campo073, campo027);

        // Preenche com as informações de conversão.
        if (campo901 != null) {
            //Atribui campo codigo da moeda do portador vindo do Stratus, contido no campo logico CPO_901.
            informacoesDCC.setCodigoMoedaPortador(campo901.getDccMoedaPortador());

            //Atribui campo descricao da moeda do portador vindo do Stratus, contido no campo logico CPO_901.
            informacoesDCC.setDescricaoMoedaPortador(campo901.getDccDescricaoMoeda());

            //Atribui campo valor de markup vindo do Stratus, contido no campo logico CPO_901.
            informacoesDCC.setValorMarkup(campo901.getDccValorMarkup());

            //Atribui campo Percentual de Markup PL vindo do Stratus, contido no campo logico CPO_901.
            informacoesDCC.setPercentualMarkup(campo901.getDccPercentualMarkupPl());

            //Atribui campo digito trans portador vindo do Stratus, contido no campo logico CPO_901.
            informacoesDCC.setDigitoTransacaoPortador(campo901.getDccDigTransPortador());

            //Atribui campo trans moeda portador vindo do Stratus, contido no campo logico CPO_901.
            informacoesDCC.setValorTransacaoMoedaPortador(campo901.getDccTransMoedaPortador());

            //Atribui campo trans moeda dol vindo do Stratus, contido no campo logico CPO_901.
            informacoesDCC.setValorTransacaoDolar(campo901.getDccTransMoedaDol());

            //Atribui campo digito moeda portador vindo do Stratus, contido no campo logico CPO_901.
            informacoesDCC.setDigitoMoedaPortador(campo901.getDccDigitoMoedaPortador());

            //Atribui campo cotacao moeda portador vindo do Stratus, contido no campo logico CPO_901.
            informacoesDCC.setCotacaoMoedaPortador(campo901.getDccCotacaoMoedaPortador());

            //Atribui campo digito cotacao dol vindo do Stratus, contido no campo logico CPO_901.
            informacoesDCC.setDigitoCotacaoDolar(campo901.getDccDigitoCotacaoDol());

            //Atribui campo cotacao dol planet vindo do Stratus, contido no campo logico CPO_901.
            informacoesDCC.setCotacaoDolarPlanet(campo901.getDccCotacaoDolPl());

            //Atribui campo data e hora cambio planet vindo do Stratus, contido no campo logico CPO_901.
            informacoesDCC.setDataHoraCambioPlanet(campo901.getDccDataHoraCambioPl());

            //Atribui campo hora da autorizacao da transacao vindo do Stratus, contido no campo logico CPO_901.
            informacoesDCC.setHoraAutorizacaoTransacao(campo901.getDccHoraAutorizacaoTransacao());

            //Atribui campo tempo de resposta da planet vindo do Stratus, contido no campo logico CPO_901.
            informacoesDCC.setTempoRespostaPlanet(campo901.getDccTempoRespostaPlanet());
        }

        // Atribui as informações do tipo DCC para a transacao de Monitoracao(MonitoracaoTransacaoAutorizadorVO).
        monitoracaoTransacao.setDCC(true);
        monitoracaoTransacao.setInformacoesDCC(informacoesDCC);
    }

    /**
     * Método responsável em calcular o Status DCC da Transação.
     * <br><br>
     *
     * @param informacoesDCC Objeto com as informações de transacao DCC.
     * @param campo073 Objeto com as informações referente ao campo CPO_073.
     * @param campo027 Objeto com as informações referente ao campo CPO_027.
     *
     */
    private void calculaStatusETipoTransacaoDCC(InformacoesDCC informacoesDCC, CPO_073 campo073, CPO_027 campo027) {
        //Define o status DCC da transacao.
        char flagDcc = campo073.getFlagDCC().charAt(0);

        switch (flagDcc) {
            case 'E':
                informacoesDCC.setStatusDCC(StatusDCC.ELEGIVEL);
                break;
            case 'N':
                informacoesDCC.setStatusDCC(StatusDCC.NAO_ELEGIVEL);
                break;
            case 'D':
                informacoesDCC.setStatusDCC(StatusDCC.DCC);
                break;
            case 'P':
                informacoesDCC.setStatusDCC(StatusDCC.NEGADO_PELA_PLANET);
                break;
            case 'O':
                informacoesDCC.setStatusDCC(StatusDCC.NAO_SELECIONADO_DCC_CLIENTE);
                break;
            case 'T':
                informacoesDCC.setStatusDCC(StatusDCC.TIMEOUT_PLANET);
                break;
            case 'F':
                informacoesDCC.setStatusDCC(StatusDCC.TIMEOUT_PLANET);
                break;
            case ' ':
                informacoesDCC.setStatusDCC(StatusDCC.NAO_ELEGIVEL);
                break;
            default:
                informacoesDCC.setStatusDCC(StatusDCC.NAO_ELEGIVEL);
                break;
        }

        //Verifica e defini o tipo da transação DCC (C- Consulta, F - Financeira).
        if (!"".equals(campo027.getObservacao()) && CODIGOS_RETORNO_CONSULTA_DCC.contains(campo027.getObservacao())) {
            informacoesDCC.setTipoTransacao("C");
        } else {
            informacoesDCC.setTipoTransacao("F");
        }
    }
    
    
    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM, dos campos logicos CPO_904, CPO_905 e CPO_909 para 
     * os atributos do objeto MonitoracaoTransacaoAutorizadorVO. Informações referentes ao BIT47.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo904 Objeto com as informações referente ao campo CPO_904.
     * @param campo905 Objeto com as informações referente ao campo CPO_905.
     * @param campo909 Objeto com as informações referente ao campo CPO_909.
     * @throws ParserException 
     */
    private void mapeamentoCamposBIT47(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_904 campo904, CampoLogicoVO campo905, CampoLogicoVO campo909) throws ParserException {
    	try {
	    	//Efetuar Mapeamento BIT47
	    	InformacoesBIT47 informacoesBIT47= new InformacoesBIT47();
	    	String release = monitoracaoTransacao.getReleaseEspecificacao();
	    	//Informações referentes a GPRS
	    	if (campo909 != null) {
	    		CPO_909 campo909Orig= null;
	    		CPO_909_06 campo909_06= null;
	    		
	    		// Verifica o release da especificação POS, para recuperar o valor do campo referente Geo-localização.
                        
	    		if(release != null & release.endsWith("6") ){
	    			campo909_06= (CPO_909_06) campo909;
	    			
		    		informacoesBIT47.setNivelSinalGPRS(campo909_06.getBit47TsSinal());
		    		informacoesBIT47.setFallback(campo909_06.getBit47FallBack());
		    		
		    		informacoesBIT47.setGeoLocalizacao(campo909_06.getBit47Geolocalizacao());
	    		}else{
	    			campo909Orig= (CPO_909) campo909;
	    			
	    			informacoesBIT47.setNumeroDocumento(campo909Orig.getBit47NumeroDocumento());
		    		informacoesBIT47.setNivelSinalGPRS(campo909Orig.getBit47TsSinal());
		    		informacoesBIT47.setFallback(campo909Orig.getBit47FallBack());	    	
	    		}
	    	}
	    	
	    	if (campo905 != null) {
	    		CPO_905 campo905Orig= null;
	    		CPO_905_06 campo905_06= null;
	    		
	    		// Verifica o release da especificação POS.
	    		if(release != null && release.endsWith("6") ){
	    			campo905_06= (CPO_905_06) campo905;
	    	
		    		DateTimeFormatter fmt= DateTimeFormat.forPattern("yyMMddHHmmss");		    			    		
		    		try {
		    			String dataHora= campo905_06.getBit47Pref_1().substring(0, campo905_06.getBit47Pref_1().indexOf("FFFF"));
						informacoesBIT47.setDataHoraTransacaoBIT47(fmt.parseDateTime(dataHora).toDate());
					} catch (Exception e) {
						informacoesBIT47.setDataHoraTransacaoBIT47(null);
					}
	    		
		    		informacoesBIT47.setModoConexao(campo905_06.getModoConexao_1());		    				    		
		    		informacoesBIT47.setNumeroDiscado(campo905_06.getTelefoneDiscado_1_A());
		    		informacoesBIT47.setQtdeTentativasDiscagens( Integer.parseInt(campo905_06.getQuantidadeTentativasDiscagens_1_A()) );
		    		
		    		for(int i= 1; i <= informacoesBIT47.getQtdeTentativasDiscagens(); i++) {
		    			String nomeCampo= "resultadoDiscagem_1_A" + i;
		    			
		    			InformacoesDiscagemBIT47 informacoesDiscagem= new InformacoesDiscagemBIT47();
		    			informacoesDiscagem.setNumeroDaTentativa(i);
		    			
		    			informacoesDiscagem.setCodigoRespostaDiscagem( (String) PropertyUtils.getProperty(campo905_06, nomeCampo) );
							    			
		    			if("OK".equalsIgnoreCase(informacoesDiscagem.getCodigoRespostaDiscagem())){
		    				informacoesDiscagem.setSucesso(true);
		    			}				
		    			
		    			informacoesBIT47.addInformacoesDiscagem(informacoesDiscagem);
					}
		    		
	    		}else{
	    			campo905Orig= (CPO_905) campo905;
	    			
	    			DateTimeFormatter fmt= DateTimeFormat.forPattern("yyMMddHHmmss");		    			    		
		    		try {
		    			String dataHora= campo905Orig.getBit47Pref_1().substring(0, campo905Orig.getBit47Pref_1().indexOf("FFFF"));
						informacoesBIT47.setDataHoraTransacaoBIT47(fmt.parseDateTime(dataHora).toDate());
					} catch (Exception e) {
						informacoesBIT47.setDataHoraTransacaoBIT47(null);
					}
	    		
		    		informacoesBIT47.setModoConexao(campo905Orig.getModoConexao_1());
		    		informacoesBIT47.setModoDiscagem(campo905Orig.getModoDiscagem_1());
		    		
		    		informacoesBIT47.setNumeroDiscado(campo905Orig.getTelefoneDiscado_1_A());
		    		informacoesBIT47.setQtdeTentativasDiscagens( Integer.parseInt(campo905Orig.getQuantidadeTentativasDiscagens_1_A()) );
		    		
		    		for(int i= 1; i <= informacoesBIT47.getQtdeTentativasDiscagens(); i++) {
		    			String nomeCampo= "resultadoDiscagem_1_A" + i;
		    			
		    			InformacoesDiscagemBIT47 informacoesDiscagem= new InformacoesDiscagemBIT47();
		    			informacoesDiscagem.setNumeroDaTentativa(i);
		    			
		    			informacoesDiscagem.setCodigoRespostaDiscagem( (String) PropertyUtils.getProperty(campo905Orig, nomeCampo) );
							    			
		    			if("OK".equalsIgnoreCase(informacoesDiscagem.getCodigoRespostaDiscagem())){
		    				informacoesDiscagem.setSucesso(true);
		    			}				
		    			
		    			informacoesBIT47.addInformacoesDiscagem(informacoesDiscagem);
					}	    			
	    		}
	    	}
	    	
	    	if (campo904 != null) {
	    		informacoesBIT47.setNumeroDocumento(campo904.getNumeroDocumento1());
	    		informacoesBIT47.setTempoTransacao(campo904.getTempoResposta1());
	    	}
	    	
	    	
	    	monitoracaoTransacao.setInformacoesBIT47(informacoesBIT47);
    	
    	} catch (Exception e) {					
			throw new ParserException(e);
		}
    }
    
    
    /**
     * Metodo responsavel em efetuar o mapeamento "De->Para" dos atributos usados na monitoração do BAM,do campo logico CPO_913 para os atributos do
     * objeto MonitoracaoTransacaoAutorizadorVO. Informações referentes a Autorização Parcial.
     * <br><br>
     *
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo913 Objeto com as informações referente ao campo CPO_913.
     */
    private void mapeamentoCampo913(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_913 campo913) {
        String flagIndi = campo913.getFlagIndicativoAutorizacaoParcial();

        // Atribui valor do indicativo de autorizacao parcial, contido no campo logico CPO_913.
        monitoracaoTransacao.setIndicativoAutorizacaoParcial(flagIndi);

        // Ajusta Origem Multivan
        monitoracaoTransacao.setCodMultivan(campo913.getRedeVan());

        // Atribui valor se a transação é ou não do tipo "Autorização Parcial".
        if (flagIndi != null && (INDICADOR_AUTORIZACAO_PARCIAL.contains(flagIndi))) {
            monitoracaoTransacao.setAutorizacaoParcial(true);
        }
        if ("S".equalsIgnoreCase(campo913.getTokenFlag())) {
            monitoracaoTransacao.setIndicTransacaoToken(true);
        }
        // Ajusta nr. do celular para envio de SMS - v6.7.2
        if (StringUtils.isNotBlank(campo913.getNumeroCelularSms())) {
            monitoracaoTransacao.setNumeroCelularSms(campo913.getNumeroCelularSms());
        }
    }

    /**
     * Metodo responsável por ajustar o mapeamento "De-Para" dos atributos utilozados no campo logico CPO_033 para atributos do objeto MOnitoracalTransacaoAutoriadorVO
     * @param monitoracaoTransacao Objeto MonitoracaoTransacaoAutorizadorVO a ser populado.
     * @param campo033 
     */
    private void mapeamentoCampo033(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_033 campo033) {
        monitoracaoTransacao.setRecorrente(campo033.isRecorrente());
    }

    private void mapeamentoCampo018(MonitoracaoTransacaoAutorizadorVO monitoracaoTransacao, CPO_018 campo018) {
        monitoracaoTransacao.setNsuConfirmacaoAutorizacaoPOS(StringUtils.isNotBlank(campo018.getBit62NrDoc1()) ?  campo018.getBit62NrDoc1() : null);
    }

    
}
