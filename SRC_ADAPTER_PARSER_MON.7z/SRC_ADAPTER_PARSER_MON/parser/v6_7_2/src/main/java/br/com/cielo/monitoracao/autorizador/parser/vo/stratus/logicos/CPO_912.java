package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_912, sobre Dados do BIT47.
 * 
 * <DL><DT><B>Criada em:</B><DD>22/04/2014</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_912 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String bit47V41IndSub2;
	private String bit47V41QtdTra2;	
	private String bit47V41NrDoc_1;
	private String bit47V41LinImp_1;
	private String bit47V41NrDoc_2;
	private String bit47V41LinImp_2;
	private String bit47V41NrDoc_3;
	private String bit47V41LinImp_3;
	private String bit47V41NrDoc_4;
	private String bit47V41LinImp_4;
	private String bit47V41NrDoc_5;
	private String bit47V41LinImp_5;
	
	
	public CPO_912(){		
	}
	

	/**
	 * @return the bit47V41IndSub2
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public String getBit47V41IndSub2() {
		return bit47V41IndSub2;
	}
	/**
	 * @param bit47v41IndSub2 the bit47V41IndSub2 to set
	 */
	public void setBit47V41IndSub2(String bit47v41IndSub2) {
		bit47V41IndSub2 = bit47v41IndSub2;
	}

	/**
	 * @return the bit47V41QtdTra2
	 */
	@PositionalField(initialPosition= 3, finalPosition= 4)
	public String getBit47V41QtdTra2() {
		return bit47V41QtdTra2;
	}
	/**
	 * @param bit47v41QtdTra2 the bit47V41QtdTra2 to set
	 */
	public void setBit47V41QtdTra2(String bit47v41QtdTra2) {
		bit47V41QtdTra2 = bit47v41QtdTra2;
	}

	/**
	 * @return the bit47V41NrDoc_1
	 */
	@PositionalField(initialPosition= 5, finalPosition= 10)
	public String getBit47V41NrDoc_1() {
		return bit47V41NrDoc_1;
	}
	/**
	 * @param bit47v41NrDoc_1 the bit47V41NrDoc_1 to set
	 */
	public void setBit47V41NrDoc_1(String bit47v41NrDoc_1) {
		bit47V41NrDoc_1 = bit47v41NrDoc_1;
	}

	/**
	 * @return the bit47V41LinImp_1
	 */
	@PositionalField(initialPosition= 11, finalPosition= 16)
	public String getBit47V41LinImp_1() {
		return bit47V41LinImp_1;
	}
	/**
	 * @param bit47v41LinImp_1 the bit47V41LinImp_1 to set
	 */
	public void setBit47V41LinImp_1(String bit47v41LinImp_1) {
		bit47V41LinImp_1 = bit47v41LinImp_1;
	}

	/**
	 * @return the bit47V41NrDoc_2
	 */
	@PositionalField(initialPosition= 17, finalPosition= 22)
	public String getBit47V41NrDoc_2() {
		return bit47V41NrDoc_2;
	}
	/**
	 * @param bit47v41NrDoc_2 the bit47V41NrDoc_2 to set
	 */
	public void setBit47V41NrDoc_2(String bit47v41NrDoc_2) {
		bit47V41NrDoc_2 = bit47v41NrDoc_2;
	}

	/**
	 * @return the bit47V41LinImp_2
	 */
	@PositionalField(initialPosition= 23, finalPosition= 28)
	public String getBit47V41LinImp_2() {
		return bit47V41LinImp_2;
	}
	/**
	 * @param bit47v41LinImp_2 the bit47V41LinImp_2 to set
	 */
	public void setBit47V41LinImp_2(String bit47v41LinImp_2) {
		bit47V41LinImp_2 = bit47v41LinImp_2;
	}

	/**
	 * @return the bit47V41NrDoc_3
	 */
	@PositionalField(initialPosition= 29, finalPosition= 34)
	public String getBit47V41NrDoc_3() {
		return bit47V41NrDoc_3;
	}
	/**
	 * @param bit47v41NrDoc_3 the bit47V41NrDoc_3 to set
	 */
	public void setBit47V41NrDoc_3(String bit47v41NrDoc_3) {
		bit47V41NrDoc_3 = bit47v41NrDoc_3;
	}

	/**
	 * @return the bit47V41LinImp_3
	 */
	@PositionalField(initialPosition= 35, finalPosition= 40)
	public String getBit47V41LinImp_3() {
		return bit47V41LinImp_3;
	}
	/**
	 * @param bit47v41LinImp_3 the bit47V41LinImp_3 to set
	 */
	public void setBit47V41LinImp_3(String bit47v41LinImp_3) {
		bit47V41LinImp_3 = bit47v41LinImp_3;
	}

	/**
	 * @return the bit47V41NrDoc_4
	 */
	@PositionalField(initialPosition= 41, finalPosition= 46)
	public String getBit47V41NrDoc_4() {
		return bit47V41NrDoc_4;
	}
	/**
	 * @param bit47v41NrDoc_4 the bit47V41NrDoc_4 to set
	 */
	public void setBit47V41NrDoc_4(String bit47v41NrDoc_4) {
		bit47V41NrDoc_4 = bit47v41NrDoc_4;
	}

	/**
	 * @return the bit47V41LinImp_4
	 */
	@PositionalField(initialPosition= 47, finalPosition= 52)
	public String getBit47V41LinImp_4() {
		return bit47V41LinImp_4;
	}
	/**
	 * @param bit47v41LinImp_4 the bit47V41LinImp_4 to set
	 */
	public void setBit47V41LinImp_4(String bit47v41LinImp_4) {
		bit47V41LinImp_4 = bit47v41LinImp_4;
	}

	/**
	 * @return the bit47V41NrDoc_5
	 */
	@PositionalField(initialPosition= 53, finalPosition= 58)
	public String getBit47V41NrDoc_5() {
		return bit47V41NrDoc_5;
	}
	/**
	 * @param bit47v41NrDoc_5 the bit47V41NrDoc_5 to set
	 */
	public void setBit47V41NrDoc_5(String bit47v41NrDoc_5) {
		bit47V41NrDoc_5 = bit47v41NrDoc_5;
	}

	/**
	 * @return the bit47V41LinImp_5
	 */
	@PositionalField(initialPosition= 59, finalPosition= 64)
	public String getBit47V41LinImp_5() {
		return bit47V41LinImp_5;
	}
	/**
	 * @param bit47v41LinImp_5 the bit47V41LinImp_5 to set
	 */
	public void setBit47V41LinImp_5(String bit47v41LinImp_5) {
		bit47V41LinImp_5 = bit47v41LinImp_5;
	}
		
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
