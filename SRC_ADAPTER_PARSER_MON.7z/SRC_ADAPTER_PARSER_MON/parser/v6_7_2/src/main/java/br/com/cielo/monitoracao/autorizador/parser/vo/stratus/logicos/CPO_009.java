package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_009, sobre Dados do Roteamento.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_009 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String ciersPl;
	private String marca;
	private String tipo;
	private String flagPPOnline;
	
	public CPO_009(){		
	}

	/**
	 * @return the ciersPl
	 */
	@PositionalField(initialPosition= 1, finalPosition= 6)
	public String getCiersPl() {
		return ciersPl;
	}

	/**
	 * @param ciersPl the ciersPl to set
	 */
	public void setCiersPl(String ciersPl) {
		this.ciersPl = ciersPl;
	}

	/**
	 * @return the marca
	 */
	@PositionalField(initialPosition= 7, finalPosition= 8)
	public String getMarca() {
		return marca;
	}

	/**
	 * @param marca the marca to set
	 */
	public void setMarca(String marca) {
		this.marca = marca;
	}

	/**
	 * @return the tipo
	 */
	@PositionalField(initialPosition= 9, finalPosition= 9)
	public String getTipo() {
		return tipo;
	}

	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	/**
	 * @return the flagPPOnline
	 */
	@PositionalField(initialPosition= 10, finalPosition= 10)
	public String getFlagPPOnline() {
		return flagPPOnline;
	}

	/**
	 * @param flagPPOnline the flagPPOnline to set
	 */
	public void setFlagPPOnline(String flagPPOnline) {
		this.flagPPOnline = flagPPOnline;
	}

	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
