package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;


/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_022, Visa Vale.
 * 
 * <DL><DT><B>Criada em:</B><DD>19/12/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_022 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String refeicaoAlimentacao;
	private String indCart;
	private String indInet;
	private String indFone;
	
	
	public CPO_022(){		
	}
	
	
	/**	 
	 * Representa o Campo STRATUS: ACTR-REF-ALIM
	 *	 
	 *		0=ALIM 1=REF
	 * 
	 * @return the refeicaoAlimentacao
	 */
	@PositionalField(initialPosition= 1, finalPosition= 1)
	public String getRefeicaoAlimentacao() {
		return refeicaoAlimentacao;
	}
	/**
	 * @param refeicaoAlimentacao the refeicaoAlimentacao to set
	 */
	public void setRefeicaoAlimentacao(String refeicaoAlimentacao) {
		this.refeicaoAlimentacao = refeicaoAlimentacao;
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-IND-CART
	 *	 
	 * 
	 * @return the indCart
	 */
	@PositionalField(initialPosition= 2, finalPosition= 2)
	public String getIndCart() {
		return indCart;
	}
	/**
	 * @param indCart the indCart to set
	 */
	public void setIndCart(String indCart) {
		this.indCart = indCart;
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-IND-INET
	 *	 
	 * 
	 * @return the indInet
	 */
	@PositionalField(initialPosition= 3, finalPosition= 3)
	public String getIndInet() {
		return indInet;
	}
	/**
	 * @param indInet the indInet to set
	 */
	public void setIndInet(String indInet) {
		this.indInet = indInet;
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-IND-FONE
	 *	 
	 * 
	 * @return the indFone
	 */
	@PositionalField(initialPosition= 4, finalPosition= 4)
	public String getIndFone() {
		return indFone;
	}
	/**
	 * @param indFone the indFone to set
	 */
	public void setIndFone(String indFone) {
		this.indFone = indFone;
	}

	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
