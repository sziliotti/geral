package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_079, sobre GUARDA DADOS DE CHIP MASTERCARD.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_079 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String de055;
	private String filler;
	
	public CPO_079(){		
	}

	/**
	 * @return the de055
	 */
	@PositionalField(initialPosition= 1, finalPosition= 6)
	public String getDe055() {
		return de055;
	}

	/**
	 * @param de055 the de055 to set
	 */
	public void setDe055(String de055) {
		this.de055 = de055;
	}

	/**
	 * @return the filler
	 */
	@PositionalField(initialPosition= 7, finalPosition= 7)
	public String getFiller() {
		return filler;
	}

	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		this.filler = filler;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
