package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_011, sobre Dados do Trilha.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_011 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	public static Logger logger= LoggerFactory.getLogger(CPO_011.class);
	
	private int tamanhoTrilha;
	private String dadosTrilha;
	
	public CPO_011(){
		
	}

	/**
	 * @return the tamanhoTrilha
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public int getTamanhoTrilha() {
		return tamanhoTrilha;
	}
	/**
	 * @param tamanhoTrilha the tamanhoTrilha to set
	 */
	public void setTamanhoTrilha(String tamanhoTrilha) {
		try {
			this.tamanhoTrilha= Integer.parseInt(tamanhoTrilha);
		} catch (NumberFormatException e) {
			this.tamanhoTrilha= 0;
			logger.warn("Erro realizando parser no objeto [CPO_011], em campo N�merico[tamanhoTrilha]. Valor recebido= '"+tamanhoTrilha+"'");			
		}
	}
	/**
	 * @param tamanhoTrilha the tamanhoTrilha to set
	 */
	public void setTamanhoTrilha(int tamanhoTrilha) {
		this.tamanhoTrilha = tamanhoTrilha;
	}

	/**
	 * @return the dadosTrilha
	 */
	@PositionalField(initialPosition= 3, finalPosition= 39)
	public String getDadosTrilha() {
		return dadosTrilha;
	}

	/**
	 * @param dadosTrilha the dadosTrilha to set
	 */
	public void setDadosTrilha(String dadosTrilha) {
		this.dadosTrilha = dadosTrilha;
	}

	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
