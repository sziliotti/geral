package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.metadata.DefaultFieldDecorator;

/**
 *<B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 *<br><br>
 * Classe Decorator para formatos do tipo double, com 5 posições, do framework FFPOJO.
 *	 
 *<DL><DT><B>Criada em:</B><DD>23/10/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class Double5PosDecorator extends DefaultFieldDecorator {
	public static Logger logger= LoggerFactory.getLogger(Double5PosDecorator.class);

	/* (non-Javadoc)
	 * @see com.github.ffpojo.metadata.DefaultFieldDecorator#toString(java.lang.Object)
	 */	
	public String toString(Object field) {
		String valDoub= String.valueOf(field);
		
		//Verifica tamanho das casas decimais, se necessario completa com até 2 posições.		
		String retorno= valDoub.substring(0, valDoub.indexOf(".")) + 
						String.format("%1$-2s", valDoub.substring(valDoub.indexOf(".")+1) ).replace(' ', '0');
		
		//Completa com zeros, as 5 posições.
		retorno= String.format("%1$5s", retorno).replace(' ', '0');
				
		return retorno;
	}

	/* (non-Javadoc)
	 * @see com.github.ffpojo.metadata.DefaultFieldDecorator#fromString(java.lang.String)
	 */
	@Override
    public Object fromString(String str) {
		double valReturn= 0;
		if(str!=null && !str.equals("")){
			String valDoubleStr= str.substring(0, 3)+"."+str.substring(3);
						
			try {
				valReturn = Double.parseDouble(valDoubleStr);
			} catch (NumberFormatException e) {			
				//logger.warn("Erro realizando parser no objeto, em campo numerico. Valor recebido= '"+str+"'");			
			}
		}
        return valReturn;
    }
}
