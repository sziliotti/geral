package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_006, sobre Dados da Transacao. 
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_006 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	public static Logger logger= LoggerFactory.getLogger(CPO_006.class);
	
	private String transacao;
	private String nsu;
	private String fluxoHost;
	private String produto;
	private String codigoProcessamento;
	private int quantidadeParcelas;
	private String tipoTransacao;
	private String formaDeEntrada;
	private String risco;
	private String garantia;
	private String indicadorAvs;
	private String tipoCriptografia;
	private String indicadorTerminaisV31;
	private String monProd;
	
	public CPO_006(){		
	}
	
	
	/** 
	 * Representa o Campo STRATUS: ACTR-TRANSACAO
	 *
	 * 0610 - RESPOSTA DE SONDA
	*  0202 - CONFIRMACAO
	*  0500 - FECHAMENTO DE LOTE
	*  1400 - DESFAZIMENTO
	*  1420 - CANCELAMENTO
	*  1500 - REFERIDA
	*  1500 - REFERIDA
	*  1220 - OFF-LINE
	*  1104 - OFF-LINE EMV CONFIRMACAO ANTERIOR
	*  1204 - OFF-LINE EMV
	*  1224 - OFF-LINE EMV
	*  1120 - OFF-LINE CDC PREAUT
	*  1200 - TRANSACOES FINANCEIRAS
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 1, finalPosition= 4)
	public String getTransacao() {
		return transacao;
	}
	/**
	 * @param transacao
	 */
	public void setTransacao(String transacao) {
		this.transacao = transacao;
	}
	
	/** 
	 * Representa o Campo STRATUS: ACTR-NSU
	 *
	 * @return
	 */
	@PositionalField(initialPosition= 5, finalPosition= 10)
	public String getNsu() {
		return nsu;
	}
	/**
	 * @param nsu
	 */
	public void setNsu(String nsu) {
		this.nsu = nsu;
	}
	
	/**
	 *  
	 * Representa o Campo STRATUS: ACTR-FLUXO-HOST 
	 *
	 * 0001 - CREDITO
	 * 0003 - PRE-AUTORIZACAO
	 * 0004 - DEBITO
	 * 0006 - CONSULTA CDC
	 * 0008 - SAUDE
	 * 0010 - MOEDEIRO CONSUMO
	 * 0011 - MOEDEIRO CARGA
	 * 0012 - VISAVALE / VALETIK
	 * 0400 - AVS
	 * 8000 - RESPOSTA DE SONDA
	 * 8010 - TERCEIRA PERNA
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 11, finalPosition= 14)
	public String getFluxoHost() {
		return fluxoHost;
	}
	/**
	 * @param fluxoHost
	 */
	public void setFluxoHost(String fluxoHost) {
		this.fluxoHost = fluxoHost;
	}
	
	/** 
	 * Representa o Campo STRATUS: ACTR-PRODUTO 
	 *
	 * 0000 - NAO DEFINIDO
	* 0001 - CREDITO
	* 0002 - ELECTRON
	* 0003 - PRE-AUT
	* 0004 - CONS CDC
	* 0005 - VALE REF.
	* 0006 - VALE ALIM.
	* 0007 - PAGUE CONT
	* 0008 - PC CONECTA
	* 0009 - CEL CLARO
	* 0011 - VALETIK
	* 0012 - PROMOCAO
	* 0013 - VISA CASH
	* 0014 - VVP
	* 0015 - CASH SALDO
	* 0016 - CASH EXTR
	* 0019 - JCB
	* 0020 - RECARGA CR
	* 0021 - RECARGA DB
	* 0022 - ING CRED
	* 0023 - ING DEB
	* 0030 - PGTO COBAN
	* 0031 - CONS COBAN
	* 0032 - SAQUE ELETRONICO
	* 0045 - PREFEITURA CRED
	* 0046 - PREFEITURA DEBITO
	* 0060 - RVV VMACHI
	* 0070 - PRIVATE
	* 0071 - PAGTO DIN
	* 0072 - PAGTO CHEQ
	* 0090 - INICIALIZA
	* 0091 - TST COMUNI
	* 0092 - SUPRIMENTO
	* 0093 - BX TECNICA
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 15, finalPosition= 18)
	public String getProduto() {
		return produto;
	}
	/**
	 * @param produto
	 */
	public void setProduto(String produto) {
		this.produto = produto;
	}
	
	/** 
	 * Representa o Campo STRATUS: ACTR-COD-PROC
	 *
	 * 003000 - CREDITO - A VISTA
	* 003010 - CREDITO - FINANCIADO ADM
	* 003020 - CREDITO - FINANCIADO LOJA
	* 001010 - DEBITO  - CDC
	* 001030 - DEBITO  - PRE-DATADO
	* 001000 - DEBITO  - A VISTA
	* 380010 - DEBITO  - CONSULTA CDC
	* 22XXXX - CANCELAMENTO
	* 920000 - FECHAMENTO DE LOTE
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 19, finalPosition= 24)
	public String getCodigoProcessamento() {
		return codigoProcessamento;
	}
	/**
	 * @param codigoProc
	 */
	public void setCodigoProcessamento(String codigoProc) {
		this.codigoProcessamento = codigoProc;
	}
	
	/** 
	 * Representa o Campo STRATUS: ACTR-QTD-PARCELA
	 *
	 * @return
	 */
	@PositionalField(initialPosition= 25, finalPosition= 26)
	public int getQuantidadeParcelas() {
		return quantidadeParcelas;
	}
	/**
	 * @param quantidadeParcelas
	 */
	public void setQuantidadeParcelas(int quantidadeParcelas) {
		this.quantidadeParcelas = quantidadeParcelas;
	}
	/**
	 * @param quantidadeParcelas
	 */
	public void setQuantidadeParcelas(String quantidadeParcelas) {		
		try {
			this.quantidadeParcelas= Integer.parseInt(quantidadeParcelas);
		} catch (NumberFormatException e) {
			this.quantidadeParcelas= 0;
			logger.warn("Erro realizando parser no objeto [CPO_006], em campo N�merico[quantidadeParcelas]. Valor recebido= '"+quantidadeParcelas+"'");			
		}	
	}
	
	/** 
	 * Representa o Campo STRATUS: ACTR-TIPTRA
	 *
	 * 
	 *  100 - VENDA A VISTA (CREDITO)
	 *  101 - VENDA PRAZO FINC. CARTAO
	 *  102 - VENDA PRAZO FINC.ESTAB
	 *  103 - CANCELAMENTO ONLINE
	 *  104 - VENDA A VISTA OFFLINE
	 *  105 - VENDA PRAZO FINC. CARTAO OFFLINE
	 *  106 - VENDA PRAZO FINC.ESTAB OFFLINE
	 *  107 - CANCELAMENTO OFFLINE
	 *  108 - PRE-AUTORIZACAO
	 *  109 - CONSULTA CDC
	 *  111 - SAQUE CARTAO DEBITO
	 *  112 - PAGAMENTO COM CARTAO DEBITO
	 *  114 - CARGA CARTAO INTELIG. ON
	 *  115 - PGTO.CARTAO INTELIG. OFF
	 *  116 - VD DEBITO FORCADA
	 *  117 - VD ELECTRON VISTA ON
	 *  118 - VD ELECTRON FIN.CART. ON
	 *  119 - VD ELECTRON FIN.ESTAB.ON
	 *  120 - VD ELECTRON VISTA ON (PAGUE-CONTA)
	 *  121 - POUPCARD CREDITO A VISTA
	 *  122 - POUPCARD CREDITO PARCELADO EMISSOR
	 *  123 - POUPCARD CREDITO PARCELADO LOJA
	 *  125 - PREAUT CIA AEREA A VISTA
	 *  126 - PREAUT CIA AEREA PARCELADO EMISSOR
	 *  127 - PREAUT CIA AEREA PARCELADO LOJA
	 *  130 - AUTORIZACAO NSA A VISA
	 *  131 - AUTORIZACAO NSA PARCELADO EMISSOR
	 *  132 - AUTORIZACAO NSA PARCELADO LOJA
	 *  133 - AUTORIZACAO NSA - EDI SYSTEM - A VISTA
	 *  134 - AUTORIZACAO NSA - EDI SYSTEM - PARC
	 *  135 - AUTORIZACAO NSA - EDI SYSTEM - PARC LOJA
	 *  140 - CONSULTA BONUS
	 *  141 - RESGATE BONUS
	 *  142 - VD ELECTRON VISTA ON (VALETIK)
	 *  143 - VD ELECTRON VST (VR)
	 *  144 - VD ELECTRON VST (VA)
	 *  145 - RECARGA CELULAR CREDITO
	 *  146 - RECARGA CELULAR ELECTRON
	 *  150 - TRANSACAO AVS
	 *  160 - VENDA A VISTA (PRIVATE LABEL)
	 *  161 - VENDA PRAZO FINC. CARTAO (PRIVATE LABEL)
	 *  162 - VENDA PRAZO FINC.ESTAB(PRIVATE LABEL)
	 *  163 - PAGAMENTO DINHEIRO (PRIVATE LABEL)
	 *  164 - PAGAMENTO CHEQUE (PRIVATE LABEL)
	 *  200 - PAGAMENTO DINHEIRO - BOLETO
	 *  201 - PAGAMENTO DINHEIRO - CONSUMO
	 *  202 - PAGAMENTO DINHEIRO - TRIBUTO
	 *  203 - CONSULTA DA ULTIMA TRANSACAO COBAN NO TERMINAL
	 *  999 - DESFAZER
	 *  01  - FECHAMENTO DE LOTE
	 *  02  - DESFAZIMENTO DE CANCELAMENTO
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 27, finalPosition= 29)
	public String getTipoTransacao() {
		return tipoTransacao;
	}
	/**
	 * @param tipoTransacao
	 */
	public void setTipoTransacao(String tipoTransacao) {
		this.tipoTransacao = tipoTransacao;
	}
	
	/** 
	 * Representa o Campo STRATUS: ACTR-FORMA-DE-ENTRADA
	 *
	 * 
	 * X = DIGITADA 
	 * D = TRILHA 2 
	 * H = TRILHA 1 
	 * C = CHIP
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 30, finalPosition= 30)
	public String getFormaDeEntrada() {
		return formaDeEntrada;
	}
	/**
	 * @param formaDeEntrada
	 */
	public void setFormaDeEntrada(String formaDeEntrada) {
		this.formaDeEntrada = formaDeEntrada;
	}
	
	/** 
	 * Representa o Campo STRATUS: ACTR-RISCO
	 *
	 * @return
	 */
	@PositionalField(initialPosition= 31, finalPosition= 32)
	public String getRisco() {
		return risco;
	}
	/**
	 * @param risco
	 */
	public void setRisco(String risco) {
		this.risco = risco;
	}
	
	/** 
	 * Representa o Campo STRATUS: ACTR-GARANTIA
	 *
	 * @return
	 */
	@PositionalField(initialPosition= 33, finalPosition= 34)
	public String getGarantia() {
		return garantia;
	}
	/**
	 * @param garantia
	 */
	public void setGarantia(String garantia) {
		this.garantia = garantia;
	}
	
	/** 
	 * Representa o Campo STRATUS: ACTR-IND-AVS
	 *
	 * @return
	 */
	@PositionalField(initialPosition= 35, finalPosition= 35)
	public String getIndicadorAvs() {
		return indicadorAvs;
	}
	/**
	 * @param indicadorAvs
	 */
	public void setIndicadorAvs(String indicadorAvs) {
		this.indicadorAvs = indicadorAvs;
	}
	
	/** 
	 * Representa o Campo STRATUS: ACTR-TIPO-CRIPTO
	 *
	 * 
	 * CM = CAM+SESSION KEY /MASTER KEY
	*   CD = CAM+DUKPT
	*   CA = CAM
	*   DK = DUKPT
	*   SM = SESSION KEY / MASTER KEY
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 36, finalPosition= 37)
	public String getTipoCriptografia() {
		return tipoCriptografia;
	}
	/**
	 * @param tipoCriptografia
	 */
	public void setTipoCriptografia(String tipoCriptografia) {
		this.tipoCriptografia = tipoCriptografia;
	}
	
	/** 
	 * Representa o Campo STRATUS: ACTR-V31-IND-FECTO
	 *
	 * INDICADOR DE TERMINAIS V31 COM OPCAO DE FECHAMENTO DE LOTE.
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 38, finalPosition= 38)
	public String getIndicadorTerminaisV31() {
		return indicadorTerminaisV31;
	}
	/**
	 * @param indicadorTerminaisV31
	 */
	public void setIndicadorTerminaisV31(String indicadorTerminaisV31) {
		this.indicadorTerminaisV31 = indicadorTerminaisV31;
	}
	
	/** 
	 * Representa o Campo STRATUS: ACTR-MON-PROD 
	 *
	 * @return
	 */
	@PositionalField(initialPosition= 39, finalPosition= 40)
	public String getMonProd() {
		return monProd;
	}
	/**
	 * @param monProd
	 */
	public void setMonProd(String monProd) {
		this.monProd = monProd;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
