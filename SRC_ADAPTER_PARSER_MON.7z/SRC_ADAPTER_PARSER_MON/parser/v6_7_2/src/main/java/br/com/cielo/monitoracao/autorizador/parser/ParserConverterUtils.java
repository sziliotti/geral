package br.com.cielo.monitoracao.autorizador.parser;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * <br><br>
 * Classe estatica do tipo util, responsavel em efetuar as conversoes e valores
 * entre hexdecimal -> bytes; bytes -> hex; hex -> Decimal; bytes -> String
 * (utilizando o encoding EBCDIC).
 *
 * <DL><DT><B>Criada em:</B><DD>28/08/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class ParserConverterUtils {

    public static Logger logger = LoggerFactory.getLogger(ParserConverterUtils.class);

    private static final String DEFAULT_EBCDIC_ENCODING = "Cp1047";
    private static final int ZIP_BUFFER_SIZE = 50;

    /**
     * Nivel de compactação utilizado para uma melhor compactação.
     */
    public static final int ZIP_LEVEL_BEST_COMPRESSION = Deflater.BEST_COMPRESSION;

    /**
     * Nivel de compactação utilizado para uma compactação mais rapida.
     */
    public static final int ZIP_LEVEL_BEST_SPEED = Deflater.BEST_SPEED;

    /**
     * Nivel de compactação utilizado para uma compactação padrão.
     */
    public static final int ZIP_LEVEL_DEFAULT_COMPRESSION = Deflater.DEFAULT_COMPRESSION;

    /**
     * Metodo de compactação utilizando algortimo Deflated.
     */
    public static final int ZIP_LEVEL_DEFLATED = Deflater.DEFLATED;

    /**
     * Construtor privado.
     */
    private ParserConverterUtils() {
    }

    /**
     * Metodo responsavel em converter uma string hexdeciaml em um array de
     * bytes.
     * <br><br>
     *
     * @param hex String no formato hexdecimal.
     * @return Array de bytes da string passada como parametro.
     */
    public static byte[] hexToBytes(String hex) {
        return hexToBytes(hex.toCharArray());
    }

    /**
     * Metodo responsavel em converter um array de characteres do tipo
     * hexdeciaml em um array de bytes.
     * <br><br>
     *
     * @param hex Array de characteres no formato hexdecimal.
     * @return Array de bytes do conjunto de char passado como parametro.
     */
    public static byte[] hexToBytes(char[] hex) {
        byte[] raw = null;
        try {
            raw = Hex.decodeHex(hex);
        } catch (DecoderException e) {
            //logger.error("Erro em converter o valor do campo. Exception: "+e.getMessage());
            //e.printStackTrace();
            return raw;
        }
        return raw;
    }

    /**
     * Metodo responsavel em converter um array de bytes em uma string do tipo
     * hexadecimal.
     * <br><br>
     *
     * @param bytes Array de bytes a ser convertido.
     * @return String do tipo hexadecimal.
     */
    public static String bytesToHex(byte[] bytes) {
        return Hex.encodeHexString(bytes);
    }

    /**
     * Metodo responsavel em converter uma string do tipo hexdecimal em um
     * decimal.
     * <br><br>
     *
     * @param hexValue String a ser convertida.
     * @return Valor decimal da string passada como parametro.
     */
    public static int hexToDecimal(String hexValue) {
        int decimalVal = Integer.parseInt(hexValue, 16);

        return decimalVal;
    }

    /**
     * Metodo responsavel em converter um array de bytes, contendo valores hex,
     * em uma string do tipo ASCII, utilizando charset default para Cielo
     * (DEFAULT_EBCDIC_ENCODING).
     * <br><br>
     *
     * @param buffer Array de bytes a ser convertido.
     * @return String do tipo ASCII.
     */
    public static String hexToString(byte[] buffer) {
        String s = null;

        try {
            s = new String(buffer, DEFAULT_EBCDIC_ENCODING);

        } catch (UnsupportedEncodingException e) {
            logger.error("Erro em converter o valor do campo: '" + buffer);
        }
        return s;
    }

    /**
     * Metodo responsavel em converter um array de bytes, contendo valores hex,
     * em uma string do tipo ASCII, utitilizando charset passado como parâmetro.
     * <br><br>
     *
     * @param buffer Array de bytes a ser convertido.
     * @param charSetEncoding Charset usado para conversão. Exemplo: "UTF-8"
     * @return String do tipo ASCII.
     */
    public static String hexToString(byte[] buffer, String charSetEncoding) {
        String retorno = null;

        try {
            retorno = new String(buffer, charSetEncoding);

        } catch (UnsupportedEncodingException e) {
            logger.error("Erro em converter o valor do campo: '" + buffer);
        }
        return retorno;
    }

    /**
     * Metodo responsavel em converter uma string contendo valores hex, em uma
     * string do tipo ASCII.
     * <br><br>
     *
     * @param str String a ser convertida.
     * @return String do tipo ASCII.
     */
    public static String hexToString(String str) {
        String retorno = hexToString(hexToBytes(str));
        return retorno;
    }

    /**
     * Metodo responsavel em converter uma string contendo valores hex, em uma
     * string do tipo ASCII, utitilizando charset passado como parâmetro.
     * <br><br>
     *
     * @param str String a ser convertida.
     * @param charSetEncoding Charset usado para conversão. Exemplo: "UTF-8"
     * @return String do tipo ASCII.
     */
    public static String hexToString(String str, String charSetEncoding) {
        String retorno = hexToString(hexToBytes(str), charSetEncoding);
        return retorno;
    }

    /**
     * Metodo responsavel em converter uma string do tipo ASCII, em uma string
     * contendo valores hex.
     * <br><br>
     *
     * @param str String a ser convertida.
     * @return String contendo valores hex
     */
    public static String stringToHex(String str) {
        return Hex.encodeHexString(str.getBytes());
    }

    /**
     * Metodo responsavel em converter uma string do tipo ASCII, em uma string
     * contendo valores hex,, utitilizando charset passado como parâmetro.
     * <br><br>
     *
     * @param str String a ser convertida.
     * @param charSetEncoding Charset usado para conversão. Exemplo: "UTF-8"
     * @return String contendo valores hex
     */
    public static String stringToHex(String str, String charSetEncoding) {
        String retorno = null;
        try {
            retorno = ParserConverterUtils.bytesToHex(str.getBytes(charSetEncoding));
        } catch (UnsupportedEncodingException e) {
            logger.error("Erro em converter o valor do campo: " + str);
        }
        return retorno;
    }

    /**
     * Método responsável em efetuar parser utilizando um periodo de tempo
     * Jiffy, retornando um objeto do tipo data.
     * <br><br>
     *
     * @param jiffyBinario Array de bytes contendo o valor em timestamp a ser
     * convertido.
     * @return Objeto do tipo Date, convertido.
     */
    public static Date parseJiffy(byte[] jiffyBinario) {
        int ano = 1980, mes = 0, dia = 1;
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
        cal.clear();
        cal.set(ano, mes, dia);
        long milliJan1980 = cal.getTime().getTime();

        // One jiffy is 1/65,536 of a second. The s$jiffy_date_time subroutine returns the number of jiffies elapsed since the 
        // beginning of January 1, 1980, Greenwich Mean Time.
        ByteBuffer bb = ByteBuffer.wrap(jiffyBinario);
        Long jiffyLong = bb.getLong();

        long milliDesde1980 = (long) ((double) 1000 * jiffyLong / 65536);
        Date retorno = null;

        if (milliDesde1980 > 0) {
            retorno = new Date(milliDesde1980 + milliJan1980);
        }
        return retorno;
    }

    /**
     * Método responsável em efetuar parser de um Date, retornando um array de
     * bytes contendo o valor em timestamp de um periodo de tempo Jiffy.
     * <br><br>
     *
     * @param date Objeto do tipo Date a ser convertido.
     * @return Array de bytes contendo o valor em timestamp, convertido.
     */
    public static byte[] parseJiffy(Date dateParse) {
        int ano = 1980, mes = 0, dia = 1;
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
        cal.clear();
        cal.set(ano, mes, dia);
        long milliJan1980 = cal.getTime().getTime();

        //Fazer conversão para padrão Jiffy
        long dataParseMs = dateParse.getTime();
        long milliDesde1980 = dataParseMs - milliJan1980;

        long jiffyLong = (long) ((double) milliDesde1980 * 65536 / 1000);

        //long jiffyValue= dataAtualms / 60;
        //byte[] jiffyBinario= String.valueOf(jiffyLong).getBytes();
        ByteBuffer bb = ByteBuffer.allocate(8);
        bb.putLong(jiffyLong);
        byte[] jiffyBinario = bb.array();

        return jiffyBinario;
    }

    /**
     * Metodo responsavel em retornar um sub-array de bytes, a partir de um
     * array de bytes passado como parametro e suas posicoes inicial e final.
     * <br><br>
     *
     * @param bufferRegistro Array de bytes do qual sera extraido o sub-array.
     * @param inicio Posicao inicial do sub-array, a ser extraido.
     * @param tamanhoCampo Tamanho do sub-array, a ser extraido.
     * @return Array de bytes conforme parametros informados.
     */
    public static byte[] subArray(byte[] bufferRegistro, int inicio, int tamanhoCampo) throws Exception {
        byte[] tempBuffer = new byte[tamanhoCampo];
        System.arraycopy(bufferRegistro, inicio, tempBuffer, 0, tamanhoCampo);

        return tempBuffer;
    }

    /**
     * Metodo responsavel em compactar um array de bytes passado como parametro,
     * utilizando o método de compactação padrão.
     * <br><br>
     *
     * @param msgBytes Array de bytes a ser compactado.
     * @return Array de bytes compactado.
     * @throws IOException
     */
    public static byte[] zipMessage(byte[] msgBytes) {
        return zipMessage(ParserConverterUtils.ZIP_LEVEL_DEFAULT_COMPRESSION, msgBytes);
    }

    /**
     * Metodo responsavel em compactar um array de bytes passado como parametro,
     * informando o método de compactação desejado.
     * <br><br>
     * Possiveis niveis de compactação:
     * <DD>ZIP_LEVEL_BEST_COMPRESSION
     * <DD>ZIP_LEVEL_BEST_SPEED
     * <DD>ZIP_LEVEL_DEFAULT_COMPRESSION
     * <DD>ZIP_LEVEL_DEFLATED
     * <br><br>
     * Exemplo de utilização:
     * <DD>byte[] novaMsg=
     * ParserConverterUtils.zipMessage(ParserConverterUtils.ZIP_LEVEL_BEST_COMPRESSION,
     * msgBytes[]);
     * <br><br>
     *
     * @param level Nivel de compressao desejado
     * @param msgBytes Array de bytes a ser compactado.
     * @return Array de bytes compactado.
     */
    public static byte[] zipMessage(int level, byte[] msgBytes) {
        byte[] msgBytesReturno = null;

        Deflater compresser = new Deflater(level, false);
        compresser.setInput(msgBytes);
        compresser.finish();

        ByteArrayOutputStream oZipStream = new ByteArrayOutputStream();
        try {
            while (!compresser.finished()) {
                byte[] byteAtual = new byte[ZIP_BUFFER_SIZE];
                int iBytesRead = compresser.deflate(byteAtual);

                if (iBytesRead == byteAtual.length) {
                    oZipStream.write(byteAtual);
                } else {
                    oZipStream.write(byteAtual, 0, iBytesRead);
                }
            }

            compresser.end();
            msgBytesReturno = oZipStream.toByteArray();

        } catch (IOException e) {
            logger.error(e.getMessage());

        } finally {
            try {
                oZipStream.close();
            } catch (IOException e) {
                logger.error(e.getMessage());
            }
        }
        return msgBytesReturno;
    }

    /**
     * Metodo responsavel para descompactar um array de bytes passado como
     * parametro.
     * <br><br>
     *
     * @param msgBytes Array de bytes a ser descompactado.
     * @return Array de bytes descompactado.
     * @throws ParserException
     * @throws IOException
     */
    public static byte[] unzipMessage(byte[] msgBytes) throws ParserException {
        byte[] msgBytesReturn = null;

        Inflater decompresser = new Inflater(false);
        decompresser.setInput(msgBytes);

        ByteArrayOutputStream oZipStream = new ByteArrayOutputStream();
        try {
            while (!decompresser.finished()) {
                byte[] byteAtual = new byte[ZIP_BUFFER_SIZE];
                int iBytesRead = decompresser.inflate(byteAtual);

                if (iBytesRead == byteAtual.length) {
                    oZipStream.write(byteAtual);
                } else {
                    oZipStream.write(byteAtual, 0, iBytesRead);
                }
            }
            msgBytesReturn = oZipStream.toByteArray();

        } catch (DataFormatException ex) {
            logger.warn("Mensagem não esta zipada.");
            throw new ParserException("Mensagem: " + msgBytes + " não esta zipada.", ex);

        } catch (IOException e) {
            logger.error(e.getMessage());
        } finally {

            try {
                oZipStream.close();
            } catch (IOException e) {
                logger.error(e.getMessage());
            }
        }
        return msgBytesReturn;
    }

}
