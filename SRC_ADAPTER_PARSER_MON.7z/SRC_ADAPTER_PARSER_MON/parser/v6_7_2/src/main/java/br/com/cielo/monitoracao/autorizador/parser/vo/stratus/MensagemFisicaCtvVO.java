package br.com.cielo.monitoracao.autorizador.parser.vo.stratus;

import java.io.Serializable;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * <br><br>
 * VO responsavel em guardar as informacoes da mensagem de cabecalho do Stratus. Mensagem do tipo CTV.
 * 
 * <DL><DT><B>Criada em:</B><DD>02/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class MensagemFisicaCtvVO implements Serializable{		
	private static final long serialVersionUID = 1L;
	
	private final String prefixFieldName= "CPO_";
	
	private String nomeCampo;
	private int tamanhoCampo;
	private String valorCampo;
	
	private boolean campoBinario= false;
	private byte[] valorCampoBinario;
	
	private boolean possuiMultiplosMapeamento= false;
	
	/**
	 * @return
	 */
	public String getNomeCampo() {
		return nomeCampo;
	}
	/**
	 * @return
	 */
	public int getTamanhoCampo() {
		return tamanhoCampo;
	}
	/**
	 * @return
	 */
	public String getValorCampo() {
		return valorCampo;
	}
	/**	  
	 * @param nomeCampo
	 */
	public void setNomeCampo(String nomeCampo) {
		this.nomeCampo= nomeCampo;
	}
	
	/**
	 * Atribui o sufixo "CPO_" para melhor identificaçao dos campos.
	 * 
	 * @param nomeCampo
	 */
	public void setNomeCampo(int nomeCampo) {			
		this.setNomeCampo(prefixFieldName + String.format("%03d", nomeCampo));			
	}
		
	/**
	 * @param tamanhoCampo
	 */
	public void setTamanhoCampo(int tamanhoCampo) {
		this.tamanhoCampo = tamanhoCampo;
	}
	/**
	 * @param valorCampo
	 */
	public void setValorCampo(String valorCampo) {
		this.valorCampo = valorCampo;
	}
	/**
	 * @return the campoBinario
	 */
	public boolean isCampoBinario() {
		return campoBinario;
	}
	/**
	 * @param campoBinario the campoBinario to set
	 */
	public void setCampoBinario(boolean campoBinario) {
		this.campoBinario = campoBinario;
	}
	/**
	 * @return the valorCampoBinario
	 */
	public byte[] getValorCampoBinario() {
		return valorCampoBinario;
	}
	/**
	 * @param valorCampoBinario the valorCampoBinario to set
	 */
	public void setValorCampoBinario(byte[] valorCampoBinario) {
		this.valorCampoBinario = valorCampoBinario;
	}
	/**
	 * @return the possuiMultiplosMapeamento
	 */
	public boolean isPossuiMultiplosMapeamento() {
		return possuiMultiplosMapeamento;
	}
	/**
	 * @param possuiMultiplosMapeamento the possuiMultiplosMapeamento to set
	 */
	public void setPossuiMultiplosMapeamento(boolean possuiMultiplosMapeamento) {
		this.possuiMultiplosMapeamento = possuiMultiplosMapeamento;
	}
	
}
