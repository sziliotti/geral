package br.com.cielo.monitoracao.autorizador.parser;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * <br><br>
 * Classe de Excecao referente ao Parser das mensagens recebidas.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/08/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class ParserException extends Exception {
	private static final long serialVersionUID = 1952127564632714360L;

	/**
	 * 
	 */
	public ParserException() {
	}

	/**
	 * @param message
	 */
	public ParserException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public ParserException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public ParserException(String message, Throwable cause) {
		super(message, cause);
	}
}
