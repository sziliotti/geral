package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_905, sobre Dados do BIT47.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_905 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
		
	/*
	 * Cabecalho Principal ADIC-BRB47-1-OCC1(Ocorre 3 vezes)
	 * 
	 * Cabecaho 1
	 */	
	private String quantidadeBytesEnviados_1;
	private String quantidadeBytesRecebidos_1;
	private String modoConexao_1;
	private String modoDiscagem_1;
	private String bit47Pref_1;
		
	//Cabecalho ADIC-BRB47-1-OCC2(Ocorre 3 vezes)
	private String telefoneDiscado_1_A;
	private String quantidadeTentativasDiscagens_1_A;
		//Cabecalho ADIC-BRB47-1-OCC3(Ocorre 10 vezes)
	private String resultadoDiscagem_1_A1;
	private String resultadoDiscagem_1_A2;
	private String resultadoDiscagem_1_A3;
	private String resultadoDiscagem_1_A4;
	private String resultadoDiscagem_1_A5;
	private String resultadoDiscagem_1_A6;
	private String resultadoDiscagem_1_A7;
	private String resultadoDiscagem_1_A8;
	private String resultadoDiscagem_1_A9;
	private String resultadoDiscagem_1_A10;
	
	private String telefoneDiscado_1_B;
	private String quantidadeTentativasDiscagens_1_B;
	private String resultadoDiscagem_1_B1;
	private String resultadoDiscagem_1_B2;
	private String resultadoDiscagem_1_B3;
	private String resultadoDiscagem_1_B4;
	private String resultadoDiscagem_1_B5;
	private String resultadoDiscagem_1_B6;
	private String resultadoDiscagem_1_B7;
	private String resultadoDiscagem_1_B8;
	private String resultadoDiscagem_1_B9;
	private String resultadoDiscagem_1_B10;
	
	private String telefoneDiscado_1_C;
	private String quantidadeTentativasDiscagens_1_C;
	private String resultadoDiscagem_1_C1;
	private String resultadoDiscagem_1_C2;
	private String resultadoDiscagem_1_C3;
	private String resultadoDiscagem_1_C4;
	private String resultadoDiscagem_1_C5;
	private String resultadoDiscagem_1_C6;
	private String resultadoDiscagem_1_C7;
	private String resultadoDiscagem_1_C8;
	private String resultadoDiscagem_1_C9;
	private String resultadoDiscagem_1_C10;
			
	
	/*
	 * Cabecalho Principal ADIC-BRB47-1-OCC1(Ocorre 3 vezes)
	 * 
	 * Cabecaho 2
	 */
	private String quantidadeBytesEnviados_2;
	private String quantidadeBytesRecebidos_2;
	private String modoConexao_2;
	private String modoDiscagem_2;
	private String bit47Pref_2;
		
	//Cabecalho ADIC-BRB47-1-OCC2(Ocorre 3 vezes)
	private String telefoneDiscado_2_A;
	private String quantidadeTentativasDiscagens_2_A;
		//Cabecalho ADIC-BRB47-1-OCC3(Ocorre 10 vezes)
	private String resultadoDiscagem_2_A1;
	private String resultadoDiscagem_2_A2;
	private String resultadoDiscagem_2_A3;
	private String resultadoDiscagem_2_A4;
	private String resultadoDiscagem_2_A5;
	private String resultadoDiscagem_2_A6;
	private String resultadoDiscagem_2_A7;
	private String resultadoDiscagem_2_A8;
	private String resultadoDiscagem_2_A9;
	private String resultadoDiscagem_2_A10;
	
	private String telefoneDiscado_2_B;
	private String quantidadeTentativasDiscagens_2_B;
	private String resultadoDiscagem_2_B1;
	private String resultadoDiscagem_2_B2;
	private String resultadoDiscagem_2_B3;
	private String resultadoDiscagem_2_B4;
	private String resultadoDiscagem_2_B5;
	private String resultadoDiscagem_2_B6;
	private String resultadoDiscagem_2_B7;
	private String resultadoDiscagem_2_B8;
	private String resultadoDiscagem_2_B9;
	private String resultadoDiscagem_2_B10;
	
	private String telefoneDiscado_2_C;
	private String quantidadeTentativasDiscagens_2_C;
	private String resultadoDiscagem_2_C1;
	private String resultadoDiscagem_2_C2;
	private String resultadoDiscagem_2_C3;
	private String resultadoDiscagem_2_C4;
	private String resultadoDiscagem_2_C5;
	private String resultadoDiscagem_2_C6;
	private String resultadoDiscagem_2_C7;
	private String resultadoDiscagem_2_C8;
	private String resultadoDiscagem_2_C9;
	private String resultadoDiscagem_2_C10;
	
	/*
	 * Cabecalho Principal ADIC-BRB47-1-OCC1(Ocorre 3 vezes)
	 * 
	 * Cabecaho 3
	 */
	private String quantidadeBytesEnviados_3;
	private String quantidadeBytesRecebidos_3;
	private String modoConexao_3;
	private String modoDiscagem_3;
	private String bit47Pref_3;
		
	//Cabe�alho ADIC-BRB47-1-OCC2(Ocorre 3 vezes)
	private String telefoneDiscado_3_A;
	private String quantidadeTentativasDiscagens_3_A;
		//Cabecalho ADIC-BRB47-1-OCC3(Ocorre 10 vezes)
	private String resultadoDiscagem_3_A1;
	private String resultadoDiscagem_3_A2;
	private String resultadoDiscagem_3_A3;
	private String resultadoDiscagem_3_A4;
	private String resultadoDiscagem_3_A5;
	private String resultadoDiscagem_3_A6;
	private String resultadoDiscagem_3_A7;
	private String resultadoDiscagem_3_A8;
	private String resultadoDiscagem_3_A9;
	private String resultadoDiscagem_3_A10;
	
	private String telefoneDiscado_3_B;
	private String quantidadeTentativasDiscagens_3_B;
	private String resultadoDiscagem_3_B1;
	private String resultadoDiscagem_3_B2;
	private String resultadoDiscagem_3_B3;
	private String resultadoDiscagem_3_B4;
	private String resultadoDiscagem_3_B5;
	private String resultadoDiscagem_3_B6;
	private String resultadoDiscagem_3_B7;
	private String resultadoDiscagem_3_B8;
	private String resultadoDiscagem_3_B9;
	private String resultadoDiscagem_3_B10;
	
	private String telefoneDiscado_3_C;
	private String quantidadeTentativasDiscagens_3_C;
	private String resultadoDiscagem_3_C1;
	private String resultadoDiscagem_3_C2;
	private String resultadoDiscagem_3_C3;
	private String resultadoDiscagem_3_C4;
	private String resultadoDiscagem_3_C5;
	private String resultadoDiscagem_3_C6;
	private String resultadoDiscagem_3_C7;
	private String resultadoDiscagem_3_C8;
	private String resultadoDiscagem_3_C9;
	private String resultadoDiscagem_3_C10;
	
	private String filler;
	
	
	public CPO_905(){		
	}

	
	/*
	 * ITEM ADIC-BRB47-1-OCC1 NUMERO 1
	 */
	/**
	 * @return the bit47ByEnv_1
	 */
	@PositionalField(initialPosition= 1, finalPosition= 4)
	public String getQuantidadeBytesEnviados_1() {
		return quantidadeBytesEnviados_1;
	}
	/**
	 * @param bit47ByEnv_1 the bit47ByEnv_1 to set
	 */
	public void setQuantidadeBytesEnviados_1(String bit47ByEnv_1) {
		this.quantidadeBytesEnviados_1 = bit47ByEnv_1;
	}

	/**
	 * @return the bit47ByRec_1
	 */
	@PositionalField(initialPosition= 5, finalPosition= 10)
	public String getQuantidadeBytesRecebidos_1() {
		return quantidadeBytesRecebidos_1;
	}
	/**
	 * @param bit47ByRec_1 the bit47ByRec_1 to set
	 */
	public void setQuantidadeBytesRecebidos_1(String bit47ByRec_1) {
		this.quantidadeBytesRecebidos_1 = bit47ByRec_1;
	}

	/**
	 * @return the bit47ModCon_1
	 */
	@PositionalField(initialPosition= 11, finalPosition= 12)
	public String getModoConexao_1() {
		return modoConexao_1;
	}
	/**
	 * @param bit47ModCon_1 the bit47ModCon_1 to set
	 */
	public void setModoConexao_1(String bit47ModCon_1) {
		this.modoConexao_1 = bit47ModCon_1;
	}

	/**
	 * @return the bit47ModDis_1
	 */
	@PositionalField(initialPosition= 13, finalPosition= 13)
	public String getModoDiscagem_1() {
		return modoDiscagem_1;
	}
	/**
	 * @param bit47ModDis_1 the bit47ModDis_1 to set
	 */
	public void setModoDiscagem_1(String bit47ModDis_1) {
		this.modoDiscagem_1 = bit47ModDis_1;
	}

	/**
	 * @return the bit47Pref_1
	 */
	@PositionalField(initialPosition= 14, finalPosition= 29)
	public String getBit47Pref_1() {
		return bit47Pref_1;
	}
	/**
	 * @param bit47Pref_1 the bit47Pref_1 to set
	 */
	public void setBit47Pref_1(String bit47Pref_1) {
		this.bit47Pref_1 = bit47Pref_1;
	}

	/**
	 * @return the bit47FonDis_1_A
	 */
	@PositionalField(initialPosition= 30, finalPosition= 45)
	public String getTelefoneDiscado_1_A() {
		return telefoneDiscado_1_A;
	}
	/**
	 * @param bit47FonDis_1_A the bit47FonDis_1_A to set
	 */
	public void setTelefoneDiscado_1_A(String bit47FonDis_1_A) {
		this.telefoneDiscado_1_A = bit47FonDis_1_A;
	}

	/**
	 * @return the bit47QuantidadeTen_1_A
	 */
	@PositionalField(initialPosition= 46, finalPosition= 47)
	public String getQuantidadeTentativasDiscagens_1_A() {
		return quantidadeTentativasDiscagens_1_A;
	}
	/**
	 * @param bit47QuantidadeTen_1_A the bit47QuantidadeTen_1_A to set
	 */
	public void setQuantidadeTentativasDiscagens_1_A(String bit47QuantidadeTen_1_A) {
		this.quantidadeTentativasDiscagens_1_A = bit47QuantidadeTen_1_A;
	}

	/**
	 * @return the bit47ResDis_1_A1
	 */
	@PositionalField(initialPosition= 48, finalPosition= 49)
	public String getResultadoDiscagem_1_A1() {
		return resultadoDiscagem_1_A1;
	}
	/**
	 * @param bit47ResDis_1_A1 the bit47ResDis_1_A1 to set
	 */
	public void setResultadoDiscagem_1_A1(String bit47ResDis_1_A1) {
		this.resultadoDiscagem_1_A1 = bit47ResDis_1_A1;
	}

	/**
	 * @return the bit47ResDis_1_A2
	 */
	@PositionalField(initialPosition= 50, finalPosition= 51)
	public String getResultadoDiscagem_1_A2() {
		return resultadoDiscagem_1_A2;
	}
	/**
	 * @param bit47ResDis_1_A2 the bit47ResDis_1_A2 to set
	 */
	public void setResultadoDiscagem_1_A2(String bit47ResDis_1_A2) {
		this.resultadoDiscagem_1_A2 = bit47ResDis_1_A2;
	}

	/**
	 * @return the bit47ResDis_1_A3
	 */
	@PositionalField(initialPosition= 52, finalPosition= 53)
	public String getResultadoDiscagem_1_A3() {
		return resultadoDiscagem_1_A3;
	}
	/**
	 * @param bit47ResDis_1_A3 the bit47ResDis_1_A3 to set
	 */
	public void setResultadoDiscagem_1_A3(String bit47ResDis_1_A3) {
		this.resultadoDiscagem_1_A3 = bit47ResDis_1_A3;
	}

	/**
	 * @return the bit47ResDis_1_A4
	 */
	@PositionalField(initialPosition= 54, finalPosition= 55)
	public String getResultadoDiscagem_1_A4() {
		return resultadoDiscagem_1_A4;
	}
	/**
	 * @param bit47ResDis_1_A4 the bit47ResDis_1_A4 to set
	 */
	public void setResultadoDiscagem_1_A4(String bit47ResDis_1_A4) {
		this.resultadoDiscagem_1_A4 = bit47ResDis_1_A4;
	}

	/**
	 * @return the bit47ResDis_1_A5
	 */
	@PositionalField(initialPosition= 56, finalPosition= 57)
	public String getResultadoDiscagem_1_A5() {
		return resultadoDiscagem_1_A5;
	}
	/**
	 * @param bit47ResDis_1_A5 the bit47ResDis_1_A5 to set
	 */
	public void setResultadoDiscagem_1_A5(String bit47ResDis_1_A5) {
		this.resultadoDiscagem_1_A5 = bit47ResDis_1_A5;
	}

	/**
	 * @return the bit47ResDis_1_A6
	 */
	@PositionalField(initialPosition= 58, finalPosition= 59)
	public String getResultadoDiscagem_1_A6() {
		return resultadoDiscagem_1_A6;
	}
	/**
	 * @param bit47ResDis_1_A6 the bit47ResDis_1_A6 to set
	 */
	public void setResultadoDiscagem_1_A6(String bit47ResDis_1_A6) {
		this.resultadoDiscagem_1_A6 = bit47ResDis_1_A6;
	}

	/**
	 * @return the bit47ResDis_1_A7
	 */
	@PositionalField(initialPosition= 60, finalPosition= 61)
	public String getResultadoDiscagem_1_A7() {
		return resultadoDiscagem_1_A7;
	}
	/**
	 * @param bit47ResDis_1_A7 the bit47ResDis_1_A7 to set
	 */
	public void setResultadoDiscagem_1_A7(String bit47ResDis_1_A7) {
		this.resultadoDiscagem_1_A7 = bit47ResDis_1_A7;
	}

	/**
	 * @return the bit47ResDis_1_A8
	 */
	@PositionalField(initialPosition= 62, finalPosition= 63)
	public String getResultadoDiscagem_1_A8() {
		return resultadoDiscagem_1_A8;
	}
	/**
	 * @param bit47ResDis_1_A8 the bit47ResDis_1_A8 to set
	 */
	public void setResultadoDiscagem_1_A8(String bit47ResDis_1_A8) {
		this.resultadoDiscagem_1_A8 = bit47ResDis_1_A8;
	}

	/**
	 * @return the bit47ResDis_1_A9
	 */
	@PositionalField(initialPosition= 64, finalPosition= 65)
	public String getResultadoDiscagem_1_A9() {
		return resultadoDiscagem_1_A9;
	}
	/**
	 * @param bit47ResDis_1_A9 the bit47ResDis_1_A9 to set
	 */
	public void setResultadoDiscagem_1_A9(String bit47ResDis_1_A9) {
		this.resultadoDiscagem_1_A9 = bit47ResDis_1_A9;
	}

	/**
	 * @return the bit47ResDis_1_A10
	 */
	@PositionalField(initialPosition= 66, finalPosition= 67)
	public String getResultadoDiscagem_1_A10() {
		return resultadoDiscagem_1_A10;
	}
	/**
	 * @param bit47ResDis_1_A10 the bit47ResDis_1_A10 to set
	 */
	public void setResultadoDiscagem_1_A10(String bit47ResDis_1_A10) {
		this.resultadoDiscagem_1_A10 = bit47ResDis_1_A10;
	}

	/**
	 * @return the bit47FonDis_1_B
	 */
	@PositionalField(initialPosition= 68, finalPosition= 83)
	public String getTelefoneDiscado_1_B() {
		return telefoneDiscado_1_B;
	}
	/**
	 * @param bit47FonDis_1_B the bit47FonDis_1_B to set
	 */
	public void setTelefoneDiscado_1_B(String bit47FonDis_1_B) {
		this.telefoneDiscado_1_B = bit47FonDis_1_B;
	}

	/**
	 * @return the bit47QuantidadeTen_1_B
	 */
	@PositionalField(initialPosition= 84, finalPosition= 85)
	public String getQuantidadeTentativasDiscagens_1_B() {
		return quantidadeTentativasDiscagens_1_B;
	}
	/**
	 * @param bit47QuantidadeTen_1_B the bit47QuantidadeTen_1_B to set
	 */
	public void setQuantidadeTentativasDiscagens_1_B(String bit47QuantidadeTen_1_B) {
		this.quantidadeTentativasDiscagens_1_B = bit47QuantidadeTen_1_B;
	}

	/**
	 * @return the bit47ResDis_1_B1
	 */
	@PositionalField(initialPosition= 86, finalPosition= 87)
	public String getResultadoDiscagem_1_B1() {
		return resultadoDiscagem_1_B1;
	}
	/**
	 * @param bit47ResDis_1_B1 the bit47ResDis_1_B1 to set
	 */
	public void setResultadoDiscagem_1_B1(String bit47ResDis_1_B1) {
		this.resultadoDiscagem_1_B1 = bit47ResDis_1_B1;
	}

	/**
	 * @return the bit47ResDis_1_B2
	 */
	@PositionalField(initialPosition= 88, finalPosition= 89)
	public String getResultadoDiscagem_1_B2() {
		return resultadoDiscagem_1_B2;
	}
	/**
	 * @param bit47ResDis_1_B2 the bit47ResDis_1_B2 to set
	 */
	public void setResultadoDiscagem_1_B2(String bit47ResDis_1_B2) {
		this.resultadoDiscagem_1_B2 = bit47ResDis_1_B2;
	}

	/**
	 * @return the bit47ResDis_1_B3
	 */
	@PositionalField(initialPosition= 90, finalPosition= 91)
	public String getResultadoDiscagem_1_B3() {
		return resultadoDiscagem_1_B3;
	}
	/**
	 * @param bit47ResDis_1_B3 the bit47ResDis_1_B3 to set
	 */
	public void setResultadoDiscagem_1_B3(String bit47ResDis_1_B3) {
		this.resultadoDiscagem_1_B3 = bit47ResDis_1_B3;
	}

	/**
	 * @return the bit47ResDis_1_B4
	 */
	@PositionalField(initialPosition= 92, finalPosition= 93)
	public String getResultadoDiscagem_1_B4() {
		return resultadoDiscagem_1_B4;
	}
	/**
	 * @param bit47ResDis_1_B4 the bit47ResDis_1_B4 to set
	 */
	public void setResultadoDiscagem_1_B4(String bit47ResDis_1_B4) {
		this.resultadoDiscagem_1_B4 = bit47ResDis_1_B4;
	}

	/**
	 * @return the bit47ResDis_1_B5
	 */
	@PositionalField(initialPosition= 94, finalPosition= 95)
	public String getResultadoDiscagem_1_B5() {
		return resultadoDiscagem_1_B5;
	}
	/**
	 * @param bit47ResDis_1_B5 the bit47ResDis_1_B5 to set
	 */
	public void setResultadoDiscagem_1_B5(String bit47ResDis_1_B5) {
		this.resultadoDiscagem_1_B5 = bit47ResDis_1_B5;
	}

	/**
	 * @return the bit47ResDis_1_B6
	 */
	@PositionalField(initialPosition= 96, finalPosition= 97)
	public String getResultadoDiscagem_1_B6() {
		return resultadoDiscagem_1_B6;
	}
	/**
	 * @param bit47ResDis_1_B6 the bit47ResDis_1_B6 to set
	 */
	public void setResultadoDiscagem_1_B6(String bit47ResDis_1_B6) {
		this.resultadoDiscagem_1_B6 = bit47ResDis_1_B6;
	}

	/**
	 * @return the bit47ResDis_1_B7
	 */
	@PositionalField(initialPosition= 98, finalPosition= 99)
	public String getResultadoDiscagem_1_B7() {
		return resultadoDiscagem_1_B7;
	}
	/**
	 * @param bit47ResDis_1_B7 the bit47ResDis_1_B7 to set
	 */
	public void setResultadoDiscagem_1_B7(String bit47ResDis_1_B7) {
		this.resultadoDiscagem_1_B7 = bit47ResDis_1_B7;
	}

	/**
	 * @return the bit47ResDis_1_B8
	 */
	@PositionalField(initialPosition= 100, finalPosition= 101)
	public String getResultadoDiscagem_1_B8() {
		return resultadoDiscagem_1_B8;
	}
	/**
	 * @param bit47ResDis_1_B8 the bit47ResDis_1_B8 to set
	 */
	public void setResultadoDiscagem_1_B8(String bit47ResDis_1_B8) {
		this.resultadoDiscagem_1_B8 = bit47ResDis_1_B8;
	}

	/**
	 * @return the bit47ResDis_1_B9
	 */
	@PositionalField(initialPosition= 102, finalPosition= 103)
	public String getResultadoDiscagem_1_B9() {
		return resultadoDiscagem_1_B9;
	}
	/**
	 * @param bit47ResDis_1_B9 the bit47ResDis_1_B9 to set
	 */
	public void setResultadoDiscagem_1_B9(String bit47ResDis_1_B9) {
		this.resultadoDiscagem_1_B9 = bit47ResDis_1_B9;
	}

	/**
	 * @return the bit47ResDis_1_B10
	 */
	@PositionalField(initialPosition= 104, finalPosition= 105)
	public String getResultadoDiscagem_1_B10() {
		return resultadoDiscagem_1_B10;
	}
	/**
	 * @param bit47ResDis_1_B10 the bit47ResDis_1_B10 to set
	 */
	public void setResultadoDiscagem_1_B10(String bit47ResDis_1_B10) {
		this.resultadoDiscagem_1_B10 = bit47ResDis_1_B10;
	}

	/**
	 * @return the bit47FonDis_1_C
	 */
	@PositionalField(initialPosition= 106, finalPosition= 121)
	public String getTelefoneDiscado_1_C() {
		return telefoneDiscado_1_C;
	}
	/**
	 * @param bit47FonDis_1_C the bit47FonDis_1_C to set
	 */
	public void setTelefoneDiscado_1_C(String bit47FonDis_1_C) {
		this.telefoneDiscado_1_C = bit47FonDis_1_C;
	}

	/**
	 * @return the bit47QuantidadeTen_1_C
	 */
	@PositionalField(initialPosition= 122, finalPosition= 123)
	public String getQuantidadeTentativasDiscagens_1_C() {
		return quantidadeTentativasDiscagens_1_C;
	}
	/**
	 * @param bit47QuantidadeTen_1_C the bit47QuantidadeTen_1_C to set
	 */
	public void setQuantidadeTentativasDiscagens_1_C(String bit47QuantidadeTen_1_C) {
		this.quantidadeTentativasDiscagens_1_C = bit47QuantidadeTen_1_C;
	}

	/**
	 * @return the bit47ResDis_1_C1
	 */
	@PositionalField(initialPosition= 124, finalPosition= 125)
	public String getResultadoDiscagem_1_C1() {
		return resultadoDiscagem_1_C1;
	}
	/**
	 * @param bit47ResDis_1_C1 the bit47ResDis_1_C1 to set
	 */
	public void setResultadoDiscagem_1_C1(String bit47ResDis_1_C1) {
		this.resultadoDiscagem_1_C1 = bit47ResDis_1_C1;
	}

	/**
	 * @return the bit47ResDis_1_C2
	 */
	@PositionalField(initialPosition= 126, finalPosition= 127)
	public String getResultadoDiscagem_1_C2() {
		return resultadoDiscagem_1_C2;
	}
	/**
	 * @param bit47ResDis_1_C2 the bit47ResDis_1_C2 to set
	 */
	public void setResultadoDiscagem_1_C2(String bit47ResDis_1_C2) {
		this.resultadoDiscagem_1_C2 = bit47ResDis_1_C2;
	}

	/**
	 * @return the bit47ResDis_1_C3
	 */
	@PositionalField(initialPosition= 128, finalPosition= 129)
	public String getResultadoDiscagem_1_C3() {
		return resultadoDiscagem_1_C3;
	}
	/**
	 * @param bit47ResDis_1_C3 the bit47ResDis_1_C3 to set
	 */
	public void setResultadoDiscagem_1_C3(String bit47ResDis_1_C3) {
		this.resultadoDiscagem_1_C3 = bit47ResDis_1_C3;
	}

	/**
	 * @return the bit47ResDis_1_C4
	 */
	@PositionalField(initialPosition= 130, finalPosition= 131)
	public String getResultadoDiscagem_1_C4() {
		return resultadoDiscagem_1_C4;
	}
	/**
	 * @param bit47ResDis_1_C4 the bit47ResDis_1_C4 to set
	 */
	public void setResultadoDiscagem_1_C4(String bit47ResDis_1_C4) {
		this.resultadoDiscagem_1_C4 = bit47ResDis_1_C4;
	}

	/**
	 * @return the bit47ResDis_1_C5
	 */
	@PositionalField(initialPosition= 132, finalPosition= 133)
	public String getResultadoDiscagem_1_C5() {
		return resultadoDiscagem_1_C5;
	}
	/**
	 * @param bit47ResDis_1_C5 the bit47ResDis_1_C5 to set
	 */
	public void setResultadoDiscagem_1_C5(String bit47ResDis_1_C5) {
		this.resultadoDiscagem_1_C5 = bit47ResDis_1_C5;
	}

	/**
	 * @return the bit47ResDis_1_C6
	 */
	@PositionalField(initialPosition= 134, finalPosition= 135)
	public String getResultadoDiscagem_1_C6() {
		return resultadoDiscagem_1_C6;
	}
	/**
	 * @param bit47ResDis_1_C6 the bit47ResDis_1_C6 to set
	 */
	public void setResultadoDiscagem_1_C6(String bit47ResDis_1_C6) {
		this.resultadoDiscagem_1_C6 = bit47ResDis_1_C6;
	}

	/**
	 * @return the bit47ResDis_1_C7
	 */
	@PositionalField(initialPosition= 136, finalPosition= 137)
	public String getResultadoDiscagem_1_C7() {
		return resultadoDiscagem_1_C7;
	}
	/**
	 * @param bit47ResDis_1_C7 the bit47ResDis_1_C7 to set
	 */
	public void setResultadoDiscagem_1_C7(String bit47ResDis_1_C7) {
		this.resultadoDiscagem_1_C7 = bit47ResDis_1_C7;
	}

	/**
	 * @return the bit47ResDis_1_C8
	 */
	@PositionalField(initialPosition= 138, finalPosition= 139)
	public String getResultadoDiscagem_1_C8() {
		return resultadoDiscagem_1_C8;
	}
	/**
	 * @param bit47ResDis_1_C8 the bit47ResDis_1_C8 to set
	 */
	public void setResultadoDiscagem_1_C8(String bit47ResDis_1_C8) {
		this.resultadoDiscagem_1_C8 = bit47ResDis_1_C8;
	}

	/**
	 * @return the bit47ResDis_1_C9
	 */
	@PositionalField(initialPosition= 140, finalPosition= 141)
	public String getResultadoDiscagem_1_C9() {
		return resultadoDiscagem_1_C9;
	}
	/**
	 * @param bit47ResDis_1_C9 the bit47ResDis_1_C9 to set
	 */
	public void setResultadoDiscagem_1_C9(String bit47ResDis_1_C9) {
		this.resultadoDiscagem_1_C9 = bit47ResDis_1_C9;
	}

	/**
	 * @return the bit47ResDis_1_C10
	 */
	@PositionalField(initialPosition= 142, finalPosition= 143)
	public String getResultadoDiscagem_1_C10() {
		return resultadoDiscagem_1_C10;
	}
	/**
	 * @param bit47ResDis_1_C10 the bit47ResDis_1_C10 to set
	 */
	public void setResultadoDiscagem_1_C10(String bit47ResDis_1_C10) {
		this.resultadoDiscagem_1_C10 = bit47ResDis_1_C10;
	}

	
	/*
	 * ITEM ADIC-BRB47-1-OCC1 NUMERO 2
	 */
	/**
	 * @return the bit47ByEnv_2
	 */
	@PositionalField(initialPosition= 144, finalPosition= 147)
	public String getQuantidadeBytesEnviados_2() {
		return quantidadeBytesEnviados_2;
	}
	/**
	 * @param bit47ByEnv_2 the bit47ByEnv_2 to set
	 */
	public void setQuantidadeBytesEnviados_2(String bit47ByEnv_2) {
		this.quantidadeBytesEnviados_2 = bit47ByEnv_2;
	}

	/**
	 * @return the bit47ByRec_2
	 */
	@PositionalField(initialPosition= 148, finalPosition= 153)
	public String getQuantidadeBytesRecebidos_2() {
		return quantidadeBytesRecebidos_2;
	}
	/**
	 * @param bit47ByRec_2 the bit47ByRec_2 to set
	 */
	public void setQuantidadeBytesRecebidos_2(String bit47ByRec_2) {
		this.quantidadeBytesRecebidos_2 = bit47ByRec_2;
	}
	
	/**
	 * @return the bit47ModCon_2
	 */
	@PositionalField(initialPosition= 154, finalPosition= 155)
	public String getModoConexao_2() {
		return modoConexao_2;
	}
	/**
	 * @param bit47ModCon_2 the bit47ModCon_2 to set
	 */
	public void setModoConexao_2(String bit47ModCon_2) {
		this.modoConexao_2 = bit47ModCon_2;
	}

	/**
	 * @return the bit47ModDis_2
	 */
	@PositionalField(initialPosition= 156, finalPosition= 156)
	public String getModoDiscagem_2() {
		return modoDiscagem_2;
	}
	/**
	 * @param bit47ModDis_2 the bit47ModDis_2 to set
	 */
	public void setModoDiscagem_2(String bit47ModDis_2) {
		this.modoDiscagem_2 = bit47ModDis_2;
	}

	/**
	 * @return the bit47Pref_2
	 */
	@PositionalField(initialPosition= 157, finalPosition= 172)
	public String getBit47Pref_2() {
		return bit47Pref_2;
	}
	/**
	 * @param bit47Pref_2 the bit47Pref_2 to set
	 */
	public void setBit47Pref_2(String bit47Pref_2) {
		this.bit47Pref_2 = bit47Pref_2;
	}

	/**
	 * @return the bit47FonDis_2_A
	 */
	@PositionalField(initialPosition= 173, finalPosition= 188)
	public String getTelefoneDiscado_2_A() {
		return telefoneDiscado_2_A;
	}
	/**
	 * @param bit47FonDis_2_A the bit47FonDis_2_A to set
	 */
	public void setTelefoneDiscado_2_A(String bit47FonDis_2_A) {
		this.telefoneDiscado_2_A = bit47FonDis_2_A;
	}

	/**
	 * @return the bit47QuantidadeTen_2_A
	 */
	@PositionalField(initialPosition= 189, finalPosition= 190)
	public String getQuantidadeTentativasDiscagens_2_A() {
		return quantidadeTentativasDiscagens_2_A;
	}
	/**
	 * @param bit47QuantidadeTen_2_A the bit47QuantidadeTen_2_A to set
	 */
	public void setQuantidadeTentativasDiscagens_2_A(String bit47QuantidadeTen_2_A) {
		this.quantidadeTentativasDiscagens_2_A = bit47QuantidadeTen_2_A;
	}

	/**
	 * @return the bit47ResDis_2_A1
	 */
	@PositionalField(initialPosition= 191, finalPosition= 192)
	public String getResultadoDiscagem_2_A1() {
		return resultadoDiscagem_2_A1;
	}
	/**
	 * @param bit47ResDis_2_A1 the bit47ResDis_2_A1 to set
	 */
	public void setResultadoDiscagem_2_A1(String bit47ResDis_2_A1) {
		this.resultadoDiscagem_2_A1 = bit47ResDis_2_A1;
	}

	/**
	 * @return the bit47ResDis_2_A2
	 */
	@PositionalField(initialPosition= 193, finalPosition= 194)
	public String getResultadoDiscagem_2_A2() {
		return resultadoDiscagem_2_A2;
	}
	/**
	 * @param bit47ResDis_2_A2 the bit47ResDis_2_A2 to set
	 */
	public void setResultadoDiscagem_2_A2(String bit47ResDis_2_A2) {
		this.resultadoDiscagem_2_A2 = bit47ResDis_2_A2;
	}

	/**
	 * @return the bit47ResDis_2_A3
	 */
	@PositionalField(initialPosition= 195, finalPosition= 196)
	public String getResultadoDiscagem_2_A3() {
		return resultadoDiscagem_2_A3;
	}
	/**
	 * @param bit47ResDis_2_A3 the bit47ResDis_2_A3 to set
	 */
	public void setResultadoDiscagem_2_A3(String bit47ResDis_2_A3) {
		this.resultadoDiscagem_2_A3 = bit47ResDis_2_A3;
	}

	/**
	 * @return the bit47ResDis_2_A4
	 */
	@PositionalField(initialPosition= 197, finalPosition= 198)
	public String getResultadoDiscagem_2_A4() {
		return resultadoDiscagem_2_A4;
	}
	/**
	 * @param bit47ResDis_2_A4 the bit47ResDis_2_A4 to set
	 */
	public void setResultadoDiscagem_2_A4(String bit47ResDis_2_A4) {
		this.resultadoDiscagem_2_A4 = bit47ResDis_2_A4;
	}

	/**
	 * @return the bit47ResDis_2_A5
	 */
	@PositionalField(initialPosition= 199, finalPosition= 200)
	public String getResultadoDiscagem_2_A5() {
		return resultadoDiscagem_2_A5;
	}
	/**
	 * @param bit47ResDis_2_A5 the bit47ResDis_2_A5 to set
	 */
	public void setResultadoDiscagem_2_A5(String bit47ResDis_2_A5) {
		this.resultadoDiscagem_2_A5 = bit47ResDis_2_A5;
	}

	/**
	 * @return the bit47ResDis_2_A6
	 */
	@PositionalField(initialPosition= 201, finalPosition= 202)
	public String getResultadoDiscagem_2_A6() {
		return resultadoDiscagem_2_A6;
	}
	/**
	 * @param bit47ResDis_2_A6 the bit47ResDis_2_A6 to set
	 */
	public void setResultadoDiscagem_2_A6(String bit47ResDis_2_A6) {
		this.resultadoDiscagem_2_A6 = bit47ResDis_2_A6;
	}

	/**
	 * @return the bit47ResDis_2_A7
	 */
	@PositionalField(initialPosition= 203, finalPosition= 204)
	public String getResultadoDiscagem_2_A7() {
		return resultadoDiscagem_2_A7;
	}
	/**
	 * @param bit47ResDis_2_A7 the bit47ResDis_2_A7 to set
	 */
	public void setResultadoDiscagem_2_A7(String bit47ResDis_2_A7) {
		this.resultadoDiscagem_2_A7 = bit47ResDis_2_A7;
	}

	/**
	 * @return the bit47ResDis_2_A8
	 */
	@PositionalField(initialPosition= 205, finalPosition= 206)
	public String getResultadoDiscagem_2_A8() {
		return resultadoDiscagem_2_A8;
	}
	/**
	 * @param bit47ResDis_2_A8 the bit47ResDis_2_A8 to set
	 */
	public void setResultadoDiscagem_2_A8(String bit47ResDis_2_A8) {
		this.resultadoDiscagem_2_A8 = bit47ResDis_2_A8;
	}

	/**
	 * @return the bit47ResDis_2_A9
	 */
	@PositionalField(initialPosition= 207, finalPosition= 208)
	public String getResultadoDiscagem_2_A9() {
		return resultadoDiscagem_2_A9;
	}
	/**
	 * @param bit47ResDis_2_A9 the bit47ResDis_2_A9 to set
	 */
	public void setResultadoDiscagem_2_A9(String bit47ResDis_2_A9) {
		this.resultadoDiscagem_2_A9 = bit47ResDis_2_A9;
	}

	/**
	 * @return the bit47ResDis_2_A10
	 */
	@PositionalField(initialPosition= 209, finalPosition= 210)
	public String getResultadoDiscagem_2_A10() {
		return resultadoDiscagem_2_A10;
	}
	/**
	 * @param bit47ResDis_2_A10 the bit47ResDis_2_A10 to set
	 */
	public void setResultadoDiscagem_2_A10(String bit47ResDis_2_A10) {
		this.resultadoDiscagem_2_A10 = bit47ResDis_2_A10;
	}

	/**
	 * @return the bit47FonDis_2_B
	 */
	@PositionalField(initialPosition= 211, finalPosition= 226)
	public String getTelefoneDiscado_2_B() {
		return telefoneDiscado_2_B;
	}
	/**
	 * @param bit47FonDis_2_B the bit47FonDis_2_B to set
	 */
	public void setTelefoneDiscado_2_B(String bit47FonDis_2_B) {
		this.telefoneDiscado_2_B = bit47FonDis_2_B;
	}

	/**
	 * @return the bit47QuantidadeTen_2_B
	 */
	@PositionalField(initialPosition= 227, finalPosition= 228)
	public String getQuantidadeTentativasDiscagens_2_B() {
		return quantidadeTentativasDiscagens_2_B;
	}
	/**
	 * @param bit47QuantidadeTen_2_B the bit47QuantidadeTen_2_B to set
	 */
	public void setQuantidadeTentativasDiscagens_2_B(String bit47QuantidadeTen_2_B) {
		this.quantidadeTentativasDiscagens_2_B = bit47QuantidadeTen_2_B;
	}

	/**
	 * @return the bit47ResDis_2_B1
	 */
	@PositionalField(initialPosition= 229, finalPosition= 230)
	public String getResultadoDiscagem_2_B1() {
		return resultadoDiscagem_2_B1;
	}
	/**
	 * @param bit47ResDis_2_B1 the bit47ResDis_2_B1 to set
	 */
	public void setResultadoDiscagem_2_B1(String bit47ResDis_2_B1) {
		this.resultadoDiscagem_2_B1 = bit47ResDis_2_B1;
	}

	/**
	 * @return the bit47ResDis_2_B2
	 */
	@PositionalField(initialPosition= 231, finalPosition= 232)
	public String getResultadoDiscagem_2_B2() {
		return resultadoDiscagem_2_B2;
	}
	/**
	 * @param bit47ResDis_2_B2 the bit47ResDis_2_B2 to set
	 */
	public void setResultadoDiscagem_2_B2(String bit47ResDis_2_B2) {
		this.resultadoDiscagem_2_B2 = bit47ResDis_2_B2;
	}

	/**
	 * @return the bit47ResDis_2_B3
	 */
	@PositionalField(initialPosition= 233, finalPosition= 234)
	public String getResultadoDiscagem_2_B3() {
		return resultadoDiscagem_2_B3;
	}
	/**
	 * @param bit47ResDis_2_B3 the bit47ResDis_2_B3 to set
	 */
	public void setResultadoDiscagem_2_B3(String bit47ResDis_2_B3) {
		this.resultadoDiscagem_2_B3 = bit47ResDis_2_B3;
	}

	/**
	 * @return the bit47ResDis_2_B4
	 */
	@PositionalField(initialPosition= 235, finalPosition= 236)
	public String getResultadoDiscagem_2_B4() {
		return resultadoDiscagem_2_B4;
	}
	/**
	 * @param bit47ResDis_2_B4 the bit47ResDis_2_B4 to set
	 */
	public void setResultadoDiscagem_2_B4(String bit47ResDis_2_B4) {
		this.resultadoDiscagem_2_B4 = bit47ResDis_2_B4;
	}

	/**
	 * @return the bit47ResDis_2_B5
	 */
	@PositionalField(initialPosition= 237, finalPosition= 238)
	public String getResultadoDiscagem_2_B5() {
		return resultadoDiscagem_2_B5;
	}
	/**
	 * @param bit47ResDis_2_B5 the bit47ResDis_2_B5 to set
	 */
	public void setResultadoDiscagem_2_B5(String bit47ResDis_2_B5) {
		this.resultadoDiscagem_2_B5 = bit47ResDis_2_B5;
	}

	/**
	 * @return the bit47ResDis_2_B6
	 */
	@PositionalField(initialPosition= 239, finalPosition= 240)
	public String getResultadoDiscagem_2_B6() {
		return resultadoDiscagem_2_B6;
	}
	/**
	 * @param bit47ResDis_2_B6 the bit47ResDis_2_B6 to set
	 */
	public void setResultadoDiscagem_2_B6(String bit47ResDis_2_B6) {
		this.resultadoDiscagem_2_B6 = bit47ResDis_2_B6;
	}

	/**
	 * @return the bit47ResDis_2_B7
	 */
	@PositionalField(initialPosition= 241, finalPosition= 242)
	public String getResultadoDiscagem_2_B7() {
		return resultadoDiscagem_2_B7;
	}
	/**
	 * @param bit47ResDis_2_B7 the bit47ResDis_2_B7 to set
	 */
	public void setResultadoDiscagem_2_B7(String bit47ResDis_2_B7) {
		this.resultadoDiscagem_2_B7 = bit47ResDis_2_B7;
	}

	/**
	 * @return the bit47ResDis_2_B8
	 */
	@PositionalField(initialPosition= 243, finalPosition= 244)
	public String getResultadoDiscagem_2_B8() {
		return resultadoDiscagem_2_B8;
	}
	/**
	 * @param bit47ResDis_2_B8 the bit47ResDis_2_B8 to set
	 */
	public void setResultadoDiscagem_2_B8(String bit47ResDis_2_B8) {
		this.resultadoDiscagem_2_B8 = bit47ResDis_2_B8;
	}

	/**
	 * @return the bit47ResDis_2_B9
	 */
	@PositionalField(initialPosition= 245, finalPosition= 246)
	public String getResultadoDiscagem_2_B9() {
		return resultadoDiscagem_2_B9;
	}
	/**
	 * @param bit47ResDis_2_B9 the bit47ResDis_2_B9 to set
	 */
	public void setResultadoDiscagem_2_B9(String bit47ResDis_2_B9) {
		this.resultadoDiscagem_2_B9 = bit47ResDis_2_B9;
	}

	/**
	 * @return the bit47ResDis_2_B10
	 */
	@PositionalField(initialPosition= 247, finalPosition= 248)
	public String getResultadoDiscagem_2_B10() {
		return resultadoDiscagem_2_B10;
	}
	/**
	 * @param bit47ResDis_2_B10 the bit47ResDis_2_B10 to set
	 */
	public void setResultadoDiscagem_2_B10(String bit47ResDis_2_B10) {
		this.resultadoDiscagem_2_B10 = bit47ResDis_2_B10;
	}

	/**
	 * @return the bit47FonDis_2_C
	 */
	@PositionalField(initialPosition= 249, finalPosition= 264)
	public String getTelefoneDiscado_2_C() {
		return telefoneDiscado_2_C;
	}
	/**
	 * @param bit47FonDis_2_C the bit47FonDis_2_C to set
	 */
	public void setTelefoneDiscado_2_C(String bit47FonDis_2_C) {
		this.telefoneDiscado_2_C = bit47FonDis_2_C;
	}

	/**
	 * @return the bit47QuantidadeTen_2_C
	 */
	@PositionalField(initialPosition= 265, finalPosition= 266)
	public String getQuantidadeTentativasDiscagens_2_C() {
		return quantidadeTentativasDiscagens_2_C;
	}
	/**
	 * @param bit47QuantidadeTen_2_C the bit47QuantidadeTen_2_C to set
	 */
	public void setQuantidadeTentativasDiscagens_2_C(String bit47QuantidadeTen_2_C) {
		this.quantidadeTentativasDiscagens_2_C = bit47QuantidadeTen_2_C;
	}

	/**
	 * @return the bit47ResDis_2_C1
	 */
	@PositionalField(initialPosition= 267, finalPosition= 268)
	public String getResultadoDiscagem_2_C1() {
		return resultadoDiscagem_2_C1;
	}
	/**
	 * @param bit47ResDis_2_C1 the bit47ResDis_2_C1 to set
	 */
	public void setResultadoDiscagem_2_C1(String bit47ResDis_2_C1) {
		this.resultadoDiscagem_2_C1 = bit47ResDis_2_C1;
	}

	/**
	 * @return the bit47ResDis_2_C2
	 */
	@PositionalField(initialPosition= 269, finalPosition= 270)
	public String getResultadoDiscagem_2_C2() {
		return resultadoDiscagem_2_C2;
	}
	/**
	 * @param bit47ResDis_2_C2 the bit47ResDis_2_C2 to set
	 */
	public void setResultadoDiscagem_2_C2(String bit47ResDis_2_C2) {
		this.resultadoDiscagem_2_C2 = bit47ResDis_2_C2;
	}

	/**
	 * @return the bit47ResDis_2_C3
	 */
	@PositionalField(initialPosition= 271, finalPosition= 272)
	public String getResultadoDiscagem_2_C3() {
		return resultadoDiscagem_2_C3;
	}
	/**
	 * @param bit47ResDis_2_C3 the bit47ResDis_2_C3 to set
	 */
	public void setResultadoDiscagem_2_C3(String bit47ResDis_2_C3) {
		this.resultadoDiscagem_2_C3 = bit47ResDis_2_C3;
	}

	/**
	 * @return the bit47ResDis_2_C4
	 */
	@PositionalField(initialPosition= 273, finalPosition= 274)
	public String getResultadoDiscagem_2_C4() {
		return resultadoDiscagem_2_C4;
	}
	/**
	 * @param bit47ResDis_2_C4 the bit47ResDis_2_C4 to set
	 */
	public void setResultadoDiscagem_2_C4(String bit47ResDis_2_C4) {
		this.resultadoDiscagem_2_C4 = bit47ResDis_2_C4;
	}

	/**
	 * @return the bit47ResDis_2_C5
	 */
	@PositionalField(initialPosition= 275, finalPosition= 276)
	public String getResultadoDiscagem_2_C5() {
		return resultadoDiscagem_2_C5;
	}
	/**
	 * @param bit47ResDis_2_C5 the bit47ResDis_2_C5 to set
	 */
	public void setResultadoDiscagem_2_C5(String bit47ResDis_2_C5) {
		this.resultadoDiscagem_2_C5 = bit47ResDis_2_C5;
	}

	/**
	 * @return the bit47ResDis_2_C6
	 */
	@PositionalField(initialPosition= 277, finalPosition= 278)
	public String getResultadoDiscagem_2_C6() {
		return resultadoDiscagem_2_C6;
	}
	/**
	 * @param bit47ResDis_2_C6 the bit47ResDis_2_C6 to set
	 */
	public void setResultadoDiscagem_2_C6(String bit47ResDis_2_C6) {
		this.resultadoDiscagem_2_C6 = bit47ResDis_2_C6;
	}

	/**
	 * @return the bit47ResDis_2_C7
	 */
	@PositionalField(initialPosition= 279, finalPosition= 280)
	public String getResultadoDiscagem_2_C7() {
		return resultadoDiscagem_2_C7;
	}
	/**
	 * @param bit47ResDis_2_C7 the bit47ResDis_2_C7 to set
	 */
	public void setResultadoDiscagem_2_C7(String bit47ResDis_2_C7) {
		this.resultadoDiscagem_2_C7 = bit47ResDis_2_C7;
	}

	/**
	 * @return the bit47ResDis_2_C8
	 */
	@PositionalField(initialPosition= 281, finalPosition= 282)
	public String getResultadoDiscagem_2_C8() {
		return resultadoDiscagem_2_C8;
	}
	/**
	 * @param bit47ResDis_2_C8 the bit47ResDis_2_C8 to set
	 */
	public void setResultadoDiscagem_2_C8(String bit47ResDis_2_C8) {
		this.resultadoDiscagem_2_C8 = bit47ResDis_2_C8;
	}

	/**
	 * @return the bit47ResDis_2_C9
	 */
	@PositionalField(initialPosition= 283, finalPosition= 284)
	public String getResultadoDiscagem_2_C9() {
		return resultadoDiscagem_2_C9;
	}
	/**
	 * @param bit47ResDis_2_C9 the bit47ResDis_2_C9 to set
	 */
	public void setResultadoDiscagem_2_C9(String bit47ResDis_2_C9) {
		this.resultadoDiscagem_2_C9 = bit47ResDis_2_C9;
	}

	/**
	 * @return the bit47ResDis_2_C10
	 */
	@PositionalField(initialPosition= 285, finalPosition= 286)
	public String getResultadoDiscagem_2_C10() {
		return resultadoDiscagem_2_C10;
	}
	/**
	 * @param bit47ResDis_2_C10 the bit47ResDis_2_C10 to set
	 */
	public void setResultadoDiscagem_2_C10(String bit47ResDis_2_C10) {
		this.resultadoDiscagem_2_C10 = bit47ResDis_2_C10;
	}

	
	/*
	 * ITEM ADIC-BRB47-1-OCC1 NUMERO 3
	 */
	/**
	 * @return the bit47ByEnv_3
	 */
	@PositionalField(initialPosition= 287, finalPosition= 290)
	public String getQuantidadeBytesEnviados_3() {
		return quantidadeBytesEnviados_3;
	}
	/**
	 * @param bit47ByEnv_3 the bit47ByEnv_3 to set
	 */
	public void setQuantidadeBytesEnviados_3(String bit47ByEnv_3) {
		this.quantidadeBytesEnviados_3 = bit47ByEnv_3;
	}

	/**
	 * @return the bit47ByRec_3
	 */
	@PositionalField(initialPosition= 291, finalPosition= 296)
	public String getQuantidadeBytesRecebidos_3() {
		return quantidadeBytesRecebidos_3;
	}
	/**
	 * @param bit47ByRec_3 the bit47ByRec_3 to set
	 */
	public void setQuantidadeBytesRecebidos_3(String bit47ByRec_3) {
		this.quantidadeBytesRecebidos_3 = bit47ByRec_3;
	}

	/**
	 * @return the bit47ModCon_3
	 */
	@PositionalField(initialPosition= 297, finalPosition= 298)
	public String getModoConexao_3() {
		return modoConexao_3;
	}
	/**
	 * @param bit47ModCon_3 the bit47ModCon_3 to set
	 */
	public void setModoConexao_3(String bit47ModCon_3) {
		this.modoConexao_3 = bit47ModCon_3;
	}

	/**
	 * @return the bit47ModDis_3
	 */
	@PositionalField(initialPosition= 299, finalPosition= 299)
	public String getModoDiscagem_3() {
		return modoDiscagem_3;
	}
	/**
	 * @param bit47ModDis_3 the bit47ModDis_3 to set
	 */
	public void setModoDiscagem_3(String bit47ModDis_3) {
		this.modoDiscagem_3 = bit47ModDis_3;
	}

	/**
	 * @return the bit47Pref_3
	 */
	@PositionalField(initialPosition= 300, finalPosition= 315)
	public String getBit47Pref_3() {
		return bit47Pref_3;
	}
	/**
	 * @param bit47Pref_3 the bit47Pref_3 to set
	 */
	public void setBit47Pref_3(String bit47Pref_3) {
		this.bit47Pref_3 = bit47Pref_3;
	}

	/**
	 * @return the bit47FonDis_3_A
	 */
	@PositionalField(initialPosition= 316, finalPosition= 331)
	public String getTelefoneDiscado_3_A() {
		return telefoneDiscado_3_A;
	}
	/**
	 * @param bit47FonDis_3_A the bit47FonDis_3_A to set
	 */
	public void setTelefoneDiscado_3_A(String bit47FonDis_3_A) {
		this.telefoneDiscado_3_A = bit47FonDis_3_A;
	}

	/**
	 * @return the bit47QuantidadeTen_3_A
	 */
	@PositionalField(initialPosition= 332, finalPosition= 333)
	public String getQuantidadeTentativasDiscagens_3_A() {
		return quantidadeTentativasDiscagens_3_A;
	}
	/**
	 * @param bit47QuantidadeTen_3_A the bit47QuantidadeTen_3_A to set
	 */
	public void setQuantidadeTentativasDiscagens_3_A(String bit47QuantidadeTen_3_A) {
		this.quantidadeTentativasDiscagens_3_A = bit47QuantidadeTen_3_A;
	}

	/**
	 * @return the bit47ResDis_3_A1
	 */
	@PositionalField(initialPosition= 334, finalPosition= 335)
	public String getResultadoDiscagem_3_A1() {
		return resultadoDiscagem_3_A1;
	}
	/**
	 * @param bit47ResDis_3_A1 the bit47ResDis_3_A1 to set
	 */
	public void setResultadoDiscagem_3_A1(String bit47ResDis_3_A1) {
		this.resultadoDiscagem_3_A1 = bit47ResDis_3_A1;
	}

	/**
	 * @return the bit47ResDis_3_A2
	 */
	@PositionalField(initialPosition= 336, finalPosition= 337)
	public String getResultadoDiscagem_3_A2() {
		return resultadoDiscagem_3_A2;
	}
	/**
	 * @param bit47ResDis_3_A2 the bit47ResDis_3_A2 to set
	 */
	public void setResultadoDiscagem_3_A2(String bit47ResDis_3_A2) {
		this.resultadoDiscagem_3_A2 = bit47ResDis_3_A2;
	}

	/**
	 * @return the bit47ResDis_3_A3
	 */
	@PositionalField(initialPosition= 338, finalPosition= 339)
	public String getResultadoDiscagem_3_A3() {
		return resultadoDiscagem_3_A3;
	}
	/**
	 * @param bit47ResDis_3_A3 the bit47ResDis_3_A3 to set
	 */
	public void setResultadoDiscagem_3_A3(String bit47ResDis_3_A3) {
		this.resultadoDiscagem_3_A3 = bit47ResDis_3_A3;
	}

	/**
	 * @return the bit47ResDis_3_A4
	 */
	@PositionalField(initialPosition= 340, finalPosition= 341)
	public String getResultadoDiscagem_3_A4() {
		return resultadoDiscagem_3_A4;
	}
	/**
	 * @param bit47ResDis_3_A4 the bit47ResDis_3_A4 to set
	 */
	public void setResultadoDiscagem_3_A4(String bit47ResDis_3_A4) {
		this.resultadoDiscagem_3_A4 = bit47ResDis_3_A4;
	}

	/**
	 * @return the bit47ResDis_3_A5
	 */
	@PositionalField(initialPosition= 342, finalPosition= 343)
	public String getResultadoDiscagem_3_A5() {
		return resultadoDiscagem_3_A5;
	}
	/**
	 * @param bit47ResDis_3_A5 the bit47ResDis_3_A5 to set
	 */
	public void setResultadoDiscagem_3_A5(String bit47ResDis_3_A5) {
		this.resultadoDiscagem_3_A5 = bit47ResDis_3_A5;
	}

	/**
	 * @return the bit47ResDis_3_A6
	 */
	@PositionalField(initialPosition= 344, finalPosition= 345)
	public String getResultadoDiscagem_3_A6() {
		return resultadoDiscagem_3_A6;
	}
	/**
	 * @param bit47ResDis_3_A6 the bit47ResDis_3_A6 to set
	 */
	public void setResultadoDiscagem_3_A6(String bit47ResDis_3_A6) {
		this.resultadoDiscagem_3_A6 = bit47ResDis_3_A6;
	}

	/**
	 * @return the bit47ResDis_3_A7
	 */
	@PositionalField(initialPosition= 346, finalPosition= 347)
	public String getResultadoDiscagem_3_A7() {
		return resultadoDiscagem_3_A7;
	}
	/**
	 * @param bit47ResDis_3_A7 the bit47ResDis_3_A7 to set
	 */
	public void setResultadoDiscagem_3_A7(String bit47ResDis_3_A7) {
		this.resultadoDiscagem_3_A7 = bit47ResDis_3_A7;
	}

	/**
	 * @return the bit47ResDis_3_A8
	 */
	@PositionalField(initialPosition= 348, finalPosition= 349)
	public String getResultadoDiscagem_3_A8() {
		return resultadoDiscagem_3_A8;
	}
	/**
	 * @param bit47ResDis_3_A8 the bit47ResDis_3_A8 to set
	 */
	public void setResultadoDiscagem_3_A8(String bit47ResDis_3_A8) {
		this.resultadoDiscagem_3_A8 = bit47ResDis_3_A8;
	}

	/**
	 * @return the bit47ResDis_3_A9
	 */
	@PositionalField(initialPosition= 350, finalPosition= 351)
	public String getResultadoDiscagem_3_A9() {
		return resultadoDiscagem_3_A9;
	}
	/**
	 * @param bit47ResDis_3_A9 the bit47ResDis_3_A9 to set
	 */
	public void setResultadoDiscagem_3_A9(String bit47ResDis_3_A9) {
		this.resultadoDiscagem_3_A9 = bit47ResDis_3_A9;
	}

	/**
	 * @return the bit47ResDis_3_A10
	 */
	@PositionalField(initialPosition= 352, finalPosition= 353)
	public String getResultadoDiscagem_3_A10() {
		return resultadoDiscagem_3_A10;
	}
	/**
	 * @param bit47ResDis_3_A10 the bit47ResDis_3_A10 to set
	 */
	public void setResultadoDiscagem_3_A10(String bit47ResDis_3_A10) {
		this.resultadoDiscagem_3_A10 = bit47ResDis_3_A10;
	}

	/**
	 * @return the bit47FonDis_3_B
	 */
	@PositionalField(initialPosition= 354, finalPosition= 369)
	public String getTelefoneDiscado_3_B() {
		return telefoneDiscado_3_B;
	}
	/**
	 * @param bit47FonDis_3_B the bit47FonDis_3_B to set
	 */
	public void setTelefoneDiscado_3_B(String bit47FonDis_3_B) {
		this.telefoneDiscado_3_B = bit47FonDis_3_B;
	}

	/**
	 * @return the bit47QuantidadeTen_3_B
	 */
	@PositionalField(initialPosition= 370, finalPosition= 371)
	public String getQuantidadeTentativasDiscagens_3_B() {
		return quantidadeTentativasDiscagens_3_B;
	}
	/**
	 * @param bit47QuantidadeTen_3_B the bit47QuantidadeTen_3_B to set
	 */
	public void setQuantidadeTentativasDiscagens_3_B(String bit47QuantidadeTen_3_B) {
		this.quantidadeTentativasDiscagens_3_B = bit47QuantidadeTen_3_B;
	}

	/**
	 * @return the bit47ResDis_3_B1
	 */
	@PositionalField(initialPosition= 372, finalPosition= 373)
	public String getResultadoDiscagem_3_B1() {
		return resultadoDiscagem_3_B1;
	}
	/**
	 * @param bit47ResDis_3_B1 the bit47ResDis_3_B1 to set
	 */
	public void setResultadoDiscagem_3_B1(String bit47ResDis_3_B1) {
		this.resultadoDiscagem_3_B1 = bit47ResDis_3_B1;
	}

	/**
	 * @return the bit47ResDis_3_B2
	 */
	@PositionalField(initialPosition= 374, finalPosition= 375)
	public String getResultadoDiscagem_3_B2() {
		return resultadoDiscagem_3_B2;
	}
	/**
	 * @param bit47ResDis_3_B2 the bit47ResDis_3_B2 to set
	 */
	public void setResultadoDiscagem_3_B2(String bit47ResDis_3_B2) {
		this.resultadoDiscagem_3_B2 = bit47ResDis_3_B2;
	}

	/**
	 * @return the bit47ResDis_3_B3
	 */
	@PositionalField(initialPosition= 376, finalPosition= 377)
	public String getResultadoDiscagem_3_B3() {
		return resultadoDiscagem_3_B3;
	}
	/**
	 * @param bit47ResDis_3_B3 the bit47ResDis_3_B3 to set
	 */
	public void setResultadoDiscagem_3_B3(String bit47ResDis_3_B3) {
		this.resultadoDiscagem_3_B3 = bit47ResDis_3_B3;
	}

	/**
	 * @return the bit47ResDis_3_B4
	 */
	@PositionalField(initialPosition= 378, finalPosition= 379)
	public String getResultadoDiscagem_3_B4() {
		return resultadoDiscagem_3_B4;
	}
	/**
	 * @param bit47ResDis_3_B4 the bit47ResDis_3_B4 to set
	 */
	public void setResultadoDiscagem_3_B4(String bit47ResDis_3_B4) {
		this.resultadoDiscagem_3_B4 = bit47ResDis_3_B4;
	}

	/**
	 * @return the bit47ResDis_3_B5
	 */
	@PositionalField(initialPosition= 380, finalPosition= 381)
	public String getResultadoDiscagem_3_B5() {
		return resultadoDiscagem_3_B5;
	}
	/**
	 * @param bit47ResDis_3_B5 the bit47ResDis_3_B5 to set
	 */
	public void setResultadoDiscagem_3_B5(String bit47ResDis_3_B5) {
		this.resultadoDiscagem_3_B5 = bit47ResDis_3_B5;
	}

	/**
	 * @return the bit47ResDis_3_B6
	 */
	@PositionalField(initialPosition= 382, finalPosition= 383)
	public String getResultadoDiscagem_3_B6() {
		return resultadoDiscagem_3_B6;
	}
	/**
	 * @param bit47ResDis_3_B6 the bit47ResDis_3_B6 to set
	 */
	public void setResultadoDiscagem_3_B6(String bit47ResDis_3_B6) {
		this.resultadoDiscagem_3_B6 = bit47ResDis_3_B6;
	}

	/**
	 * @return the bit47ResDis_3_B7
	 */
	@PositionalField(initialPosition= 384, finalPosition= 385)
	public String getResultadoDiscagem_3_B7() {
		return resultadoDiscagem_3_B7;
	}
	/**
	 * @param bit47ResDis_3_B7 the bit47ResDis_3_B7 to set
	 */
	public void setResultadoDiscagem_3_B7(String bit47ResDis_3_B7) {
		this.resultadoDiscagem_3_B7 = bit47ResDis_3_B7;
	}

	/**
	 * @return the bit47ResDis_3_B8
	 */
	@PositionalField(initialPosition= 386, finalPosition= 387)
	public String getResultadoDiscagem_3_B8() {
		return resultadoDiscagem_3_B8;
	}
	/**
	 * @param bit47ResDis_3_B8 the bit47ResDis_3_B8 to set
	 */
	public void setResultadoDiscagem_3_B8(String bit47ResDis_3_B8) {
		this.resultadoDiscagem_3_B8 = bit47ResDis_3_B8;
	}

	/**
	 * @return the bit47ResDis_3_B9
	 */
	@PositionalField(initialPosition= 388, finalPosition= 389)
	public String getResultadoDiscagem_3_B9() {
		return resultadoDiscagem_3_B9;
	}
	/**
	 * @param bit47ResDis_3_B9 the bit47ResDis_3_B9 to set
	 */
	public void setResultadoDiscagem_3_B9(String bit47ResDis_3_B9) {
		this.resultadoDiscagem_3_B9 = bit47ResDis_3_B9;
	}

	/**
	 * @return the bit47ResDis_3_B10
	 */
	@PositionalField(initialPosition= 390, finalPosition= 391)
	public String getResultadoDiscagem_3_B10() {
		return resultadoDiscagem_3_B10;
	}
	/**
	 * @param bit47ResDis_3_B10 the bit47ResDis_3_B10 to set
	 */
	public void setResultadoDiscagem_3_B10(String bit47ResDis_3_B10) {
		this.resultadoDiscagem_3_B10 = bit47ResDis_3_B10;
	}

	/**
	 * @return the bit47FonDis_3_C
	 */
	@PositionalField(initialPosition= 392, finalPosition= 407)
	public String getTelefoneDiscado_3_C() {
		return telefoneDiscado_3_C;
	}
	/**
	 * @param bit47FonDis_3_C the bit47FonDis_3_C to set
	 */
	public void setTelefoneDiscado_3_C(String bit47FonDis_3_C) {
		this.telefoneDiscado_3_C = bit47FonDis_3_C;
	}

	/**
	 * @return the bit47QuantidadeTen_3_C
	 */
	@PositionalField(initialPosition= 408, finalPosition= 409)
	public String getQuantidadeTentativasDiscagens_3_C() {
		return quantidadeTentativasDiscagens_3_C;
	}
	/**
	 * @param bit47QuantidadeTen_3_C the bit47QuantidadeTen_3_C to set
	 */
	public void setQuantidadeTentativasDiscagens_3_C(String bit47QuantidadeTen_3_C) {
		this.quantidadeTentativasDiscagens_3_C = bit47QuantidadeTen_3_C;
	}

	/**
	 * @return the bit47ResDis_3_C1
	 */
	@PositionalField(initialPosition= 410, finalPosition= 411)
	public String getResultadoDiscagem_3_C1() {
		return resultadoDiscagem_3_C1;
	}
	/**
	 * @param bit47ResDis_3_C1 the bit47ResDis_3_C1 to set
	 */
	public void setResultadoDiscagem_3_C1(String bit47ResDis_3_C1) {
		this.resultadoDiscagem_3_C1 = bit47ResDis_3_C1;
	}

	/**
	 * @return the bit47ResDis_3_C2
	 */
	@PositionalField(initialPosition= 412, finalPosition= 413)
	public String getResultadoDiscagem_3_C2() {
		return resultadoDiscagem_3_C2;
	}
	/**
	 * @param bit47ResDis_3_C2 the bit47ResDis_3_C2 to set
	 */
	public void setResultadoDiscagem_3_C2(String bit47ResDis_3_C2) {
		this.resultadoDiscagem_3_C2 = bit47ResDis_3_C2;
	}

	/**
	 * @return the bit47ResDis_3_C3
	 */
	@PositionalField(initialPosition= 414, finalPosition= 415)
	public String getResultadoDiscagem_3_C3() {
		return resultadoDiscagem_3_C3;
	}
	/**
	 * @param bit47ResDis_3_C3 the bit47ResDis_3_C3 to set
	 */
	public void setResultadoDiscagem_3_C3(String bit47ResDis_3_C3) {
		this.resultadoDiscagem_3_C3 = bit47ResDis_3_C3;
	}

	/**
	 * @return the bit47ResDis_3_C4
	 */
	@PositionalField(initialPosition= 416, finalPosition= 417)
	public String getResultadoDiscagem_3_C4() {
		return resultadoDiscagem_3_C4;
	}
	/**
	 * @param bit47ResDis_3_C4 the bit47ResDis_3_C4 to set
	 */
	public void setResultadoDiscagem_3_C4(String bit47ResDis_3_C4) {
		this.resultadoDiscagem_3_C4 = bit47ResDis_3_C4;
	}

	/**
	 * @return the bit47ResDis_3_C5
	 */
	@PositionalField(initialPosition= 418, finalPosition= 419)
	public String getResultadoDiscagem_3_C5() {
		return resultadoDiscagem_3_C5;
	}
	/**
	 * @param bit47ResDis_3_C5 the bit47ResDis_3_C5 to set
	 */
	public void setResultadoDiscagem_3_C5(String bit47ResDis_3_C5) {
		this.resultadoDiscagem_3_C5 = bit47ResDis_3_C5;
	}

	/**
	 * @return the bit47ResDis_3_C6
	 */
	@PositionalField(initialPosition= 420, finalPosition= 421)
	public String getResultadoDiscagem_3_C6() {
		return resultadoDiscagem_3_C6;
	}
	/**
	 * @param bit47ResDis_3_C6 the bit47ResDis_3_C6 to set
	 */
	public void setResultadoDiscagem_3_C6(String bit47ResDis_3_C6) {
		this.resultadoDiscagem_3_C6 = bit47ResDis_3_C6;
	}

	/**
	 * @return the bit47ResDis_3_C7
	 */
	@PositionalField(initialPosition= 422, finalPosition= 423)
	public String getResultadoDiscagem_3_C7() {
		return resultadoDiscagem_3_C7;
	}
	/**
	 * @param bit47ResDis_3_C7 the bit47ResDis_3_C7 to set
	 */
	public void setResultadoDiscagem_3_C7(String bit47ResDis_3_C7) {
		this.resultadoDiscagem_3_C7 = bit47ResDis_3_C7;
	}

	/**
	 * @return the bit47ResDis_3_C8
	 */
	@PositionalField(initialPosition= 424, finalPosition= 425)
	public String getResultadoDiscagem_3_C8() {
		return resultadoDiscagem_3_C8;
	}
	/**
	 * @param bit47ResDis_3_C8 the bit47ResDis_3_C8 to set
	 */
	public void setResultadoDiscagem_3_C8(String bit47ResDis_3_C8) {
		this.resultadoDiscagem_3_C8 = bit47ResDis_3_C8;
	}

	/**
	 * @return the bit47ResDis_3_C9
	 */
	@PositionalField(initialPosition= 426, finalPosition= 427)
	public String getResultadoDiscagem_3_C9() {
		return resultadoDiscagem_3_C9;
	}
	/**
	 * @param bit47ResDis_3_C9 the bit47ResDis_3_C9 to set
	 */
	public void setResultadoDiscagem_3_C9(String bit47ResDis_3_C9) {
		this.resultadoDiscagem_3_C9 = bit47ResDis_3_C9;
	}

	/**
	 * @return the bit47ResDis_3_C10
	 */
	@PositionalField(initialPosition= 428, finalPosition= 429)
	public String getResultadoDiscagem_3_C10() {
		return resultadoDiscagem_3_C10;
	}
	/**
	 * @param bit47ResDis_3_C10 the bit47ResDis_3_C10 to set
	 */
	public void setResultadoDiscagem_3_C10(String bit47ResDis_3_C10) {
		this.resultadoDiscagem_3_C10 = bit47ResDis_3_C10;
	}

	/**
	 * @return the filler
	 */
	@PositionalField(initialPosition= 430, finalPosition= 430)
	public String getFiller() {
		return filler;
	}
	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		this.filler = filler;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
