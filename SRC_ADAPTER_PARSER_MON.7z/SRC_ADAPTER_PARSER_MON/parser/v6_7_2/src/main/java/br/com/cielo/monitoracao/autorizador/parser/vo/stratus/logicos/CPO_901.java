package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator.DateHourCompleteDecorator;
import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator.Double12PosDecorator;
import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator.Double15PosDecorator;
import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator.Double4PosDecorator;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_901, sobre Dados de informações de transações DCC.
 * 
 * <DL><DT><B>Criada em:</B><DD>11/04/2014</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_901 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	public static Logger logger= LoggerFactory.getLogger(CPO_901.class);
	
	private String dccMoedaPortador;
	private String dccDescricaoMoeda;
	private double dccValorMarkup;
	private double dccPercentualMarkupPl;
	private String dccDigTransPortador;	
	private double dccTransMoedaPortador;
	private double dccTransMoedaDol;
	private String dccDigitoMoedaPortador;
	private String dccCotacaoMoedaPortador;
	private String dccDigitoCotacaoDol;
	private String dccCotacaoDolPl;
	private Date dccDataHoraCambioPl;	
	private String dccHoraAutorizacaoTransacao;
	private long dccTempoRespostaPlanet;
	private String filler;
	
	
	public CPO_901(){		
	}
	

	/**
	 * Representa o Campo STRATUS: ADIC-DCC-MOEDA-PORT
	 * 
	 * @return the dccMoedaPortador
	 */
	@PositionalField(initialPosition= 1, finalPosition= 3)
	public String getDccMoedaPortador() {
		return dccMoedaPortador;
	}
	/**
	 * @param dccMoedaPortador the dccMoedaPortador to set
	 */
	public void setDccMoedaPortador(String dccMoedaPortador) {
		this.dccMoedaPortador = dccMoedaPortador;
	}
	
	/**
	 * Representa o Campo STRATUS: ADIC-DCC-MOEDA-DESC
	 * 
	 * @return the dccDescricaoMoeda
	 */
	@PositionalField(initialPosition= 4, finalPosition= 6)
	public String getDccDescricaoMoeda() {
		return dccDescricaoMoeda;
	}
	/**
	 * @param dccDescricaoMoeda the dccDescricaoMoeda to set
	 */
	public void setDccDescricaoMoeda(String dccDescricaoMoeda) {
		this.dccDescricaoMoeda = dccDescricaoMoeda;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-DCC-VALOR-MARKUP
	 * 
	 * @return the dccValorMarkup
	 */
	@PositionalField(initialPosition= 7, finalPosition= 21, decorator= Double15PosDecorator.class)
	public double getDccValorMarkup() {
		return dccValorMarkup;
	}
	/**
	 * @param dccValorMarkup the dccValorMarkup to set
	 */
	public void setDccValorMarkup(double dccValorMarkup) {
		this.dccValorMarkup = dccValorMarkup;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-DCC-PERC-MARKUP-PL
	 * 
	 * @return the dccPercentualMarkupPl
	 */
	@PositionalField(initialPosition= 22, finalPosition= 25, decorator= Double4PosDecorator.class)
	public double getDccPercentualMarkupPl() {
		return dccPercentualMarkupPl;
	}
	/**
	 * @param dccPercentualMarkupPl the dccPercentualMarkupPl to set
	 */
	public void setDccPercentualMarkupPl(double dccPercentualMarkupPl) {
		this.dccPercentualMarkupPl = dccPercentualMarkupPl;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-DCC-DIG-TRANS-PORT
	 * 
	 * @return the dccDigTransPortador
	 */
	@PositionalField(initialPosition= 26, finalPosition= 26)
	public String getDccDigTransPortador() {
		return dccDigTransPortador;
	}
	/**
	 * @param dccDigTransPortador the dccDigTransPortador to set
	 */
	public void setDccDigTransPortador(String dccDigTransPortador) {
		this.dccDigTransPortador = dccDigTransPortador;
	}	

	/**
	 * Representa o Campo STRATUS: ADIC-DCC-TRANS-MOEDA-PORT-2
	 * 
	 * @return the dccTransMoedaPortador
	 */
	@PositionalField(initialPosition= 27, finalPosition= 38, decorator= Double12PosDecorator.class)
	public double getDccTransMoedaPortador() {
		return dccTransMoedaPortador;
	}
	/**
	 * @param dccTransMoedaPortador the dccTransMoedaPortador to set
	 */
	public void setDccTransMoedaPortador(double dccTransMoedaPortador) {
		this.dccTransMoedaPortador = dccTransMoedaPortador;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-DCC-TRANS-MOEDA-DOL
	 * 
	 * @return the dccTransMoedaDol
	 */
	@PositionalField(initialPosition= 39, finalPosition= 50, decorator= Double12PosDecorator.class)
	public double getDccTransMoedaDol() {
		return dccTransMoedaDol;
	}
	/**
	 * @param dccTransMoedaDol the dccTransMoedaDol to set
	 */
	public void setDccTransMoedaDol(double dccTransMoedaDol) {
		this.dccTransMoedaDol = dccTransMoedaDol;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-DCC-DIG-MOEDA-PORT
	 * 
	 * @return the dccDigitoMoedaPortador
	 */
	@PositionalField(initialPosition= 51, finalPosition=51)
	public String getDccDigitoMoedaPortador() {
		return dccDigitoMoedaPortador;
	}
	/**
	 * @param dccDigitoMoedaPortador the dccDigitoMoedaPortador to set
	 */
	public void setDccDigitoMoedaPortador(String dccDigitoMoedaPortador) {
		this.dccDigitoMoedaPortador = dccDigitoMoedaPortador;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-DCC-COT-MOEDA-PORT
	 * 
	 * @return the dccCotacaoMoedaPortador
	 */
	@PositionalField(initialPosition= 52, finalPosition= 58)
	public String getDccCotacaoMoedaPortador() {
		return dccCotacaoMoedaPortador;
	}
	/**
	 * @param dccCotacaoMoedaPortador the dccCotacaoMoedaPortador to set
	 */
	public void setDccCotacaoMoedaPortador(String dccCotacaoMoedaPortador) {
		this.dccCotacaoMoedaPortador = dccCotacaoMoedaPortador;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-DCC-DIG-COT-DOL
	 * 
	 * @return the dccDigitoCotacaoDol
	 */
	@PositionalField(initialPosition= 59, finalPosition= 59)
	public String getDccDigitoCotacaoDol() {
		return dccDigitoCotacaoDol;
	}
	/**
	 * @param dccDigitoCotacaoDol the dccDigitoCotacaoDol to set
	 */
	public void setDccDigitoCotacaoDol(String dccDigitoCotacaoDol) {
		this.dccDigitoCotacaoDol = dccDigitoCotacaoDol;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-DCC-COT-DOL-PL
	 * 
	 * @return the dccCotacaoDolPl
	 */
	@PositionalField(initialPosition= 60, finalPosition= 66)
	public String getDccCotacaoDolPl() {
		return dccCotacaoDolPl;
	}
	/**
	 * @param dccCotacaoDolPl the dccCotacaoDolPl to set
	 */
	public void setDccCotacaoDolPl(String dccCotacaoDolPl) {
		this.dccCotacaoDolPl = dccCotacaoDolPl;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-DCC-DT-CAMBIO-PL e ADIC-DCC-HR-CAMBIO-PL
	 * 
	 * @return the dccDataCambioPl
	 */
	@PositionalField(initialPosition= 67, finalPosition= 80, decorator= DateHourCompleteDecorator.class)
	public Date getDccDataHoraCambioPl() {
		return dccDataHoraCambioPl;
	}
	/**
	 * @param dccDataCambioPl the dccDataCambioPl to set
	 */
	public void setDccDataHoraCambioPl(Date dccDataHoraCambioPl) {
		this.dccDataHoraCambioPl = dccDataHoraCambioPl;
	}
	
	/**
	 * Representa o Campo STRATUS: ADIC-DCC-HR-AUTOR-TRANS
	 * 
	 * @return the dccHoraAutorizacaoTransacao
	 */
	@PositionalField(initialPosition= 81, finalPosition= 86)
	public String getDccHoraAutorizacaoTransacao() {	
		return dccHoraAutorizacaoTransacao;
	}
	/**
	 * @param dccHoraAutorizacaoTransacao the dccHoraAutorizacaoTransacao to set
	 */
	public void setDccHoraAutorizacaoTransacao(String dccHoraAutorizacaoTransacao) {
		String retorno= "";
		if(dccHoraAutorizacaoTransacao!=null && !dccHoraAutorizacaoTransacao.equals("")){
			retorno= dccHoraAutorizacaoTransacao.substring(0, 2)+":"+
					 dccHoraAutorizacaoTransacao.substring(2, 4)+":"+
					 dccHoraAutorizacaoTransacao.substring(4);
		}
		this.dccHoraAutorizacaoTransacao= retorno;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-DCC-TEMPO-RESP-PLANET
	 * 
	 * @return the dccTempoRespostaPlanet
	 */
	@PositionalField(initialPosition= 87, finalPosition= 91)
	public long getDccTempoRespostaPlanet() {
		return dccTempoRespostaPlanet;
	}
	/**
	 * @param dccTempoRespostaPlanet the dccTempoRespostaPlanet to set
	 */
	public void setDccTempoRespostaPlanet(String dccTempoRespostaPlanet) {
		try {
			this.dccTempoRespostaPlanet= Long.parseLong(dccTempoRespostaPlanet);
		} catch (NumberFormatException e) {
			this.dccTempoRespostaPlanet= 0;
			//logger.warn("Erro realizando parser no objeto [CPO_901], em campo Numerico[dccTempoRespostaPlanet]. Valor recebido= '"+dccTempoRespostaPlanet+"'");						
		}		
	}
	/**
	 * @param dccTempoRespostaPlanet the dccTempoRespostaPlanet to set
	 */
	public void setDccTempoRespostaPlanet(long dccTempoRespostaPlanet) {
		this.dccTempoRespostaPlanet = dccTempoRespostaPlanet;
	}

	/**
	 * Representa o Campo STRATUS: filler
	 *	 
	 * @return the filler
	 */
	@PositionalField(initialPosition= 92, finalPosition= 486)
	public String getFiller() {
		return filler;
	}
	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		this.filler = filler;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
