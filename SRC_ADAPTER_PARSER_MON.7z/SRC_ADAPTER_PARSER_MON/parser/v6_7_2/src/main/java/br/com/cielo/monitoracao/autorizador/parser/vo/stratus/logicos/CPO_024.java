package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator.DateDecorator;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;


/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_025, referente informações de Confirmação TEF 4.1.
 * 
 * <DL><DT><B>Criada em:</B><DD>19/12/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_024 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String quantidade;
	private String nsu1;
	private Date data1;
	private String nsu2;
	private Date data2;
	private String nsu3;
	private Date data3;
	private String nsu4;
	private Date data4;
	private String nsu5;
	private Date data5;
	
	
	public CPO_024(){		
	}
	
	/**	 
	 * Representa o Campo STRATUS: ACTR-CONF-41-QTD
	 * 
	 * @return the quantidade
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public String getQuantidade() {
		return quantidade;
	}
	/**
	 * @param quantidade the quantidade to set
	 */
	public void setQuantidade(String quantidade) {
		this.quantidade = quantidade;
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-CONF-41-NSU ocorrencia 1.
	 * 
	 * @return the nsu1
	 */
	@PositionalField(initialPosition= 3, finalPosition= 8)
	public String getNsu1() {
		return nsu1;
	}
	/**
	 * @param nsu1 the nsu1 to set
	 */
	public void setNsu1(String nsu1) {
		this.nsu1 = nsu1;
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-CONF-41-DATA ocorrencia 1.
	 * 
	 * @return the data1
	 */
	@PositionalField(initialPosition= 9, finalPosition= 14, decorator= DateDecorator.class)
	public Date getData1() {
		return data1;
	}
	/**
	 * @param data1 the data1 to set
	 */
	public void setData1(Date data1) {
		this.data1 = data1;
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-CONF-41-NSU ocorrencia 2.
	 * 
	 * @return the nsu2
	 */
	@PositionalField(initialPosition= 15, finalPosition= 20)
	public String getNsu2() {
		return nsu2;
	}
	/**
	 * @param nsu2 the nsu2 to set
	 */
	public void setNsu2(String nsu2) {
		this.nsu2 = nsu2;
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-CONF-41-DATA ocorrencia 2.
	 * 
	 * @return the data2
	 */
	@PositionalField(initialPosition= 21, finalPosition= 26, decorator= DateDecorator.class)
	public Date getData2() {
		return data2;
	}
	/**
	 * @param data2 the data2 to set
	 */
	public void setData2(Date data2) {
		this.data2 = data2;
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-CONF-41-NSU ocorrencia 3.
	 * 
	 * @return the nsu3
	 */
	@PositionalField(initialPosition= 27, finalPosition= 32)
	public String getNsu3() {
		return nsu3;
	}
	/**
	 * @param nsu3 the nsu3 to set
	 */
	public void setNsu3(String nsu3) {
		this.nsu3 = nsu3;
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-CONF-41-DATA ocorrencia 3.
	 * 
	 * @return the data3
	 */
	@PositionalField(initialPosition= 33, finalPosition= 38, decorator= DateDecorator.class)
	public Date getData3() {
		return data3;
	}
	/**
	 * @param data3 the data3 to set
	 */
	public void setData3(Date data3) {
		this.data3 = data3;
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-CONF-41-NSU ocorrencia 4.
	 * 
	 * @return the nsu4
	 */
	@PositionalField(initialPosition= 39, finalPosition= 44)
	public String getNsu4() {
		return nsu4;
	}
	/**
	 * @param nsu4 the nsu4 to set
	 */
	public void setNsu4(String nsu4) {
		this.nsu4 = nsu4;
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-CONF-41-DATA ocorrencia 4.
	 * 
	 * @return the data4
	 */
	@PositionalField(initialPosition= 45, finalPosition= 50, decorator= DateDecorator.class)
	public Date getData4() {
		return data4;
	}
	/**
	 * @param data4 the data4 to set
	 */
	public void setData4(Date data4) {
		this.data4 = data4;
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-CONF-41-NSU ocorrencia 5.
	 * 
	 * @return the nsu5
	 */
	@PositionalField(initialPosition= 51, finalPosition= 56)
	public String getNsu5() {
		return nsu5;
	}
	/**
	 * @param nsu5 the nsu5 to set
	 */
	public void setNsu5(String nsu5) {
		this.nsu5 = nsu5;
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-CONF-41-DATA ocorrencia 5.
	 * 
	 * @return the data5
	 */
	@PositionalField(initialPosition= 57, finalPosition= 62, decorator= DateDecorator.class)
	public Date getData5() {
		return data5;
	}
	/**
	 * @param data5 the data5 to set
	 */
	public void setData5(Date data5) {
		this.data5 = data5;
	}

	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
