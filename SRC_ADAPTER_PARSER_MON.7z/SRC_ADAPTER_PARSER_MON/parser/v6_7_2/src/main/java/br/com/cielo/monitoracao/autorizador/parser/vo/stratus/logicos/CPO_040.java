package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator.DateHourDecorator;
import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator.Double10PosDecorator;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_040, sobre Dados do xx.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_040 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	public static Logger logger= LoggerFactory.getLogger(CPO_040.class);
	
	/*private SimpleDateFormat dateHourFormat= new SimpleDateFormat("yyMMddHHmmss");*/
	
	private String checkOutTEF;
	private String monTecnologia;
	private String monCidade;
	private String monVersao;
	private Date monDataHoraTPS;
	private String apl02Via36;
	private String apl02Via36Qr;
	private String standIn;
	private String standInFlag;
	private String standInEmergencia;
	private String standInProgramado;
	private String standInTimeOut;
	private String standInQueda;
	private double valorCC;
	private String bandeira;
	private String bancoLiquidante;
	private String liquidanteGradeBandeira;
	private String bancoEmissor;
	private String bandeiraTerminal;
	private String eCommerceDe48;
	private String mRcanc;
	private String terminalCodigoNoSec;
	private String codigoAcao;
	private String checkValueTransacoesMaestro;
	private String usoFuturo;
	
	
	public CPO_040(){		
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-CKECK-OUT-TEF
	 *
	 * @return the checkOutTEF
	 */
	@PositionalField(initialPosition= 1, finalPosition= 10)
	public String getCheckOutTEF() {
		return checkOutTEF;
	}

	/**
	 * @param checkOutTEF the checkOutTEF to set
	 */
	public void setCheckOutTEF(String checkOutTEF) {
		this.checkOutTEF = checkOutTEF;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-MON-TECN 
	 *
	 * @return the monTecnologia
	 */
	@PositionalField(initialPosition= 11, finalPosition= 12)
	public String getMonTecnologia() {
		return monTecnologia;
	}

	/**
	 * @param monTecnologia the monTecnologia to set
	 */
	public void setMonTecnologia(String monTecnologia) {
		this.monTecnologia = monTecnologia;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-MON-CIDADE
	 *
	 * @return the monCidade
	 */
	@PositionalField(initialPosition= 13, finalPosition= 27)
	public String getMonCidade() {
		return monCidade;
	}

	/**
	 * @param monCidade the monCidade to set
	 */
	public void setMonCidade(String monCidade) {
		this.monCidade = monCidade;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-MON-VERSAO
	 *
	 * @return the monVersao
	 */
	@PositionalField(initialPosition= 28, finalPosition= 38)
	public String getMonVersao() {
		return monVersao;
	}

	/**
	 * @param monVersao the monVersao to set
	 */
	public void setMonVersao(String monVersao) {
		this.monVersao = monVersao;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-MON-DATA-TPS  e ACTR-MON-HORA-TPS
	 *
	 * @return the monDataHoraTPS
	 */
	@PositionalField(initialPosition= 39, finalPosition= 50, decorator= DateHourDecorator.class)
	public Date getMonDataHoraTPS() {
		return monDataHoraTPS;
	}
	/**
	 * @param monDataHoraTPS the monDataHoraTPS to set
	 */
	/*public void setMonDataHoraTPS(String monDataHoraTPS) {		
		try {
			this.monDataHoraTPS = dateHourFormat.parse(monDataHoraTPS);
		} catch (ParseException e) {
			this.monDataHoraTPS = new Date();
			logger.warn("Erro realizando parser no objeto [CPO_040], em campo data[monDataHoraTPS]. Valor recebido= '"+monDataHoraTPS+"'");			
		}
	}*/
	/**
	 * @param monDataHoraTPS the monDataHoraTPS to set
	 */
	public void setMonDataHoraTPS(Date monDataHoraTPS) {
		this.monDataHoraTPS = monDataHoraTPS;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-APL-02-VIA-36
	 *
	 * @return the apl02Via36
	 */
	@PositionalField(initialPosition= 51, finalPosition= 51)
	public String getApl02Via36() {
		return apl02Via36;
	}

	/**
	 * @param apl02Via36 the apl02Via36 to set
	 */
	public void setApl02Via36(String apl02Via36) {
		this.apl02Via36 = apl02Via36;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-APL-02-VIA-36-QR
	 *
	 * @return the apl02Via36Qr
	 */
	@PositionalField(initialPosition= 52, finalPosition= 53)
	public String getApl02Via36Qr() {
		return apl02Via36Qr;
	}

	/**
	 * @param apl02Via36Qr the apl02Via36Qr to set
	 */
	public void setApl02Via36Qr(String apl02Via36Qr) {
		this.apl02Via36Qr = apl02Via36Qr;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-STAND-IN 
	 *
	 * @return the standIn
	 */
	@PositionalField(initialPosition= 54, finalPosition= 54)
	public String getStandIn() {
		return standIn;
	}

	/**
	 * @param standIn the standIn to set
	 */
	public void setStandIn(String standIn) {
		this.standIn = standIn;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-STAND-IN-FLAG
	 *
	 * @return the standInFlag
	 */
	@PositionalField(initialPosition= 55, finalPosition= 55)
	public String getStandInFlag() {
		return standInFlag;
	}

	/**
	 * @param standInFlag the standInFlag to set
	 */
	public void setStandInFlag(String standInFlag) {
		this.standInFlag = standInFlag;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-STAND-IN-EMERGENCIA
	 *
	 * @return the standInEmergencia
	 */
	@PositionalField(initialPosition= 56, finalPosition= 56)
	public String getStandInEmergencia() {
		return standInEmergencia;
	}

	/**
	 * @param standInEmergencia the standInEmergencia to set
	 */
	public void setStandInEmergencia(String standInEmergencia) {
		this.standInEmergencia = standInEmergencia;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-STAND-IN-PROGRAMADO
	 *
	 * @return the standInProgramado
	 */
	@PositionalField(initialPosition= 57, finalPosition= 57)
	public String getStandInProgramado() {
		return standInProgramado;
	}

	/**
	 * @param standInProgramado the standInProgramado to set
	 */
	public void setStandInProgramado(String standInProgramado) {
		this.standInProgramado = standInProgramado;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-STAND-IN-TIME-OUT
	 *
	 * @return the standInTimeOut
	 */
	@PositionalField(initialPosition= 58, finalPosition= 58)
	public String getStandInTimeOut() {
		return standInTimeOut;
	}

	/**
	 * @param standInTimeOut the standInTimeOut to set
	 */
	public void setStandInTimeOut(String standInTimeOut) {
		this.standInTimeOut = standInTimeOut;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-STAND-IN-QUEDA
	 *
	 * @return the standInQueda
	 */
	@PositionalField(initialPosition= 59, finalPosition= 59)
	public String getStandInQueda() {
		return standInQueda;
	}

	/**
	 * @param standInQueda the standInQueda to set
	 */
	public void setStandInQueda(String standInQueda) {
		this.standInQueda = standInQueda;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-VALOR-CC
	 *
	 * @return the valorCC
	 */
	@PositionalField(initialPosition= 60, finalPosition= 69, decorator= Double10PosDecorator.class)
	public double getValorCC() {
		return valorCC;
	}
	/**
	 * @param valorCC the valorCC to set
	 */
	/*public void setValorCC(String valorCC) {		
		String valFi= valorCC.substring(0, 8)+"."+valorCC.substring(10);		
		try {
			this.valorCC = Double.parseDouble(valFi);
		} catch (NumberFormatException e) {
			this.valorCC= 0;
			logger.warn("Erro realizando parser no objeto [CPO_040], em campo numerico[valorCC]. Valor recebido= '"+valorCC+"'");			
		}	
	}*/

	/**
	 * @param valorCC the valorCC to set
	 */
	public void setValorCC(double valorCC) {
		this.valorCC = valorCC;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-BANDEIRA 
	 * 
	 * BANDEIRA 001 - VISA / 002 - MASTER
	 *
	 * @return the bandeira
	 */
	@PositionalField(initialPosition= 70, finalPosition= 72)
	public String getBandeira() {
		return bandeira;
	}

	/**
	 * @param bandeira the bandeira to set
	 */
	public void setBandeira(String bandeira) {
		this.bandeira = bandeira;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-BCO-LIQ
	 *
	 * @return the bancoLiquidante
	 */
	@PositionalField(initialPosition= 73, finalPosition= 75)
	public String getBancoLiquidante() {
		return bancoLiquidante;
	}

	/**
	 * @param bancoLiquidante the bancoLiquidante to set
	 */
	public void setBancoLiquidante(String bancoLiquidante) {
		this.bancoLiquidante = bancoLiquidante;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-LIQ-GRAD-BAND
	 * 
	 * G = GRADE  B = BANDEIRA
	 *
	 * @return the liquidanteGradeBandeira
	 */
	@PositionalField(initialPosition= 76, finalPosition= 76)
	public String getLiquidanteGradeBandeira() {
		return liquidanteGradeBandeira;
	}

	/**
	 * @param liquidanteGradeBandeira the liquidanteGradeBandeira to set
	 */
	public void setLiquidanteGradeBandeira(String liquidanteGradeBandeira) {
		this.liquidanteGradeBandeira = liquidanteGradeBandeira;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-BCO-EMI
	 *
	 * @return the bancoEmissor
	 */
	@PositionalField(initialPosition= 77, finalPosition= 79)
	public String getBancoEmissor() {
		return bancoEmissor;
	}

	/**
	 * @param bancoEmissor the bancoEmissor to set
	 */
	public void setBancoEmissor(String bancoEmissor) {
		this.bancoEmissor = bancoEmissor;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-BANDEIRA-TERMINAL
	 *
	 * @return the bandeiraTerminal
	 */
	@PositionalField(initialPosition= 80, finalPosition= 82)
	public String getBandeiraTerminal() {
		return bandeiraTerminal;
	}

	/**
	 * @param bandeiraTerminal the bandeiraTerminal to set
	 */
	public void setBandeiraTerminal(String bandeiraTerminal) {
		this.bandeiraTerminal = bandeiraTerminal;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-E-COMMERCE-DE48
	 *
	 * @return the eCommerceDe48
	 */
	@PositionalField(initialPosition= 83, finalPosition= 85)
	public String geteCommerceDe48() {
		return eCommerceDe48;
	}

	/**
	 * @param eCommerceDe48 the eCommerceDe48 to set
	 */
	public void seteCommerceDe48(String eCommerceDe48) {
		this.eCommerceDe48 = eCommerceDe48;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-M-RCANC
	 *
	 * @return the mRcanc
	 */
	@PositionalField(initialPosition= 86, finalPosition= 86)
	public String getmRcanc() {
		return mRcanc;
	}

	/**
	 * @param mRcanc the mRcanc to set
	 */
	public void setmRcanc(String mRcanc) {
		this.mRcanc = mRcanc;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-TERM-COD-NO-SEC
	 *
	 * @return the terminalCodigoNoSec
	 */
	@PositionalField(initialPosition= 87, finalPosition= 91)
	public String getTerminalCodigoNoSec() {
		return terminalCodigoNoSec;
	}

	/**
	 * @param terminalCodigoNoSec the terminalCodigoNoSec to set
	 */
	public void setTerminalCodigoNoSec(String terminalCodigoNoSec) {
		this.terminalCodigoNoSec = terminalCodigoNoSec;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-CODIGO-ACAO
	 * 
	 * CODIGO DE ACAO USADO PARA PREENCHER O ULTIMO
	 *                  BYTE
	 *                  DO CODIGO DE PROCESSAMENTO DA VERSAO 30.
	 *                  EXEMPLO DE USO: 4 - FORCAR TELECARGA
	 *                  PARA MAIORES DETALHES VEJA A DOCUMENTACAO DA
	 *                  V30, CAMPO 3
	 *
	 * @return the codigoAcao
	 */
	@PositionalField(initialPosition= 92, finalPosition= 92)
	public String getCodigoAcao() {
		return codigoAcao;
	}

	/**
	 * @param codigoAcao the codigoAcao to set
	 */
	public void setCodigoAcao(String codigoAcao) {
		this.codigoAcao = codigoAcao;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-CHECK-VALUE-MC
	 *
	 * @return the checkValueTransacoesMaestro
	 */
	@PositionalField(initialPosition= 93, finalPosition= 96)
	public String getCheckValueTransacoesMaestro() {
		return checkValueTransacoesMaestro;
	}

	/**
	 * @param checkValueTransacoesMaestro the checkValueTransacoesMaestro to set
	 */
	public void setCheckValueTransacoesMaestro(String checkValueTransacoesMaestro) {
		this.checkValueTransacoesMaestro = checkValueTransacoesMaestro;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-USO-FUTURO
	 *
	 * @return the usoFuturo
	 */
	@PositionalField(initialPosition= 97, finalPosition= 99)
	public String getUsoFuturo() {
		return usoFuturo;
	}
	/**
	 * @param usoFuturo the usoFuturo to set
	 */
	public void setUsoFuturo(String usoFuturo) {
		this.usoFuturo = usoFuturo;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
