package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_025, sobre Dados do xx.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_025 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String bit62TamCart06;
	private String bit62DisCart06;
	private String bit62TamRes06;
	private String bit62ReseMiss06;
	private String filler;
	
	public CPO_025(){		
	}

	/**
	 * @return the bit62TamCart06
	 */
	@PositionalField(initialPosition= 1, finalPosition= 4)
	public String getBit62TamCart06() {
		return bit62TamCart06;
	}

	/**
	 * @param bit62TamCart06 the bit62TamCart06 to set
	 */
	public void setBit62TamCart06(String bit62TamCart06) {
		this.bit62TamCart06 = bit62TamCart06;
	}

	/**
	 * @return the bit62DisCart06
	 */
	@PositionalField(initialPosition= 5, finalPosition= 34)
	public String getBit62DisCart06() {
		return bit62DisCart06;
	}

	/**
	 * @param bit62DisCart06 the bit62DisCart06 to set
	 */
	public void setBit62DisCart06(String bit62DisCart06) {
		this.bit62DisCart06 = bit62DisCart06;
	}

	/**
	 * @return the bit62TamRes06
	 */
	@PositionalField(initialPosition= 35, finalPosition= 38)
	public String getBit62TamRes06() {
		return bit62TamRes06;
	}

	/**
	 * @param bit62TamRes06 the bit62TamRes06 to set
	 */
	public void setBit62TamRes06(String bit62TamRes06) {
		this.bit62TamRes06 = bit62TamRes06;
	}

	/**
	 * @return the bit62ReseMiss06
	 */
	@PositionalField(initialPosition= 39, finalPosition= 78)
	public String getBit62ReseMiss06() {
		return bit62ReseMiss06;
	}

	/**
	 * @param bit62ReseMiss06 the bit62ReseMiss06 to set
	 */
	public void setBit62ReseMiss06(String bit62ReseMiss06) {
		this.bit62ReseMiss06 = bit62ReseMiss06;
	}

	/**
	 * @return the filler
	 */
	@PositionalField(initialPosition= 79, finalPosition= 94)
	public String getFiller() {
		return filler;
	}

	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		this.filler = filler;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
