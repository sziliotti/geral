package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_074, sobre Dados de Subproduto e indicador de display Grafico.
 * 
 * @author ziliotti
 *
 */
@PositionalRecord
public class CPO_074 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String displayGrafico;
	private String produtoSecundario;
	
	public CPO_074(){		
	}

	/**	 
	 * Representa o Campo STRATUS: ACTR-DISPLAY-GRAFICO
	 * 
	 * @return the displayGrafico
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public String getDisplayGrafico() {
		return displayGrafico;
	}

	/**
	 * @param displayGrafico the displayGrafico to set
	 */
	public void setDisplayGrafico(String displayGrafico) {
		this.displayGrafico = displayGrafico;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-PRODUTO-SECUNDARIO
	 * 
	 * @return the produtoSecundario
	 */
	@PositionalField(initialPosition= 3, finalPosition= 6)
	public String getProdutoSecundario() {
		return produtoSecundario;
	}

	/**
	 * @param produtoSecundario the produtoSecundario to set
	 */
	public void setProdutoSecundario(String produtoSecundario) {
		this.produtoSecundario = produtoSecundario;
	}
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
