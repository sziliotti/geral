package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_027, sobre Dados de Resposta.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_027 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String codigoResposta;
	private String observacao;
	private String mensagem;
	private String codigoAut;
	private String quemRespondeu;
	private String complementoCodigoResposta;
	
	public CPO_027(){		
	}

	/**	   
	 * Representa o Campo STRATUS: ACTR-CODRES
	 *
	 * @return the codigoResposta
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public String getCodigoResposta() {
		return codigoResposta;
	}

	/**
	 * @param codigoResposta the codigoResposta to set
	 */
	public void setCodigoResposta(String codigoResposta) {
		this.codigoResposta = codigoResposta;
	}

	/**	   
	 * Representa o Campo STRATUS: ACTR-OBS
	 *
	 * @return the observacao
	 */
	@PositionalField(initialPosition= 3, finalPosition= 5)
	public String getObservacao() {
		return observacao;
	}

	/**
	 * @param observacao the observacao to set
	 */
	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	/**	   
	 * Representa o Campo STRATUS: ACTR-MSG
	 *
	 * @return the mensagem
	 */
	@PositionalField(initialPosition= 6, finalPosition= 45)
	public String getMensagem() {
		return mensagem;
	}

	/**
	 * @param mensagem the mensagem to set
	 */
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	/**	   
	 * Representa o Campo STRATUS: ACTR-CODAUT
	 *
	 * @return the codigoAut
	 */
	@PositionalField(initialPosition= 46, finalPosition= 51)
	public String getCodigoAut() {
		return codigoAut;
	}

	/**
	 * @param codigoAut the codigoAut to set
	 */
	public void setCodigoAut(String codigoAut) {
		this.codigoAut = codigoAut;
	}

	/**	   
	 * Representa o Campo STRATUS: ACTR-QUEMRESP
	 *
	 * @return the quemRespondeu
	 */
	@PositionalField(initialPosition= 52, finalPosition= 53)
	public String getQuemRespondeu() {
		return quemRespondeu;
	}

	/**
	 * @param quemRespondeu the quemRespondeu to set
	 */
	public void setQuemRespondeu(String quemRespondeu) {
		this.quemRespondeu = quemRespondeu;
	}

	/**	   
	 * Representa o Campo STRATUS: ACTR-CODRES-COMPLEMENTO
	 *
	 * @return the complementoCodigoResposta
	 */
	@PositionalField(initialPosition= 54, finalPosition= 54)
	public String getComplementoCodigoResposta() {
		return complementoCodigoResposta;
	}

	/**
	 * @param complementoCodigoResposta the complementoCodigoResposta to set
	 */
	public void setComplementoCodigoResposta(String complementoCodigoResposta) {
		this.complementoCodigoResposta = complementoCodigoResposta;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
