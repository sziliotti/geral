package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 *
 * Objeto referente ao campo CPO_913.
 *
 * <DL><DT><B>Criada em:</B><DD>27/11/2014</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @author Nemer Daud
 * @version 2.0
 *
 *
 *
 * CAMPO                TAM     INI     FIM
GEN-DDD                 2	1	2
GEN-NUM-CEL             10	3	12
GEN-CANAL               2	13	14
GEN-IND-AUT-PARC	1	15	15
GEN-COD-VENDA           15	16	30
GEN-ESTAB-VAREJO	10	31	40
GEN-IND-VERDE           1	41	41
GEN-TCB55-TAM-FORMFACT	2	42	43
GEN-TCB55-FORMFACT	64	44	107
GEN-PRD-MTZ-UNICO	4	108	111
GEN-PRD-SEC-UNICO	4	112	115
GEN-REDE-VAN            3	116	118
GEN-EC-VAN              18	119	136
GEN-IND-MASTER-PASS	3	137	139
GEN-CARD-TYPE           3	140	142
GEN-NSU-REF-REDE	12	143	154
GEN-NII-HIPER           4	155	158
GEN-CRIPT-REDE-VAN	12	159	170
GEN-BIT-INCORRETO	3	171	173
GEN-CPO007-ORIGINAL	12	174	185
GEN-NUM-DESF            1	186	186
GEN-TCB62-DAD-EMISS	64	187	250
GEN-BINACQ-VISA         11	251	261
GEN-TIPTRA-ORIG	        3	262	264
GEN-IND-PAG-TRIB	1	265	265
GEN-IND-ENV-CNPJ	1	266	266
GEN-TCB55-TAM-NOMEEC	3	267	269
GEN-TCB55-NOMEEC	64	270	333
GEN-TOKEN-FLAG	        1	334	334
GEN-TOKEN-FPAN	        19	335	353
GEN-TOKEN-REQ-ID	11	354	364
GEN-TOKEN-ASS-LVL	2	365	366
GEN-IND-NOVO-RELPOS	1	367	367
---> NOVOS - MPOS
GEN-ASSINATURA-P22      1       368     368
GEN-TIPO-LIQU           1       369     369
GEN-BIT22               12      370     381
GEN-NUM-CELULAR-SMS     11      382     392  
 *
 */
@PositionalRecord
public class CPO_913 extends CampoLogicoVO implements Serializable {

    private static final long serialVersionUID = 1L;

    private String ddd;
    private String numeroCelular;
    private String canal;
    private String flagIndicativoAutorizacaoParcial;
    private String codigoVenda;
    private String estabelecimentoVarejo;
    private String indicadoVerde;
    private String tcb55TamanhoFormfact;
    private String tcb55Formfact;

    private String ProdMtzUnico;
    private String ProdSecUnico;
    private String RedeVan;
    private String ecVan;

    private String indMasterPass;
    private String cardType;
    private String nsuRefRede;
    private String niiHiper;
    private String criptRedeVan;
    private String bitIncorreto;
    private String cpo007Original;
    private String numDesf;
    private String tcb62DadEmiss;
    private String binAcqVisa;
    private String tipTraOrig;
    private String indPagTrib;
    private String indEnvCNPJ;
    private String tcb55TamNomEEC;
    private String tcb55NomEEC;
    private String tokenFlag;
    private String tokenFPan;
    private String tokenReqID;
    private String tokenAssLVL;
    private String indNovoRelPos;
    private String assinaturaP22;
    private String tipoLiquidacao;
    private String bit22;
    private String numeroCelularSms;

    public CPO_913() {
    }

    /**
     * Representa o Campo STRATUS: GEN-DDD
     *
     * @return the ddd
     */
    @PositionalField(initialPosition = 1, finalPosition = 2)
    public String getDdd() {
        return ddd;
    }

    /**
     * @param ddd the ddd to set
     */
    public void setDdd(String ddd) {
        this.ddd = ddd;
    }

    /**
     * Representa o Campo STRATUS: GEN-NUM-CEL
     *
     * @return the numeroCelular
     */
    @PositionalField(initialPosition = 3, finalPosition = 12)
    public String getNumeroCelular() {
        return numeroCelular;
    }

    /**
     * @param numeroCelular the numeroCelular to set
     */
    public void setNumeroCelular(String numeroCelular) {
        this.numeroCelular = numeroCelular;
    }

    /**
     * Representa o Campo STRATUS: GEN-CANAL
     *
     * @return the canal
     */
    @PositionalField(initialPosition = 13, finalPosition = 14)
    public String getCanal() {
        return canal;
    }

    /**
     * @param canal the canal to set
     */
    public void setCanal(String canal) {
        this.canal = canal;
    }

    /**
     * Representa o Campo STRATUS: GEN-IND-AUT-PARC
     *
     * @return the flagIndicativoAutorizacaoParcial
     */
    @PositionalField(initialPosition = 15, finalPosition = 15)
    public String getFlagIndicativoAutorizacaoParcial() {
        return flagIndicativoAutorizacaoParcial;
    }

    /**
     * @param flagIndicativoAutorizacaoParcial the
     * flagIndicativoAutorizacaoParcial to set
     */
    public void setFlagIndicativoAutorizacaoParcial(
            String flagIndicativoAutorizacaoParcial) {
        this.flagIndicativoAutorizacaoParcial = flagIndicativoAutorizacaoParcial;
    }

    /**
     * Representa o Campo STRATUS: GEN-COD-VENDA
     *
     * @return the codigoVenda
     */
    @PositionalField(initialPosition = 16, finalPosition = 30)
    public String getCodigoVenda() {
        return codigoVenda;
    }

    /**
     * @param codigoVenda the codigoVenda to set
     */
    public void setCodigoVenda(String codigoVenda) {
        this.codigoVenda = codigoVenda;
    }

    /**
     * Representa o Campo STRATUS: GEN-ESTAB-VAREJO
     *
     * @return the estabelecimentoVarejo
     */
    @PositionalField(initialPosition = 31, finalPosition = 40)
    public String getEstabelecimentoVarejo() {
        return estabelecimentoVarejo;
    }

    /**
     * @param estabelecimentoVarejo the estabelecimentoVarejo to set
     */
    public void setEstabelecimentoVarejo(String estabelecimentoVarejo) {
        this.estabelecimentoVarejo = estabelecimentoVarejo;
    }

    /**
     * Representa o Campo STRATUS: GEN-IND-VERDE
     *
     * @return the indicadoVerde
     */
    @PositionalField(initialPosition = 41, finalPosition = 41)
    public String getIndicadoVerde() {
        return indicadoVerde;
    }

    /**
     * @param indicadoVerde the indicadoVerde to set
     */
    public void setIndicadoVerde(String indicadoVerde) {
        this.indicadoVerde = indicadoVerde;
    }

    /**
     * Representa o Campo STRATUS: GEN-TCB55-TAM-FORMFACT
     *
     * @return the tcb55TamanhoFormfact
     */
    @PositionalField(initialPosition = 42, finalPosition = 43)
    public String getTcb55TamanhoFormfact() {
        return tcb55TamanhoFormfact;
    }

    /**
     * @param tcb55TamanhoFormfact the tcb55TamanhoFormfact to set
     */
    public void setTcb55TamanhoFormfact(String tcb55TamanhoFormfact) {
        this.tcb55TamanhoFormfact = tcb55TamanhoFormfact;
    }

    /**
     * Representa o Campo STRATUS: GEN-TCB55-FORMFACT
     *
     * @return the tcb55Formfact
     */
    @PositionalField(initialPosition = 44, finalPosition = 107)
    public String getTcb55Formfact() {
        return tcb55Formfact;
    }

    /**
     * @param tcb55Formfact the tcb55Formfact to set
     */
    public void setTcb55Formfact(String tcb55Formfact) {
        this.tcb55Formfact = tcb55Formfact;
    }

    /**
     * Representa o Campo STRATUS: GEN-PRD-MTZ-UNICO
     *
     * @return the ProdMtzUnico
     */
    @PositionalField(initialPosition = 108, finalPosition = 111)
    public String getProdMtzUnico() {
        return ProdMtzUnico;
    }

    public void setProdMtzUnico(String ProdMtzUnico) {
        this.ProdMtzUnico = ProdMtzUnico;
    }

    /**
     * Representa o Campo STRATUS: GEN-PRD-SEC-UNICO
     *
     * @return the ProdSecUnico
     */
    @PositionalField(initialPosition = 112, finalPosition = 115)
    public String getProdSecUnico() {
        return ProdSecUnico;
    }

    public void setProdSecUnico(String ProdSecUnico) {
        this.ProdSecUnico = ProdSecUnico;
    }

    /**
     * Representa o Campo STRATUS: GEN-REDE-VAN
     *
     * @return the codRedeVan
     */
    @PositionalField(initialPosition = 116, finalPosition = 118)
    public String getRedeVan() {
        return RedeVan;
    }

    public void setRedeVan(String RedeVan) {
        this.RedeVan = RedeVan;
    }

    /**
     * Representa o Campo STRATUS: GEN-EC-VAN
     *
     * @return the ecVan
     */
    @PositionalField(initialPosition = 119, finalPosition = 136)
    public String getEcVan() {
        return ecVan;
    }

    public void setEcVan(String ecVan) {
        this.ecVan = ecVan;
    }

    /**
     * Representa o Campo STRATUS: GEN-IND-MASTER-PASS
     *
     * @return
     */
    @PositionalField(initialPosition = 137, finalPosition = 139)
    public String getIndMasterPass() {
        return indMasterPass;
    }

    public void setIndMasterPass(String indMasterPass) {
        this.indMasterPass = indMasterPass;
    }

    /**
     * Representa o Campo STRATUS: GEN-CARD-TYPE
     *
     * @return
     */
    @PositionalField(initialPosition = 140, finalPosition = 142)
    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    /**
     * Representa o Campo STRATUS: GEN-NSU-REF-REDE
     *
     * @return
     */
    @PositionalField(initialPosition = 143, finalPosition = 154)
    public String getNsuRefRede() {
        return nsuRefRede;
    }

    public void setNsuRefRede(String nsuRefRede) {
        this.nsuRefRede = nsuRefRede;
    }

    /**
     * Representa o Campo STRATUS: GEN-NII-HIPER
     *
     * @return
     */
    @PositionalField(initialPosition = 155, finalPosition = 158)
    public String getNiiHiper() {
        return niiHiper;
    }

    public void setNiiHiper(String niiHiper) {
        this.niiHiper = niiHiper;
    }

    /**
     * Representa o Campo STRATUS: GEN-CRIPT-REDE-VAN
     *
     * @return
     */
    @PositionalField(initialPosition = 159, finalPosition = 170)
    public String getCriptRedeVan() {
        return criptRedeVan;
    }

    public void setCriptRedeVan(String criptRedeVan) {
        this.criptRedeVan = criptRedeVan;
    }

    /**
     * Representa o Campo STRATUS: GEN-BIT-INCORRETO
     *
     * @return
     */
    @PositionalField(initialPosition = 171, finalPosition = 173)
    public String getBitIncorreto() {
        return bitIncorreto;
    }

    public void setBitIncorreto(String bitIncorreto) {
        this.bitIncorreto = bitIncorreto;
    }

    /**
     * Representa o Campo STRATUS: GEN-CPO007-ORIGINAL
     *
     * @return
     */
    @PositionalField(initialPosition = 174, finalPosition = 185)
    public String getCpo007Original() {
        return cpo007Original;
    }

    public void setCpo007Original(String cpo007Original) {
        this.cpo007Original = cpo007Original;
    }

    /**
     * Representa o Campo STRATUS: GEN-NUM-DESF
     *
     * @return
     */
    @PositionalField(initialPosition = 186, finalPosition = 186)
    public String getNumDesf() {
        return numDesf;
    }

    public void setNumDesf(String numDesf) {
        this.numDesf = numDesf;
    }

    /**
     * Representa o Campo STRATUS: GEN-TCB62-DAD-EMISS
     *
     * @return
     */
    @PositionalField(initialPosition = 187, finalPosition = 250)
    public String getTcb62DadEmiss() {
        return tcb62DadEmiss;
    }

    public void setTcb62DadEmiss(String tcb62DadEmiss) {
        this.tcb62DadEmiss = tcb62DadEmiss;
    }

    /**
     * Representa o Campo STRATUS: GEN-BINACQ-VISA
     *
     * @return
     */
    @PositionalField(initialPosition = 251, finalPosition = 261)
    public String getBinAcqVisa() {
        return binAcqVisa;
    }

    public void setBinAcqVisa(String binAcqVisa) {
        this.binAcqVisa = binAcqVisa;
    }

    /**
     * Representa o Campo STRATUS: GEN-TIPTRA-ORIG
     *
     * @return
     */
    @PositionalField(initialPosition = 262, finalPosition = 264)
    public String getTipTraOrig() {
        return tipTraOrig;
    }

    public void setTipTraOrig(String tipTraOrig) {
        this.tipTraOrig = tipTraOrig;
    }

    /**
     * Representa o Campo STRATUS: GEN-IND-PAG-TRIB
     *
     * @return
     */
    @PositionalField(initialPosition = 265, finalPosition = 265)
    public String getIndPagTrib() {
        return indPagTrib;
    }

    public void setIndPagTrib(String indPagTrib) {
        this.indPagTrib = indPagTrib;
    }

    /**
     * Representa o Campo STRATUS: GEN-IND-ENV-CNPJ
     *
     * @return
     */
    @PositionalField(initialPosition = 266, finalPosition = 266)
    public String getIndEnvCNPJ() {
        return indEnvCNPJ;
    }

    public void setIndEnvCNPJ(String indEnvCNPJ) {
        this.indEnvCNPJ = indEnvCNPJ;
    }

    /**
     * Representa o Campo STRATUS: GEN-TCB55-TAM-NOMEEC
     *
     * @return
     */
    @PositionalField(initialPosition = 267, finalPosition = 269)
    public String getTcb55TamNomEEC() {
        return tcb55TamNomEEC;
    }

    public void setTcb55TamNomEEC(String tcb55TamNomEEC) {
        this.tcb55TamNomEEC = tcb55TamNomEEC;
    }

    /**
     * Representa o Campo STRATUS: GEN-TCB55-NOMEEC
     *
     * @return
     */
    @PositionalField(initialPosition = 270, finalPosition = 333)
    public String getTcb55NomEEC() {
        return tcb55NomEEC;
    }

    public void setTcb55NomEEC(String tcb55NomEEC) {
        this.tcb55NomEEC = tcb55NomEEC;
    }

    /**
     * Representa o Campo STRATUS: GEN-TOKEN-FLAG
     *
     * @return
     */
    @PositionalField(initialPosition = 334, finalPosition = 334)
    public String getTokenFlag() {
        return tokenFlag;
    }

    public void setTokenFlag(String tokenFlag) {
        this.tokenFlag = tokenFlag;
    }

    /**
     * Representa o Campo STRATUS: GEN-TOKEN-FPAN
     *
     * @return
     */
    @PositionalField(initialPosition = 335, finalPosition = 353)
    public String getTokenFPan() {
        return tokenFPan;
    }

    public void setTokenFPan(String tokenFPan) {
        this.tokenFPan = tokenFPan;
    }

    /**
     * Representa o Campo STRATUS: GEN-TOKEN-REQ-ID
     *
     * @return
     */
    @PositionalField(initialPosition = 354, finalPosition = 364)
    public String getTokenReqID() {
        return tokenReqID;
    }

    public void setTokenReqID(String tokenReqID) {
        this.tokenReqID = tokenReqID;
    }

    /**
     * Representa o Campo STRATUS: GEN-TOKEN-ASS-LVL
     *
     * @return
     */
    @PositionalField(initialPosition = 365, finalPosition = 366)
    public String getTokenAssLVL() {
        return tokenAssLVL;
    }

    public void setTokenAssLVL(String tokenAssLVL) {
        this.tokenAssLVL = tokenAssLVL;
    }

    /**
     * Representa o Campo STRATUS: GEN-IND-NOVO-RELPOS
     *
     * @return
     */
    @PositionalField(initialPosition = 367, finalPosition = 367)
    public String getIndNovoRelPos() {
        return indNovoRelPos;
    }

    public void setIndNovoRelPos(String indNovoRelPos) {
        this.indNovoRelPos = indNovoRelPos;
    }
    
     /**
     * Representa o Campo STRATUS: GEN-ASSINATURA-P22
     *
     * @return
     */
    @PositionalField(initialPosition = 368, finalPosition = 368)
    public String getAssinaturaP22() {
        return assinaturaP22;
    }

    public void setAssinaturaP22(String assinaturaP22) {
        this.assinaturaP22 = assinaturaP22;
    }

     /**
     * Representa o Campo STRATUS: GEN-TIPO-LIQU 
     *
     * @return
     */
    @PositionalField(initialPosition = 369, finalPosition = 369)
    public String getTipoLiquidacao() {
        return tipoLiquidacao;
    }

    public void setTipoLiquidacao(String tipoLiquidacao) {
        this.tipoLiquidacao = tipoLiquidacao;
    }

    /**
     * Representa o Campo STRATUS: GEN-BIT22 
     *
     * @return
     */
    @PositionalField(initialPosition = 370, finalPosition = 381)
    public String getBit22() {
        return bit22;
    }

    public void setBit22(String bit22) {
        this.bit22 = bit22;
    }
    
    /**
     * Representa o Campo STRATUS: GEN-NUM-CELULAR-SMS 
     *
     * @return
     */
    @PositionalField(initialPosition = 382, finalPosition = 392)
    public String getNumeroCelularSms() {
        return numeroCelularSms;
    }

    public void setNumeroCelularSms(String numeroCelularSms) {
        this.numeroCelularSms = numeroCelularSms;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }
}
