package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_034, sobre Dados do xx.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_034 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String tcpuns01_P22;
	private String tcpuns02_P22;
	private String tcpuns03_P22;
	private String tcpuns04_P22;
	private String tcpuns05_P22;
	private String tcpuns06_P22;
	private String tcpuns07_P22;
	private String tcpuns08_P22;
	private String tcpuns09_P22;
	private String tcpuns10_P22;
	private String tcpuns11_P22;
	private String tcpuns12_P22;
	
	
	public CPO_034(){		
	}


	/**
	 * 2 = CAPACIDADE DE LEITURA DE TRILHA
	 *  5 = CAPACIDADE DE LEITURA DE CHIP
	 * 
	 * @return the tcpuns01_P22
	 */
	@PositionalField(initialPosition= 1, finalPosition= 1)
	public String getTcpuns01_P22() {
		return tcpuns01_P22;
	}


	/**
	 * 	 * 
	 * @param tcpuns01_P22 the tcpuns01_P22 to set
	 */
	public void setTcpuns01_P22(String tcpuns01_P22) {
		this.tcpuns01_P22 = tcpuns01_P22;
	}


	/**
	 *  0 = SEM PIN - SENHA
	 *  1 = COM PIN - SENHA
	 * 
	 * @return the tcpuns02_P22
	 */
	@PositionalField(initialPosition= 2, finalPosition= 2)
	public String getTcpuns02_P22() {
		return tcpuns02_P22;
	}


	/**
	 * @param tcpuns02_P22 the tcpuns02_P22 to set
	 */
	public void setTcpuns02_P22(String tcpuns02_P22) {
		this.tcpuns02_P22 = tcpuns02_P22;
	}


	/**
	 * 0 = NAO TEM CAP. RETENCAO DE CARTAO
	 * 
	 * @return the tcpuns03_P22
	 */
	@PositionalField(initialPosition= 3, finalPosition= 3)
	public String getTcpuns03_P22() {
		return tcpuns03_P22;
	}


	/**
	 * @param tcpuns03_P22 the tcpuns03_P22 to set
	 */
	public void setTcpuns03_P22(String tcpuns03_P22) {
		this.tcpuns03_P22 = tcpuns03_P22;
	}


	/**
	 * 1 = TERMINAL ATENDIDO
	 * 
	 * @return the tcpuns04_P22
	 */
	@PositionalField(initialPosition= 4, finalPosition= 4)
	public String getTcpuns04_P22() {
		return tcpuns04_P22;
	}


	/**
	 * @param tcpuns04_P22 the tcpuns04_P22 to set
	 */
	public void setTcpuns04_P22(String tcpuns04_P22) {
		this.tcpuns04_P22 = tcpuns04_P22;
	}


	/**
	 *  0 = CLIENTE PRESENTE
	 *  1 = CLIENTE NAO PRESENTE
	 *  7 = CLIENTE NAO PRESENTE COM. ELETRONICO
	 * 
	 * @return the tcpuns05_P22
	 */
	@PositionalField(initialPosition= 5, finalPosition= 5)
	public String getTcpuns05_P22() {
		return tcpuns05_P22;
	}


	/**
	 * @param tcpuns05_P22 the tcpuns05_P22 to set
	 */
	public void setTcpuns05_P22(String tcpuns05_P22) {
		this.tcpuns05_P22 = tcpuns05_P22;
	}


	/**
	 * 0 = CARTAO NAO PRESENTE
	 *  1 = CARTAO PRESENTE
	 * 
	 * @return the tcpuns06_P22
	 */
	@PositionalField(initialPosition= 6, finalPosition= 6)
	public String getTcpuns06_P22() {
		return tcpuns06_P22;
	}


	/**
	 * @param tcpuns06_P22 the tcpuns06_P22 to set
	 */
	public void setTcpuns06_P22(String tcpuns06_P22) {
		this.tcpuns06_P22 = tcpuns06_P22;
	}


	/**
	 * 2 = TRANSACAO COM TRILHA
	 *  5 = TRANSACAO COM CHIP
	 *  6 = TRANSACAO MANUAL
	 * 
	 * @return the tcpuns07_P22
	 */
	@PositionalField(initialPosition= 7, finalPosition= 7)
	public String getTcpuns07_P22() {
		return tcpuns07_P22;
	}


	/**
	 * @param tcpuns07_P22 the tcpuns07_P22 to set
	 */
	public void setTcpuns07_P22(String tcpuns07_P22) {
		this.tcpuns07_P22 = tcpuns07_P22;
	}


	/**
	 * 0 = NAO IDENTIFICADO (SEM SENHA)
	 *  1 = SENHA ON
	 *  5 = SENHA OFF
	 * 
	 * @return the tcpuns08_P22
	 */
	@PositionalField(initialPosition= 8, finalPosition= 8)
	public String getTcpuns08_P22() {
		return tcpuns08_P22;
	}


	/**
	 * @param tcpuns08_P22 the tcpuns08_P22 to set
	 */
	public void setTcpuns08_P22(String tcpuns08_P22) {
		this.tcpuns08_P22 = tcpuns08_P22;
	}


	/**
	 * 3 = VALIDOU A SENHA, BANCO
	 *  4 = VALIDOU A SENHA, CARTAO CHIP (ICC)
	 * 
	 * @return the tcpuns09_P22
	 */
	@PositionalField(initialPosition= 9, finalPosition= 9)
	public String getTcpuns09_P22() {
		return tcpuns09_P22;
	}


	/**
	 * @param tcpuns09_P22 the tcpuns09_P22 to set
	 */
	public void setTcpuns09_P22(String tcpuns09_P22) {
		this.tcpuns09_P22 = tcpuns09_P22;
	}


	/**
	 * 1 = TERMINAL NAO TEM CAPACIDADE DE AUTIALIZAR O
	 *      CARTAO
	 *     
	 * @return the tcpuns10_P22
	 */
	@PositionalField(initialPosition= 10, finalPosition= 10)
	public String getTcpuns10_P22() {
		return tcpuns10_P22;
	}


	/**
	 * @param tcpuns10_P22 the tcpuns10_P22 to set
	 */
	public void setTcpuns10_P22(String tcpuns10_P22) {
		this.tcpuns10_P22 = tcpuns10_P22;
	}


	/**
	 * 0 = NAO TEM CAPACIDADE DE IMPRIMIR MENSAGEM
	 * 
	 * @return the tcpuns11_P22
	 */
	@PositionalField(initialPosition= 11, finalPosition= 11)
	public String getTcpuns11_P22() {
		return tcpuns11_P22;
	}


	/**
	 * @param tcpuns11_P22 the tcpuns11_P22 to set
	 */
	public void setTcpuns11_P22(String tcpuns11_P22) {
		this.tcpuns11_P22 = tcpuns11_P22;
	}


	/**
	 * 6 = TAMANHO MAXIMO DO PIN (6 POSICOES)
	 * 
	 * @return the tcpuns12_P22
	 */
	@PositionalField(initialPosition= 12, finalPosition= 12)
	public String getTcpuns12_P22() {
		return tcpuns12_P22;
	}


	/**
	 * @param tcpuns12_P22 the tcpuns12_P22 to set
	 */
	public void setTcpuns12_P22(String tcpuns12_P22) {
		this.tcpuns12_P22 = tcpuns12_P22;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
