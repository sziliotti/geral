package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator.DateDecorator;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_902, sobre Dados do xx.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_902 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	public static Logger logger= LoggerFactory.getLogger(CPO_902.class);
	
	/*private SimpleDateFormat dateFormat= new SimpleDateFormat("yyMMdd");*/
	
	private String brBit61IdeSub1;
	private String brBit61IdeSof1;
	private String brBit61IdeSub2;
	private String brBit61TamanhoPOS2;
	private String brBit61Serpos2;
	private String brBit61IdeSub3;
	private String brBit61TamanhoPIN3;
	private String brBit61SerPIN3;
	private String brBit61IdeSub8;
	private String brBit61TipFin8;
	private String brBit61NumeroParcelas8;
	private Date brBit61DataPred8;
	private String brBit61TiPris8;
	private String brBit61IdeSub9;
	private String brBit61NumeroDocumento9;
	private Date brBit61DataTransacao9;
	private String brBit61NumeroLog9;
	private String brBit61IdeSub10;
	private String brBit61Chicon10;
	private String brBit61IdeSub13;
	private String brBit61CodigoSeguranca13;
	private String brBit61IdeSub14;
	private String brBit61CodigoProduto14;
	
	public CPO_902(){		
	}

	/**
	 * @return the brBit61IdeSub1
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public String getBrBit61IdeSub1() {
		return brBit61IdeSub1;
	}

	/**
	 * @param brBit61IdeSub1 the brBit61IdeSub1 to set
	 */
	public void setBrBit61IdeSub1(String brBit61IdeSub1) {
		this.brBit61IdeSub1 = brBit61IdeSub1;
	}

	/**
	 * @return the brBit61IdeSof1
	 */
	@PositionalField(initialPosition= 3, finalPosition= 14)
	public String getBrBit61IdeSof1() {
		return brBit61IdeSof1;
	}

	/**
	 * @param brBit61IdeSof1 the brBit61IdeSof1 to set
	 */
	public void setBrBit61IdeSof1(String brBit61IdeSof1) {
		this.brBit61IdeSof1 = brBit61IdeSof1;
	}

	/**
	 * @return the brBit61IdeSub2
	 */
	@PositionalField(initialPosition= 15, finalPosition= 16)
	public String getBrBit61IdeSub2() {
		return brBit61IdeSub2;
	}

	/**
	 * @param brBit61IdeSub2 the brBit61IdeSub2 to set
	 */
	public void setBrBit61IdeSub2(String brBit61IdeSub2) {
		this.brBit61IdeSub2 = brBit61IdeSub2;
	}

	/**
	 * @return the brBit61TamanhoPOS2
	 */
	@PositionalField(initialPosition= 17, finalPosition= 18)
	public String getBrBit61TamanhoPOS2() {
		return brBit61TamanhoPOS2;
	}

	/**
	 * @param brBit61TamanhoPOS2 the brBit61TamanhoPOS2 to set
	 */
	public void setBrBit61TamanhoPOS2(String brBit61TamanhoPOS2) {
		this.brBit61TamanhoPOS2 = brBit61TamanhoPOS2;
	}

	/**
	 * @return the brBit61Serpos2
	 */
	@PositionalField(initialPosition= 19, finalPosition= 38)
	public String getBrBit61Serpos2() {
		return brBit61Serpos2;
	}

	/**
	 * @param brBit61Serpos2 the brBit61Serpos2 to set
	 */
	public void setBrBit61Serpos2(String brBit61Serpos2) {
		this.brBit61Serpos2 = brBit61Serpos2;
	}

	/**
	 * @return the brBit61IdeSub3
	 */
	@PositionalField(initialPosition= 39, finalPosition= 40)
	public String getBrBit61IdeSub3() {
		return brBit61IdeSub3;
	}

	/**
	 * @param brBit61IdeSub3 the brBit61IdeSub3 to set
	 */
	public void setBrBit61IdeSub3(String brBit61IdeSub3) {
		this.brBit61IdeSub3 = brBit61IdeSub3;
	}

	/**
	 * @return the brBit61TamanhoPIN3
	 */
	@PositionalField(initialPosition= 41, finalPosition= 42)
	public String getBrBit61TamanhoPIN3() {
		return brBit61TamanhoPIN3;
	}

	/**
	 * @param brBit61TamanhoPIN3 the brBit61TamanhoPIN3 to set
	 */
	public void setBrBit61TamanhoPIN3(String brBit61TamanhoPIN3) {
		this.brBit61TamanhoPIN3 = brBit61TamanhoPIN3;
	}

	/**
	 * @return the brBit61SerPIN3
	 */
	@PositionalField(initialPosition= 43, finalPosition= 62)
	public String getBrBit61SerPIN3() {
		return brBit61SerPIN3;
	}

	/**
	 * @param brBit61SerPIN3 the brBit61SerPIN3 to set
	 */
	public void setBrBit61SerPIN3(String brBit61SerPIN3) {
		this.brBit61SerPIN3 = brBit61SerPIN3;
	}

	/**
	 * @return the brBit61IdeSub8
	 */
	@PositionalField(initialPosition= 63, finalPosition= 64)
	public String getBrBit61IdeSub8() {
		return brBit61IdeSub8;
	}

	/**
	 * @param brBit61IdeSub8 the brBit61IdeSub8 to set
	 */
	public void setBrBit61IdeSub8(String brBit61IdeSub8) {
		this.brBit61IdeSub8 = brBit61IdeSub8;
	}

	/**
	 * @return the brBit61TipFin8
	 */
	@PositionalField(initialPosition= 65, finalPosition= 66)
	public String getBrBit61TipFin8() {
		return brBit61TipFin8;
	}

	/**
	 * @param brBit61TipFin8 the brBit61TipFin8 to set
	 */
	public void setBrBit61TipFin8(String brBit61TipFin8) {
		this.brBit61TipFin8 = brBit61TipFin8;
	}

	/**
	 * @return the brBit61NumeroParcelas8
	 */
	@PositionalField(initialPosition= 67, finalPosition= 68)
	public String getBrBit61NumeroParcelas8() {
		return brBit61NumeroParcelas8;
	}

	/**
	 * @param brBit61NumeroParcelas8 the brBit61NumeroParcelas8 to set
	 */
	public void setBrBit61NumeroParcelas8(String brBit61NumeroParcelas8) {
		this.brBit61NumeroParcelas8 = brBit61NumeroParcelas8;
	}

	/**
	 * @return the brBit61DataPred8
	 */
	@PositionalField(initialPosition= 69, finalPosition= 74, decorator= DateDecorator.class)
	public Date getBrBit61DataPred8() {
		return brBit61DataPred8;
	}
	/**
	 * @param brBit61DataPred8 the brBit61DataPred8 to set
	 */
	/*public void setBrBit61DataPred8(String brBit61DataPred8) {		
		try {
			this.brBit61DataPred8= dateFormat.parse(brBit61DataPred8);
		} catch (ParseException e) {
			logger.warn("Erro realizando parser no objeto [CPO_902], em campo data[brBit61DataPred8]. Valor recebido= '"+brBit61DataPred8+"'");
			this.brBit61DataPred8= new Date();			
		}
	}*/
	/**
	 * @param brBit61DataPred8 the brBit61DataPred8 to set
	 */
	public void setBrBit61DataPred8(Date brBit61DataPred8) {
		this.brBit61DataPred8 = brBit61DataPred8;
	}

	/**
	 * @return the brBit61TiPris8
	 */
	@PositionalField(initialPosition= 75, finalPosition= 76)
	public String getBrBit61TiPris8() {
		return brBit61TiPris8;
	}

	/**
	 * @param brBit61TiPris8 the brBit61TiPris8 to set
	 */
	public void setBrBit61TiPris8(String brBit61TiPris8) {
		this.brBit61TiPris8 = brBit61TiPris8;
	}

	/**
	 * @return the brBit61IdeSub9
	 */
	@PositionalField(initialPosition= 77, finalPosition= 78)
	public String getBrBit61IdeSub9() {
		return brBit61IdeSub9;
	}

	/**
	 * @param brBit61IdeSub9 the brBit61IdeSub9 to set
	 */
	public void setBrBit61IdeSub9(String brBit61IdeSub9) {
		this.brBit61IdeSub9 = brBit61IdeSub9;
	}

	/**
	 * @return the brBit61NumeroDocumento9
	 */
	@PositionalField(initialPosition= 79, finalPosition= 84)
	public String getBrBit61NumeroDocumento9() {
		return brBit61NumeroDocumento9;
	}

	/**
	 * @param brBit61NumeroDocumento9 the brBit61NumeroDocumento9 to set
	 */
	public void setBrBit61NumeroDocumento9(String brBit61NumeroDocumento9) {
		this.brBit61NumeroDocumento9 = brBit61NumeroDocumento9;
	}

	/**
	 * @return the brBit61DataTransacao9
	 */
	@PositionalField(initialPosition= 85, finalPosition= 90, decorator= DateDecorator.class)
	public Date getBrBit61DataTransacao9() {
		return brBit61DataTransacao9;
	}
	/**
	 * @param brBit61DataTransacao9 the brBit61DataTransacao9 to set
	 */
	/*public void setBrBit61DataTransacao9(String brBit61DataTransacao9) {		
		try {
			this.brBit61DataTransacao9= dateFormat.parse(brBit61DataTransacao9);
		} catch (ParseException e) {
			logger.warn("Erro realizando parser no objeto [CPO_902], em campo data[brBit61DataTransacao9]. Valor recebido= '"+brBit61DataTransacao9+"'");
			this.brBit61DataTransacao9= new Date();			
		}
	}*/
	/**
	 * @param brBit61DataTransacao9 the brBit61DataTransacao9 to set
	 */
	public void setBrBit61DataTransacao9(Date brBit61DataTransacao9) {
		this.brBit61DataTransacao9 = brBit61DataTransacao9;
	}

	/**
	 * @return the brBit61NumeroLog9
	 */
	@PositionalField(initialPosition= 91, finalPosition= 98)
	public String getBrBit61NumeroLog9() {
		return brBit61NumeroLog9;
	}

	/**
	 * @param brBit61NumeroLog9 the brBit61NumeroLog9 to set
	 */
	public void setBrBit61NumeroLog9(String brBit61NumeroLog9) {
		this.brBit61NumeroLog9 = brBit61NumeroLog9;
	}

	/**
	 * @return the brBit61IdeSub10
	 */
	@PositionalField(initialPosition= 99, finalPosition= 100)
	public String getBrBit61IdeSub10() {
		return brBit61IdeSub10;
	}

	/**
	 * @param brBit61IdeSub10 the brBit61IdeSub10 to set
	 */
	public void setBrBit61IdeSub10(String brBit61IdeSub10) {
		this.brBit61IdeSub10 = brBit61IdeSub10;
	}

	/**
	 * @return the brBit61Chicon10
	 */
	@PositionalField(initialPosition= 101, finalPosition= 102)
	public String getBrBit61Chicon10() {
		return brBit61Chicon10;
	}

	/**
	 * @param brBit61Chicon10 the brBit61Chicon10 to set
	 */
	public void setBrBit61Chicon10(String brBit61Chicon10) {
		this.brBit61Chicon10 = brBit61Chicon10;
	}

	/**
	 * @return the brBit61IdeSub13
	 */
	@PositionalField(initialPosition= 103, finalPosition= 104)
	public String getBrBit61IdeSub13() {
		return brBit61IdeSub13;
	}

	/**
	 * @param brBit61IdeSub13 the brBit61IdeSub13 to set
	 */
	public void setBrBit61IdeSub13(String brBit61IdeSub13) {
		this.brBit61IdeSub13 = brBit61IdeSub13;
	}

	/**
	 * @return the brBit61CodigoSeguranca13
	 */
	@PositionalField(initialPosition= 105, finalPosition= 106)
	public String getBrBit61CodigoSeguranca13() {
		return brBit61CodigoSeguranca13;
	}

	/**
	 * @param brBit61CodigoSeguranca13 the brBit61CodigoSeguranca13 to set
	 */
	public void setBrBit61CodigoSeguranca13(String brBit61CodigoSeguranca13) {
		this.brBit61CodigoSeguranca13 = brBit61CodigoSeguranca13;
	}

	/**
	 * @return the brBit61IdeSub14
	 */
	@PositionalField(initialPosition= 107, finalPosition= 108)
	public String getBrBit61IdeSub14() {
		return brBit61IdeSub14;
	}

	/**
	 * @param brBit61IdeSub14 the brBit61IdeSub14 to set
	 */
	public void setBrBit61IdeSub14(String brBit61IdeSub14) {
		this.brBit61IdeSub14 = brBit61IdeSub14;
	}

	/**
	 * @return the brBit61CodigoProduto14
	 */
	@PositionalField(initialPosition= 109, finalPosition= 112)
	public String getBrBit61CodigoProduto14() {
		return brBit61CodigoProduto14;
	}

	/**
	 * @param brBit61CodigoProduto14 the brBit61CodigoProduto14 to set
	 */
	public void setBrBit61CodigoProduto14(String brBit61CodigoProduto14) {
		this.brBit61CodigoProduto14 = brBit61CodigoProduto14;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
