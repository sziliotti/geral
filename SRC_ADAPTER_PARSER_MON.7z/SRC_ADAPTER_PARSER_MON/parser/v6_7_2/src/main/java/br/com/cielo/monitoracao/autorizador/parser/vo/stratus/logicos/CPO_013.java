package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_013, sobre Dados do Terminal.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_013 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String codigoTerminal;
	private String versaoTerminal;
	private String originalTerminal;
	private String tipoTerminal;
	private String tipoTecnologiaTerminal;
	private String codigoNoTerminal;
	private String serie;
	
	public CPO_013(){		
	}

	/**
	 * Representa o Campo STRATUS:  ACTR-TERMINAL-CODIGO
	 *
	 * @return the codigoTerminal
	 */
	@PositionalField(initialPosition= 1, finalPosition= 8)
	public String getCodigoTerminal() {
		return codigoTerminal;
	}

	/**
	 * @param codigoTerminal the codigoTerminal to set
	 */
	public void setCodigoTerminal(String codigoTerminal) {
		this.codigoTerminal = codigoTerminal;
	}

	/**
	 * Representa o Campo STRATUS:  ACTR-TERMINAL-VERSAO
	 *
	 * @return the versaoTerminal
	 */
	@PositionalField(initialPosition= 9, finalPosition= 20)
	public String getVersaoTerminal() {
		return versaoTerminal;
	}

	/**
	 * @param versaoTerminal the versaoTerminal to set
	 */
	public void setVersaoTerminal(String versaoTerminal) {
		this.versaoTerminal = versaoTerminal;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-TERMINAL-ORIGINAL 
	 *
	 * @return the originalTerminal
	 */
	@PositionalField(initialPosition= 21, finalPosition= 28)
	public String getOriginalTerminal() {
		return originalTerminal;
	}

	/**
	 * @param originalTerminal the originalTerminal to set
	 */
	public void setOriginalTerminal(String originalTerminal) {
		this.originalTerminal = originalTerminal;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-TERMINAL-TIPO 
	 *
	 * @return the tipoTerminal
	 */
	@PositionalField(initialPosition= 29, finalPosition= 30)
	public String getTipoTerminal() {
		return tipoTerminal;
	}

	/**
	 * @param tipoTerminal the tipoTerminal to set
	 */
	public void setTipoTerminal(String tipoTerminal) {
		this.tipoTerminal = tipoTerminal;
	}

	/**
	 * Representa o Campo STRATUS:  ACTR-TERMINAL-TIPO-TECN
	 *
	 * @return the tipoTecnologiaTerminal
	 */
	@PositionalField(initialPosition= 31, finalPosition= 31)
	public String getTipoTecnologiaTerminal() {
		return tipoTecnologiaTerminal;
	}

	/**
	 * @param tipoTecnologiaTerminal the tipoTecnologiaTerminal to set
	 */
	public void setTipoTecnologiaTerminal(String tipoTecnologiaTerminal) {
		this.tipoTecnologiaTerminal = tipoTecnologiaTerminal;
	}

	/**
	 * Representa o Campo STRATUS:  ACTR-TERM-COD-NO
	 *
	 * @return the codigoNoTerminal
	 */
	@PositionalField(initialPosition= 32, finalPosition= 36)
	public String getCodigoNoTerminal() {
		return codigoNoTerminal;
	}

	/**
	 * @param codigoNoTerminal the codigoNoTerminal to set
	 */
	public void setCodigoNoTerminal(String codigoNoTerminal) {
		this.codigoNoTerminal = codigoNoTerminal;
	}

	/**
	 * Representa o Campo STRATUS:  ACTR-SERIE
	 *
	 * @return the serie
	 */
	@PositionalField(initialPosition= 37, finalPosition= 56)
	public String getSerie() {
		return serie;
	}

	/**
	 * @param serie the serie to set
	 */
	public void setSerie(String serie) {
		this.serie = serie;
	}

	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
