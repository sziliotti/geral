package br.com.cielo.monitoracao.jmx;

import java.lang.management.ManagementFactory;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.management.MBeanServer;
import javax.management.ObjectName;

/**
 * Classe basica de MXBean de Monitoramento JMX.
 * @author fernando.moraes
 * @version $Id: AbstractMessageStatistics.java 1957 2017-08-10 11:52:00Z fernando.moraes $
 */
public abstract class AbstractMessageStatistics implements MessageStatisticsMXBean {

    private static final String SYNC_MESSAGE_STATISTICS = "SYNC_MESSAGE_STATISTICS";
    private static final BigDecimal CONST_THOUSAND = BigDecimal.valueOf(1000L);
    private final Map<String, BigDecimal> props_ = new ConcurrentHashMap<String, BigDecimal>();
    private final Map<String, String> times_ = new ConcurrentHashMap<String, String>();
    private MBeanServer platformMBeanServer;
    private ObjectName objectName;

    @Override
    public abstract String getBeanName();

    @PostConstruct
    protected void registerInJMX() {
        try {
            objectName = new ObjectName("br.com.cielo.monitoracao.jmx:type=MessageStatistics,name=" + getBeanName());
            platformMBeanServer = ManagementFactory.getPlatformMBeanServer();
            platformMBeanServer.registerMBean(this, objectName);
            initialize();
        } catch (Exception e) {
            throw new IllegalStateException("Problem during registration of Monitoring into JMX: " + e.getMessage(), e);
        }
    }

    @PreDestroy
    protected void unregisterFromJMX() {
        try {
            platformMBeanServer.unregisterMBean(this.objectName);
        } catch (Exception e) {
            throw new IllegalStateException("Problem during unregistration of Monitoring into JMX: " + e.getMessage(), e);
        }
    }

    @Override
    public BigDecimal setProperty(String key, BigDecimal value) {
        if (KEY_TOTAL_MESSAGES.equals(key)) {
            throw new IllegalArgumentException("Propriedade '" + key + "' nao pode ser alterada diretamente. Use 'addMessages'.");
        }
        BigDecimal oldValue;
        if (value == null) {
            oldValue = props_.remove(key);
        } else {
            synchronized (SYNC_MESSAGE_STATISTICS) {
                oldValue = props_.put(key, value);
                if (KEY_TPS_LAST.equals(key)) {
                    BigDecimal currVal = props_.get(KEY_TPS_MIN);
                    if (currVal == null || value.compareTo(currVal) <= 0) {
                        props_.put(KEY_TPS_MIN, value);
                        times_.put(KEY_TPS_MIN, new Date().toString());
                    }
                    currVal = props_.get(KEY_TPS_MAX);
                    if (currVal == null || value.compareTo(currVal) >= 0) {
                        props_.put(KEY_TPS_MAX, value);
                        times_.put(KEY_TPS_MAX, new Date().toString());
                    }
                }
                if (KEY_POST_LATENCY_LAST.equals(key)) {
                    BigDecimal currVal = props_.get(KEY_POST_LATENCY_MIN);
                    if (currVal == null || value.compareTo(currVal) <= 0) {
                        props_.put(KEY_POST_LATENCY_MIN, value);
                        times_.put(KEY_POST_LATENCY_MIN, new Date().toString());
                    }
                    currVal = props_.get(KEY_POST_LATENCY_MAX);
                    if (currVal == null || value.compareTo(currVal) >= 0) {
                        props_.put(KEY_POST_LATENCY_MAX, value);
                        times_.put(KEY_POST_LATENCY_MAX, new Date().toString());
                    }
                }
                if (KEY_PERSISTENCE_LATENCY_LAST.equals(key)) {
                    BigDecimal currVal = props_.get(KEY_PERSISTENCE_LATENCY_MIN);
                    if (currVal == null || value.compareTo(currVal) <= 0) {
                        props_.put(KEY_PERSISTENCE_LATENCY_MIN, value);
                        times_.put(KEY_PERSISTENCE_LATENCY_MIN, new Date().toString());
                    }
                    currVal = props_.get(KEY_PERSISTENCE_LATENCY_MAX);
                    if (currVal == null || value.compareTo(currVal) >= 0) {
                        props_.put(KEY_PERSISTENCE_LATENCY_MAX, value);
                        times_.put(KEY_PERSISTENCE_LATENCY_MAX, new Date().toString());
                    }
                }
                if (KEY_PARSE_LATENCY_LAST.equals(key)) {
                    BigDecimal currVal = props_.get(KEY_PARSE_LATENCY_MIN);
                    if (currVal == null || value.compareTo(currVal) <= 0) {
                        props_.put(KEY_PARSE_LATENCY_MIN, value);
                        times_.put(KEY_PARSE_LATENCY_MIN, new Date().toString());
                    }
                    currVal = props_.get(KEY_PARSE_LATENCY_MAX);
                    if (currVal == null || value.compareTo(currVal) >= 0) {
                        props_.put(KEY_PARSE_LATENCY_MAX, value);
                        times_.put(KEY_PARSE_LATENCY_MAX, new Date().toString());
                    }
                }
            }
        }
        return oldValue;
    }

    @Override
    public BigDecimal getProperty(String key) {
        return props_.get(key);
    }

    @Override
    public Map<String, BigDecimal> getProperties() {
        return props_;
    }

    @Override
    public Map<String, String> getTimes() {
        return times_;
    }

    @Override
    public void addMessages(BigDecimal value) {
        synchronized (SYNC_MESSAGE_STATISTICS) {
            // tempo decorrido em MILISSEGUNDOS
            long time = System.currentTimeMillis() - getProperty(KEY_START_TIME).longValue();
            // converte MILISSEGUNDOS para SEGUNDOS
            BigDecimal seconds = BigDecimal.valueOf(time).divide(CONST_THOUSAND, 18, RoundingMode.HALF_UP);
            // total de mensages / tempo decorrido em SEGUNDOS
            BigDecimal tps = value;
            if (BigDecimal.ZERO.compareTo(seconds) != 0) {
                tps = value.divide(seconds, 4, RoundingMode.HALF_UP);
            }
            setProperty(KEY_TPS_LAST, tps);
            props_.put(KEY_TOTAL_MESSAGES, getProperty(KEY_TOTAL_MESSAGES).add(value));
            startTimeCount();
        }
    }

    @Override
    public void startTimeCount() {
        long currentTime = System.currentTimeMillis();
        props_.put(KEY_START_TIME, new BigDecimal(currentTime));
        times_.put(KEY_START_TIME, new Date(currentTime).toString());
    }

    private void initialize() {
        times_.clear();
        props_.clear();
        props_.put(KEY_TOTAL_MESSAGES, BigDecimal.ZERO);
        startTimeCount();
    }
}
