package br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator.DateDecorator;
import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.decorator.DateHourDecorator;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_016, sobre Dados do xx.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_016 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	public static Logger logger= LoggerFactory.getLogger(CPO_019.class);
	
	/*private SimpleDateFormat dateFormat= new SimpleDateFormat("yyMMdd");	
	private SimpleDateFormat dateHourFormat= new SimpleDateFormat("yyMMddHHmmss");*/
		
	private String seqCartTcb23;
	private Date dataHoraOperacao;
	private Date dataCPO134;
	
	public CPO_016(){		
	}

	
	/**
	 * @return the seqCartTcb23
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public String getSeqCartTcb23() {
		return seqCartTcb23;
	}

	/**
	 * @param seqCartTcb23 the seqCartTcb23 to set
	 */
	public void setSeqCartTcb23(String seqCartTcb23) {
		this.seqCartTcb23 = seqCartTcb23;
	}

	/**
	 * @return the dataHoraOperacao
	 */
	@PositionalField(initialPosition= 3, finalPosition= 14, decorator= DateHourDecorator.class)
	public Date getDataHoraOperacao() {
		return dataHoraOperacao;
	}
	/**
	 * @param dataHoraOperacao the dataHoraOperacao to set
	 */
	/*public void setDataHoraOperacao(String dataHoraOperacao) {		
		try {
			this.dataHoraOperacao = dateHourFormat.parse(dataHoraOperacao);
		} catch (ParseException e) {
			this.dataHoraOperacao= new Date();
			logger.warn("Erro realizando parser no objeto [CPO_016], em campo data[dataHoraOperacao]. Valor recebido= '"+dataHoraOperacao+"'");			
		}
	}*/
	/**
	 * @param dataHoraOperacao the dataHoraOperacao to set
	 */
	public void setDataHoraOperacao(Date dataHoraOperacao) {
		this.dataHoraOperacao = dataHoraOperacao;
	}

	/**
	 * @return the dataCPO134
	 */
	@PositionalField(initialPosition= 15, finalPosition= 20, decorator= DateDecorator.class)
	public Date getDataCPO134() {
		return dataCPO134;
	}
	/**
	 * @param dataCPO134 the dataCPO134 to set
	 */
	/*public void setDataCPO134(String dataCPO134) {		
		try {
			this.dataCPO134 = dateFormat.parse(dataCPO134);
		} catch (ParseException e) {
			this.dataCPO134 = new Date();
			logger.warn("Erro realizando parser no objeto [CPO_016], em campo data[dataCPO134]. Valor recebido= '"+dataCPO134+"'");			
		}
	}*/
	/**
	 * @param dataCPO134 the dataCPO134 to set
	 */
	public void setDataCPO134(Date dataCPO134) {
		this.dataCPO134 = dataCPO134;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
