

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *<B>Projeto: Stratus-Monitoracao-Adapter</B><BR>
 *
 * Classe principal responsavel em inicializar o Adapter Socket que receberá mensagens do Stratus.
 *	 
 *<DL><DT><B>Criada em:</B><DD>09/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class MainConsumer {
	
	public static Logger logger= LoggerFactory.getLogger(MainConsumer.class);
	
	/**
	 * Método principal da classe.
	 * 
	 * @param args
	 */
	public static void main(String[] args){
		org.apache.camel.spring.Main main= new org.apache.camel.spring.Main();
		main.setApplicationContext(new ClassPathXmlApplicationContext("teste-context.xml"));
		main.enableHangupSupport();
		
		try {			
			main.run();
						
		} catch (Exception e) {
			logger.error("Falha ao manter ativo contexto do camel", e);
		}
	}
}
