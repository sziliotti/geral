package br.com.cielo.bam.integration.adapter;

import java.util.ArrayList;

public class TesteNumeroRandom {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ArrayList<String> numeros= new ArrayList<String>();
		while(true){
			if(true){
				//Numero aleatorio entre a quantidade de mensagens disponiveis.
				int idx= (int) (Math.random() *10); 
				
				System.out.println("Numero: "+idx);
				if(numeros.contains(idx+"")){
					continue;
				}else{
					numeros.add(idx+"");
				}
				
				if(numeros.size()==10){
					System.out.println("Tamanho do array: "+numeros.size());
					System.out.println("Zerando array !");
					numeros.clear();
					System.out.println("Novo Tamanho do array: "+numeros.size());
					break;
				}
				
			}				
			
		}		

	}

}
