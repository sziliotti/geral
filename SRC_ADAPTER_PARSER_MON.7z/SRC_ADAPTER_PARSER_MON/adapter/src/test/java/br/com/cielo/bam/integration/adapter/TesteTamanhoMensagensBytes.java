package br.com.cielo.bam.integration.adapter;

import java.nio.ByteBuffer;
import java.util.Scanner;

import br.com.cielo.monitoracao.bam.integration.utils.ConverterUtils;

public class TesteTamanhoMensagensBytes {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		TesteTamanhoMensagensBytes main= new TesteTamanhoMensagensBytes();
		main.processaTransacoes();
		
	}
	
	private void processaTransacoes(){
		String[] arquivosTransacoes= {"/transacoes-aprovadas.txt"
									  /*,"/transacoes-canceladas.txt" 
									  ,"/transacoes-desfeitas.txt"
									  ,"/transacoes-compactada-prod.txt"*/
									 };
		
		for(String nomeArquivo : arquivosTransacoes) {
			Scanner scanner= new Scanner(getClass().getResourceAsStream(nomeArquivo));
			while(scanner.hasNext()) {
				String msgStratus= scanner.next();
				if(msgStratus != null && !msgStratus.equals("")){
					System.out.println("MSG ORIG ARQUIVO: "+msgStratus);
					
					String tamanhoMsgHex= msgStratus.substring(0, 4);
					System.out.println("TAMANHO EM HEX(ORIG) VINDA DO ARQUIVO: "+ tamanhoMsgHex);
					String valorMsg= msgStratus.substring(4);
					System.out.println("MSG(ORIG) SEM TAMANHO: "+valorMsg);
					System.out.println("TAMANHO DA MENSAGEM EM DECIMAL(ORIG): "+ConverterUtils.hexToDecimal(tamanhoMsgHex));
					System.out.println("======================================================================================");
					
					byte[] msgEmBytes= ConverterUtils.hexToBytes(valorMsg);
					int tamanhoMsg= msgEmBytes.length;
					System.out.println("TAMANHO DA MENSAGEM(DECIMAL) APOS CONVERTER EM BYTES: "+tamanhoMsg);
					System.out.println("======================================================================================");
			
					
					//String tamanhoHex= String.format("%1$4s", Integer.toString(msgEmBytes.length / 2, 16)).replace(' ', '0');
					String tamanhoHex= String.format("%1$4s", Integer.toString(msgEmBytes.length, 16)).replace(' ', '0');
					System.out.println("TAMANHO EM HEX APOS CONVERTER EM BYTES: "+tamanhoHex);
					System.out.println("TAMANHO EM DECIMAL APOS CONVERTER EM BYTES: "+ConverterUtils.hexToDecimal(tamanhoHex));					
					System.out.println("======================================================================================");
					
					String msgOrig= ConverterUtils.bytesToHex(msgEmBytes);
					String msgHexFinal= tamanhoHex + msgOrig;
					System.out.println("MENSAGEM HEX FINAL: "+msgHexFinal);
					System.out.println("======================================================================================");
					System.out.println("======================================================================================");
					
					
					
					byte[] msgOrigEmBytes= ConverterUtils.hexToBytes(msgHexFinal);
					ByteBuffer bbuf= ByteBuffer.allocate(msgOrigEmBytes.length);
					bbuf.put(msgEmBytes);
					short iTamanho= bbuf.getShort();
					byte[] xPayload= new byte[iTamanho];
					ByteBuffer b2= bbuf.get(xPayload);					
					System.out.println("ByteBuffer array(ORIG): "+ ConverterUtils.bytesToHex( b2.array() ));					
				}
			}
		}		
	}

}
