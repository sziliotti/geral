/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.bam.integration.adapter;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Set;
import java.util.UUID;
import org.apache.commons.codec.binary.Hex;
import org.apache.mina.util.ConcurrentHashSet;

/**
 *
 * @author fabiom
 */
public class TesteColisaoUUID_MD5 {

    private static final Set<String> hashs = new ConcurrentHashSet<String>();

    public static void main(String args[]) throws NoSuchAlgorithmException, IOException {
        TesteColisaoUUID_MD5 testMD5 = new TesteColisaoUUID_MD5();
        testMD5.start();
    }

    //private static MessageDigest md;

    public TesteColisaoUUID_MD5() throws NoSuchAlgorithmException {
       // md = MessageDigest.getInstance("MD5");
    }

   
    private void start() throws NoSuchAlgorithmException {
        Runnable job1 = new Md5Executor();

        Thread t1 = new Thread(new Md5Executor());
        Thread t2 = new Thread(new Md5Executor());
        Thread t3 = new Thread(new Md5Executor());
        Thread t4 = new Thread(new Md5Executor());
        Thread t5 = new Thread(new Md5Executor());
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();

    }

    
    private class Md5Executor implements Runnable {
        private MessageDigest md;

        public Md5Executor() throws NoSuchAlgorithmException {
            md = MessageDigest.getInstance("MD5");
        }
        
        
        private void generateMd5() {
                
//        File f = new File("D:\\massa\\testeHashColisao.txt");
//        try {

            for (long i = 0; i <= 500000; i++) {
                String correlationId = Hex.encodeHexString(md.digest(UUID.randomUUID().toString().getBytes()));
                //fw.write(correlationId + System.lineSeparator());
                if (!hashs.add(correlationId)) {
                    System.out.println("Colisão detectada na tentativa n. " + i + ", do hash:" + correlationId);
                    break;
                }
                if (i % 100000 == 0) {
                    System.out.println("===> Processou: "+i);
                }
            }
//        } finally {
//            fw.close();
//        }

    }
        public void run() {
            generateMd5();
        }
        
    }

}
