package br.com.cielo.bam.integration.adapter;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.monitoracao.bam.integration.utils.ConverterUtils;

/**
 *<B>Projeto: xxxxxx</B><BR>
 *
 * 
 *	 
 *<DL><DT><B>Criada em:</B><DD>15/05/2014</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class EnviarMensagemTeste {
	public static Logger logger= LoggerFactory.getLogger(EnviarMensagemTeste.class);

	/**
	 * @param args
	 */
	
	private static AtomicInteger count = new AtomicInteger();
	
	public static void main(String[] args) {
		logger.info("Enviando mensagem de Teste, para criação da FILA do Stratus !!");
		
		new Thread(){
			public void run() {
				while(true){
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					System.out.println("TPS " + new Date() + ": " + count.getAndSet(0));
				}
				
			};
		}.start();
		
		String hostname= "localhost";
		int porta= 7801;		
		try {
			Socket socket= new Socket(hostname, porta);
			OutputStream out= socket.getOutputStream();	
			
			Scanner scanner = new Scanner(new File("blob.txt"));
			ArrayList<byte[]> buffer = new ArrayList<byte[]>();
			while(scanner.hasNextLine()){
				byte[] b = ConverterUtils.unzipMessage(ConverterUtils.hexToBytes(scanner.nextLine()));
				ByteBuffer byteBuffer = ByteBuffer.allocate(b.length + 2);
				
				byteBuffer.putShort((short)b.length);
				byteBuffer.put(b);

				buffer.add(byteBuffer.array());
			}
			
			int i = 0;
			while(true){
				out.write(buffer.get(i++));
				out.flush();
				try {
					Thread.sleep(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if(i >= buffer.size()){
					i = 0;
				}
				
				count.addAndGet(1);
			}
			
		} catch (UnknownHostException e) {			
			logger.error("Host desconhecido !", e);
		} catch (IOException e) {
			logger.error("Falha ao enviar mensagem de teste para o Socket !!", e);
		}	

	}

}
