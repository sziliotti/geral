package br.com.cielo.bam.integration.adapter;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Scanner;

import br.com.cielo.monitoracao.bam.integration.utils.ConverterUtils;

/**
 *<B>Projeto: Stratus-Monitoracao-Adapter</B><BR>
 *
 * Classe Main responsavel em enviar mensagens, simulando o Stratus.
 *	 
 *<DL><DT><B>Criada em:</B><DD>09/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class SimuladorStratusMain {

	/**
	 * @param args
	 */
	public static void main(String[] args)throws Exception {
		if(args[0].equalsIgnoreCase("-help")){
			System.out.println(" 1 - host\n 2-porta \n 3- Mensagem ok ou com erro(s/n) \n 4- Tempo de wait entre mensagens(ms)");		
		}else{
			String hostname= args[0];
			int porta= Integer.parseInt(args[1]);
			boolean msgBoa= args[2].equalsIgnoreCase("S");
			int sleep= Integer.parseInt(args[3]);
			
			SimuladorStratusMain main= new SimuladorStratusMain();			
			ArrayList<String> transacoesStratus= main.retornaTransacoes();
			main.enviaTransacoesStratus(hostname, porta, msgBoa, sleep, transacoesStratus);		
		}
	}
		
	
	/**
	 * Metodo para envio de transacoes do stratus ao ServerSocket.
	 * 
	 * @param hostname
	 * @param porta
	 * @param msgBoa
	 * @param sleep
	 * @param transacoesStratus
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void enviaTransacoesStratus(String hostname, int porta, boolean msgBoa, int sleep, ArrayList<String> transacoesStratus) throws IOException, InterruptedException{
		Socket socket= new Socket(hostname, porta);
			
		ArrayList<String> numeros= new ArrayList<String>();
		int i= 1;
		OutputStream out= socket.getOutputStream();				
		while(true){
			byte[] msg= null;
			
			if(msgBoa){
				//Numero aleatorio entre a quantidade de mensagens disponiveis.
				int idx= (int) (Math.random() * transacoesStratus.size()); 
				
				//Envia conjunto de msgs sem repetir.
				if(numeros.contains(idx+"")){
					continue;
				}else{
					numeros.add(idx+"");
				}
				
				String msgStratusOK= transacoesStratus.get(idx);				
				msg= ConverterUtils.hexToBytes(msgStratusOK);
			}else{
				String msgStratusNOK= "00ccf0f0f0e1d4c2f4f9f3f1f0f2f0f0f1f0f0f5f1f3f0f1f2f9f0f6f8f4f1f7f9f7f6f5f4f5f5f8f9f0f6f8f4f1f7f9f7f6f5f5f1f1f7f7f0f2f9f0f2f0f0c1d7d9d6e5c1c4c140f4f3f1f5f1f140f0f1f7f1f8f8f8f1f1f1f0f0f2f3f1f1f1f2c2c40000000003900ff0f1f0f3f1f0f0f0f1f5f1f6f5f1e3c9d4f3f2f5f6f6f1c1d4d4c1d5c1e4e2404040404040404040f0f0f0c3d6f0f3e6c9e6f2f5f4f0f1f3f0f1f2f9f2f3f1f1f1f2f0f0f1f2f3f7f0f1f0f0f0f0f0f2f1f1f7f3f0f2f3f8f9d5d5000000000000000000";
				msg= ConverterUtils.hexToBytes(msgStratusNOK);			
			}
						
			out.write(msg);
			out.flush();
			
			System.out.println("[SIMULADOR] "+i+"-) Mensagem(hex) enviada em "+new Date().toString()+": "+ConverterUtils.bytesToHex(msg));			
			System.out.println("===============================================================================================================================================================================");
			i++;
			
			if(numeros.size() == transacoesStratus.size()){				
				System.out.println("Zerando array !");
				numeros.clear();
				System.out.println("Começando nova Rajada !!!");
				System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
				i= 1;
			}			
			
			Thread.sleep(sleep);
		}		
	}
	
	/**
	 * Método responsável em retornar a lista de transações, localizadas no arquivo "transacoes.txt" para teste.
	 * 
	 * @return
	 * 		ArrayList com cada transação gravada no arquivo.
	 */
	private ArrayList<String> retornaTransacoes(){
		ArrayList<String> conjuntoTransacoes= new ArrayList<String>();
		
		String[] arquivosTransacoes= {
									  //"/transacoes.txt" 
									  //,"/transacoes-aprovadas.txt" 
									  //,"/transacoes-canceladas.txt" 
									  //,"/transacoes-desfeitas.txt"
									  "/transacoes-compactada-prod.txt"
									 };
		
		for(String nomeArquivo : arquivosTransacoes) {
			Scanner scanner= new Scanner(getClass().getResourceAsStream(nomeArquivo));
			while(scanner.hasNext()) {
				String msgStratus= scanner.next();
				if(msgStratus != null && !msgStratus.equals("")){
					//Usar com arquivo "transacoes-compactada-prod.txt", sem tamanho de 2 bytes iniciais.
					if(nomeArquivo.contains("compactada")){	
						byte[] msgEmBytes= ConverterUtils.hexToBytes(msgStratus);
						byte[] msgEmBytesDesc= ConverterUtils.unzipMessage(msgEmBytes);
						
						String tamanhoHex= String.format("%1$4s", Integer.toString(msgEmBytesDesc.length, 16)).replace(' ', '0');					
						String msgOrig= ConverterUtils.bytesToHex(msgEmBytesDesc);
						String msgHexFinal= tamanhoHex + msgOrig;
						
						conjuntoTransacoes.add(msgHexFinal);
					}else{					
						conjuntoTransacoes.add(msgStratus);
					}
				}
			}
		}
		Collections.shuffle(conjuntoTransacoes);
		
		return conjuntoTransacoes;
	}
}
