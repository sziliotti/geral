#!/bin/bash

COMMAND=`which java`
if [ ! -x "$COMMAND" ] ; then
   echo "Error: JAVA is not defined correctly"
   exit 1
fi

JMX_PORT=$(grep '^bamAdapter.jmx.connectorPort' config/configuration.properties | tail -1 | cut -d = -f 2)

JMX_CFG="-Dcom.sun.management.jmxremote=true"
JMX_CFG="$JMX_CFG -Dcom.sun.management.jmxremote.port=$JMX_PORT"
JMX_CFG="$JMX_CFG -Dcom.sun.management.jmxremote.local.only=false"
JMX_CFG="$JMX_CFG -Dcom.sun.management.jmxremote.authenticate=false"
JMX_CFG="$JMX_CFG -Dcom.sun.management.jmxremote.ssl=false"

java -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:log/verbosegc.log -XX:+UseConcMarkSweepGC -XX:+CMSScavengeBeforeRemark -XX:+ParallelRefProcEnabled -XX:CMSInitiatingOccupancyFraction=30 -Xms2g -Xmx2g $JMX_CFG -Dlogback.configurationFile=config/logback.xml -Djava.util.logging.config.file=config/logging.properties -jar ${project.build.finalName}.jar $1 1>> log/stratus-monitoracao-adapter.out 2>> log/stratus-monitoracao-adapter.err &
