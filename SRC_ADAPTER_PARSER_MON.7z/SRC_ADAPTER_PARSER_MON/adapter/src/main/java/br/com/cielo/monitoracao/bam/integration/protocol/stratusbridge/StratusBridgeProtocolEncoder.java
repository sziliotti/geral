package br.com.cielo.monitoracao.bam.integration.protocol.stratusbridge;

import br.com.cielo.monitoracao.bam.integration.protocol.m100.*;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

import org.apache.commons.io.HexDump;
import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolEncoder;
import org.apache.mina.filter.codec.ProtocolEncoderOutput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <B>Projeto: Stratus-Monitoracao-Adapter</B><BR>
 *
 * Classe que faz a codificacao(encode) da mensagem para o protocolo M100.
 *
 * <DL><DT><B>Criada em:</B><DD>10/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 * @since 26/07/2012 - Versão inicial do projeto mainframe-adapter, feito por
 * EYVC8F.
 */
public class StratusBridgeProtocolEncoder implements ProtocolEncoder {

    private static final Logger logger = LoggerFactory.getLogger(StratusBridgeProtocolEncoder.class);
    // tamanho da mensagem de retorno para o Stratus Bridge
    private static final int RESPONSE_MESSAGE_TYPE=2;
    /**
     * Encodes higher-level message objects into binary or protocol-specific
     * data. MINA invokes
     * {@link #encode(IoSession, Object, ProtocolEncoderOutput)} method with
     * message which is popped from the session write queue, and then the
     * encoder implementation puts encoded messages (typically
     * {@link IoBuffer}s) into {@link ProtocolEncoderOutput}.
     *
     * @param session ;
     * @param object ;
     * @param out ;
     *
     * @throws Exception if the message violated protocol specification
     */
    public void encode(final IoSession session, final Object object, final ProtocolEncoderOutput out) throws Exception {
        byte[] msg = (byte[]) object;

        IoBuffer buffer = IoBuffer.allocate(16); // tamanho 14 + 2 de tamanho
        buffer.put(new byte[] {0,(byte)0x0e}); // ajusta 2 primeiros bytes para 14
        
        ByteBuffer bb = ByteBuffer.wrap(msg);
        if (logger.isDebugEnabled()) {
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            stream.write(msg);
            logger.debug("Enviando:\n" + stream.toString());
        }
        // 2 bytes para o tipo da menagem de retorno
        buffer.put(new byte[] {0,(byte)2});
        // Código da instancia (posicao 2-3)
        byte[] originalHeader = new byte[12];
        bb.position(2);
        bb.get(originalHeader,0,12);
        buffer.put(originalHeader); 

        buffer.flip();

        out.write(buffer);
    }

    /**
     * Releases all resources related with this encoder.
     *
     * @param session ;
     *
     * @throws Exception if failed to dispose all resources
     */
    public void dispose(final IoSession session) throws Exception {

    }

}
