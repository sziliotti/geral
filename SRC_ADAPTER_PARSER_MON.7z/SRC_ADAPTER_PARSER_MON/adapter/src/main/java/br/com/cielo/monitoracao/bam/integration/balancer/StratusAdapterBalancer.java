package br.com.cielo.monitoracao.bam.integration.balancer;

import br.com.cielo.monitoracao.bam.integration.handle.LostTransactionsHandle;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang.StringUtils;
import org.apache.mina.util.ConcurrentHashSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author fernando.moraes
 */
public class StratusAdapterBalancer implements Processor {

    public static final String MESSAGE_DESTINATION = "_MESSAGE_DESTINATION";
    private static final Logger LOGGER = LoggerFactory.getLogger(StratusAdapterBalancer.class);
    protected static final int LRU_MAX_SIZE = 1000;
    protected static final int EXCHANGE_ERRORS_BEFORE_BLACKLIST = 20;
    protected final Set<Processor> failedProcessors = new ConcurrentHashSet<Processor>();
    protected List<Processor> healthyProcessors;
    private final String destination;
    private int blacklistExpirationTimeInMinutes = 5;
    private int blacklistExpirationTimeInMilisec = blacklistExpirationTimeInMinutes * 60 * 1000;
    private int processorIndex = 0;
    private final boolean run = true;

    public StratusAdapterBalancer(final String blacklistExpirationTimeInMinutes, final String destination) {
        this.destination = destination;
        this.blacklistExpirationTimeInMinutes = new Integer(blacklistExpirationTimeInMinutes);
        this.blacklistExpirationTimeInMilisec = this.blacklistExpirationTimeInMinutes * 60 * 1000;
        Thread monitor = new Thread("Blacklist Monitor") {
            @Override
            public void run() {
                while (run) {
                    try {
                        Thread.sleep(blacklistExpirationTimeInMilisec);
                    } catch (InterruptedException e) {
                        throw new RuntimeException("Falhou ao executar sleep", e);
                    }
                    LOGGER.info(">>>> [{}] Limpeza dos processadores incluidos na blackList", destination);
                    // anaga lista blacklist de processor
                    for (Iterator<Processor> iterator = failedProcessors.iterator(); iterator.hasNext();) {
                        Processor processorToRetry = iterator.next();
                        iterator.remove();
                        addProcessor(processorToRetry);
                        LOGGER.info("++++ [{}] Removendo processador [{}] da blackList", destination, processorToRetry);
                    }
                }
            }
        };
        monitor.start();
    }

    public List<Processor> getProcessors() {
        return healthyProcessors;
    }

    public void setProcessors(List<Processor> processors) {
        healthyProcessors = new CopyOnWriteArrayList(processors);
    }

    protected Processor chooseProcessor(Exchange exchange) {
        synchronized (this) {
            if (getProcessors().size() > 0) {
                if (processorIndex > getProcessors().size() - 1) {
                    processorIndex = 0;
                }
                Processor target = getProcessors().get(processorIndex);
                processorIndex++;
                return target;
            }
        }
        return null;
    }

    protected void addProcessor(Processor p) {
        synchronized (this) {
            if (!getProcessors().contains(p)) {
                healthyProcessors.add(p);
            }
        }
    }

    /**
     * Remove processador da lista de processadores saudaveis.
     *
     * @param target processador a ser removido
     * @return retorna {@code true} se processador existe na lista, caso contrario retorna {@code false}.
     */
    protected boolean removeProcessor(Processor target) {
        return healthyProcessors.remove(target);
    }

    protected void rejectExchange(Exchange exchange) {
        exchange.setProperty(LostTransactionsHandle.LOST_TRANSACTION_PROPERTY_DESTINATION, destination);
    }

    private boolean isImpossibleToSend=false;
    @Override
    public void process(Exchange exchange) throws Exception {
        while (true) {
			String msgDestination = exchange.getIn().getHeader(MESSAGE_DESTINATION, String.class);
			if (StringUtils.isNotBlank(msgDestination) && !msgDestination.equals(destination)) {
				LOGGER.debug(">>>> Destino da mensagens [{}] diferente do balanceador [{}]", msgDestination, destination);
				break;
			}
            final Processor target = chooseProcessor(exchange);
            if (target == null) {               
                // nao ha mais target para tentar, possivelmente todos na blacklist. Jogando para fila de lost                
                if(LOGGER.isWarnEnabled() && !isImpossibleToSend) {
                    // só envia o warn uma vez.
                    LOGGER.warn(">>>> [{}] Nao foi possivel enviar transacao", destination);                    
                }
                isImpossibleToSend=true;
                rejectExchange(exchange);
                throw new Exception("Nao foi possivel enviar transacao: " + destination);
            } else {
                try {
                    target.process(exchange);
                    if(LOGGER.isWarnEnabled() && isImpossibleToSend) {
                        // só envia o warn uma vez.
                        LOGGER.warn("<<<< [{}] Envio de transação voltou a normalidade:", destination);
                    }
                    isImpossibleToSend=false;
                    break;
                } catch (Exception ex) {
                    removeProcessorFromActiveProcessors(target, ex);
                    rejectExchange(exchange);
                    // fail over. Continue eh redundante neste ponto pois eh o fim do laco infinito, mas eh para garantir
                    // que se um dia alguma outra condicao for posta abaixo, a logica nao se quebre.
                    throw ex;
                }
            }
        }
    }

    private void removeProcessorFromActiveProcessors(Processor target, Exception ex) {
        // Erro enviando exchange para endpoint. Remover o target da lista e aguardar pelo menos 5 minutos para recolocar
        // Se nao processador nao existir na lista de processadores ativos, é porque outra thread ja o fez entao ignora e retorna.
        if (!removeProcessor(target)) {
            return;
        }
        failedProcessors.add(target);
        LOGGER.error("Erro executando processador [{}] com o erro: {}", target, ex.getMessage(), ex);
        LOGGER.info("---- [{}] Adicionando processador [{}] na blacklist para ficar {} minutos de reclusao", 
				destination, target, blacklistExpirationTimeInMinutes);
    }
}
