package br.com.cielo.monitoracao.bam.integration.asynchsocket;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.CamelContext;
import org.apache.camel.Consumer;
import org.apache.camel.Processor;
import org.apache.camel.Producer;
import org.apache.camel.impl.DefaultEndpoint;
import org.apache.camel.util.CamelContextHelper;
import org.apache.mina.filter.codec.ProtocolCodecFactory;

import br.com.cielo.monitoracao.bam.integration.asynchsocket.mina.MinaConsumer;
import br.com.cielo.monitoracao.bam.integration.asynchsocket.mina.MinaProducer;
import br.com.cielo.monitoracao.bam.integration.asynchsocket.mina.MinaServer;

/**
 *<B>Projeto: Stratus-Monitoracao-Adapter</B><BR>
 *
 * Endpoint responsavel por gerenciar conexoes socket de entrada e saida.
 *	 
 *<DL><DT><B>Criada em:</B><DD>09/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 * @since 2011 - Versão inicial do projeto mainframe-adapter, feito por masousa.
 */
public class SocketAsynchRequestResponseEndpoint extends DefaultEndpoint {

	/**
	 * Lista de servidores sockets abertos no contexto
	 */
	private static HashMap<String, MinaServer> servers = new HashMap<String, MinaServer>();

	
	private MinaServer server;
	private ProtocolCodecFactory protocolCodecFactory;
	private String protocolo;

	/**
	 * 
	 * @author EYVC8F
	 * 
	 * @return ;
	 * @since 26/07/2012
	 */
	public String getProtocolo() {
		return protocolo;
	}

	/**
	 * 
	 * 
	 * @author EYVC8F
	 * 
	 * @param protocolo
	 *            ;
	 * @since 26/07/2012
	 */
	public void setProtocolo(final String protocolo) {
		this.protocolo= protocolo;
	}

	/**
	 * 
	 * @author EYVC8F
	 * 
	 * @param ip
	 *            ;
	 * @param port
	 *            ;
	 * @param endpointUri
	 *            ;
	 * @param component
	 *            ;
	 * @param parameters
	 *            ;
	 * @param camelContext
	 *            ;
	 * @since 26/07/2012
	 */
	public SocketAsynchRequestResponseEndpoint(final String ip, final int port,
											   final String endpointUri, final SocketAsynchRequestResponseComponent component,
											   final Map<String, Object> parameters, final CamelContext camelContext) {
		
		super(endpointUri, component);
		String key= ip + ":" + port;

		String protocol= (String) parameters.get("protocolo");
		if (protocol != null) {
			protocol= protocol.replaceAll("#", "");
			protocolCodecFactory= CamelContextHelper.mandatoryLookup(camelContext, protocol, ProtocolCodecFactory.class);
		}

		synchronized (servers) {
			if (!servers.containsKey(key)) {
				server= new MinaServer(port, protocolCodecFactory);

				servers.put(key, server);
			} else {
				server= servers.get(key);
			}
		}
	}

	@Override
	protected void doStart() throws Exception {
		server.start();
	}

	@Override
	public void doStop() throws Exception {
		server.stop();
	}

	/**
	 * Retorna instancia de produtor do ServerSocket por onde o camel retorna
	 * mensagens para o cliente.
	 * 
	 * @throws Exception
	 *             ;
	 * @return ;
	 */
	public Producer createProducer() throws Exception {
		return new MinaProducer(this, server.getHandler());
	}

	/**
	 * Retorna instande de consumidor por onde o cliente envia mensagens. Sendo
	 * consumido do lado do camel.
	 * 
	 * @param paramProcessor
	 *            ;
	 * @return Consumer;
	 * @throws Exception
	 *             ;
	 */
	public Consumer createConsumer(final Processor paramProcessor) throws Exception {
		MinaConsumer consumer= new MinaConsumer(this, paramProcessor);
		server.getHandler().setConsumer(consumer);
		
		return consumer;
	}

	/**
	 * @return boolean
	 */
	public boolean isSingleton() {
		return true;
	}

}
