/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.monitoracao.bam.amq.plugins;

import org.apache.activemq.broker.Broker;
import org.apache.activemq.broker.BrokerPlugin;

/**
 * <plugins>
 * <bean xmlns="http://www.springframework.org/schema/beans" id="FlowControlQueuePlugin"
 * class="com.abouchama.activemq.FlowControlQueuePlugin">
 * <property name="QueueName" value="xxxxx" />
 * <property name="MaxMessagesPerQueue" value="99" />
 * </bean>
 * </plugins> @author nemer
 */
public class QueueFlowControlPlugin implements BrokerPlugin {

    long maxMessagesPerQueue = 999999999;
    String queueName;

    public String getQueueName() {
        return queueName;
    }

    public void setQueueName(String queueName) {
        this.queueName = queueName;
    }

    public long getMaxMessagesPerQueue() {
        return maxMessagesPerQueue;
    }

    public void setMaxMessagesPerQueue(long maxMessagesPerQueue) {
        maxMessagesPerQueue = maxMessagesPerQueue;
    }

    @Override
    public Broker installPlugin(Broker broker) throws Exception {
        return new QueueFlowControl(broker, queueName, maxMessagesPerQueue);
    }
}
