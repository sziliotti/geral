package br.com.cielo.monitoracao.bam.integration.utils;

import java.util.Properties;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 *
 * @author Fernando Moraes (Smart Software)
 * @since 6.5.0
 */
@Component
public class ApplicationUtils implements ApplicationContextAware {

    // IDs de Beans Spring
    public static final String BEAN_CONFIGURATION_PROPERTIES = "configurationProperties";
    // Beans
    private static ApplicationContext context;
    private static Properties configurationProperties;

    private ApplicationUtils() {
    }

    public static ApplicationContext getContext() {
        return context;
    }

    public static String getConfiguration(String key, String defaultValue) {
        return getConfigurationProperties().getProperty(key, defaultValue);
    }

    private static Properties getConfigurationProperties() {
        if (configurationProperties == null) {
            configurationProperties = getContext().getBean(BEAN_CONFIGURATION_PROPERTIES, Properties.class);
        }
        return configurationProperties;
    }

	@Override
	public void setApplicationContext(ApplicationContext ac) throws BeansException {
        context = ac;
	}
}
