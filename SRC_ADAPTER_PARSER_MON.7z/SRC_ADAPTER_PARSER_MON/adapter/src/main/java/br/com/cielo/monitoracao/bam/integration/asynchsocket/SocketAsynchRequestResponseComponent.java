package br.com.cielo.monitoracao.bam.integration.asynchsocket;

import java.util.Map;

import org.apache.camel.CamelContext;
import org.apache.camel.Endpoint;
import org.apache.camel.impl.DefaultComponent;

/**
 *<B>Projeto: Stratus-Monitoracao-Adapter</B><BR>
 *
 * Componente camel para o Socket de entrada e saida assincrono.
 *	 
 *<DL><DT><B>Criada em:</B><DD>09/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 * @since 2011 - Versão inicial do projeto mainframe-adapter, feito por masousa.
 */
public class SocketAsynchRequestResponseComponent extends DefaultComponent{

	/**
	 * Construtor chamado pelo camel
	 * @param context contexto
	 */
    public SocketAsynchRequestResponseComponent(final CamelContext context) {
        super(context);
    }

    
	/**
	 * @param uri .
	 * @param remaining 
	 * @param parameters ;
	 * @throws Exception ;  
	 * @return Endpoint	 
	 */
	@Override
	protected Endpoint createEndpoint(final String uri, final String remaining, final Map<String, Object> parameters) throws Exception {
		String []ip= remaining.split(":");
		
		return new SocketAsynchRequestResponseEndpoint(ip[0], Integer.parseInt(ip[1]), uri, this, parameters, this.getCamelContext());
	}

}
