package br.com.cielo.monitoracao.bam.integration.jms.activemq;

import br.com.cielo.monitoracao.bam.integration.ExtractTypeProcessor;
import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.Session;
import org.apache.camel.Exchange;

/**
 * Produtos JMS para ActiveMQ.
 *
 * @author fernando.moraes
 */
public class AMQJmsProducerService {

    private static final String MSG_HEADER_SARRID = "sarrid";
    protected ConnectionFactory connectionFactory;
    protected Connection cachedConnection = null;
    protected Session cachedSession = null;
    protected MessageProducer cachedProducer;
    protected String queueName;

    public AMQJmsProducerService(String queueName, ConnectionFactory connectionFactory) {
        this.queueName = queueName;
        this.connectionFactory = connectionFactory;
    }

    public void resetConnection() {
        try {
            cachedProducer.close();
        } catch (Exception ex) {
        }
        try {
            cachedSession.close();
        } catch (Exception ex) {
        }
        try {
            cachedConnection.close();
        } catch (Exception ex) {
        }
        cachedProducer = null;
        cachedSession = null;
        cachedConnection = null;
    }

    public void sendMessage(Exchange exchange) throws Exception {
        try {
            BytesMessage bm = getSession().createBytesMessage();
            Object messageType = exchange.getIn().getHeader(ExtractTypeProcessor.MESSAGE_TYPE);
            Object idSession = exchange.getIn().getHeader(MSG_HEADER_SARRID);
            Object breadCrumbId = exchange.getIn().getHeader(Exchange.BREADCRUMB_ID);
            bm.writeBytes((byte[]) exchange.getIn().getBody());
            if (messageType != null) {
                bm.setIntProperty(ExtractTypeProcessor.MESSAGE_TYPE, messageType != null ? (Integer) messageType : null);
            }
            if (idSession != null) {
                bm.setLongProperty(MSG_HEADER_SARRID, idSession != null ? (Long) idSession : null);
            }
            if (breadCrumbId != null) {
                bm.setStringProperty(Exchange.BREADCRUMB_ID, breadCrumbId != null ? (String) breadCrumbId : null);
            }
            getProducer().send(bm);
        } catch (Exception ex) {
            // se encontra algum erro no envio, reseta a conexão e repassa exceção.
            exchange.setException(ex);
            resetConnection();
            throw ex;
        }
    }

    protected Connection getConnection() throws Exception {
        if (cachedConnection == null) {
            cachedConnection = connectionFactory.createConnection();
            cachedConnection.start();
        }
        return cachedConnection;
    }

    protected Session getSession() throws Exception {
        if (cachedSession == null) {
            cachedSession = getConnection().createSession(false, Session.AUTO_ACKNOWLEDGE);
        }
        return cachedSession;
    }

    protected MessageProducer getProducer() throws Exception {
        if (cachedProducer == null) {
            Destination destination = getSession().createQueue(queueName);
            cachedProducer = getSession().createProducer(destination);
            cachedProducer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
        }
        return cachedProducer;
    }
}
