package br.com.cielo.monitoracao.bam.integration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *<B>Projeto: Stratus-Monitoracao-Adapter</B><BR>
 *
 * Classe principal responsavel em inicializar o Adapter Socket que receberá mensagens do Stratus.
 *	 
 *<DL><DT><B>Criada em:</B><DD>09/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class Main {
	
	public static Logger logger= LoggerFactory.getLogger(Main.class);
	private static final String CONFIG_DEFAULT = "config/spring-context.xml";
	
	/**
	 * Método principal da classe.
	 * 
	 * @param args
	 */
	public static void main(String[] args){
		org.apache.camel.spring.Main main= new org.apache.camel.spring.Main();
		String config = CONFIG_DEFAULT;
		if (args.length > 0) {
			config = args[0];
		}
		main.setApplicationContext(new ClassPathXmlApplicationContext("file:" + config));
		main.enableHangupSupport();
		
		try {			
			main.run();
						
		} catch (Exception e) {
			logger.error("Falha ao manter ativo contexto do camel", e);
		}
	}
}
