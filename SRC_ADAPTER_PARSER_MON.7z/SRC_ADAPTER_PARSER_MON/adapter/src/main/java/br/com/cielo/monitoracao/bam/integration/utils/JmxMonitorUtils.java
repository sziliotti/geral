package br.com.cielo.monitoracao.bam.integration.utils;

import java.util.Hashtable;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

/**
 *
 * @author Fernando Moraes (Smart Software)
 * @since 6.5.0
 */
public class JmxMonitorUtils {

    private static final String JMX_OBJECT_DOMAIN = "br.com.cielo.monitoracao.adapter";
	public static final String JMX_OBJECT_TYPE_KEY = "type";
	public static final String JMX_OBJECT_NAME_KEY = "name";
	
	private JmxMonitorUtils() {
	}

	public static ObjectName buildObjectName(String name, String type) throws MalformedObjectNameException {
		Hashtable<String, String> values = new Hashtable<String, String>(3);
		values.put(JMX_OBJECT_NAME_KEY, name);
		values.put(JMX_OBJECT_TYPE_KEY, type);
		return new ObjectName(JMX_OBJECT_DOMAIN, values);
	}
}
