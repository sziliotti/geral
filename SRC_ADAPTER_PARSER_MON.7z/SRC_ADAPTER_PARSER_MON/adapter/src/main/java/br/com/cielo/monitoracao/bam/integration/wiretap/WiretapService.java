package br.com.cielo.monitoracao.bam.integration.wiretap;

import javax.jms.ConnectionFactory;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.BeanNameAware;

public class WiretapService implements Processor, BeanNameAware {

    protected String destination;
    protected WiretapExecutor wiretapExecutor;
    private String componentName;

    public WiretapService(String destination, ConnectionFactory connectionFactory) {
        this.destination = destination;
        this.wiretapExecutor = new WiretapExecutor(destination, connectionFactory);
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        wiretapExecutor.execute(exchange);
    }

    @Override
    public void setBeanName(String name) {
        this.componentName = name;
    }

    public String getComponentName() {
        return componentName;
    }
}
