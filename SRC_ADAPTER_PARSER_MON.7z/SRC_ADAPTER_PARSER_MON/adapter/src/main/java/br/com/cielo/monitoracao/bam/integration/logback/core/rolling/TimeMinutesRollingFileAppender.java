package br.com.cielo.monitoracao.bam.integration.logback.core.rolling;

import br.com.cielo.monitoracao.bam.integration.utils.ApplicationUtils;
import ch.qos.logback.core.FileAppender;
import ch.qos.logback.core.rolling.RollingFileAppender;
import ch.qos.logback.core.rolling.TimeBasedRollingPolicy;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Custom {@link FileAppender} to rollover at N minutes using rolling policy {@link TimeBasedRollingPolicy} with
 * {@code fileNamePattern} with pattern {@code %d{yyyy-MM-dd_HHmm}}.
 * @param <E>
 * 
 * @author fernando.moraes
 * @since 6.5.0
 */
public class TimeMinutesRollingFileAppender<E> extends RollingFileAppender<E> {

	private static long start = System.currentTimeMillis(); // minutes
	private Integer rollOverTimeIMillis;

	@Override
	public void rollover() {
		long currentTime = System.currentTimeMillis();
		Logger.getLogger(TimeMinutesRollingFileAppender.class.getName()).log(Level.FINEST, "debug: {0}, {1}, {2}, {3}",
			new Object[]{
				currentTime, start, getRollOverTimeIMillis(), ((currentTime - start) >= getRollOverTimeIMillis())
			}
		);
		if ((currentTime - start) >= getRollOverTimeIMillis()) {
			super.rollover();
			start = System.currentTimeMillis();
		}
	}

	/**
	 * @return the rollOverTimeIMillis
	 */
	public Integer getRollOverTimeIMillis() {
		if (rollOverTimeIMillis == null) {
			int intervalDefault = 5;
			try {
				intervalDefault = Integer.parseInt(ApplicationUtils.getConfiguration("lost.transactions.log.rolling.interval.minutes", Integer.toString(intervalDefault)));
			} catch (Exception ex) {
				Logger.getLogger(TimeMinutesRollingFileAppender.class.getName()).log(Level.WARNING, "Erro reading property in config file", ex);
			}
			rollOverTimeIMillis = intervalDefault * 60 * 1000;
		}
		return rollOverTimeIMillis;
	}
}
