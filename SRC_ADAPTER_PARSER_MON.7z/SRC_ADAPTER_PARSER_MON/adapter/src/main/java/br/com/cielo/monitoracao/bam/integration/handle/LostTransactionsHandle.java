package br.com.cielo.monitoracao.bam.integration.handle;

import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <B>Projeto: Stratus-Monitoracao-Adapter</B><BR>
 *
 * Classe responsavel em gravar as transações perdidas ou não enviadas ao ActiveMQ em um arquivo, separado por minuto.
 *
 * <DL><DT><B>Criada em:</B><DD>11/10/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class LostTransactionsHandle implements Processor {

    public static final String LOST_TRANSACTION_PROPERTY_DESTINATION = "DESTINATION";
	public static final String LOST_TRANSACTION_EXCEPTION_MARK = "ON_EXCEPTION";
    private static final Logger LOGGER = LoggerFactory.getLogger(LostTransactionsHandle.class);
    private static final Logger LOGGER_LOST = LoggerFactory.getLogger("LostTransactionsLogger");
    private static final AtomicInteger EXCHANGES_REJECTED_COUNT = new AtomicInteger(0);
    private final long groupInterval;

    public LostTransactionsHandle(long groupInterval) {
        this.groupInterval = groupInterval;
    }

    public void start() {
        Thread monitor = new Thread("LostTransactions Monitor") {
            @Override
            public void run() {
                Date now = new Date();
                while (true) {
                    try {
                        Thread.sleep(groupInterval);
                    } catch (InterruptedException e) {
                        throw new RuntimeException("Falhou ao executar sleep", e);
                    }
                    LOGGER.info(">>>> Contagem Mesagens GLOBAIS Armazenadas em Log de Perdidas: ["
                            + EXCHANGES_REJECTED_COUNT.get() + "] desde o ultimo startup: [" + now + "]"
                    );
                }
            }
        };
        monitor.start();
    }

    /**
     * Método responsavel em gravar a mensagem(já compactada) perdida em um arquivo, para posterior processamento.
     *
     * @param exchange
     * @throws java.lang.Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        EXCHANGES_REJECTED_COUNT.incrementAndGet();
        String destination = exchange.getProperty(LOST_TRANSACTION_PROPERTY_DESTINATION, "UNKNOWN", String.class);
        byte[] xPayloadCompress = (byte[]) exchange.getIn().getBody();
        logMessage(LOST_TRANSACTION_EXCEPTION_MARK, destination, Base64.encodeBase64String(xPayloadCompress));
    }

	public static void logMessage(String mark, String destination, String msg) {
		LOGGER_LOST.debug(mark + " " + destination + " " + msg);
	}
}
