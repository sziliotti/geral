package br.com.cielo.monitoracao.bam.integration.protocol.stratusbridge;

import br.com.cielo.monitoracao.bam.integration.protocol.m100.*;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolEncoder;

/**
 *<B>Projeto: Stratus-Monitoracao-Adapter</B><BR>
 *
 * Classe Factory para captura do encode e decode do protocolo M100.
 *	 
 *<DL><DT><B>Criada em:</B><DD>10/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 * @since 26/07/2012 - Versão inicial do projeto mainframe-adapter, feito por EYVC8F.
 */
public class StratusBridgeProtocolCodecFactory implements ProtocolCodecFactory {

	/**
	 * @param session ;
	 * @throws Exception ;
	 * @return ; 
	 */
	public ProtocolEncoder getEncoder(final IoSession session) throws Exception {
		return new StratusBridgeProtocolEncoder();
	}

	/**
	 * @param session ;
	 * @throws Exception ;
	 * @return ;
	 */
	public ProtocolDecoder getDecoder(final IoSession session) throws Exception {
		return new StratusBridgeProtocolDecoder();
	}

}
