package br.com.cielo.monitoracao.bam.integration.protocol.m100;

import java.io.ByteArrayOutputStream;

import org.apache.commons.io.HexDump;
import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolEncoder;
import org.apache.mina.filter.codec.ProtocolEncoderOutput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *<B>Projeto: Stratus-Monitoracao-Adapter</B><BR>
 *
 * Classe que faz a codificacao(encode) da mensagem para o protocolo M100.
 *	 
 *<DL><DT><B>Criada em:</B><DD>10/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 * @since 26/07/2012 - Versão inicial do projeto mainframe-adapter, feito por EYVC8F.
 */
public class M100ProtocolEncoder implements ProtocolEncoder{

	private static final Logger logger = LoggerFactory.getLogger(M100ProtocolEncoder.class);

	/**
     * Encodes higher-level message objects into binary or protocol-specific data.
     * MINA invokes {@link #encode(IoSession, Object, ProtocolEncoderOutput)}
     * method with message which is popped from the session write queue, and then
     * the encoder implementation puts encoded messages (typically {@link IoBuffer}s)
     * into {@link ProtocolEncoderOutput}.
     *
     * @param session ;
     * @param object ;
     * @param out ;
     * 
     * @throws Exception if the message violated protocol specification
     */
	public void encode(final IoSession session, final Object object, final ProtocolEncoderOutput out) throws Exception {
		byte[] msg= (byte[]) object;
		
		IoBuffer buffer= IoBuffer.allocate(msg.length + 2);
		
		if(logger.isDebugEnabled())	{
			ByteArrayOutputStream stream= new ByteArrayOutputStream();
			HexDump.dump(msg, 0, stream, 0);
			
			logger.debug( "Enviando:\n" + stream.toString() );
		}

		buffer.putShort((short)msg.length);		
		buffer.put(msg);
		buffer.flip();		
		
		out.write(buffer);
	}

	 /**
     * Releases all resources related with this encoder.
     * 
     * @param session ;
     *
     * @throws Exception if failed to dispose all resources
     */
	public void dispose(final IoSession session) throws Exception {
		
	}

}
