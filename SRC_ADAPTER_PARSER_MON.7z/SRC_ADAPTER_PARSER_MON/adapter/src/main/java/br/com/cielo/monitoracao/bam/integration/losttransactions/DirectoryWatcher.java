package br.com.cielo.monitoracao.bam.integration.losttransactions;

import br.com.cielo.monitoracao.bam.integration.ExtractTypeProcessor;
import br.com.cielo.monitoracao.bam.integration.balancer.StratusAdapterBalancer;
import br.com.cielo.monitoracao.bam.integration.handle.LostTransactionsHandle;
import br.com.cielo.monitoracao.bam.integration.utils.ConverterUtils;
import br.com.cielo.monitoracao.bam.integration.utils.JmxMonitorUtils;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import static java.nio.file.StandardWatchEventKinds.ENTRY_CREATE;
import static java.nio.file.StandardWatchEventKinds.OVERFLOW;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.GZIPOutputStream;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import org.apache.camel.CamelContext;
import org.apache.camel.CamelContextAware;
import org.apache.camel.Endpoint;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.jmx.export.naming.SelfNaming;

/**
 * Observador do diretorio de log de transacoes perdidas.
 *
 * @author fernando.moraes (Smart Software)
 * @since 6.5.0
 */
@ManagedResource(description = "Monitor do diretorio de logs de transacoes perdidas")
public class DirectoryWatcher implements SelfNaming, BeanNameAware, CamelContextAware {

    private static final Logger LOGGER = LoggerFactory.getLogger(DirectoryWatcher.class);
	private static final Logger LOGGER_LOST = LoggerFactory.getLogger("LostTransactionsLogger");
	private static final AtomicInteger MONITOR_FILES_CREATED = new AtomicInteger(0);
	private static final AtomicInteger MONITOR_FILES_FOUND = new AtomicInteger(0);
	private static final AtomicInteger MONITOR_FILES_PROCS = new AtomicInteger(0);
	private static final AtomicInteger MONITOR_LINES_PROCS = new AtomicInteger(0);
	private static final String ENDPOINT_NAME = "vm:inputQueue";
	private static final String FILE_GZIP_EXTENSION = ".gz";
	private static final String PROP_LAST_FILE = "last.file";
	private static final String PROP_LAST_TIMESTAMP = "last.timestamp";
	private static final String LOST_TRS_LOG_MARK = "ROLLOVER";
	private static final String LOST_TRS_LOG_DST = "LOG";
	private static final String LOST_TRS_LOG_MSG = "EMPTY";
	private final AtomicInteger threadPoolSize = new AtomicInteger(0);
    private String componentName;
    private CamelContext camelContext;
	private Endpoint endpoint;
	private ProducerTemplate producerTemplate;
    private WatchService watcher;
    private Map<WatchKey,Path> keys;
	private Properties properties;
	private ExecutorService threadPool;
	private ConcurrentLinkedQueue<File> oldRollingFilesQueue;
    private long groupInterval;
	private String logDirectory;
	private String fileControl;
	private String filePrefix;
	private String fileExtension;
    private int rollingInterval;
    private int rollingMaxFiles;

    @Override
    public void setCamelContext(CamelContext camelContext) {
        this.camelContext = camelContext;
    }

    @Override
    public CamelContext getCamelContext() {
        return camelContext;
    }

	public void setGroupInterval(long groupInterval) {
		this.groupInterval = groupInterval;
	}

	public void setLogDirectory(String logDirectory) {
		this.logDirectory = logDirectory;
	}

	public void setFileControl(String fileControl) {
		this.fileControl = fileControl;
	}

	public void setFilePrefix(String filePrefix) {
		this.filePrefix = filePrefix;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public void setRollingInterval(int rollingInterval) {
		this.rollingInterval = rollingInterval;
	}

	public void setRollingMaxFiles(int rollingMaxFiles) {
		this.rollingMaxFiles = rollingMaxFiles;
	}

	public void start() throws IOException {
		watcher = FileSystems.getDefault().newWatchService();
        keys = new HashMap<WatchKey,Path>();
		properties = new Properties();
		properties.load(new FileInputStream(fileControl));
        Path dir = Paths.get(logDirectory);
        WatchKey key = dir.register(watcher, ENTRY_CREATE);
        keys.put(key, dir);
		endpoint = getCamelContext().getEndpoint(ENDPOINT_NAME);
		producerTemplate = getCamelContext().createProducerTemplate();
		ThreadFactory namedThreadFactory = new ThreadFactoryBuilder().setNameFormat("DirectoryWatcher Log Processor %d").build();
		threadPool = Executors.newSingleThreadScheduledExecutor(namedThreadFactory);
		prepareQueueOfOldRollingFiles(dir);
//		final RollingFileAppender appender = (RollingFileAppender) ((ch.qos.logback.classic.Logger) LOGGER_LOST).getAppender("lostTransactions");
		Thread monitor = new Thread("DirectoryWatcher Monitor") {
            @Override
            public void run() {
                Date now = new Date();
				long start = System.currentTimeMillis(); // minutes
				int maxIntervalSinceLastLoggingInMillis = rollingInterval * 60 * 1000;
                while (true) {
                    try {
                        Thread.sleep(groupInterval);
						long currentTime = System.currentTimeMillis();
						if ((currentTime - start) >= maxIntervalSinceLastLoggingInMillis) {
//							try {
//								appender.rollover();
//							} catch (Exception e) {
//								LOGGER.warn("Erro no rollover do log das transacoes perdidas", e);
//							}
							LostTransactionsHandle.logMessage(LOST_TRS_LOG_MARK, LOST_TRS_LOG_DST, LOST_TRS_LOG_MSG);
							start = currentTime;
						}
                    } catch (InterruptedException e) {
                        throw new RuntimeException("Falhou ao executar sleep", e);
                    }
                    LOGGER.info(">>>> Arquivos Encontrados: [{}], Processados: [{}] com "
							+ "Mensagens Perdidas Reprocessadas: [{}] desde o ultimo startup: [{}]"
							, MONITOR_FILES_FOUND.get(), MONITOR_FILES_PROCS.get(), MONITOR_LINES_PROCS.get(), now
                    );
                }
            }
        };
        monitor.start();
        monitor = new Thread("DirectoryWatcher Processor") {
            @Override
            public void run() {
				processEvents();
            }
        };
        monitor.start();
	}

	public void stop() {
		LOGGER.info("Finalizando DirectoryWatcher");
		threadPool.shutdown();
	}

	private void prepareQueueOfOldRollingFiles(Path dir) {
		List<File> files = new ArrayList<File>();
		String filePattern = filePrefix + "*" + fileExtension + FILE_GZIP_EXTENSION;
		for (File f : dir.toFile().listFiles()) {
			if (f.isFile() && FilenameUtils.wildcardMatch(f.getName(), filePattern)) {
				files.add(f);
			}
		}
		Collections.sort(files);
		oldRollingFilesQueue = new ConcurrentLinkedQueue<File>();
		for (File f : files) {
			oldRollingFilesQueue.add(f);
		}
		LOGGER.info("Arquivos em fila de exclusão: {}", oldRollingFilesQueue.size());
	}

	private void deleteOldRollingFiles() {
		LOGGER.debug("deleteOldRollingFiles - size: {}", oldRollingFilesQueue.size());
		if (oldRollingFilesQueue.size() > rollingMaxFiles) {
			File f = oldRollingFilesQueue.poll();
			LOGGER.debug("deleteOldRollingFiles: - delete: {}", f.getName());
			FileUtils.deleteQuietly(f);
			deleteOldRollingFiles();
		}
	}

	/**
     * Process all events for keys queued to the watcher
     */
    private void processEvents() {
		while (true) {
			// wait for key to be signalled
			WatchKey key;
			try {
				key = watcher.take();
			} catch (InterruptedException x) {
				return;
			}
			Path dir = keys.get(key);
			if (dir == null) {
				LOGGER.warn("WatchKey desconhecido: {}", key);
				continue;
			}
			for (WatchEvent<?> event : key.pollEvents()) {
				WatchEvent.Kind kind = event.kind();
				// TBD - provide example of how OVERFLOW event is handled
				if (kind == OVERFLOW) {
					continue;
				}
				// Context for directory entry event is the file name of entry
				WatchEvent<Path> ev = cast(event);
				Path name = ev.context();
				Path child = dir.resolve(name);
				// print out event
				String filename = child.toFile().getName();
				if (!filename.endsWith(FILE_GZIP_EXTENSION)) {
					MONITOR_FILES_CREATED.incrementAndGet();
					LOGGER.debug("{}({}): {}", event.kind().name(), MONITOR_FILES_CREATED.get(), child);
					if (filename.startsWith(filePrefix) && filename.endsWith(fileExtension)) {
						MONITOR_FILES_FOUND.incrementAndGet();
						processLog(child.toFile());
					}
				}
			}
			// reset key and remove from set if directory no longer accessible
			boolean valid = key.reset();
			if (!valid) {
				keys.remove(key);
				// all directories are inaccessible
				if (keys.isEmpty()) {
					break;
				}
			}
		}
    }

	private void processLog(File fileLog) {
		LOGGER.debug("Verificando Log: {}", fileLog);
		String arquivo = properties.getProperty(PROP_LAST_FILE);
		if (StringUtils.isBlank(arquivo)) {
			arquivo = fileLog.getName();
		} else {
			String logStamp = StringUtils.removeStart(StringUtils.removeEnd(fileLog.getName(), fileExtension), filePrefix);
			String arqStamp = StringUtils.removeStart(StringUtils.removeEnd(arquivo, fileExtension), filePrefix);
			boolean teste = logStamp.compareTo(arqStamp) < 0;
			LOGGER.debug("Teste: {} < {} = {}", logStamp, arqStamp, teste);
			if (teste) {
				return;
			}
			arquivo = fileLog.getName();
		}
		MONITOR_FILES_PROCS.incrementAndGet();
		LOGGER.info("Processando Log: {}", fileLog);
		properties.setProperty(PROP_LAST_FILE, arquivo);
		saveProperties();
		threadPool.execute(new ProcessLogHandle(fileLog));
	}

	private void processLineLog(String line) {
		String[] infos = line.split("\\s");
		if (infos.length < 5) {
			LOGGER.warn("Registro desprezado - campos: {}", infos.length);
			return;
		}
		if (!LostTransactionsHandle.LOST_TRANSACTION_EXCEPTION_MARK.equals(infos[2])) {
			LOGGER.debug("Registro desprezado - excecao: {}", infos[2]);
			return;
		}
		String registro = infos[0];
		String ultimoRegistro = properties.getProperty(PROP_LAST_TIMESTAMP);
		if (StringUtils.isNotBlank(ultimoRegistro)) {
			if (registro.compareTo(ultimoRegistro) < 0) {
				LOGGER.debug("Registro desprezado - horario: {}", registro);
				return;
			}
		}
		properties.setProperty(PROP_LAST_TIMESTAMP, registro);
		saveProperties();
		MONITOR_LINES_PROCS.incrementAndGet();
		byte[] message = ConverterUtils.unzipMessage(Base64.decodeBase64(infos[infos.length - 1]));
		String destination = infos[infos.length - 2];
		LOGGER.debug("Info lido: {} - {} - {}", registro, destination, Arrays.toString(message));
		Exchange exchange = endpoint.createExchange();
		exchange.getIn().setHeader(Exchange.BREADCRUMB_ID, infos[1]);
		exchange.getIn().setHeader(StratusAdapterBalancer.MESSAGE_DESTINATION, destination);
		exchange.getIn().setHeader(ExtractTypeProcessor.MESSAGE_TYPE, 1);
		exchange.getIn().setBody(message);
		Exchange sended = producerTemplate.send(endpoint, exchange);
		LOGGER.debug("Exchange: id={}, transacted={}, failed={}", 
				sended.getExchangeId(),
				sended.isTransacted(),
				sended.isFailed(), 
				sended.getException()
		);
	}

	private void saveProperties() {
		FileOutputStream output = null;
		try {
			output = new FileOutputStream(fileControl);
			properties.store(output, null);
		} catch (IOException ex) {
			LOGGER.error("Erro gravando arquivo", ex);
		} finally {
			if (output != null) {
				try {
					output.close();
				} catch (IOException ex) {
					LOGGER.error("Erro fechando arquivo", ex);
				}
			}
		}
	}

	private void compressLog(File fileLog) {
		LOGGER.debug("Compactando Log: {}", fileLog);
		String inFilename = fileLog.getAbsolutePath();
		String outFilename = inFilename + FILE_GZIP_EXTENSION;
		BufferedWriter bw = null;
		BufferedReader br = null;
		try {
			//Construct the BufferedWriter object
			bw = new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(new FileOutputStream(outFilename))));
			//Construct the BufferedReader object
			br = new BufferedReader(new FileReader(inFilename));
			String line;
			// from the input file to the GZIP output file
			while ((line = br.readLine()) != null) {
				if (!isLineLogRollover(line)) {
					bw.write(line);
					bw.newLine();
				}
			}
			oldRollingFilesQueue.add(new File(outFilename));
			FileUtils.deleteQuietly(fileLog);
		} catch (IOException ex) {
			LOGGER.error("Erro compactando arquivo", ex);
		} finally {
			//Close the BufferedWrter
			if (bw != null) {
				try {
					bw.close();
				} catch (IOException ex) {
					LOGGER.error("Erro fechando arquivo compactado", ex);
				}
			}
			//Close the BufferedReader
			if (br != null) {
				try {
					br.close();
				} catch (IOException ex) {
					LOGGER.error("Erro fechando arquivo para compactacao", ex);
				}
			}
		}
	}

	private boolean isLineLogRollover(String line) {
		String[] infos = line.split("\\s");
		return infos.length > 2 && LOST_TRS_LOG_MARK.equals(infos[2]);
	}

	@SuppressWarnings("unchecked")
    private <T> WatchEvent<T> cast(WatchEvent<?> event) {
        return (WatchEvent<T>)event;
    }

	class ProcessLogHandle implements Runnable {
		private final File fileLog;

		public ProcessLogHandle(File fileLog) {
			this.fileLog = fileLog;
			threadPoolSize.incrementAndGet();
			LOGGER.debug(">>>> threadPoolSize: " + threadPoolSize.get());
		}

		@Override
		public void run() {
			FileReader fr = null;
			BufferedReader br = null;
			try {
				fr = new FileReader(fileLog);
				br = new BufferedReader(fr);
				for (String line; (line = br.readLine()) != null;) {
					processLineLog(line);
				}
				compressLog(fileLog);
				deleteOldRollingFiles();
			} catch (IOException ex) {
				LOGGER.error("Erro lendo arquivo", ex);
			} finally {
				if (fr != null) {
					try {
						fr.close();
					} catch (IOException ex) {
						LOGGER.error("Erro fechando arquivo", ex);
					}
				}
				if (br != null) {
					try {
						br.close();
					} catch (IOException ex) {
						LOGGER.error("Erro fechando leitor do arquivo", ex);
					}
				}
				threadPoolSize.decrementAndGet();
				LOGGER.debug("<<<< threadPoolSize: " + threadPoolSize.get());
			}
		}
	}

	@Override
	public void setBeanName(String name) {
        this.componentName = name;
    }

	@Override
	public ObjectName getObjectName() throws MalformedObjectNameException {
		return JmxMonitorUtils.buildObjectName(componentName, "watcher");
	}

	/**
	 * @return the MONITOR_FILES_FOUND
	 */
    @ManagedAttribute
	public long getFilesFound() {
		return MONITOR_FILES_FOUND.longValue();
	}

	/**
	 * @return the MONITOR_FILES_PROCS
	 */
    @ManagedAttribute
	public long getFilesProcess() {
		return MONITOR_FILES_PROCS.longValue();
	}

	/**
	 * @return the MONITOR_THREAD_POOL_SIZE
	 */
    @ManagedAttribute
	public long getFilesWaitingProcess() {
		return threadPoolSize.longValue();
	}

	/**
	 * @return the last file process
	 */
    @ManagedAttribute
	public String getLastFile() {
		return properties.getProperty(PROP_LAST_FILE);
	}

	/**
	 * @return the last timestamp process
	 */
    @ManagedAttribute
	public String getLastTimestamp() {
		return properties.getProperty(PROP_LAST_TIMESTAMP);
	}

	/**
	 * Reset counters.
	 */
    @ManagedOperation
    public void resetStats() {
        MONITOR_FILES_FOUND.set(0);
        MONITOR_FILES_PROCS.set(0);
    }

	/**
	 * Reset last file statistics.
	 */
    @ManagedOperation
    public void resetLastFileStats() {
		properties.setProperty(PROP_LAST_FILE, StringUtils.EMPTY);
		properties.setProperty(PROP_LAST_TIMESTAMP, StringUtils.EMPTY);
    }
}
