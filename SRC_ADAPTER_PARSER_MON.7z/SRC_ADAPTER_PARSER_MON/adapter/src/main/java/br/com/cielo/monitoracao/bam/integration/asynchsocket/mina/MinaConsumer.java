package br.com.cielo.monitoracao.bam.integration.asynchsocket.mina;

import java.util.UUID;

import org.apache.camel.Endpoint;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.impl.DefaultConsumer;
import org.apache.commons.codec.binary.Hex;

/**
 * <B>Projeto: Stratus-Monitoracao-Adapter</B><BR>
 *
 * Componente consumidor que recebe entrada do socket e insere no contexto do
 * Camel.
 *
 * <DL><DT><B>Criada em:</B><DD>09/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 * @since 2011 - Versão inicial do projeto mainframe-adapter, feito por masousa.
 */
public class MinaConsumer extends DefaultConsumer {

    /**
     *
     *
     * @author EYVC8F
     *
     * @param endpoint ;
     * @param processor ;
     * @since 26/07/2012
     */
    public MinaConsumer(final Endpoint endpoint, final Processor processor) {
        super(endpoint, processor);
    }

    /**
     * Recebe mensagem de servidor socket
     *
     * @param message mensagem de entrada
     * @param idSession identificador da conexao de entrada
     * @throws Exception ;
     */
    public void post(final Object message, final long idSession) throws Exception {
        //String correlationId = Hex.encodeHexString(md.digest(UUID.randomUUID().toString().getBytes()));
        // comentado uso do MD5 pois ele não é thread-safe
        String correlationId= Hex.encodeHexString(UUID.randomUUID().toString().getBytes());
        Exchange exchange= getEndpoint().createExchange();
        exchange.getIn().setHeader("sarrid", idSession);
        exchange.getIn().setHeader(Exchange.BREADCRUMB_ID, correlationId);
        exchange.getIn().setBody(message);

        getProcessor().process(exchange);
    }
}
