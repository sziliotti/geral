package br.com.cielo.monitoracao.bam.integration.asynchsocket.mina;

import java.net.InetSocketAddress;

import org.apache.mina.core.service.IoAcceptor;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.SocketSessionConfig;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;

/**
 *<B>Projeto: Stratus-Monitoracao-Adapter</B><BR>
 *
 * Implementacao de ServidorSocket assincrono gerenciado pelo Mina.
 *	 
 *<DL><DT><B>Criada em:</B><DD>09/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 * @since 2011 - Versão inicial do projeto mainframe-adapter, feito por masousa. 
 */
public class MinaServer{
	
	/** Tamanho do buffer de leitura do socket **/
	final int SIZE_MAX_BUFFER_READ = 64*1024;
	
	
	private IoAcceptor acceptor;
	private final int port;
	private boolean started;
	private final ProtocolCodecFactory protocolCodecFactory;
	
	//private static final Logger logger = LoggerFactory.getLogger(MinaServer.class);	
	
	/**
	 * 
	 * @author EYVC8F
	 *
	 * @return ;
	 * @since 26/07/2012
	 */
	public boolean isStarted() {
		return started;
	}

	/**
	 * 
	 * @author EYVC8F
	 *
	 * @param port ;
	 * @param protocolCodecFactory ;
	 * @since 26/07/2012
	 */
	public MinaServer(final int port , final ProtocolCodecFactory protocolCodecFactory) {
		this.port= port;
		this.protocolCodecFactory= protocolCodecFactory;
	}

	/**
	 * Inicia servidor socket para recepcao de conexoes
	 * 
	 * @throws Exception ;
	 */
	public void start() throws Exception {
		if(!started){
			acceptor= new NioSocketAcceptor(Runtime.getRuntime().availableProcessors());
	       /*	configureJMX(acceptor);*/
	       	
			ProtocolCodecFilter protocolCodecFilter= new ProtocolCodecFilter(protocolCodecFactory);
	       	acceptor.getFilterChain().addLast("codec", protocolCodecFilter);
	       	acceptor.setHandler(new MinaHandler());

	       	// Altera tamanho do buffer de  recepcao por sessao
			this.acceptor.getSessionConfig().setMaxReadBufferSize(SIZE_MAX_BUFFER_READ);
			this.acceptor.getSessionConfig().setMinReadBufferSize(SIZE_MAX_BUFFER_READ);
	       	((SocketSessionConfig)acceptor.getSessionConfig()).setTrafficClass(0x04);
	       	((SocketSessionConfig)acceptor.getSessionConfig()).setTcpNoDelay(true);

	       	acceptor.bind(new InetSocketAddress(port));
	       		       	
	       	started = true;
		}
	}
	
	/**
	 * Rotina para ativar JMX para monitoramento do MINA
	 * 
	 * @param objectToJmx ;
	 */
	/*private void configureJMX(IoAcceptor objectToJmx ) {

		MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();
		IoServiceMBean acceptorMBean = new IoServiceMBean( objectToJmx );
		
		try {
			
			ObjectName objectName;			
			objectName = new ObjectName( objectToJmx.getClass().getPackage().getName() +
					":type=acceptor,name=" + objectToJmx.getClass().getSimpleName());
			
			mBeanServer.registerMBean( acceptorMBean, objectName );
			
		} catch (Exception e) {
			if (LOGGER.isWarnEnabled()) {
				LOGGER.warn("Erro ativando JMX:", e);
			}
		}
	}*/

	/**
	 * Retorna interface para facilitar a comunicacao entre os producers e consumers do camel com a conexao socket
	 * 
	 * @return ;
	 */
	public MinaHandler getHandler(){
		return (MinaHandler) acceptor.getHandler();
	}
	
	/**
	 * Para servidor socket
	 * 
	 * @throws Exception ;
	 */
	public void stop() throws Exception {
		if(acceptor!=null){
			acceptor.unbind();
			acceptor = null;
		}
	}
	
}
