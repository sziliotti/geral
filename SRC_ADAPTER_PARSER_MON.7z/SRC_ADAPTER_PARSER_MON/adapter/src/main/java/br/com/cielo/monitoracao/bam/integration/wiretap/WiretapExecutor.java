package br.com.cielo.monitoracao.bam.integration.wiretap;

import br.com.cielo.monitoracao.bam.integration.jms.activemq.AMQJmsProducerService;
import javax.jms.ConnectionFactory;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;

public class WiretapExecutor {

    private final AMQJmsProducerService producer;

    public WiretapExecutor(String destination, ConnectionFactory connectionFactory) {
        this.producer = new AMQJmsProducerService(destination, connectionFactory);
    }

    public void execute(Exchange exchange) throws Exception {
        exchange.setPattern(ExchangePattern.InOnly);
        producer.sendMessage(exchange);
    }
}
