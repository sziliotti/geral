package br.com.cielo.monitoracao.bam.integration.protocol.m100;

import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.CumulativeProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolDecoderOutput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *<B>Projeto: Stratus-Monitoracao-Adapter</B><BR>
 *
 * Classe que faz a codificacao(decode) da mensagem para o protocolo M100.
 *	 
 *<DL><DT><B>Criada em:</B><DD>10/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 * @since 2011 - Versão inicial do projeto mainframe-adapter, feito por masousa.
 */
public class M100ProtocolDecoder extends CumulativeProtocolDecoder {
	private static final Logger logger= LoggerFactory.getLogger(M100ProtocolDecoder.class);	
		
	private static final short PAYLOAD_MAX_SIZE = 10240;
		
	/* (non-Javadoc)
	 * @see org.apache.mina.filter.codec.CumulativeProtocolDecoder#doDecode(org.apache.mina.core.session.IoSession, org.apache.mina.core.buffer.IoBuffer, org.apache.mina.filter.codec.ProtocolDecoderOutput)
	 */
	@Override
	protected boolean doDecode(IoSession session, IoBuffer ioBuffer, ProtocolDecoderOutput out) throws Exception {		
		// Existem menos de 2 bytes no buffer?
		// Caso sim, entao nao existe o numero de dados suficientes para iniciar processamento, portanto deixa os dados no buffer ate 
		// receber o resto.
		int iPosicaoInicial= ioBuffer.position();
		if(ioBuffer.remaining() < 2)
			return false;
		
		// Dois bytes de tamanho encontados no buffer, entao obtem tamanho.
		short iTamanho= ioBuffer.getShort();			
			//short iTamanho= 2436 + 1;
		if(iTamanho > PAYLOAD_MAX_SIZE) {
			// O tamanho lido eh maior que o permitido, entao limpa buffer. 
			logger.warn("Tamanho invalido recebido (" + iTamanho + ") " + "na conexao: " + session.getRemoteAddress().toString());
			
			ioBuffer.clear();
			return false;				
		}
		
		// Tratando keep-alive enviado pelo host
		if(iTamanho == 0) {
			logger.info("Keep-alive recebido de: " + session.getRemoteAddress().toString());
			return true;
		}
				
		// Existe menos dados do buffer do que o tamanho do payload?
		// Caso sim, entao nao existe o numero de dados suficientes para iniciar processamento, portanto deixa os dados no buffer ate 
		// receber o resto.		
		if(ioBuffer.remaining() < iTamanho) {				
			ioBuffer.position(iPosicaoInicial);
			
			return false;
		}
		
		// Foi encontrado um payload completo no buffer, entao recupera, extrai os e repassa payload encontrado.
		byte[] xPayload= new byte[iTamanho];
		ioBuffer.get(xPayload);
		
		// Repassando payload encontrado.
		out.write(xPayload);
		
		return true;		
	}	
}