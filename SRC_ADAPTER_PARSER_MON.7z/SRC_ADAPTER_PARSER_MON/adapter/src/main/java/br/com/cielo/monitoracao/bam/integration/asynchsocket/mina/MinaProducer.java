package br.com.cielo.monitoracao.bam.integration.asynchsocket.mina;

import org.apache.camel.Endpoint;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Produtor de mensagens a serem devolvidas pelo SocketServer
 * @author masousa
 * @since 2011
 *
 */

/**
 *<B>Projeto: Stratus-Monitoracao-Adapter</B><BR>
 *
 * Produtor de mensagens a serem devolvidas pelo SocketServer.
 *	 
 *<DL><DT><B>Criada em:</B><DD>09/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 * @since 2011 - Versão inicial do projeto mainframe-adapter, feito por masousa.
 */
public class MinaProducer extends DefaultProducer{

	/** Atributo **/
	private final MinaHandler handler;
	
	/**
	 * Logger
	 */
	private static final Logger logger = LoggerFactory.getLogger(MinaProducer.class);
	
	/**
	 *  
	 *
	 * @author EYVC8F
	 *
	 * @param endpoint ;
	 * @param handler ;
	 * @since 26/07/2012
	 */
	public MinaProducer(final Endpoint endpoint,final MinaHandler handler) {
		super(endpoint);
		this.handler = handler;
	}

	/**
	 * Envia mensagem para a conexao socket utilizando o parametro de cabecalho 'sarrid' para localizar a conexao de retorno
	 * 
	 * @param exchange ;
	 * @throws Exception ;
	 */
	public void process(final Exchange exchange) throws Exception {
		long id= (Long) exchange.getIn().getHeader("sarrid");
		handler.post(exchange.getIn().getBody(), id);		
	}
}
