package br.com.cielo.monitoracao.bam.integration;

import br.com.cielo.monitoracao.autorizador.parser.ParserConverterUtils;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoParserBuilder;
import br.com.cielo.monitoracao.autorizador.parser.TransacaoStratusParser;
import br.com.cielo.monitoracao.autorizador.parser.vo.stratus.logicos.CPO_010;
import static br.com.cielo.monitoracao.bam.integration.balancer.StratusAdapterBalancer.MESSAGE_DESTINATION;
import br.com.cielo.monitoracao.bam.integration.utils.ConverterUtils;
import com.github.ffpojo.FFPojoHelper;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Level;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.io.HexDump;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * <B>Projeto: Stratus-Monitoracao-Adapter</B><BR>
 *
 * Classe responsavel em extrair o tipo do processor, e retirada dos 2 bytes
 * inicias da mensagem. Após isso efetua compactação da mensagem, antes de
 * postar no ActiveMQ.
 *
 * <DL><DT><B>Criada em:</B><DD>10/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
@Service(value = "extractType")
public class ExtractTypeProcessor implements Processor {

    private static final Logger logger = LoggerFactory.getLogger(ExtractTypeProcessor.class);
    // Logger responsavel em gerar o trace completo da mensagem recebida do Stratus.
    private static final Logger loggerBKPFull = LoggerFactory.getLogger("BackupLoggerFull");
    // Logger responsavel em gerar apenas o conteudo descompactado da mensagem recebida do Stratus.
    private static final Logger loggerBKP = LoggerFactory.getLogger("BackupLogger");
	// Logger reponsavel pelas mensagens encaminhadas para saida "stderr"
	private static final java.util.logging.Logger errLogger = java.util.logging.Logger.getLogger(ExtractTypeProcessor.class.getName());

    public static final byte TYPE_SIZE = 4;
    public static final String MESSAGE_TYPE = "_MAINFRAME_MESSAGE_TYPE";

    /* (non-Javadoc)
     * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        byte[] xPayload = (byte[]) exchange.getIn().getBody();

        if (logger.isDebugEnabled()) {
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            HexDump.dump(xPayload, 0, stream, 0);

            logger.debug("Recebendo:\n" + stream.toString());
        }
		if (StringUtils.isNotBlank(exchange.getIn().getHeader(MESSAGE_DESTINATION, String.class))
				&& exchange.getIn().getHeader(MESSAGE_TYPE) != null) {
			// se true, mensagem perdida (lost-transaction) sendo reprocessada atraves do DirectorWatcher
			// foi preparada anteriormente
			// Compactando o conteudo da mensagem antes de repassar.
			byte[] xPayloadCompress = ConverterUtils.zipMessage(xPayload);
			exchange.getIn().setBody(xPayloadCompress);
			return;
		}

        // Recupera e mascara informações(o número) do cartão.
        byte[] xPayloadWoCardNumber = this.ofuscarInformacoesCartao(xPayload);

        // Compactando o conteudo da mensagem antes de repassar.
        //byte[] xPayloadCompress= ConverterUtils.zipMessage(xPayload);
        byte[] xPayloadCompress = ConverterUtils.zipMessage(xPayloadWoCardNumber);

        // Gera dump da mensagem recebida em arquivo diario separado, para auditoria posterior.
        //this.gravarDumpMensagens(xPayload, xPayloadCompress);
        this.gravarDumpMensagens(xPayloadWoCardNumber, xPayloadCompress);

        // Repassando mensagem compactada.
        exchange.getIn().setBody(xPayloadCompress);
        exchange.getIn().setHeader(MESSAGE_TYPE, 1);
    }

    /**
     * Método responsavel em gerar o dump da mensagem recebida para controle e
     * posterior auditoria. Esse processo é dividido em 2 partes:
     * <br><br>
     * <D>- É gerado um arquivo com o trace completo das transações capturadas
     * dos Stratus. Contendo: data/hora, tamanho e conteudo da mensagem
     * descompactada; e tamanho e conteudo da mensagem compactada.
     * <D>- É gerado um arquivo contendo apenas o conteudo da mensagem
     * descompactada vinda do Stratus; utilizado para futuro debug da aplicação.
     *
     * @param xPayload Array de bytes contendo a mensagem recebida.
     * @param xPayloadCompress Array de bytes compactado da mensagem recebida.
     * @throws IOException
     */
    private void gravarDumpMensagens(byte[] xPayload, byte[] xPayloadCompress) throws IOException {
        // Fluxo que gera o trace completo das mensagens(data-hora, tamanho e conteudo da mensagem compactada e descompactada) em um arquivo especifico.
        loggerBKPFull.debug("=================================================================================================================================================================");
        loggerBKPFull.debug("Mensagem Normal[Tamanho: " + xPayload.length + " bytes]: " + ConverterUtils.bytesToHex(xPayload));
        loggerBKPFull.debug("Mensagem Compactada[Tamanho: " + xPayloadCompress.length + " bytes]: " + ConverterUtils.bytesToHex(xPayloadCompress));
        loggerBKPFull.debug("=================================================================================================================================================================");

        // Gera a mensagem descompacta no arquivo de log especifico.
        loggerBKP.debug(ConverterUtils.bytesToHex(xPayload));
    }

    /**
     * Método responsável em recuperar as informações do campo CPO_010(campo
     * contendo as informações do cartão: número, data vencimento, etx) do array
     * de bytes que representa a transação, e com isso substituir o valor que
     * corresponde ao "número do cartão" com valor "XXXXX".
     *
     * @param msgBytes Array de bytes contendo a mensagem recebida original.
     * @return Array de bytes contendo a mensagem recebida, com os valores das
     * informações(número do cartão) do cartão já substituidas por "XXXXX".
     */
    private byte[] ofuscarInformacoesCartao(byte[] msgBytes) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        try {
            int idx = 0;
            while (idx < msgBytes.length) {
                // Recupera o nome do campo fisico nos 2 primeiros bytes.
                byte[] campoNome = ParserConverterUtils.subArray(msgBytes, idx, 2);
                int nomeCampoStr = ParserConverterUtils.hexToDecimal(ParserConverterUtils.bytesToHex(campoNome));
                idx += 2;

                //Analise e recupera o tamanho do campo fisico nos 2 bytes seguintes.
                byte[] campoTamanho = ParserConverterUtils.subArray(msgBytes, idx, 2);
                int valueTam = ParserConverterUtils.hexToDecimal(ParserConverterUtils.bytesToHex(campoTamanho));
                idx += 2;

                // Recupera o conjunto de bytes correspondete ao valor do campo fisico. Esse campo contem a string dos campos logicos.
                byte[] campoValor = ParserConverterUtils.subArray(msgBytes, idx, valueTam);
                String valorCampoStr = ParserConverterUtils.hexToString(campoValor);

                // Move index para o proximo campo(no array de bytes) da mensagem fisica recebida.
                idx += valueTam;

                // Preenche novo array de bytes
                baos.write(campoNome);
                baos.write(campoTamanho);

                //Verificar se é campo 010, que contém as informações do cartão.
                if (nomeCampoStr == 10) {
                    // Parser do valor do campo10
                    TransacaoStratusParser builder = TransacaoParserBuilder.getTransacaoStratusParser();
                    FFPojoHelper ffpojo = builder.getFFPojoInstance();
                    CPO_010 cpo10 = (CPO_010) ffpojo.createFromText(CPO_010.class, valorCampoStr);

                    // Substitui o valor do campo numeroCartao com valor "X", mantendo as 6 primeiras posições para recuperar o BIN.
                    if (cpo10.getNumeroCartao() != null && cpo10.getNumeroCartao().length() >= 6) {
                        int tamOriginal = cpo10.getNumeroCartao().length();
                        if (tamOriginal == 6) {
                            cpo10.setNumeroCartao(StringUtils.mid(cpo10.getNumeroCartao(), 0, 6)
                                    + StringUtils.rightPad("*", 13, '*'));
                        } else {
                            String cartao = cpo10.getNumeroCartao();
                            String bin = StringUtils.mid(cartao, 0, 6);
                            String ident = cartao.substring(tamOriginal-5); // pega os 4 ultimos digitos

                            cpo10.setNumeroCartao(bin + StringUtils.repeat("*", 6) + ident);
                        }

                    }

                    String novoValorCampoStr = ffpojo.parseToText(cpo10);
                    byte[] novoValorCampo10 = novoValorCampoStr.getBytes("CP1047");

                    // Preenche o novo array de bytes com o valor do novo campo010, e do restante dos bytes da transação original.
                    baos.write(novoValorCampo10);
                    baos.write(msgBytes, idx, (msgBytes.length - idx));

                    break;
                } else {
                    baos.write(campoValor);
                }
            }
        } catch (Throwable e) {
//            logger.error(e.getMessage() + "\nMensagem original: " + Arrays.toString(msgBytes), e);
            errLogger.log(Level.WARNING, "Mensagem original: " + Arrays.toString(msgBytes), e);
        }
        return baos.toByteArray();
    }
}
