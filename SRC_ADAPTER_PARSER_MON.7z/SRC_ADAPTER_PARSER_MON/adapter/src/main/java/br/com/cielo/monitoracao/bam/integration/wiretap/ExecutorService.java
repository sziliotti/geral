package br.com.cielo.monitoracao.bam.integration.wiretap;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("customWiretap")
public class ExecutorService implements Processor{
	
	@Autowired
	private List<WiretapService> services;
	
	public void process(Exchange exchange) throws Exception {
		for(WiretapService service:services){
			service.process(exchange);
		}
	}
}
