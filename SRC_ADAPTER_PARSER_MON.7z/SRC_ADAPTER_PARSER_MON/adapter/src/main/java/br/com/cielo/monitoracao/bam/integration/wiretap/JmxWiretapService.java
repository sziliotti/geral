package br.com.cielo.monitoracao.bam.integration.wiretap;

import br.com.cielo.monitoracao.bam.integration.utils.JmxMonitorUtils;
import java.util.concurrent.atomic.AtomicLong;
import javax.jms.ConnectionFactory;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import org.apache.camel.CamelContext;
import org.apache.camel.CamelContextAware;
import org.apache.camel.Exchange;
import org.apache.camel.component.seda.SedaEndpoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.jmx.export.naming.SelfNaming;

@ManagedResource(description = "Monitor das filas do Adapter")
public class JmxWiretapService extends WiretapService implements SelfNaming, CamelContextAware {

    private static final Logger LOGGER = LoggerFactory.getLogger(JmxWiretapService.class);
    private static long lastIncomingTime = 0L;
    private static boolean activeAdapter = false;
    private final AtomicLong count = new AtomicLong();
    private final AtomicLong rejectedCount = new AtomicLong();
    private final AtomicLong processTime = new AtomicLong();
    private static boolean run = true;
    private CamelContext camelContext;

    static {
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                run = false;
            }
        });
    }

    public JmxWiretapService(String destination, final long groupInterval, final long timeInactivation, ConnectionFactory connectionFactory) {
        super(destination, connectionFactory);
        Thread monitor = new Thread("WiretapService Monitor") {
            @Override
            public void run() {
                while (run) {
                    try {
                        Thread.sleep(groupInterval);
                    } catch (InterruptedException e) {
                        throw new RuntimeException("Falhou ao executar sleep", e);
                    }
                    if (System.currentTimeMillis() - lastIncomingTime > timeInactivation) {
                        activeAdapter = false;
                    }
                    SedaEndpoint seda = (SedaEndpoint) getCamelContext().getEndpoint("vm:inputQueue");
                    int size = seda.getExchanges().size();
                    LOGGER.info(getComponentName()
                            + ", RejectCount: " + rejectedCount.get()
                            + ", MeanProcessingTime: " + getMeanLatencyInMillis()
                            + ", SEDA inputQueue currentSize: " + size
                            + ", ActiveAdapter: " + activeAdapter
                    );
                    resetStats();
                }
            }
        };
        monitor.start();
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        count.incrementAndGet();
        activeAdapter = true;
        lastIncomingTime = System.currentTimeMillis();
        try {
            super.process(exchange);
        } catch (Exception ex) {
            reject(exchange);
            throw ex;
        }
        calculate(System.currentTimeMillis() - lastIncomingTime);
    }

    public void calculate(long latency) {
        processTime.addAndGet(latency);
    }

    @Override
    public ObjectName getObjectName() throws MalformedObjectNameException {
        return JmxMonitorUtils.buildObjectName(getComponentName(), "processors");
    }

    public void reject(Exchange exchange) {
        rejectedCount.incrementAndGet();
    }

    @ManagedAttribute
    public String getDestination() {
        return destination;
    }

    @ManagedAttribute
    public long getCount() {
        return count.longValue();
    }

    @ManagedAttribute
    public long getRejected() {
        return rejectedCount.longValue();
    }

    @ManagedAttribute
    public long getMeanLatencyInMillis() {
        long cnt = this.count.get();
        if (cnt > 0) {
            return processTime.get() / cnt;
        }
        return 0;
    }

    @ManagedAttribute
    public boolean isActiveAdapter() {
        return activeAdapter;
    }

    @ManagedOperation
    public void resetStats() {
        rejectedCount.set(0);
        count.set(0);
        processTime.set(0);
    }

    @Override
    public void setCamelContext(CamelContext camelContext) {
        this.camelContext = camelContext;
    }

    @Override
    public CamelContext getCamelContext() {
        return camelContext;
    }

    @Override
    public boolean equals(Object o) {
        if (o != null && (o instanceof JmxWiretapService)) {
            JmxWiretapService other = (JmxWiretapService) o;
            if (this.toString().equals(other.toString())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash + toString().hashCode();
    }

    @Override
    public String toString() {
        return "JmxWiretapService:[destination=" + getComponentName()+ "]";
    }
}
