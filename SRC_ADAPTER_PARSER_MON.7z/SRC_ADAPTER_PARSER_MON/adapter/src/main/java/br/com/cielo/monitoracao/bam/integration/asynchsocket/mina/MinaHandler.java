package br.com.cielo.monitoracao.bam.integration.asynchsocket.mina;

import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IoSession;

/**
 *<B>Projeto: Stratus-Monitoracao-Adapter</B><BR>
 *
 * Interface de comunicacao entre produtores e consumidores do camel com conexao do mina.
 *	 
 *<DL><DT><B>Criada em:</B><DD>09/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 * @since 2011 - Versão inicial do projeto mainframe-adapter, feito por masousa.
 */
public class MinaHandler extends IoHandlerAdapter{
	/** Atributo **/
	private final Log logger= LogFactory.getLog(MinaHandler.class);
	
	/** Atributo **/
	private final HashMap<Long, IoSession> activeConnections = new HashMap<Long, IoSession>();
	
	/** Atributo **/
	private MinaConsumer consumer;
	
	/**
	 * 
	 * @author EYVC8F
	 *
	 * @param consumer ;
	 * @since 26/07/2012
	 */
	public void setConsumer(final MinaConsumer consumer) {
		this.consumer = consumer;
	}

	@Override
	public void sessionCreated(final IoSession session) throws Exception {
		super.sessionCreated(session);
		synchronized(activeConnections){
			activeConnections.put(session.getId(), session);
		}
	}
	
	@Override
	public void sessionClosed(final IoSession session) throws Exception {
		super.sessionClosed(session);
		logger.debug("Conexao finalizada " + session.toString());
		
		synchronized(activeConnections){
			activeConnections.put(session.getId(), session);
		}
	}
	
	@Override
	public void messageReceived(final IoSession session, final Object message) throws Exception {
		consumer.post(message, session.getId());
	}
		
	@Override
	public void exceptionCaught(final IoSession session, final Throwable cause)	throws Exception {
	}
	
	/**
	 * Retorna mensagem para o socket indicado
	 * 
	 * @param object mensagem a ser retornada
	 * @param id id da conexao socket
	 */
	public void post(final Object object, final long id){		
		IoSession ioSession = activeConnections.get(id);
		if(ioSession!=null){
			ioSession.write(object);
		}else{
			logger.info("Nao foi localizado socket " + id + " para devolucao de mensagem [" + object + "]");
		}
	}
	
}
