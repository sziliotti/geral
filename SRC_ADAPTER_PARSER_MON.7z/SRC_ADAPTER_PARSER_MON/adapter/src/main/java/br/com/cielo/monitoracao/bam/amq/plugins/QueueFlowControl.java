/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.monitoracao.bam.amq.plugins;

import org.apache.activemq.broker.Broker;
import org.apache.activemq.broker.BrokerFilter;
import org.apache.activemq.broker.ProducerBrokerExchange;
import org.apache.activemq.broker.region.Queue;
import org.apache.activemq.command.JournalQueueAck;
import org.apache.activemq.command.Message;
import org.apache.activemq.command.MessageAck;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class QueueFlowControl extends BrokerFilter {

    private String queueName;

    public QueueFlowControl(Broker next, Long maxMessagesPerQueue) {
        super(next);
        this.maxMessagesPerQueue = maxMessagesPerQueue;
    }

    private static final Logger LOG = LoggerFactory
            .getLogger(QueueFlowControl.class);

    long maxMessagesPerQueue = 999999999;

    QueueFlowControl(Broker broker, String queueName, long maxMessagesPerQueue) {
        this(broker, maxMessagesPerQueue);
            this.queueName = queueName; 
    }

    public void setMaxSizePerMessage(long maxSizePerMessage) {
        maxMessagesPerQueue = maxSizePerMessage;
    }

    @Override
    public void send(ProducerBrokerExchange producerExchange, Message message)
            throws Exception {
        org.apache.activemq.broker.region.Destination dest = producerExchange.getRegionDestination();
        Long pendingCount = dest.getDestinationStatistics().getMessages().getCount();
        if (pendingCount > maxMessagesPerQueue) {
            // começo a remover mensagens mais velhas...
            synchronized (producerExchange.getRegionDestination()) {
                ((Queue) producerExchange.getRegionDestination()).getMessages().remove();
                super.send(producerExchange, message);
//            MessageAck ack = new MessageAck();
//            ack.setLastMessageId(m.getMessageId());
//            dest.getMessageStore().removeMessage(producerExchange.getConnectionContext(),ack);
            }
        } else {
            super.send(producerExchange, message);
        }
        
    }
}
