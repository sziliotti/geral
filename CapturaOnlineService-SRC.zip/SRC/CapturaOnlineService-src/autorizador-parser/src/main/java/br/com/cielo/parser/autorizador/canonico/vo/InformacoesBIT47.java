package br.com.cielo.parser.autorizador.canonico.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/** 
 *<B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 *<br>
 * Objeto responsavel em armazenar as insformações dos Dados Estatisticos da Conexão, utilizadas na Monitoração de Negocio.
 * 
 *	 
 *<DL><DT><B>Criada em:</B><DD>27/11/2014</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class InformacoesBIT47 implements Serializable {
	private static final long serialVersionUID = 1L;
	
	
	//Atributo que define o identificador unico da transação.
	private String numeroDocumento;
	
	//Atributo que define a data e hora da realização da transação a qual os dados estatísticos se referem .
	private Date dataHoraTransacaoBIT47;
	
	//Atributo que define o modo de conexao utilizado para a transação.
	private String modoConexao;
	
	//Atributo que define o modo de discagem utilizado para a transação.
	private String modoDiscagem;
	
	//Atributo que define o numero do celular do SIMCARD.
	private String numeroOrigem;
	
	//Atributo que define o numero de serie do SIMCARD.
	private String numeroSimCard;
	
	//Atributo que define o nível de sinal GPRS da operadora. 
	private String nivelSinalGPRS;
	
	//Atributo que define o tempo total da transação, que consiste desde a primeira interação para estimulo da transação (inserção do cartão, passagem do cartão ou acesso ao Menu 
	//de produtos) até o fim da impressão do último comprovante (podendo ser a primeira via, segunda via ou nenhum comprovante).
	private String tempoTransacao;
	
	//Atributo que define as informações de geo localização. 
	private String geoLocalizacao;
	
	//Atributo que define se foi fallback(S ou N).
	private String fallback;
		
	//Atributo que define o numero que será discado.
	private String numeroDiscado;
		
	//Atributo que define o numero de tentativas de discagens.
	private int qtdeTentativasDiscagens;
	
	//Objeto com informações das discagens.
	private ArrayList<InformacoesDiscagemBIT47> informacoesDiscagem= new ArrayList<InformacoesDiscagemBIT47>();
	
	
	
	
	/**
	 * Construtor Padrão.
	 */
	public InformacoesBIT47() {
	}
	
	
	
	/**
	 * Retorna o número do documento da mensagem a qual os dados estatísticos se referem. Se as informações se referirem a uma transação que não 
	 * tenha saído do terminal, esse campo deverá ser preenchido com zeros.
     * <br><br>
     * Campo Stratus: CPO-909 (ADIC-BRB47-5-NDOC).
     * 
	 * @return the numeroDocumento
	 */
	public String getNumeroDocumento() {
		return numeroDocumento;
	}
	/**
	 * @param numeroDocumento the numeroDocumento to set
	 */
	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}


	/**
	 * Retorna a data e hora da realização da transação a qual os dados estatísticos se referem.
     * <br><br>
     * Campo Stratus: CPO-905 (ADIC-BRB47-1-PREF-1).
     * 
	 * @return the dataHoraTransacaoBIT47
	 */
	public Date getDataHoraTransacaoBIT47() {
		return dataHoraTransacaoBIT47;
	}
	/**
	 * @param dataHoraTransacaoBIT47 the dataHoraTransacaoBIT47 to set
	 */
	public void setDataHoraTransacaoBIT47(Date dataHoraTransacaoBIT47) {
		this.dataHoraTransacaoBIT47 = dataHoraTransacaoBIT47;
	}
	
	/**
	 * Retorna o modo de conexão utilizado para transmissão da transação.
     * <br><br>
     * Campo Stratus: CPO-905 (ADIC-BRB47-1-MOD-CON-1).
     * 
	 * @return the modoConexao
	 */
	public String getModoConexao() {
		return modoConexao;
	}
	/**
	 * @param modoConexao the modoConexao to set
	 */
	public void setModoConexao(String modoConexao) {
		this.modoConexao = modoConexao;
	}

	/**
	 * Retorna a o modo de discagem utilizado para transmissão da transação.
     * <br><br>
     * Campo Stratus: CPO-905 (ADIC-BRB47-1-MOD-DIS-1).
     * 
	 * @return the modoDiscagem
	 */
	public String getModoDiscagem() {
		return modoDiscagem;
	}
	/**
	 * @param modoDiscagem the modoDiscagem to set
	 */
	public void setModoDiscagem(String modoDiscagem) {
		this.modoDiscagem = modoDiscagem;
	}


	/**
	 * Retorna o numero do celular do SIMCARD.
     * <br><br>
     * Campo Stratus: CPO-xxx (xxxxxx).
     * 
	 * @return the numeroOrigem
	 */
	public String getNumeroOrigem() {
		return numeroOrigem;
	}
	/**
	 * @param numeroOrigem the numeroOrigem to set
	 */
	public void setNumeroOrigem(String numeroOrigem) {
		this.numeroOrigem = numeroOrigem;
	}

	/**
	 * Retorna o numero de serie do SIMCARD.
     * <br><br>
     * Campo Stratus: CPO-xxx (xxxxxx).
     * 
	 * @return the numeroSimCard
	 */
	public String getNumeroSimCard() {
		return numeroSimCard;
	}
	/**
	 * @param numeroSimCard the numeroSimCard to set
	 */
	public void setNumeroSimCard(String numeroSimCard) {
		this.numeroSimCard = numeroSimCard;
	}

	/**
	 * Retorna o nível de sinal GPRS da operadora.
     * <br><br>
     * Campo Stratus: CPO-909 (ADIC-BRB47-5-TSSINAL).
     * 
	 * @return the nivelSinalGPRS
	 */
	public String getNivelSinalGPRS() {
		return nivelSinalGPRS;
	}
	/**
	 * @param nivelSinalGPRS the nivelSinalGPRS to set
	 */
	public void setNivelSinalGPRS(String nivelSinalGPRS) {
		this.nivelSinalGPRS = nivelSinalGPRS;
	}

	/**
	 * Retorna o tempo total da transação, que consiste desde a primeira interação para estimulo da transação (inserção do cartão, passagem do cartão 
	 * ou acesso ao Menu  de produtos) até o fim da impressão do último comprovante (podendo ser a primeira via, segunda via ou nenhum comprovante).
     * <br><br>
     * Campo Stratus: CPO-904 (ADIC-BRB47-TEMRES-1).
     * 
	 * @return the tempoTransacao
	 */
	public String getTempoTransacao() {
		return tempoTransacao;
	}
	/**
	 * @param tempoTransacao the tempoTransacao to set
	 */
	public void setTempoTransacao(String tempoTransacao) {
		this.tempoTransacao = tempoTransacao;
	}
	
	/**
	 * Retorna as informações de geo localização.
     * <br><br>
     * Campo Stratus: CPO-xxx (xxxxxx).
     * 
	 * @return the geoLocalizacao
	 */
	public String getGeoLocalizacao() {
		return geoLocalizacao;
	}
	/**
	 * @param geoLocalizacao the geoLocalizacao to set
	 */
	public void setGeoLocalizacao(String geoLocalizacao) {
		this.geoLocalizacao = geoLocalizacao;
	}

	/**
	 * Retorna a informação se é considerado Fallback ou não. É considerado como fallback (S = Sim) a partir da segunda tentativa de qualquer tipo de 
	 * conexão. Com o falback é possível saber se a conexão foi estabelecida pelo nó primário ou pelo secundário. 
	 * <br><br>
	 * Sendo assim deve-se assumir:
	 * 		<DD>"S"– Para mais de 1 tentativa;
	 * 		<DD>"N" – Para a 1ª tentativa com sucesso.
     * <br><br>
     * Campo Stratus: CPO-909 (ADIC-BRB47-5-FALLBACK).
     * 
	 * @return the fallback
	 */
	public String getFallback() {
		return fallback;
	}
	/**
	 * @param fallback the fallback to set
	 */
	public void setFallback(String fallback) {
		this.fallback = fallback;
	}

	/**
	 * Retorna o numero do telefone que será discado. Para terminais Discados: Últimos 4 dígitos do telefone discado pelo POS neste conjunto de 
	 * discagens. Para terminais GPRS / Ethernet / WiFi: considerar IP mais Porta. Ex.: 0950.
     * <br><br>
     * Campo Stratus: CPO-905 (ADIC-BRB47-1-FON-DIS-1).
     * 
	 * @return the numeroDiscado
	 */
	public String getNumeroDiscado() {
		return numeroDiscado;
	}
	/**
	 * @param numeroDiscado the numeroDiscado to set
	 */
	public void setNumeroDiscado(String numeroDiscado) {
		this.numeroDiscado = numeroDiscado;
	}

	/**
	 * Retorna a quantidade de todas as discagens efetuadas para este telefone, informado no campo anterior ou a quantidade de tentativas de 
	 * conexão por um mesmo acesso.
     * <br><br>
     * Campo Stratus: CPO-905 (ADIC-BRB47-1-QTD-TEN-1).
     * 
	 * @return the qtdeTentativasDiscagens
	 */
	public int getQtdeTentativasDiscagens() {
		return qtdeTentativasDiscagens;
	}
	/**
	 * @param qtdeTentativasDiscagens the qtdeTentativasDiscagens to set
	 */
	public void setQtdeTentativasDiscagens(int qtdeTentativasDiscagens) {
		this.qtdeTentativasDiscagens = qtdeTentativasDiscagens;
	}
	
	/**
	 * Retorna o conjunto de objetos com informações de cada tentativa de discagem do BIT47.     
     * 
	 * @return the informacoesDiscagem
	 */
	public ArrayList<InformacoesDiscagemBIT47> getInformacoesDiscagem() {
		return informacoesDiscagem;
	}
	/**
	 * @param informacoesDiscagem the informacoesDiscagem to set
	 */
	public void setInformacoesDiscagem(ArrayList<InformacoesDiscagemBIT47> informacoesDiscagem) {
		this.informacoesDiscagem = informacoesDiscagem;
	}	
	/**
	 * @param informacoesDiscagem
	 */
	public void addInformacoesDiscagem(InformacoesDiscagemBIT47 informacoesDiscagem) {
		this.informacoesDiscagem.add(informacoesDiscagem);
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
