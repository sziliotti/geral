package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

import br.com.cielo.parser.autorizador.stratus.vo.logicos.decorator.DateHourDecorator;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 *
 * Objeto referente ao campo CPO_018, sobre Dados do BIT62.
 *
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_018 extends CampoLogicoVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * * ******************************************************************
     *     * CPO-018 *
     * ****************************************************************** 03
     * ACTR-CAMPO-018. 05 ACTR-CPO-018 pic 9(004) comp-4. 05 ACTR-TCBIT62 pic
     * x(375). 05 filler redefines ACTR-TCBIT62. 09 ACTR-TCB62-IDESUB-1 pic
     * 9(002). 09 ACTR-TCB62-NR-DOC-1 pic 9(006). 09 ACTR-TCB62-DTHRTR-1 pic
     * 9(012). 09 ACTR-TCB62-CODRES-1 pic x(003). 09 ACTR-TCB62-TVR-1 pic
     * x(010). 09 ACTR-TCB62-NRALEA-1 pic x(008). 09 ACTR-TCB62-TIPCRI-1 pic
     * 9(002). 09 ACTR-TCB62-CRIACC-1 pic x(016). 09 ACTR-TCB62-TAMEMI-1 pic
     * 9(004). 09 ACTR-TCB62-INDCHV-1 pic x(002). 09 ACTR-TCB62-VRSCRI-1 pic
     * x(002). 09 ACTR-TCB62-CVR-1 pic x(008). 09 ACTR-TCB62-TAMRES-1 pic
     * 9(004). 09 ACTR-TCB62-DADRES-1 pic x(020). 09 ACTR-TCB62-IDESUB-2 pic
     * 9(002). 09 ACTR-TCB62-CRIRES-2 pic x(008). 09 ACTR-TCB62-CODRES-2 pic
     * x(002). 09 ACTR-TCB62-CONATC-2 pic x(004). 09 ACTR-TCB62-TAMSCR-2 pic
     * 9(004). 09 ACTR-TCB62-DADSCR-2 pic x(256).
     *
     */
    private String bit62IdeSub1;
    private String bit62NrDoc1;
    private Date bit62DtHrTr;
    private String bit62CodRes1;
    private String bit62TVR1;
    private String bit62NRALEA1;
    private String bit62TipCri1;
    private String bit62CriAcc1;
    private String bit62Tamemi1;
    private String bit62IndChv1;
    private String bit62VRSCRI1;
    private String bit62CVR1;
    private String bit62TamRes1;
    private String bit62DadRes1;
    private String bit62IdeSub2;
    private String bit62CriRes2;
    private String bit62CodRes2;
    private String bit62ConATC2;
    private String bit62TamScr2;
    private String bit62DadScr2;

    public CPO_018() {
    }

    @PositionalField(initialPosition = 1, finalPosition = 2)
    public String getBit62IdeSub1() {
        return bit62IdeSub1;
    }

    public void setBit62IdeSub1(String bit62IdeSub1) {
        this.bit62IdeSub1 = bit62IdeSub1;
    }

    @PositionalField(initialPosition = 3, finalPosition = 8)
    public String getBit62NrDoc1() {
        return bit62NrDoc1;
    }

    public void setBit62NrDoc1(String bit62NrDoc1) {
        this.bit62NrDoc1 = bit62NrDoc1;
    }

    @PositionalField(initialPosition = 9, finalPosition = 20, decorator= DateHourDecorator.class)
    public Date getBit62DtHrTr() {
        return bit62DtHrTr;
    }

    public void setBit62DtHrTr(Date bit62DtHrTr) {
        this.bit62DtHrTr = bit62DtHrTr;
    }

    @PositionalField(initialPosition = 21, finalPosition = 23)
    public String getBit62CodRes1() {
        return bit62CodRes1;
    }

    public void setBit62CodRes1(String bit62CodRes1) {
        this.bit62CodRes1 = bit62CodRes1;
    }

    @PositionalField(initialPosition = 24, finalPosition = 33)
    public String getBit62TVR1() {
        return bit62TVR1;
    }

    public void setBit62TVR1(String bit62TVR1) {
        this.bit62TVR1 = bit62TVR1;
    }

    @PositionalField(initialPosition = 34, finalPosition = 41)
    public String getBit62NRALEA1() {
        return bit62NRALEA1;
    }

    public void setBit62NRALEA1(String bit62NRALEA1) {
        this.bit62NRALEA1 = bit62NRALEA1;
    }

    @PositionalField(initialPosition = 42, finalPosition = 43)
    public String getBit62TipCri1() {
        return bit62TipCri1;
    }

    public void setBit62TipCri1(String bit62TipCri1) {
        this.bit62TipCri1 = bit62TipCri1;
    }

    @PositionalField(initialPosition = 44, finalPosition = 59)
    public String getBit62CriAcc1() {
        return bit62CriAcc1;
    }

    public void setBit62CriAcc1(String bit62CriAcc1) {
        this.bit62CriAcc1 = bit62CriAcc1;
    }

    @PositionalField(initialPosition = 60, finalPosition = 63)
    public String getBit62Tamemi1() {
        return bit62Tamemi1;
    }

    public void setBit62Tamemi1(String bit62Tamemi1) {
        this.bit62Tamemi1 = bit62Tamemi1;
    }

    @PositionalField(initialPosition = 64, finalPosition = 65)
    public String getBit62IndChv1() {
        return bit62IndChv1;
    }

    public void setBit62IndChv1(String bit62IndChv1) {
        this.bit62IndChv1 = bit62IndChv1;
    }

    @PositionalField(initialPosition = 66, finalPosition = 67)
    public String getBit62VRSCRI1() {
        return bit62VRSCRI1;
    }

    public void setBit62VRSCRI1(String bit62VRSCRI1) {
        this.bit62VRSCRI1 = bit62VRSCRI1;
    }

    @PositionalField(initialPosition = 68, finalPosition = 75)
    public String getBit62CVR1() {
        return bit62CVR1;
    }

    public void setBit62CVR1(String bit62CVR1) {
        this.bit62CVR1 = bit62CVR1;
    }

    @PositionalField(initialPosition = 76, finalPosition = 79)
    public String getBit62TamRes1() {
        return bit62TamRes1;
    }

    public void setBit62TamRes1(String bit62TamRes1) {
        this.bit62TamRes1 = bit62TamRes1;
    }

    @PositionalField(initialPosition = 80, finalPosition = 99)
    public String getBit62DadRes1() {
        return bit62DadRes1;
    }

    public void setBit62DadRes1(String bit62DadRes1) {
        this.bit62DadRes1 = bit62DadRes1;
    }

    @PositionalField(initialPosition = 100, finalPosition = 101)
    public String getBit62IdeSub2() {
        return bit62IdeSub2;
    }

    public void setBit62IdeSub2(String bit62IdeSub2) {
        this.bit62IdeSub2 = bit62IdeSub2;
    }

    @PositionalField(initialPosition = 102, finalPosition = 109)
    public String getBit62CriRes2() {
        return bit62CriRes2;
    }

    public void setBit62CriRes2(String bit62CriRes2) {
        this.bit62CriRes2 = bit62CriRes2;
    }

    @PositionalField(initialPosition = 110, finalPosition = 111)
    public String getBit62CodRes2() {
        return bit62CodRes2;
    }

    public void setBit62CodRes2(String bit62CodRes2) {
        this.bit62CodRes2 = bit62CodRes2;
    }

    @PositionalField(initialPosition = 112, finalPosition = 115)
    public String getBit62ConATC2() {
        return bit62ConATC2;
    }

    public void setBit62ConATC2(String bit62ConATC2) {
        this.bit62ConATC2 = bit62ConATC2;
    }

    @PositionalField(initialPosition = 116, finalPosition = 119)
    public String getBit62TamScr2() {
        return bit62TamScr2;
    }

    public void setBit62TamScr2(String bit62TamScr2) {
        this.bit62TamScr2 = bit62TamScr2;
    }

    @PositionalField(initialPosition = 120, finalPosition = 375)
    public String getBit62DadScr2() {
        return bit62DadScr2;
    }

    public void setBit62DadScr2(String bit62DadScr2) {
        this.bit62DadScr2 = bit62DadScr2;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

}
