package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_071, sobre Dados INDICADOR DE TRANSACAO MOBILE PAYMENT.
 * 
 * <DL><DT><B>Criada em:</B><DD>23/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_071 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String indicadorMobile;
	private String filler;
	
	
	public CPO_071(){		
	}

	
	/**
	 * @return the indicadorMobile
	 */
	@PositionalField(initialPosition= 1, finalPosition= 1)
	public String getIndicadorMobile() {
		return indicadorMobile;
	}
	/**
	 * @param indicadorMobile the indicadorMobile to set
	 */
	public void setIndicadorMobile(String indicadorMobile) {
		this.indicadorMobile = indicadorMobile;
	}


	/**
	 * @return the filler
	 */
	@PositionalField(initialPosition= 2, finalPosition= 2)
	public String getFiller() {
		return filler;
	}
	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		this.filler = filler;
	}


	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
