package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_012, sobre Dados do Estabelecimento.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_012 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;	
	public static Logger logger= LoggerFactory.getLogger(CPO_012.class);
	
	private String numeroEstabelecimento;
	private String numeroLoja;
	private String uf;
	private String cep;
	private int moeda;	
	private int numeroMcc;
		
	public CPO_012(){
		
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-ESTAB-NUM
	 *
	 * @return the numeroEstabelecimento
	 */
	@PositionalField(initialPosition= 1, finalPosition= 11)
	public String getNumeroEstabelecimento() {
		return numeroEstabelecimento;
	}

	/**
	 * @param numeroEstabelecimento the numeroEstabelecimento to set
	 */
	public void setNumeroEstabelecimento(String numeroEstabelecimento) {
		this.numeroEstabelecimento = numeroEstabelecimento;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-ESTAB-LOJ 
	 *
	 * @return the numeroLoja
	 */
	@PositionalField(initialPosition= 12, finalPosition= 15)
	public String getNumeroLoja() {
		return numeroLoja;
	}

	/**
	 * @param numeroLoja the numeroLoja to set
	 */
	public void setNumeroLoja(String numeroLoja) {
		this.numeroLoja = numeroLoja;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-ESTAB-UF 
	 *
	 * @return the uf
	 */
	@PositionalField(initialPosition= 16, finalPosition= 17)
	public String getUf() {
		return uf;
	}

	/**
	 * @param uf the uf to set
	 */
	public void setUf(String uf) {
		this.uf = uf;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-ESTAB-CEP
	 *
	 * @return the cep
	 */
	@PositionalField(initialPosition= 18, finalPosition= 25)
	public String getCep() {
		return cep;
	}

	/**
	 * @param cep the cep to set
	 */
	public void setCep(String cep) {
		this.cep = cep;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-MOEDA 
	 *
	 * @return the moeda
	 */
	@PositionalField(initialPosition= 26, finalPosition= 28)
	public int getMoeda() {
		return moeda;
	}
	/**
	 * @param moeda the moeda to set
	 */
	public void setMoeda(String moeda) {		
		try {
			this.moeda= Integer.parseInt(moeda);
		} catch (NumberFormatException e) {
			this.moeda= 0;
			//logger.warn("Erro realizando parser no objeto [CPO_012], em campo N�merico[moeda]. Valor recebido= '"+moeda+"'");			
		}
	}
	/**
	 * @param moeda the moeda to set
	 */
	public void setMoeda(int moeda) {
		this.moeda = moeda;
	}
	
	/**
	 * Representa o Campo STRATUS: ACTR-MCC-N 
	 *
	 * @return the numeroMcc
	 */
	@PositionalField(initialPosition= 29, finalPosition= 32)
	public int getNumeroMcc() {
		return numeroMcc;
	}
	/**
	 * @param numeroMcc the numeroMcc to set
	 */
	public void setNumeroMcc(String numeroMcc) {		
		try {
			this.numeroMcc= Integer.parseInt(numeroMcc);
		} catch (NumberFormatException e) {
			this.numeroMcc= 0;
			//logger.warn("Erro realizando parser no objeto [CPO_012], em campo N�merico[numeroMcc]. Valor recebido= '"+numeroMcc+"'");			
		}
	}
	/**
	 * @param numeroMcc the numeroMcc to set
	 */
	public void setNumeroMcc(int numeroMcc) {
		this.numeroMcc = numeroMcc;
	}

	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
