package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

import br.com.cielo.parser.autorizador.stratus.vo.logicos.decorator.DateDecorator;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.decorator.DateHourDecorator;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.decorator.Double12PosDecorator;


/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR> 
 * 
 * Objeto referente ao campo CPO_001.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_001 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	public static Logger logger= LoggerFactory.getLogger(CPO_001.class);
	
	/*private SimpleDateFormat dateFormat= new SimpleDateFormat("yyMMdd");	
	private SimpleDateFormat dateHourFormat= new SimpleDateFormat("yyMMddHHmmss");*/
	
	private String identificador;
	private String conRes;
	private String aplicacaoOrigem;		
	private String autorizador;	
	private Date dataHoraHost;	
	private String maquina;
	private int lote;	
	private Date dataHoraInputTerminal;	
	private Date dataHoraInput;
	private double valorVenda;
	private Date dataPOS;
	private String transacaoPOS;
	private String flag3D;
	
	public CPO_001(){ }
	
	
	/**
	 * Representa o Campo STRATUS: ACTR-IDENT
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 1, finalPosition= 4)
	public String getIdentificador() {
		return identificador;
	}
	/**
	 * @param identificador
	 */
	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}
	
	/**
	 * Representa o Campo STRATUS: ACTR-CON-RES
	 * @return
	 */
	@PositionalField(initialPosition= 5, finalPosition= 7)
	public String getConRes() {
		return conRes;
	}
	/**
	 * @param conRes
	 */
	public void setConRes(String conRes) {
		this.conRes = conRes;
	}
	
	/**
	 * Representa o Campo STRATUS: ACTR-APLICACAO-ORI
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 8, finalPosition= 9)
	public String getAplicacaoOrigem() {
		return aplicacaoOrigem;
	}
	
	/**
	 * @param aplicacaoOrigem
	 */	
	public void setAplicacaoOrigem(String aplicacaoOrigem) {
		this.aplicacaoOrigem = aplicacaoOrigem;
	}
	
	
	/**
	 * Representa o Campo STRATUS: ACTR-DESTINO-NUM
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 10, finalPosition= 15)
	public String getAutorizador() {
		return autorizador;
	}
	/**
	 * @param aplicacaoDestino
	 */
	public void setAutorizador(String autorizador) {
		this.autorizador = autorizador;
	}	
	
	
	/*
	*//**
	 * Representa o Campo STRATUS: ACTR-APLICACAO-DES
	 * 
	 * @return
	 *//*
	@PositionalField(initialPosition= 10, finalPosition= 11)
	public String getAplicacaoDestino() {
		return aplicacaoDestino;
	}
	*//**
	 * @param aplicacaoDestino
	 *//*
	public void setAplicacaoDestino(String aplicacaoDestino) {
		this.aplicacaoDestino = aplicacaoDestino;
	}	
	*//**
	 * Representa o Campo STRATUS: FILLER
	 * 
	 * @return
	 *//*
	@PositionalField(initialPosition= 12, finalPosition= 14)
	public String getFiller() {
		return filler;
	}
	*//**
	 * @param filler
	 *//*
	public void setFiller(String filler) {
		this.filler = filler;
	}
	
	*//**
	 * Representa o Campo STRATUS: ACTR-APLICACAO-DES-VAP
	 * 
	 * @return
	 *//*
	@PositionalField(initialPosition= 15, finalPosition= 15)
	public int getAplicacaoDesVap() {
		return aplicacaoDesVap;
	}	
	*//**
	 * @param aplicacaoDesVap
	 *//*
	public void setAplicacaoDesVap(String aplicacaoDesVap) {
		this.aplicacaoDesVap = Integer.parseInt(aplicacaoDesVap);
	}	
	*//**
	 * @param aplicacaoDesVap
	 *//*
	public void setAplicacaoDesVap(int aplicacaoDesVap) {
		this.aplicacaoDesVap = aplicacaoDesVap;
	}
	*/
	
	
		
	/**
	 * Representa o Campo STRATUS: ACTR-DATA-HOST e ACTR-HORA-HOST 
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 16, finalPosition= 27, decorator= DateHourDecorator.class)
	public Date getDataHoraHost() {
		return dataHoraHost;
	}	
	
	/**
	 * @param dataHoraHost
	 */
	/*public void setDataHoraHost(String dataHoraHost) {
		try {
			this.dataHoraHost = dateHourFormat.parse(dataHoraHost);
		} catch (ParseException e) {
			this.dataHoraHost = new Date();
			logger.warn("Erro realizando parser no objeto [CPO_001], em campo data[DataHoraHost]. Valor recebido= '"+dataHoraHost+"'");			
		}
	}*/
	/**
	 * @param dataHoraHost
	 */
	public void setDataHoraHost(Date dataHoraHost) {
		this.dataHoraHost = dataHoraHost;
	}
	
	/**
	 * Representa o Campo STRATUS: ACTR-MAQUINA
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 28, finalPosition= 29)
	public String getMaquina() {
		return maquina;
	}
	/**
	 * @param maquina
	 */
	public void setMaquina(String maquina) {
		this.maquina = maquina;
	}
	
	/**
	 * Representa o Campo STRATUS: ACTR-LOTE
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 30, finalPosition= 35)
	public int getLote() {
		return lote;
	}	
	/**
	 * @param lote
	 */
	public void setLote(String lote) {
		try {
			this.lote= Integer.parseInt(lote);
		} catch (NumberFormatException e) {
			this.lote= 0;
			logger.warn("Erro realizando parser no objeto [CPO_001], em campo N�merico[lote]. Valor recebido= '"+lote+"'");						
		}		
	}	
	/**
	 * @param lote
	 */
	public void setLote(int lote) {
		this.lote = lote;
	}
	
	/**
	 * Representa o Campo STRATUS: ACTR-DATA-INP-TER e ACTR-HORA-INP-TER 
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 36, finalPosition= 47, decorator= DateHourDecorator.class)
	public Date getDataHoraInputTerminal() {
		return dataHoraInputTerminal;
	}
	/**
	 * @param dataHoraInputTerminal
	 */
	public void setDataHoraInputTerminal(Date dataHoraInputTerminal) {
		this.dataHoraInputTerminal = dataHoraInputTerminal;
	}	
		
	/**
	 * Representa o Campo STRATUS: ACTR-DATA-INP e ACTR-HORA-INP
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 48, finalPosition= 59, decorator= DateHourDecorator.class)
	public Date getDataHoraInput() {
		return dataHoraInput;
	}
	/**
	 * @param dataHoraInput
	 */
	public void setDataHoraInput(Date dataHoraInput) {
		this.dataHoraInput = dataHoraInput;
	}
	/**
	 * @param dataHoraInput
	 */
	/*public void setDataHoraInput(String dataHoraInput) {
		try {
			this.dataHoraInput= dateHourFormat.parse(dataHoraInput);
		} catch (ParseException e) {
			this.dataHoraInput= new Date();
			logger.warn("Erro realizando parser no objeto [CPO_001], em campo data[DataHoraInput]. Valor recebido= '"+dataHoraInput+"'");			
		}
	}*/
		
	/**
	 * Representa o Campo STRATUS: ACTR-VALOR-VENDA
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 60, finalPosition= 71, decorator= Double12PosDecorator.class)
	public double getValorVenda() {
		return valorVenda;
	}	
	/**
	 * @param valorVenda
	 */
	/*public void setValorVenda(String valorVenda) {
		String valVend= valorVenda.substring(0, 10)+"."+valorVenda.substring(10);		
		try {
			this.valorVenda = Double.parseDouble(valVend);
		} catch (NumberFormatException e) {
			this.valorVenda= 0;
			logger.warn("Erro realizando parser no objeto [CPO_001], em campo numerico[ValorVenda]. Valor recebido= '"+valorVenda+"'");			
		}	
	}	*/
	/**
	 * @param valorVenda
	 */
	public void setValorVenda(double valorVenda) {
		this.valorVenda = valorVenda;
	}
	
	/**
	 * Representa o Campo STRATUS: ACTR-DAT-POS
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 72, finalPosition= 77, decorator= DateDecorator.class)
	public Date getDataPOS() {
		return dataPOS;
	}
	/**
	 * @param dataPOS
	 */
	/*public void setDataPOS(String dataPOS) {
		try {
			this.dataPOS= dateFormat.parse(dataPOS);
		} catch (ParseException e) {
			this.dataPOS= new Date();
			logger.warn("Erro realizando parser no objeto [CPO_001], em campo data[DataPOS]. Valor recebido= '"+dataPOS+"'");			
		}
	}*/
	/**
	 * @param dataPOS
	 */
	public void setDataPOS(Date dataPOS) {
		this.dataPOS = dataPOS;
	}
	
	/**
	 * Representa o Campo STRATUS: ACTR-TRANSACAO-POS
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 78, finalPosition= 81)
	public String getTransacaoPOS() {
		return transacaoPOS;
	}
	/**
	 * @param transacaoPOS
	 */
	public void setTransacaoPOS(String transacaoPOS) {
		this.transacaoPOS = transacaoPOS;
	}
	
	/**
	 * Representa o Campo STRATUS: ACTR-FL-3D
	 * 
	 * INDICA SE A CHAVE DO CLIENTE E TRIPLO DES
	 *   	S = TRIPLO DES
	 *		N = NAO E TRIPLO DES
	 * 
	 * @return
	 */
	@PositionalField(initialPosition= 82, finalPosition= 82)
	public String getFlag3D() {
		return flag3D;
	}
	/**
	 * @param flag3d
	 */
	public void setFlag3D(String flag3d) {
		flag3D = flag3d;
	}	
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
