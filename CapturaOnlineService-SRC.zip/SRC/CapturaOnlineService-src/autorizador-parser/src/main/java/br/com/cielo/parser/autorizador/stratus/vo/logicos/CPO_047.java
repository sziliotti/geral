package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_047, sobre Dados de Identificação da Operadora GPRS.
 * 
 * <DL><DT><B>Criada em:</B><DD>02/10/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */ 
@PositionalRecord
public class CPO_047 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String codigoOperadora;
	private String vago;
	
	public CPO_047(){		
	}
	
	
	/**
	 * Representa o Campo STRATUS: ACTR-CODIGO-OPERADORA
	 * 
	 * @return the codigoOperadora
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public String getCodigoOperadora() {
		return codigoOperadora;
	}
	/**
	 * @param codigoOperadora the codigoOperadora to set
	 */
	public void setCodigoOperadora(String codigoOperadora) {
		this.codigoOperadora = codigoOperadora;
	}
	
	/**
	 * Representa o Campo STRATUS: ACTR-VAGO-047
	 * 
	 * @return the vago
	 */
	@PositionalField(initialPosition= 3, finalPosition= 10)
	public String getVago() {
		return vago;
	}

	/**
	 * @param vago the vago to set
	 */	
	public void setVago(String vago) {
		this.vago = vago;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
