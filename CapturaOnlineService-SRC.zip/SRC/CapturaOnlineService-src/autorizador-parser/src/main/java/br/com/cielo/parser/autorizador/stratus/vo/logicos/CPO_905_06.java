package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_905, sobre Dados do BIT47. Utilizado para o Release 6 do POS.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_905_06 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
		
	/*
	 * Cabecalho Principal ADIC-BRB47-1-OCC1(Ocorre apenas 1 vez)
	 * 
	 * Cabecaho 1
	 */
	private String bit47Pref_1;
		
	//Cabecalho ADIC-BRB47-1-OCC2(Ocorre 3 vezes)
	private String telefoneDiscado_1_A;
	private String modoConexao_1;
	private String quantidadeTentativasDiscagens_1_A;
		//Cabecalho ADIC-BRB47-1-OCC3(Ocorre 10 vezes)
	private String resultadoDiscagem_1_A1;
	private String resultadoDiscagem_1_A2;
	private String resultadoDiscagem_1_A3;
	private String resultadoDiscagem_1_A4;
	private String resultadoDiscagem_1_A5;
	private String resultadoDiscagem_1_A6;
	private String resultadoDiscagem_1_A7;
	private String resultadoDiscagem_1_A8;
	private String resultadoDiscagem_1_A9;
	private String resultadoDiscagem_1_A10;
	
	private String telefoneDiscado_1_B;
	private String quantidadeTentativasDiscagens_1_B;
	private String resultadoDiscagem_1_B1;
	private String resultadoDiscagem_1_B2;
	private String resultadoDiscagem_1_B3;
	private String resultadoDiscagem_1_B4;
	private String resultadoDiscagem_1_B5;
	private String resultadoDiscagem_1_B6;
	private String resultadoDiscagem_1_B7;
	private String resultadoDiscagem_1_B8;
	private String resultadoDiscagem_1_B9;
	private String resultadoDiscagem_1_B10;
	
	private String telefoneDiscado_1_C;
	private String quantidadeTentativasDiscagens_1_C;
	private String resultadoDiscagem_1_C1;
	private String resultadoDiscagem_1_C2;
	private String resultadoDiscagem_1_C3;
	private String resultadoDiscagem_1_C4;
	private String resultadoDiscagem_1_C5;
	private String resultadoDiscagem_1_C6;
	private String resultadoDiscagem_1_C7;
	private String resultadoDiscagem_1_C8;
	private String resultadoDiscagem_1_C9;
	private String resultadoDiscagem_1_C10;
	
	private String filler;
	
	
	public CPO_905_06(){		
	}

	
	/*
	 * ITEM ADIC-BRB47-1-OCC1 NUMERO 1
	 */		
	/**
	 * @return the bit47Pref_1
	 */
	@PositionalField(initialPosition= 14, finalPosition= 29)
	public String getBit47Pref_1() {
		return bit47Pref_1;
	}
	/**
	 * @param bit47Pref_1 the bit47Pref_1 to set
	 */
	public void setBit47Pref_1(String bit47Pref_1) {
		this.bit47Pref_1 = bit47Pref_1;
	}

	/**
	 * @return the bit47FonDis_1_A
	 */
	@PositionalField(initialPosition= 30, finalPosition= 33)
	public String getTelefoneDiscado_1_A() {
		return telefoneDiscado_1_A;
	}
	/**
	 * @param bit47FonDis_1_A the bit47FonDis_1_A to set
	 */
	public void setTelefoneDiscado_1_A(String bit47FonDis_1_A) {
		this.telefoneDiscado_1_A = bit47FonDis_1_A;
	}
	
	/**
	 * @return the bit47ModCon_1
	 */
	@PositionalField(initialPosition= 34, finalPosition= 35)
	public String getModoConexao_1() {
		return modoConexao_1;
	}
	/**
	 * @param bit47ModCon_1 the bit47ModCon_1 to set
	 */
	public void setModoConexao_1(String bit47ModCon_1) {
		this.modoConexao_1 = bit47ModCon_1;
	}

	/**
	 * @return the bit47QuantidadeTen_1_A
	 */
	@PositionalField(initialPosition= 46, finalPosition= 47)
	public String getQuantidadeTentativasDiscagens_1_A() {
		return quantidadeTentativasDiscagens_1_A;
	}
	/**
	 * @param bit47QuantidadeTen_1_A the bit47QuantidadeTen_1_A to set
	 */
	public void setQuantidadeTentativasDiscagens_1_A(String bit47QuantidadeTen_1_A) {
		this.quantidadeTentativasDiscagens_1_A = bit47QuantidadeTen_1_A;
	}

	/**
	 * @return the bit47ResDis_1_A1
	 */
	@PositionalField(initialPosition= 48, finalPosition= 49)
	public String getResultadoDiscagem_1_A1() {
		return resultadoDiscagem_1_A1;
	}
	/**
	 * @param bit47ResDis_1_A1 the bit47ResDis_1_A1 to set
	 */
	public void setResultadoDiscagem_1_A1(String bit47ResDis_1_A1) {
		this.resultadoDiscagem_1_A1 = bit47ResDis_1_A1;
	}

	/**
	 * @return the bit47ResDis_1_A2
	 */
	@PositionalField(initialPosition= 50, finalPosition= 51)
	public String getResultadoDiscagem_1_A2() {
		return resultadoDiscagem_1_A2;
	}
	/**
	 * @param bit47ResDis_1_A2 the bit47ResDis_1_A2 to set
	 */
	public void setResultadoDiscagem_1_A2(String bit47ResDis_1_A2) {
		this.resultadoDiscagem_1_A2 = bit47ResDis_1_A2;
	}

	/**
	 * @return the bit47ResDis_1_A3
	 */
	@PositionalField(initialPosition= 52, finalPosition= 53)
	public String getResultadoDiscagem_1_A3() {
		return resultadoDiscagem_1_A3;
	}
	/**
	 * @param bit47ResDis_1_A3 the bit47ResDis_1_A3 to set
	 */
	public void setResultadoDiscagem_1_A3(String bit47ResDis_1_A3) {
		this.resultadoDiscagem_1_A3 = bit47ResDis_1_A3;
	}

	/**
	 * @return the bit47ResDis_1_A4
	 */
	@PositionalField(initialPosition= 54, finalPosition= 55)
	public String getResultadoDiscagem_1_A4() {
		return resultadoDiscagem_1_A4;
	}
	/**
	 * @param bit47ResDis_1_A4 the bit47ResDis_1_A4 to set
	 */
	public void setResultadoDiscagem_1_A4(String bit47ResDis_1_A4) {
		this.resultadoDiscagem_1_A4 = bit47ResDis_1_A4;
	}

	/**
	 * @return the bit47ResDis_1_A5
	 */
	@PositionalField(initialPosition= 56, finalPosition= 57)
	public String getResultadoDiscagem_1_A5() {
		return resultadoDiscagem_1_A5;
	}
	/**
	 * @param bit47ResDis_1_A5 the bit47ResDis_1_A5 to set
	 */
	public void setResultadoDiscagem_1_A5(String bit47ResDis_1_A5) {
		this.resultadoDiscagem_1_A5 = bit47ResDis_1_A5;
	}

	/**
	 * @return the bit47ResDis_1_A6
	 */
	@PositionalField(initialPosition= 58, finalPosition= 59)
	public String getResultadoDiscagem_1_A6() {
		return resultadoDiscagem_1_A6;
	}
	/**
	 * @param bit47ResDis_1_A6 the bit47ResDis_1_A6 to set
	 */
	public void setResultadoDiscagem_1_A6(String bit47ResDis_1_A6) {
		this.resultadoDiscagem_1_A6 = bit47ResDis_1_A6;
	}

	/**
	 * @return the bit47ResDis_1_A7
	 */
	@PositionalField(initialPosition= 60, finalPosition= 61)
	public String getResultadoDiscagem_1_A7() {
		return resultadoDiscagem_1_A7;
	}
	/**
	 * @param bit47ResDis_1_A7 the bit47ResDis_1_A7 to set
	 */
	public void setResultadoDiscagem_1_A7(String bit47ResDis_1_A7) {
		this.resultadoDiscagem_1_A7 = bit47ResDis_1_A7;
	}

	/**
	 * @return the bit47ResDis_1_A8
	 */
	@PositionalField(initialPosition= 62, finalPosition= 63)
	public String getResultadoDiscagem_1_A8() {
		return resultadoDiscagem_1_A8;
	}
	/**
	 * @param bit47ResDis_1_A8 the bit47ResDis_1_A8 to set
	 */
	public void setResultadoDiscagem_1_A8(String bit47ResDis_1_A8) {
		this.resultadoDiscagem_1_A8 = bit47ResDis_1_A8;
	}

	/**
	 * @return the bit47ResDis_1_A9
	 */
	@PositionalField(initialPosition= 64, finalPosition= 65)
	public String getResultadoDiscagem_1_A9() {
		return resultadoDiscagem_1_A9;
	}
	/**
	 * @param bit47ResDis_1_A9 the bit47ResDis_1_A9 to set
	 */
	public void setResultadoDiscagem_1_A9(String bit47ResDis_1_A9) {
		this.resultadoDiscagem_1_A9 = bit47ResDis_1_A9;
	}

	/**
	 * @return the bit47ResDis_1_A10
	 */
	@PositionalField(initialPosition= 66, finalPosition= 67)
	public String getResultadoDiscagem_1_A10() {
		return resultadoDiscagem_1_A10;
	}
	/**
	 * @param bit47ResDis_1_A10 the bit47ResDis_1_A10 to set
	 */
	public void setResultadoDiscagem_1_A10(String bit47ResDis_1_A10) {
		this.resultadoDiscagem_1_A10 = bit47ResDis_1_A10;
	}

	/**
	 * @return the bit47FonDis_1_B
	 */
	@PositionalField(initialPosition= 68, finalPosition= 83)
	public String getTelefoneDiscado_1_B() {
		return telefoneDiscado_1_B;
	}
	/**
	 * @param bit47FonDis_1_B the bit47FonDis_1_B to set
	 */
	public void setTelefoneDiscado_1_B(String bit47FonDis_1_B) {
		this.telefoneDiscado_1_B = bit47FonDis_1_B;
	}

	/**
	 * @return the bit47QuantidadeTen_1_B
	 */
	@PositionalField(initialPosition= 84, finalPosition= 85)
	public String getQuantidadeTentativasDiscagens_1_B() {
		return quantidadeTentativasDiscagens_1_B;
	}
	/**
	 * @param bit47QuantidadeTen_1_B the bit47QuantidadeTen_1_B to set
	 */
	public void setQuantidadeTentativasDiscagens_1_B(String bit47QuantidadeTen_1_B) {
		this.quantidadeTentativasDiscagens_1_B = bit47QuantidadeTen_1_B;
	}

	/**
	 * @return the bit47ResDis_1_B1
	 */
	@PositionalField(initialPosition= 86, finalPosition= 87)
	public String getResultadoDiscagem_1_B1() {
		return resultadoDiscagem_1_B1;
	}
	/**
	 * @param bit47ResDis_1_B1 the bit47ResDis_1_B1 to set
	 */
	public void setResultadoDiscagem_1_B1(String bit47ResDis_1_B1) {
		this.resultadoDiscagem_1_B1 = bit47ResDis_1_B1;
	}

	/**
	 * @return the bit47ResDis_1_B2
	 */
	@PositionalField(initialPosition= 88, finalPosition= 89)
	public String getResultadoDiscagem_1_B2() {
		return resultadoDiscagem_1_B2;
	}
	/**
	 * @param bit47ResDis_1_B2 the bit47ResDis_1_B2 to set
	 */
	public void setResultadoDiscagem_1_B2(String bit47ResDis_1_B2) {
		this.resultadoDiscagem_1_B2 = bit47ResDis_1_B2;
	}

	/**
	 * @return the bit47ResDis_1_B3
	 */
	@PositionalField(initialPosition= 90, finalPosition= 91)
	public String getResultadoDiscagem_1_B3() {
		return resultadoDiscagem_1_B3;
	}
	/**
	 * @param bit47ResDis_1_B3 the bit47ResDis_1_B3 to set
	 */
	public void setResultadoDiscagem_1_B3(String bit47ResDis_1_B3) {
		this.resultadoDiscagem_1_B3 = bit47ResDis_1_B3;
	}

	/**
	 * @return the bit47ResDis_1_B4
	 */
	@PositionalField(initialPosition= 92, finalPosition= 93)
	public String getResultadoDiscagem_1_B4() {
		return resultadoDiscagem_1_B4;
	}
	/**
	 * @param bit47ResDis_1_B4 the bit47ResDis_1_B4 to set
	 */
	public void setResultadoDiscagem_1_B4(String bit47ResDis_1_B4) {
		this.resultadoDiscagem_1_B4 = bit47ResDis_1_B4;
	}

	/**
	 * @return the bit47ResDis_1_B5
	 */
	@PositionalField(initialPosition= 94, finalPosition= 95)
	public String getResultadoDiscagem_1_B5() {
		return resultadoDiscagem_1_B5;
	}
	/**
	 * @param bit47ResDis_1_B5 the bit47ResDis_1_B5 to set
	 */
	public void setResultadoDiscagem_1_B5(String bit47ResDis_1_B5) {
		this.resultadoDiscagem_1_B5 = bit47ResDis_1_B5;
	}

	/**
	 * @return the bit47ResDis_1_B6
	 */
	@PositionalField(initialPosition= 96, finalPosition= 97)
	public String getResultadoDiscagem_1_B6() {
		return resultadoDiscagem_1_B6;
	}
	/**
	 * @param bit47ResDis_1_B6 the bit47ResDis_1_B6 to set
	 */
	public void setResultadoDiscagem_1_B6(String bit47ResDis_1_B6) {
		this.resultadoDiscagem_1_B6 = bit47ResDis_1_B6;
	}

	/**
	 * @return the bit47ResDis_1_B7
	 */
	@PositionalField(initialPosition= 98, finalPosition= 99)
	public String getResultadoDiscagem_1_B7() {
		return resultadoDiscagem_1_B7;
	}
	/**
	 * @param bit47ResDis_1_B7 the bit47ResDis_1_B7 to set
	 */
	public void setResultadoDiscagem_1_B7(String bit47ResDis_1_B7) {
		this.resultadoDiscagem_1_B7 = bit47ResDis_1_B7;
	}

	/**
	 * @return the bit47ResDis_1_B8
	 */
	@PositionalField(initialPosition= 100, finalPosition= 101)
	public String getResultadoDiscagem_1_B8() {
		return resultadoDiscagem_1_B8;
	}
	/**
	 * @param bit47ResDis_1_B8 the bit47ResDis_1_B8 to set
	 */
	public void setResultadoDiscagem_1_B8(String bit47ResDis_1_B8) {
		this.resultadoDiscagem_1_B8 = bit47ResDis_1_B8;
	}

	/**
	 * @return the bit47ResDis_1_B9
	 */
	@PositionalField(initialPosition= 102, finalPosition= 103)
	public String getResultadoDiscagem_1_B9() {
		return resultadoDiscagem_1_B9;
	}
	/**
	 * @param bit47ResDis_1_B9 the bit47ResDis_1_B9 to set
	 */
	public void setResultadoDiscagem_1_B9(String bit47ResDis_1_B9) {
		this.resultadoDiscagem_1_B9 = bit47ResDis_1_B9;
	}

	/**
	 * @return the bit47ResDis_1_B10
	 */
	@PositionalField(initialPosition= 104, finalPosition= 105)
	public String getResultadoDiscagem_1_B10() {
		return resultadoDiscagem_1_B10;
	}
	/**
	 * @param bit47ResDis_1_B10 the bit47ResDis_1_B10 to set
	 */
	public void setResultadoDiscagem_1_B10(String bit47ResDis_1_B10) {
		this.resultadoDiscagem_1_B10 = bit47ResDis_1_B10;
	}

	/**
	 * @return the bit47FonDis_1_C
	 */
	@PositionalField(initialPosition= 106, finalPosition= 121)
	public String getTelefoneDiscado_1_C() {
		return telefoneDiscado_1_C;
	}
	/**
	 * @param bit47FonDis_1_C the bit47FonDis_1_C to set
	 */
	public void setTelefoneDiscado_1_C(String bit47FonDis_1_C) {
		this.telefoneDiscado_1_C = bit47FonDis_1_C;
	}

	/**
	 * @return the bit47QuantidadeTen_1_C
	 */
	@PositionalField(initialPosition= 122, finalPosition= 123)
	public String getQuantidadeTentativasDiscagens_1_C() {
		return quantidadeTentativasDiscagens_1_C;
	}
	/**
	 * @param bit47QuantidadeTen_1_C the bit47QuantidadeTen_1_C to set
	 */
	public void setQuantidadeTentativasDiscagens_1_C(String bit47QuantidadeTen_1_C) {
		this.quantidadeTentativasDiscagens_1_C = bit47QuantidadeTen_1_C;
	}

	/**
	 * @return the bit47ResDis_1_C1
	 */
	@PositionalField(initialPosition= 124, finalPosition= 125)
	public String getResultadoDiscagem_1_C1() {
		return resultadoDiscagem_1_C1;
	}
	/**
	 * @param bit47ResDis_1_C1 the bit47ResDis_1_C1 to set
	 */
	public void setResultadoDiscagem_1_C1(String bit47ResDis_1_C1) {
		this.resultadoDiscagem_1_C1 = bit47ResDis_1_C1;
	}

	/**
	 * @return the bit47ResDis_1_C2
	 */
	@PositionalField(initialPosition= 126, finalPosition= 127)
	public String getResultadoDiscagem_1_C2() {
		return resultadoDiscagem_1_C2;
	}
	/**
	 * @param bit47ResDis_1_C2 the bit47ResDis_1_C2 to set
	 */
	public void setResultadoDiscagem_1_C2(String bit47ResDis_1_C2) {
		this.resultadoDiscagem_1_C2 = bit47ResDis_1_C2;
	}

	/**
	 * @return the bit47ResDis_1_C3
	 */
	@PositionalField(initialPosition= 128, finalPosition= 129)
	public String getResultadoDiscagem_1_C3() {
		return resultadoDiscagem_1_C3;
	}
	/**
	 * @param bit47ResDis_1_C3 the bit47ResDis_1_C3 to set
	 */
	public void setResultadoDiscagem_1_C3(String bit47ResDis_1_C3) {
		this.resultadoDiscagem_1_C3 = bit47ResDis_1_C3;
	}

	/**
	 * @return the bit47ResDis_1_C4
	 */
	@PositionalField(initialPosition= 130, finalPosition= 131)
	public String getResultadoDiscagem_1_C4() {
		return resultadoDiscagem_1_C4;
	}
	/**
	 * @param bit47ResDis_1_C4 the bit47ResDis_1_C4 to set
	 */
	public void setResultadoDiscagem_1_C4(String bit47ResDis_1_C4) {
		this.resultadoDiscagem_1_C4 = bit47ResDis_1_C4;
	}

	/**
	 * @return the bit47ResDis_1_C5
	 */
	@PositionalField(initialPosition= 132, finalPosition= 133)
	public String getResultadoDiscagem_1_C5() {
		return resultadoDiscagem_1_C5;
	}
	/**
	 * @param bit47ResDis_1_C5 the bit47ResDis_1_C5 to set
	 */
	public void setResultadoDiscagem_1_C5(String bit47ResDis_1_C5) {
		this.resultadoDiscagem_1_C5 = bit47ResDis_1_C5;
	}

	/**
	 * @return the bit47ResDis_1_C6
	 */
	@PositionalField(initialPosition= 134, finalPosition= 135)
	public String getResultadoDiscagem_1_C6() {
		return resultadoDiscagem_1_C6;
	}
	/**
	 * @param bit47ResDis_1_C6 the bit47ResDis_1_C6 to set
	 */
	public void setResultadoDiscagem_1_C6(String bit47ResDis_1_C6) {
		this.resultadoDiscagem_1_C6 = bit47ResDis_1_C6;
	}

	/**
	 * @return the bit47ResDis_1_C7
	 */
	@PositionalField(initialPosition= 136, finalPosition= 137)
	public String getResultadoDiscagem_1_C7() {
		return resultadoDiscagem_1_C7;
	}
	/**
	 * @param bit47ResDis_1_C7 the bit47ResDis_1_C7 to set
	 */
	public void setResultadoDiscagem_1_C7(String bit47ResDis_1_C7) {
		this.resultadoDiscagem_1_C7 = bit47ResDis_1_C7;
	}

	/**
	 * @return the bit47ResDis_1_C8
	 */
	@PositionalField(initialPosition= 138, finalPosition= 139)
	public String getResultadoDiscagem_1_C8() {
		return resultadoDiscagem_1_C8;
	}
	/**
	 * @param bit47ResDis_1_C8 the bit47ResDis_1_C8 to set
	 */
	public void setResultadoDiscagem_1_C8(String bit47ResDis_1_C8) {
		this.resultadoDiscagem_1_C8 = bit47ResDis_1_C8;
	}

	/**
	 * @return the bit47ResDis_1_C9
	 */
	@PositionalField(initialPosition= 140, finalPosition= 141)
	public String getResultadoDiscagem_1_C9() {
		return resultadoDiscagem_1_C9;
	}
	/**
	 * @param bit47ResDis_1_C9 the bit47ResDis_1_C9 to set
	 */
	public void setResultadoDiscagem_1_C9(String bit47ResDis_1_C9) {
		this.resultadoDiscagem_1_C9 = bit47ResDis_1_C9;
	}

	/**
	 * @return the bit47ResDis_1_C10
	 */
	@PositionalField(initialPosition= 142, finalPosition= 143)
	public String getResultadoDiscagem_1_C10() {
		return resultadoDiscagem_1_C10;
	}
	/**
	 * @param bit47ResDis_1_C10 the bit47ResDis_1_C10 to set
	 */
	public void setResultadoDiscagem_1_C10(String bit47ResDis_1_C10) {
		this.resultadoDiscagem_1_C10 = bit47ResDis_1_C10;
	}

	
	/**
	 * @return the filler
	 */
	@PositionalField(initialPosition= 430, finalPosition= 430)
	public String getFiller() {
		return filler;
	}
	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		this.filler = filler;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
