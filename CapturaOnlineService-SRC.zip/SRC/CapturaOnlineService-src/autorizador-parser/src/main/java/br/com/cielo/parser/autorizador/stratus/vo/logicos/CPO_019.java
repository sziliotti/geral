package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

import br.com.cielo.parser.autorizador.stratus.vo.logicos.decorator.Double10PosDecorator;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_019, sobre Dados Pague Conta.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_019 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	public static Logger logger= LoggerFactory.getLogger(CPO_019.class);
	
	private String pedidoEcommerce;
	private String softwareDescriptor;
	private String ciersMonitoracao;
	private String switchVisa;
	private String indicadorSkyline;
	private String codigoServicoPOS;
	private double valorPagConta;
	
	public CPO_019(){		
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-PEDIDO-E-COMMERCE
	 *
	 * @return the pedidoEcommerce
	 */
	@PositionalField(initialPosition= 1, finalPosition= 20)
	public String getPedidoEcommerce() {
		return pedidoEcommerce;
	}

	/**
	 * @param pedidoEcommerce the pedidoEcommerce to set
	 */
	public void setPedidoEcommerce(String pedidoEcommerce) {
		this.pedidoEcommerce = pedidoEcommerce;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-SOFT-DESCRIPTOR 
	 *
	 * @return the softwareDescriptor
	 */
	@PositionalField(initialPosition= 21, finalPosition= 33)
	public String getSoftwareDescriptor() {
		return softwareDescriptor;
	}

	/**
	 * @param softwareDescriptor the softwareDescriptor to set
	 */
	public void setSoftwareDescriptor(String softwareDescriptor) {
		this.softwareDescriptor = softwareDescriptor;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-CIERS-MONITORACAO
	 *
	 * @return the ciersMonitoracao
	 */
	@PositionalField(initialPosition= 34, finalPosition= 39)
	public String getCiersMonitoracao() {
		return ciersMonitoracao;
	}

	/**
	 * @param ciersMonitoracao the ciersMonitoracao to set
	 */
	public void setCiersMonitoracao(String ciersMonitoracao) {
		this.ciersMonitoracao = ciersMonitoracao;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-SWITCH-VISA
	 *
	 * @return the switchVisa
	 */
	@PositionalField(initialPosition= 40, finalPosition= 40)
	public String getSwitchVisa() {
		return switchVisa;
	}

	/**
	 * @param switchVisa the switchVisa to set
	 */
	public void setSwitchVisa(String switchVisa) {
		this.switchVisa = switchVisa;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-IND-SKYLINE
	 *
	 * @return the indicadorSkyline
	 */
	@PositionalField(initialPosition= 41, finalPosition= 41)
	public String getIndicadorSkyline() {
		return indicadorSkyline;
	}

	/**
	 * @param indicadorSkyline the indicadorSkyline to set
	 */
	public void setIndicadorSkyline(String indicadorSkyline) {
		this.indicadorSkyline = indicadorSkyline;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-COD-SERV-POS
	 *
	 * @return the codigoServicoPOS
	 */
	@PositionalField(initialPosition= 42, finalPosition= 44)
	public String getCodigoServicoPOS() {
		return codigoServicoPOS;
	}

	/**
	 * @param codigoServicoPOS the codigoServicoPOS to set
	 */
	public void setCodigoServicoPOS(String codigoServicoPOS) {
		this.codigoServicoPOS = codigoServicoPOS;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-VAL-PAG-CONTA
	 *
	 * @return the valorPagConta
	 */
	@PositionalField(initialPosition= 45, finalPosition= 54, decorator= Double10PosDecorator.class)
	public double getValorPagConta() {
		return valorPagConta;
	}

	/**
	 * @param valorPagConta the valorPagConta to set
	 */
	public void setValorPagConta(double valorPagConta) {
		this.valorPagConta = valorPagConta;
	}
	/**
	 * @param valorPagConta the valorPagConta to set
	 */
	/*public void setValorPagConta(String valorPagConta) {		
		String valFin= valorPagConta.substring(0, 8)+"."+valorPagConta.substring(8);		
		try {
			this.valorPagConta= Double.parseDouble(valFin);
		} catch (NumberFormatException e) {
			this.valorPagConta= 0;
			logger.warn("Erro realizando parser no objeto [CPO_019], em campo numerico[valorPagConta]. Valor recebido= '"+valorPagConta+"'");			
		}
	}*/
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
	
}
