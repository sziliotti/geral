package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

import br.com.cielo.parser.autorizador.stratus.vo.logicos.decorator.Double12PosDecorator;


/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_023, referente Dados Fechamento de Lotes.
 * 
 * <DL><DT><B>Criada em:</B><DD>19/12/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_023 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String quantidadeVendaCredito;
	private double valorVendaCredito;
	private String quantidadeCancelamentoCredito;
	private double valorCancelamentoCredito;
	private String quantidadeVendaDebito;
	private double valorVendaDebito;
	private String quantidadeCancelamentoDebito;
	private double valorCancelamentoDebito;
	private String quantidadeVendaSmart;
	private double valorVendaSmart;
	
	
	public CPO_023(){		
	}
	
	/**	 
	 * Representa o Campo STRATUS:  ACTR-LOT-QTT-VND-CRED
	 * 
	 * @return the quantidadeVendaCredito
	 */
	@PositionalField(initialPosition= 1, finalPosition= 4)
	public String getQuantidadeVendaCredito() {
		return quantidadeVendaCredito;
	}
	/**
	 * @param quantidadeVendaCredito the quantidadeVendaCredito to set
	 */
	public void setQuantidadeVendaCredito(String quantidadeVendaCredito) {
		this.quantidadeVendaCredito = quantidadeVendaCredito;
	}

	/**	 
	 * Representa o Campo STRATUS:  ACTR-LOT-VAL-VND-CRED
	 * 
	 * @return the valorVendaCredito
	 */
	@PositionalField(initialPosition= 5, finalPosition= 16, decorator= Double12PosDecorator.class)
	public double getValorVendaCredito() {
		return valorVendaCredito;
	}
	/**
	 * @param valorVendaCredito the valorVendaCredito to set
	 */
	public void setValorVendaCredito(double valorVendaCredito) {
		this.valorVendaCredito = valorVendaCredito;
	}

	/**	 
	 * Representa o Campo STRATUS:  ACTR-LOT-QTT-CAN-CRED
	 *
	 * @return the quantidadeCancelamentoCredito
	 */
	@PositionalField(initialPosition= 17, finalPosition= 20)
	public String getQuantidadeCancelamentoCredito() {
		return quantidadeCancelamentoCredito;
	}
	/**
	 * @param quantidadeCancelamentoCredito the quantidadeCancelamentoCredito to set
	 */
	public void setQuantidadeCancelamentoCredito(String quantidadeCancelamentoCredito) {
		this.quantidadeCancelamentoCredito = quantidadeCancelamentoCredito;
	}

	/**	 
	 * Representa o Campo STRATUS:  ACTR-LOT-VAL-CAN-CRED
	 *
	 * @return the valorCancelamentoCredito
	 */
	@PositionalField(initialPosition= 21, finalPosition= 32, decorator= Double12PosDecorator.class)
	public double getValorCancelamentoCredito() {
		return valorCancelamentoCredito;
	}
	/**
	 * @param valorCancelamentoCredito the valorCancelamentoCredito to set
	 */
	public void setValorCancelamentoCredito(double valorCancelamentoCredito) {
		this.valorCancelamentoCredito = valorCancelamentoCredito;
	}

	/**	 
	 * Representa o Campo STRATUS:  ACTR-LOT-QTT-VND-DEBTO
	 *
	 * @return the quantidadeVendaDebito
	 */
	@PositionalField(initialPosition= 33, finalPosition= 36)
	public String getQuantidadeVendaDebito() {
		return quantidadeVendaDebito;
	}
	/**
	 * @param quantidadeVendaDebito the quantidadeVendaDebito to set
	 */
	public void setQuantidadeVendaDebito(String quantidadeVendaDebito) {
		this.quantidadeVendaDebito = quantidadeVendaDebito;
	}

	/**	 
	 * Representa o Campo STRATUS:  ACTR-LOT-VAL-VND-DEBTO
	 *
	 * @return the valorVendaDebito
	 */
	@PositionalField(initialPosition= 37, finalPosition= 48, decorator= Double12PosDecorator.class)
	public double getValorVendaDebito() {
		return valorVendaDebito;
	}
	/**
	 * @param valorVendaDebito the valorVendaDebito to set
	 */
	public void setValorVendaDebito(double valorVendaDebito) {
		this.valorVendaDebito = valorVendaDebito;
	}

	/**	 
	 * Representa o Campo STRATUS:  ACTR-LOT-QTT-CAN-DEBTO
	 *
	 * @return the quantidadeCancelamentoDebito
	 */
	@PositionalField(initialPosition= 49, finalPosition= 52)
	public String getQuantidadeCancelamentoDebito() {
		return quantidadeCancelamentoDebito;
	}
	/**
	 * @param quantidadeCancelamentoDebito the quantidadeCancelamentoDebito to set
	 */
	public void setQuantidadeCancelamentoDebito(String quantidadeCancelamentoDebito) {
		this.quantidadeCancelamentoDebito = quantidadeCancelamentoDebito;
	}

	/**	 
	 * Representa o Campo STRATUS:  ACTR-LOT-VAL-CAN-DEBTO
	 *
	 * @return the valorCancelamentoDebito
	 */
	@PositionalField(initialPosition= 53, finalPosition= 64, decorator= Double12PosDecorator.class)
	public double getValorCancelamentoDebito() {
		return valorCancelamentoDebito;
	}
	/**
	 * @param valorCancelamentoDebito the valorCancelamentoDebito to set
	 */
	public void setValorCancelamentoDebito(double valorCancelamentoDebito) {
		this.valorCancelamentoDebito = valorCancelamentoDebito;
	}

	/**	 
	 * Representa o Campo STRATUS:  ACTR-LOT-QTT-VND-SMART
	 *
	 * @return the quantidadeVendaSmart
	 */
	@PositionalField(initialPosition= 65, finalPosition= 68)
	public String getQuantidadeVendaSmart() {
		return quantidadeVendaSmart;
	}
	/**
	 * @param quantidadeVendaSmart the quantidadeVendaSmart to set
	 */
	public void setQuantidadeVendaSmart(String quantidadeVendaSmart) {
		this.quantidadeVendaSmart = quantidadeVendaSmart;
	}

	/**	 
	 * Representa o Campo STRATUS:  ACTR-LOT-VAL-VND-SMART
	 *
	 * @return the valorVendaSmart
	 */
	@PositionalField(initialPosition= 69, finalPosition= 80, decorator= Double12PosDecorator.class)
	public double getValorVendaSmart() {
		return valorVendaSmart;
	}
	/**
	 * @param valorVendaSmart the valorVendaSmart to set
	 */
	public void setValorVendaSmart(double valorVendaSmart) {
		this.valorVendaSmart = valorVendaSmart;
	}
	

	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
