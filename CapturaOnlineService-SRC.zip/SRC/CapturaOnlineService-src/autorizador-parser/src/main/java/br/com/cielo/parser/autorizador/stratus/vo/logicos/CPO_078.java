package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

import br.com.cielo.parser.autorizador.stratus.vo.logicos.decorator.Double12PosDecorator;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.decorator.Double5PosDecorator;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.decorator.Double9PosDecorator;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_078, sobre Dados Area Livre.
 * 
 * <DL><DT><B>Criada em:</B><DD>23/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_078 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	public static Logger logger= LoggerFactory.getLogger(CPO_078.class);
	
	private double taxaComissao;
	private double valorTarifa;
	private double valorComissao;
	private double valorIntercam;
	private String de61PosData;
	private String de22PosData;
	private String filler;
	private String promocaoBB;
	private String promocaoBBResposta;
	private double valorVendaOriginal;
	private String horaAgendaTelecarga;
	private String estabelecimentoBandeira;
	private String filler2;
	private String codParcela;
	private String filler3;
	
	public CPO_078(){		
	}

	
	/**
	 * Representa o Campo STRATUS: ACTR-TAX-COMISSAO
	 * 
	 * @return the taxaComissao
	 */
	@PositionalField(initialPosition= 1, finalPosition= 5, decorator= Double5PosDecorator.class)
	public double getTaxaComissao() {
		return taxaComissao;
	}
	/**
	 * @param taxaComissao the taxaComissao to set
	 */
	public void setTaxaComissao(double taxaComissao) {
		this.taxaComissao = taxaComissao;
	}
	/**
	 * @param taxaComissao the taxaComissao to set
	 */
	/*public void setTaxaComissao(String taxaComissao) {
		if(taxaComissao!=null && !taxaComissao.equals("")){
			String txCom= taxaComissao.substring(0, 3)+"."+taxaComissao.substring(3);		
			try {
				this.taxaComissao= Double.parseDouble(txCom);
			} catch (NumberFormatException e) {
				this.taxaComissao= 0;
				logger.warn("Erro realizando parser no objeto [CPO_078], em campo numerico[taxaComissao]. Valor recebido= '"+taxaComissao+"'");			
			}
		}
	}*/

	/**
	 * Representa o Campo STRATUS: ACTR-VLR-TARIFA
	 * 
	 * @return the valorTarifa
	 */
	@PositionalField(initialPosition= 6, finalPosition= 10, decorator= Double5PosDecorator.class)
	public double getValorTarifa() {
		return valorTarifa;
	}
	/**
	 * @param valorTarifa the valorTarifa to set
	 */
	public void setValorTarifa(double valorTarifa) {
		this.valorTarifa = valorTarifa;
	}
	/**
	 * @param valorTarifa the valorTarifa to set
	 */
	/*public void setValorTarifa(String valorTarifa) {		
		if(valorTarifa!=null && !valorTarifa.equals("")){
			String valTar= valorTarifa.substring(0, 3)+"."+valorTarifa.substring(3);		
			try {
				this.valorTarifa= Double.parseDouble(valTar);
			} catch (NumberFormatException e) {
				this.valorTarifa= 0;
				logger.warn("Erro realizando parser no objeto [CPO_078], em campo numerico[valorTarifa]. Valor recebido= '"+valorTarifa+"'");			
			}
		}
	}*/

	/**
	 * Representa o Campo STRATUS: ACTR-VLR-COMISSAO
	 * 
	 * @return the valorComissao
	 */
	@PositionalField(initialPosition= 11, finalPosition= 19, decorator= Double9PosDecorator.class)
	public double getValorComissao() {
		return valorComissao;
	}
	/**
	 * @param valorComissao the valorComissao to set
	 */
	public void setValorComissao(double valorComissao) {
		this.valorComissao = valorComissao;
	}
	/**
	 * @param valorComissao the valorComissao to set
	 */
	/*public void setValorComissao(String valorComissao) {
		if(valorComissao!=null && !valorComissao.equals("")){
			String valCom= valorComissao.substring(0, 7)+"."+valorComissao.substring(7);		
			try {
				this.valorComissao= Double.parseDouble(valCom);
			} catch (NumberFormatException e) {
				this.valorComissao= 0;
				logger.warn("Erro realizando parser no objeto [CPO_078], em campo numerico[valorComissao]. Valor recebido= '"+valorComissao+"'");			
			}
		}
	}*/

	/**
	 * Representa o Campo STRATUS: ACTR-VLR-INTERCAM
	 * 
	 * @return the valorIntercam
	 */
	@PositionalField(initialPosition= 20, finalPosition= 28, decorator= Double9PosDecorator.class)
	public double getValorIntercam() {
		return valorIntercam;
	}
	/**
	 * @param valorIntercam the valorIntercam to set
	 */
	public void setValorIntercam(double valorIntercam) {
		this.valorIntercam = valorIntercam;
	}
	/**
	 * @param valorIntercam the valorIntercam to set
	 */
	/*public void setValorIntercam(String valorIntercam) {
		if(valorIntercam!=null && !valorIntercam.equals("")){
			String valInter= valorIntercam.substring(0, 7)+"."+valorIntercam.substring(7);		
			try {
				this.valorIntercam= Double.parseDouble(valInter);
			} catch (NumberFormatException e) {
				this.valorIntercam= 0;
				logger.warn("Erro realizando parser no objeto [CPO_078], em campo numerico[valorIntercam]. Valor recebido= '"+valorIntercam+"'");			
			}
		}
	}*/

	/**
	 * Representa o Campo STRATUS: ACTR-DE61-POS-DATA
	 * 
	 * @return the de61PosData
	 */
	@PositionalField(initialPosition= 29, finalPosition= 54)
	public String getDe61PosData() {
		return de61PosData;
	}
	/**
	 * @param de61PosData the de61PosData to set
	 */
	public void setDe61PosData(String de61PosData) {
		this.de61PosData = de61PosData;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-DE22-POS-DATA
	 * 
	 * @return the de22PosData
	 */
	@PositionalField(initialPosition= 55, finalPosition= 57)
	public String getDe22PosData() {
		return de22PosData;
	}
	/**
	 * @param de22PosData the de22PosData to set
	 */
	public void setDe22PosData(String de22PosData) {
		this.de22PosData = de22PosData;
	}

	/**
	 * Representa o Campo STRATUS: FILLER
	 * 
	 * @return the filler
	 */
	@PositionalField(initialPosition= 58, finalPosition= 58)
	public String getFiller() {
		return filler;
	}
	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		this.filler = filler;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-PROMOCAO-BB
	 * 
	 * @return the promocaoBB
	 */
	@PositionalField(initialPosition= 59, finalPosition= 59)
	public String getPromocaoBB() {
		return promocaoBB;
	}
	/**
	 * @param promocaoBB the promocaoBB to set
	 */
	public void setPromocaoBB(String promocaoBB) {
		this.promocaoBB = promocaoBB;
	}

	/**
	 * Representa o Campo STRATUS:  ACTR-PROMOCAO-BB-RESPOSTA
	 * 
	 * @return the promocaoBBResposta
	 */
	@PositionalField(initialPosition= 60, finalPosition= 61)
	public String getPromocaoBBResposta() {
		return promocaoBBResposta;
	}
	/**
	 * @param promocaoBBResposta the promocaoBBResposta to set
	 */
	public void setPromocaoBBResposta(String promocaoBBResposta) {
		this.promocaoBBResposta = promocaoBBResposta;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-VALOR-VENDA-ORIGINAL
	 * 
	 * @return the valorVendaOriginal
	 */
	@PositionalField(initialPosition= 62, finalPosition= 73, decorator= Double12PosDecorator.class)
	public double getValorVendaOriginal() {
		return valorVendaOriginal;
	}
	/**
	 * @param valorVendaOriginal the valorVendaOriginal to set
	 */
	public void setValorVendaOriginal(double valorVendaOriginal) {
		this.valorVendaOriginal = valorVendaOriginal;
	}
	/**
	 * @param valorVendaOriginal the valorVendaOriginal to set
	 */
	/*public void setValorVendaOriginal(String valorVendaOriginal) {
		if(valorVendaOriginal!=null && !valorVendaOriginal.equals("")){
			String valVenOrig= valorVendaOriginal.substring(0, 10)+"."+valorVendaOriginal.substring(10);
			try {
				this.valorVendaOriginal= Double.parseDouble(valVenOrig);
			} catch (NumberFormatException e) {
				this.valorVendaOriginal= 0;
				logger.warn("Erro realizando parser no objeto [CPO_078], em campo numerico[valorVendaOriginal]. Valor recebido= '"+valorVendaOriginal+"'");			
			}
		}
	}*/

	/**
	 * Representa o Campo STRATUS: ACTR-HORA-AGEND-TELECARGA
	 * 
	 * @return the horaAgendaTelecarga
	 */
	@PositionalField(initialPosition= 74, finalPosition= 77)
	public String getHoraAgendaTelecarga() {
		return horaAgendaTelecarga;
	}
	/**
	 * @param horaAgendaTelecarga the horaAgendaTelecarga to set
	 */
	public void setHoraAgendaTelecarga(String horaAgendaTelecarga) {
		this.horaAgendaTelecarga = horaAgendaTelecarga;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-ESTAB-BANDEIRA
	 * 
	 * @return the estabelecimentoBandeira
	 */
	@PositionalField(initialPosition= 78, finalPosition= 93)
	public String getEstabelecimentoBandeira() {
		return estabelecimentoBandeira;
	}
	/**
	 * @param estabelecimentoBandeira the estabelecimentoBandeira to set
	 */
	public void setEstabelecimentoBandeira(String estabelecimentoBandeira) {
		this.estabelecimentoBandeira = estabelecimentoBandeira;
	}

	/**
	 * Representa o Campo STRATUS: FILLER
	 * 
	 * @return the filler2
	 */
	@PositionalField(initialPosition= 94, finalPosition= 98)
	public String getFiller2() {
		return filler2;
	}
	/**
	 * @param filler2 the filler2 to set
	 */
	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-COD-PARC
	 * 
	 * @return the codParcela
	 */
	@PositionalField(initialPosition= 99, finalPosition= 99)
	public String getCodParcela() {
		return codParcela;
	}
	/**
	 * @param codParcela the codParcela to set
	 */
	public void setCodParcela(String codParcela) {
		this.codParcela = codParcela;
	}

	/**
	 * Representa o Campo STRATUS: FILLER
	 * 
	 * @return the filler3
	 */
	@PositionalField(initialPosition= 100, finalPosition= 100)
	public String getFiller3() {
		return filler3;
	}
	/**
	 * @param filler3 the filler3 to set
	 */
	public void setFiller3(String filler3) {
		this.filler3 = filler3;
	}


	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
