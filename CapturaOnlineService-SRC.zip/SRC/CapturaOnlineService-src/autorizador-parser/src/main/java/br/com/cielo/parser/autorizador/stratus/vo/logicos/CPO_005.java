package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 *<B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_005, sobre Dados xxxxx. 
 * 
 * <DL><DT><B>Criada em:</B><DD>23/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
@PositionalRecord
public class CPO_005 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	public static Logger logger= LoggerFactory.getLogger(CPO_005.class);
	
	private String cvv2_1;
	private String cvv2_2;
	
	
	public CPO_005(){		
	}
	
	/**
	 *  Representa o Campo STRATUS: ACTR-CVV2-1
	 * 
	 * @return the cvv2_1
	 */
	@PositionalField(initialPosition= 1, finalPosition= 1)
	public String getCvv2_1() {
		return cvv2_1;
	}

	/**
	 * @param cvv2_1 the cvv2_1 to set
	 */
	public void setCvv2_1(String cvv2_1) {
		this.cvv2_1 = cvv2_1;
	}

	/**
	 *  Representa o Campo STRATUS: ACTR-CVV2-2
	 *  
	 * @return the cvv2_2
	 */
	@PositionalField(initialPosition= 2, finalPosition= 6)
	public String getCvv2_2() {
		return cvv2_2;
	}

	/**
	 * @param cvv2_2 the cvv2_2 to set
	 */
	public void setCvv2_2(String cvv2_2) {
		this.cvv2_2 = cvv2_2;
	}

	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
