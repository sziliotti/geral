package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_067, sobre Dados do LYNX.
 * 
 * <DL><DT><B>Criada em:</B><DD>22/04/2014</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_067 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String status;
	private String timeout;
	private String acao;
	private String regraFiltro;
	private String regraLynx;
	private String scoreNeural;
	private String scoreRegra;
	private String behaviour;
	private String flagCTFTran;

	
	public CPO_067(){		
	}
	

	/**
	 * Representa o Campo STRATUS: ACTR-LYNX-STATUS
	 * 
	 * @return the status
	 */
	@PositionalField(initialPosition= 1, finalPosition= 1)
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}	

	/**
	 * Representa o Campo STRATUS: ACTR-LYNX-TIMEOUT
	 * 
	 * @return the timeout
	 */
	@PositionalField(initialPosition= 2, finalPosition= 2)
	public String getTimeout() {
		return timeout;
	}
	/**
	 * @param timeout the timeout to set
	 */
	public void setTimeout(String timeout) {
		this.timeout = timeout;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-LYNX-ACAO
	 * 
	 * @return the acao
	 */
	@PositionalField(initialPosition= 3, finalPosition= 4)
	public String getAcao() {
		return acao;
	}
	/**
	 * @param acao the acao to set
	 */
	public void setAcao(String acao) {
		this.acao = acao;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-LYNX-REGRA-FILTRO
	 * 
	 * @return the regraFiltro
	 */
	@PositionalField(initialPosition= 5, finalPosition= 7)
	public String getRegraFiltro() {
		return regraFiltro;
	}
	/**
	 * @param regraFiltro the regraFiltro to set
	 */
	public void setRegraFiltro(String regraFiltro) {
		this.regraFiltro = regraFiltro;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-LYNX-REGRA-LYNX
	 * 
	 * @return the regraLynx
	 */
	@PositionalField(initialPosition= 8, finalPosition= 13)
	public String getRegraLynx() {
		return regraLynx;
	}
	/**
	 * @param regraLynx the regraLynx to set
	 */
	public void setRegraLynx(String regraLynx) {
		this.regraLynx = regraLynx;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-LYNX-SCORE-NEURAL
	 * 
	 * @return the scoreNeural
	 */
	@PositionalField(initialPosition= 14, finalPosition= 16)
	public String getScoreNeural() {
		return scoreNeural;
	}
	/**
	 * @param scoreNeural the scoreNeural to set
	 */
	public void setScoreNeural(String scoreNeural) {
		this.scoreNeural = scoreNeural;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-LYNX-SCORE-REGRA
	 * 
	 * @return the scoreRegra
	 */
	@PositionalField(initialPosition= 17, finalPosition= 19)
	public String getScoreRegra() {
		return scoreRegra;
	}
	/**
	 * @param scoreRegra the scoreRegra to set
	 */
	public void setScoreRegra(String scoreRegra) {
		this.scoreRegra = scoreRegra;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-LYNX-BEHAVIOUR
	 * 
	 * @return the behaviour
	 */
	@PositionalField(initialPosition= 20, finalPosition= 21)
	public String getBehaviour() {
		return behaviour;
	}
	/**
	 * @param behaviour the behaviour to set
	 */
	public void setBehaviour(String behaviour) {
		this.behaviour = behaviour;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-FLAG-CTF-TRAN
	 * 
	 * @return the flagCTFTran
	 */
	@PositionalField(initialPosition= 22, finalPosition= 22)
	public String getFlagCTFTran() {
		return flagCTFTran;
	}
	/**
	 * @param flagCTFTran the flagCTFTran to set
	 */
	public void setFlagCTFTran(String flagCTFTran) {
		this.flagCTFTran = flagCTFTran;
	}


	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
