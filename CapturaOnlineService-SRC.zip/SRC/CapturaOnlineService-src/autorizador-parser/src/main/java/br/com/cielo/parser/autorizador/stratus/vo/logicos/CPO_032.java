package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_032, sobre Dados do xx.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_032 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String campo25FormatacaoVisa;
	private String idracal;
	private String modoEntrada;
	private String filler;
	
	public CPO_032(){		
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-CPO-25-VISA
	 *
	 * @return the campo25FormatacaoVisa
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public String getCampo25FormatacaoVisa() {
		return campo25FormatacaoVisa;
	}

	/**
	 * @param campo25FormatacaoVisa the campo25FormatacaoVisa to set
	 */
	public void setCampo25FormatacaoVisa(String campo25FormatacaoVisa) {
		this.campo25FormatacaoVisa = campo25FormatacaoVisa;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-IDRACAL
	 *
	 * @return the idracal
	 */
	@PositionalField(initialPosition= 3, finalPosition= 3)
	public String getIdracal() {
		return idracal;
	}

	/**
	 * @param idracal the idracal to set
	 */
	public void setIdracal(String idracal) {
		this.idracal = idracal;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-MODENT
	 *
	 * PLSC XZZV HATY, ONDE:
	*   P = CARACTER STICAS DO PIN PAD
	*       1 - SEM PIN PAD; 2 - PIN PAD SEM LEITOR DE
	*           CHIP;
	*       3 - PIN PAD COM LEITOR DE CHIP SEM M DULO
	*           SAM;
	*       4 - PIN PAD COM LEITOR DE CHIP COM M DULO
	*           SAM;
	*       5 - PIN PAD N O HOMOLO-GADO;
	*     *
	*   L = FORMA DE ENTRADA DO CART O
	*       0 - EMV;
	*       1 - APLICA  O PROPRIET RIA TIBC 1.0
	*           (VISA CASH);
	*       2 - APLICA  O PROPRIET RIA TIBC 3.0
	*           (VISA CASH);
	*       3 - LEITURA DA TRILHA 2;
	*       4 - DIGITADO;
	*       5 - EASY ENTRY;
	*       7 - LEITURA DA TRI-LHA 1;
	*     *
	*   S = FORMA DE OBTEN  O E TRATAMENTO DA SENHA
	*       1 - SEM SENHA;
	*       2 - SENHA VALIDADA ON LINE;
	*       3 - SENHA VALIDADA OFF LINE;
	*           OBS.: NAS TRANSA  ES NEGADAS OFF LINE
	*                 COM CHIPP (ADVICE),DEVE SER
	*                 ENVIADO O QUE OCORREU NA
	*                 TENTATIVA DE ENVIO ON LINE.
	*     *
	*   C = FORMA DE CARGA DE MOEDEIRO E USO DO PRODUTO
	*       COMPRE & SAQUE
	*       0 - N O TRATAR;
	*       1 - CARGA EM MOEDEIRO A PARTIR DE DINHEIRO
	*           EM ESP CIE (N O USADO);
	*       2 - CARGA EM MOEDEIRO A PARTIR DE CART O DE
	*           CR DITO (N O USADO);
	*       3 - CARGA EM MOEDEIRO A PARTIR DE CART O DE
	*           D BITO (N O USADO);
	*       5 - SAQUE ATRA-V S DO PRODUTO COMPRE&SAQUE
	*           A PARTIR DE CART O DE CR -DITO;
	*       6 - SAQUE ATRAV S DO PRODUTO COMPRE & SAQUE
	*           A PAR-TIR DE CART O DE D BITO;
	*     *
	*   X = FORMA DE TRUNCAMENTO DO CARTAO
	*       0 - NAO TRUNCOU O NUMERO DO CARTAO NA
	*           IMPRESSAO DO COMPROVANTE;
	*       1 - TRUNCOU O NUMERO DO CARTAO NA IMPRESSAO
	*           DO COMPROVANTE;
	*     
	*   ZZ = MODO DE CONEXAO
	*        10 - HDLC;
	*        20 - X.28;
	*        30 - R DIO;
	*        40 - LAN;
	*        50 - VISA II (EXCLUSIVO PARA TEF DIAL E CONEXAO GSM);
	*        60 - CONEXAO PPP (POSWEB);
	*        70 - CONEXAO GPRS / CDMA 1X (WIRE-LESS OUTDOOR);
	*        90 - GSM X.28; 
	*        95 - GSM VISA II.
	*     
        * V = Utilizado em transacoes Agro (Somente Host).
        *  
        * H = Habilitacao de Leitores de Cartao
        * 1 - Somente leitor Tarja habilitado;
        * 2 - Somente leitor Chip habilitado;
        * 3 - Somente leitor Contactless habilitado;
        * 4 - Leitor Tarja e Chip habilitados;
        * 5 - Leitor Tarja e Contactless habilitado;
        * 6 - Leitor Chip e Contactless habilitado;
        * 7 - Leitor Tarja, Chip e Contactless habilitado.
         * 
        * A = Identificacao do Portador
        * 0 - Cartao;
        * 1 - Numero do Celular;
        * 2 - PID.
        *  
        * T = Tipo de Solucao de Captura
        * 0 - POS;
        * 1 - TEF Dedicado;
        * 2 - TEF IP / Discado;
        * 3 - E-Commerce;
        * 4 - Visa Cash em Rede (Pedagio);
        * 5 - Celular;
        * 6 - URA;
        * 7 - EDI;
        * 8 - Chamada Externa (Celular).
        *  
        * Y = RFU.
	 *
	 * @return the modoEntrada
	 */
	@PositionalField(initialPosition= 4, finalPosition= 15,trimOnRead = false)
	public String getModoEntrada() {
		return modoEntrada;
	}

	/** 
	 * 
	 * 
	 * @param modoEntrada the modoEntrada to set
	 */
	public void setModoEntrada(String modoEntrada) {
		this.modoEntrada = modoEntrada;
	}

	/** 
	 * Representa o Campo STRATUS: FILLER
	 *
	 * @return the filler
	 */
	@PositionalField(initialPosition= 16, finalPosition= 16)
	public String getFiller() {
		return filler;
	}

	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		this.filler = filler;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}