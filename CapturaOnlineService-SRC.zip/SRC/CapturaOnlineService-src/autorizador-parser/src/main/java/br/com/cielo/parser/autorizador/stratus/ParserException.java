package br.com.cielo.parser.autorizador.stratus;

/**
 * <B>Projeto: Autorizador-Stratus-Parser</B><BR>
 * <br><br>
 * Classe de Excecao referente ao Parser das mensagens recebidas.
 * 
 * <DL><DT><B>Criada em:</B><DD>01/12/2017</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class ParserException extends Exception {
	private static final long serialVersionUID = 1952127564632714360L;

	/**
	 * 
	 */
	public ParserException() {
	}

	/**
	 * @param message
	 */
	public ParserException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public ParserException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public ParserException(String message, Throwable cause) {
		super(message, cause);
	}
}
