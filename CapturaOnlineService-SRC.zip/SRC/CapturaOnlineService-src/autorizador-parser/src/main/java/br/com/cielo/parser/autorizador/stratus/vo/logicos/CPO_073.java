package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;


/** 
 *<B>Projeto: Monitoracao-Parser</B><BR>
 *
 * Objeto referente ao campo CPO_073, sobre Dados de confirmacao de transacao DCC.
 *	 
 *<DL><DT><B>Criada em:</B><DD>11/04/2014</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_073 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String flagDCC;
	private String filler;
	
	
	public CPO_073(){		
	}


	/**
	 * Representa o Campo STRATUS: ACTR-FLAG-DCC
	 * <br><br>
	 * Possue os seguintes dominios:
	 * 					<DD>E - Elegível.
	 * 					<DD>N - Não elegível.
	 * 					<DD>D - DCC.
	 * 					<DD>P - Negado pela Planet.
	 * 					<DD>O - Não foi selecionado DCC pelo cliente.
	 * 					<DD>T - Time out da planet.
	 * 					<DD>F - Planet Fora do Ar.
	 * 
	 * @return the flagDCC
	 */
	@PositionalField(initialPosition= 1, finalPosition= 1)
	public String getFlagDCC() {
		return flagDCC;
	}


	/**
	 * @param flagDCC the flagDCC to set
	 */
	public void setFlagDCC(String tipoCriptografia) {
		this.flagDCC = tipoCriptografia;
	}

	/**
	 * @return the filler
	 */
	@PositionalField(initialPosition= 2, finalPosition= 2)
	public String getFiller() {
		return filler;
	}

	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String termKSN) {
		this.filler = termKSN;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
