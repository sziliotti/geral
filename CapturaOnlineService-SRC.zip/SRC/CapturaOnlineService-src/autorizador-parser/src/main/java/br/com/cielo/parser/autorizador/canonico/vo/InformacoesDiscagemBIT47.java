package br.com.cielo.parser.autorizador.canonico.vo;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/** 
 *<B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 *<br>
 * Objeto responsavel em armazenar as insformações de discagem do BIT47.
 *   
 *	 
 *<DL><DT><B>Criada em:</B><DD>27/11/2014</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class InformacoesDiscagemBIT47  implements Serializable {
	private static final long serialVersionUID= 1L;
	
	//Atributo que define a tentativa de discagem, se foi 1a tentativa ou 2a tentativa.
	private int numeroDaTentativa;
		
	//Atributo que define se essa tentativa foi com sucesso ou não
	private boolean isSucesso;
	
	//Atributo que define o codigo de resposta da Discagem.
	private String codigoRespostaDiscagem;
	
	
	
	/**
	 * Construtor Padrão.
	 */
	public InformacoesDiscagemBIT47() {
	}
	
	
		
	/**
	 * Retorna o numero da tentativa de discagem. Por exemplo: 1 para 1a tentativo, 2 para 2a tentativa.      
     * 
	 * @return the numeroDaTentativa
	 */
	public int getNumeroDaTentativa() {
		return numeroDaTentativa;
	}
	/**
	 * @param numeroDaTentativa the numeroDaTentativa to set
	 */
	public void setNumeroDaTentativa(int numeroDaTentativa) {
		this.numeroDaTentativa = numeroDaTentativa;
	}

	/**
	 *  Retorna se a tentatica de discagem foi com sucesso ou não. Verificação atraves do campo codigoRespostaDiscagem, caso o retorno seja "OK", atribuir
	 *  valor igual a "true". 
     * 
	 * @return the isSucesso
	 */
	public boolean isSucesso() {
		return isSucesso;
	}
	/**
	 * @param isSucesso the isSucesso to set
	 */
	public void setSucesso(boolean isSucesso) {
		this.isSucesso = isSucesso;
	}

	/**
	 *  Retorna o código do resultado de cada discagem efetuada para um mesmo telefone ou resultado obtido para um acesso via interface serial. 
	 *  Pode ser igual a ED (erro discando), EL (erro de linha), EX, etc. Completar o restante com '0' a direita.
	 *  Para GPRS/GSM - Resultado da Transação – OK ou o que ocorrer com a mensagem: “TENTE NOVAMENTE”: (G22, G33, etc.).  
     * <br><br>
     * Campo Stratus: CPO-905 (ADIC-BRB47-1-RES-DIS).
     * 
	 * @return the codigoRespostaDiscagem
	 */
	public String getCodigoRespostaDiscagem() {
		return codigoRespostaDiscagem;
	}
	/**
	 * @param codigoRespostaDiscagem the codigoRespostaDiscagem to set
	 */
	public void setCodigoRespostaDiscagem(String codigoRespostaDiscagem) {
		this.codigoRespostaDiscagem = codigoRespostaDiscagem;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
