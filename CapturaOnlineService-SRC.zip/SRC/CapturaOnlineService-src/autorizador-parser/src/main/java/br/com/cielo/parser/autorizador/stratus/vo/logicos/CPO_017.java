package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_017, sobre Dados do xx.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_017 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String emvBit55;
	private String bit55;
	private String bit55IdeSub;
	private String bit55DtaAti;
	private String bit55NumeroAlca;
	private String bit55Certificado;
	private String bit55ConInt;
	private String bit55NumeroAlce;
	private String bit55ContCa;
	private String bit55VrSpin;
	private String bit55Filler1;
	private String bit55Filler2;
	
	
	public CPO_017(){		
	}

	/**
	 * @return the emvBit55
	 */
	@PositionalField(initialPosition= 1, finalPosition= 1)
	public String getEmvBit55() {
		return emvBit55;
	}

	/**
	 * @param emvBit55 the emvBit55 to set
	 */
	public void setEmvBit55(String emvBit55) {
		this.emvBit55 = emvBit55;
	}

	/**
	 * @return the bit55
	 */
	@PositionalField(initialPosition= 2, finalPosition= 2)
	public String getBit55() {
		return bit55;
	}

	/**
	 * @param bit55 the bit55 to set
	 */
	public void setBit55(String bit55) {
		this.bit55 = bit55;
	}

	/**
	 * @return the bit55IdeSub
	 */
	@PositionalField(initialPosition= 3, finalPosition= 4)
	public String getBit55IdeSub() {
		return bit55IdeSub;
	}

	/**
	 * @param bit55IdeSub the bit55IdeSub to set
	 */
	public void setBit55IdeSub(String bit55IdeSub) {
		this.bit55IdeSub = bit55IdeSub;
	}

	/**
	 * @return the bit55DtaAti
	 */
	@PositionalField(initialPosition= 5, finalPosition= 16)
	public String getBit55DtaAti() {
		return bit55DtaAti;
	}

	/**
	 * @param bit55DtaAti the bit55DtaAti to set
	 */
	public void setBit55DtaAti(String bit55DtaAti) {
		this.bit55DtaAti = bit55DtaAti;
	}

	/**
	 * @return the bit55NumeroAlca
	 */
	@PositionalField(initialPosition= 17, finalPosition= 24)
	public String getBit55NumeroAlca() {
		return bit55NumeroAlca;
	}

	/**
	 * @param bit55NumeroAlca the bit55NumeroAlca to set
	 */
	public void setBit55NumeroAlca(String bit55NumeroAlca) {
		this.bit55NumeroAlca = bit55NumeroAlca;
	}

	/**
	 * @return the bit55Certificado
	 */
	@PositionalField(initialPosition= 25, finalPosition= 32)
	public String getBit55Certificado() {
		return bit55Certificado;
	}

	/**
	 * @param bit55Certificado the bit55Certificado to set
	 */
	public void setBit55Certificado(String bit55Certificado) {
		this.bit55Certificado = bit55Certificado;
	}

	/**
	 * @return the bit55ConInt
	 */
	@PositionalField(initialPosition= 33, finalPosition= 38)
	public String getBit55ConInt() {
		return bit55ConInt;
	}

	/**
	 * @param bit55ConInt the bit55ConInt to set
	 */
	public void setBit55ConInt(String bit55ConInt) {
		this.bit55ConInt = bit55ConInt;
	}

	/**
	 * @return the bit55NumeroAlce
	 */
	@PositionalField(initialPosition= 39, finalPosition= 54)
	public String getBit55NumeroAlce() {
		return bit55NumeroAlce;
	}

	/**
	 * @param bit55NumeroAlce the bit55NumeroAlce to set
	 */
	public void setBit55NumeroAlce(String bit55NumeroAlce) {
		this.bit55NumeroAlce = bit55NumeroAlce;
	}

	/**
	 * @return the bit55ContCa
	 */
	@PositionalField(initialPosition= 55, finalPosition= 62)
	public String getBit55ContCa() {
		return bit55ContCa;
	}

	/**
	 * @param bit55ContCa the bit55ContCa to set
	 */
	public void setBit55ContCa(String bit55ContCa) {
		this.bit55ContCa = bit55ContCa;
	}

	/**
	 * @return the bit55VrSpin
	 */
	@PositionalField(initialPosition= 63, finalPosition= 65)
	public String getBit55VrSpin() {
		return bit55VrSpin;
	}

	/**
	 * @param bit55VrSpin the bit55VrSpin to set
	 */
	public void setBit55VrSpin(String bit55VrSpin) {
		this.bit55VrSpin = bit55VrSpin;
	}

	/**
	 * @return the bit55Filler1
	 */
	@PositionalField(initialPosition= 66, finalPosition= 247)
	public String getBit55Filler1() {
		return bit55Filler1;
	}

	/**
	 * @param bit55Filler1 the bit55Filler1 to set
	 */
	public void setBit55Filler1(String bit55Filler1) {
		this.bit55Filler1 = bit55Filler1;
	}

	/**
	 * @return the bit55Filler2
	 */
	@PositionalField(initialPosition= 248, finalPosition= 248)
	public String getBit55Filler2() {
		return bit55Filler2;
	}

	/**
	 * @param bit55Filler2 the bit55Filler2 to set
	 */
	public void setBit55Filler2(String bit55Filler2) {
		this.bit55Filler2 = bit55Filler2;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
