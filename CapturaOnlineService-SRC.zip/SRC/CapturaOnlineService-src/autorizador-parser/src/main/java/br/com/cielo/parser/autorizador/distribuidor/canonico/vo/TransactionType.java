package br.com.cielo.parser.autorizador.distribuidor.canonico.vo;

/**
 * Enumerado que define o tipo da venda.
 *
 * @author nemer
 */
public enum TransactionType {
    /**
     * Pagamento a vista
     */
    SINGLE(1),
    /**
     * Recorrente (ex assinatura de regista)
     */
    RECURRING(2),
    /**
     * Parcelado
     */
    INSTALLMENT(3),
    /**
     * Desconhecido: só ocorre caso o tipo da venda seja não mapeada pelo
     * sistema.
     */
    UNKNOWN(4);

    private TransactionType(final int id) {
        this.id = id;
    }

    private int id;

    /**
     * Retorna o id do tipo da venda
     *
     * @return
     */
    public int getId() {
        return this.id;
    }

    /**
     * Retorna o enumerado do tipo da venda a partir de sua representação literal (single, recurring, installmets).
     * @param saleType literal do tipo da venda, ignorando a caixa
     * @return retorna o ENUM que representa o tipo da venda, ou UKNOWN se não é conhecido.
     */
    public static TransactionType getSaleTypeFromName(String saleType) {
        if (saleType == null) {
            return UNKNOWN;
        }
        saleType = saleType.trim();
        if ("single".equals(saleType)) {
            return SINGLE;
        } else if ("recurring".equalsIgnoreCase(saleType)) {
            return RECURRING;
        } else if ("installments".equalsIgnoreCase(saleType)) {
            return INSTALLMENT;
        } else {
            return UNKNOWN;
        }
    }

}
