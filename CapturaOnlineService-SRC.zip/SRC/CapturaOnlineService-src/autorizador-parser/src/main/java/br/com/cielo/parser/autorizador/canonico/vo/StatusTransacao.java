package br.com.cielo.parser.autorizador.canonico.vo;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * <br>
 * Enumeration responsável por descrever os status da Transação.
 * 
 * <DL><DT><B>Criada em:</B><DD>02/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public enum StatusTransacao {
	CANCELAMENTO(0), DESFAZIMENTO(1), APROVADO(2), NEGADO(3), INDEFINIDO(4), CAPTURADO(5);	
	//Status CAPTURADO, usado para eCommerce

	private int idStatus;
	
	StatusTransacao(int idStatus) {
		this.idStatus = idStatus;
	}
	
	public int getValue(){
		return idStatus;
	}
	
	/**
	 * Retorna enum corresponde ao status da transação.
	 * 
	 * @param idStatus
	 * @return
	 */
	public static StatusTransacao statusOf(int idStatus) {
		switch (idStatus) {
		case 0:
			return CANCELAMENTO;
		case 1:
			return DESFAZIMENTO;
		case 2:
			return APROVADO;
		case 3:
			return NEGADO;
		case 4:
			return INDEFINIDO;
		case 5:
			return CAPTURADO;
		default:
			return INDEFINIDO;
		} 
	}
	
}
