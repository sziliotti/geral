package br.com.cielo.parser.autorizador.jmx;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * <B>Projeto: autorizador-stratus-parser</B><BR><BR>
 *
 * Classe controladora dos contares e threads de MXBean de Monitoramento JMX.
 *
 * <DL><DT><B>Criada em:</B><DD>04/12/2017</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class MessageStatisticsCountController {

    private final AtomicInteger countMessages = new AtomicInteger(0);
    private final AtomicLong startTimeMessages = new AtomicLong(0);
    private Thread thread;

    public AtomicInteger getCountMessages() {
        return countMessages;
    }

    public AtomicLong getStartTimeMessages() {
        return startTimeMessages;
    }

    public Thread getThread() {
        return thread;
    }

    public void setThread(Thread thread) {
        this.thread = thread;
    }
}
