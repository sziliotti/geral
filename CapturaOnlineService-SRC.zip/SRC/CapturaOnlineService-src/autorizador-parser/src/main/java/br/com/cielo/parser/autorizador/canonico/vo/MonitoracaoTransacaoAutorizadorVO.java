package br.com.cielo.parser.autorizador.canonico.vo;

import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * <br>
 * Objeto responsavel em aramazenar as insformacoes utilizadas na Monitoracao
 * atraves da solucao Oracle CEP Oracle BAM.
 *
 * <DL><DT><B>Criada em:</B><DD>02/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class MonitoracaoTransacaoAutorizadorVO implements TransacaoBAM {

    private static final long serialVersionUID = 1L;
    private static final String COD_MULTIVAN_CIELO = "100";

    // Define o codigo da origem multivan
    private String codMultivan = COD_MULTIVAN_CIELO;

    //Atributo com o valor do uuid da mensagem recuperada do Stratus-Monitoracao-Adapter.
    private String uuidMessageAdapter;

    //Atributo com o valor do codigo do Grupo EC.    
    private String codGrupoEC;

    //Atributo com o valor do codigo da Localidade.
    private String codigoLocalidade;

    //Atributo com o valor do codigo da Localidade a partir da Lista Completa - Bit 47
    private String codigoCompleteLocalidade;

    //Atributo com o valor do nome da operadora.
    private String nomeOperadoraGPRS;

    //Atributo com o valor da forma de pagamento.
    private String formaPagamento;

    //Atributo "NSU" da Classe CPO_006. 
    private String nsu;

    // Atributo NSU_CAN do CPO_065 
    private String nsuCanRef;
    
    // artibuto que contem a confirmação do POS de transação aprovada pelo autorizador anteriormente obtida da classe CPO_018   
    private String nsuConfirmacaoAutorizacaoPOS;
    
    //Atributo "maquina" da Classe CPO_001. 
    private String chaveMaquina;

    //6 primeiras posicoes do atributo "numeroCartao" da Classe CPO_010.
    private String bin;

    //Atributo "codigoProc" da Classe CPO_006.
    private String codigoProcessamento;

    //Atributo "dataHoraInput" da Classe CPO_001.
    private Date horaInput;

    //Atributo "dataHoraInputTerminal" da Classe CPO_001.
    private Date dataHoraInputTerminal;

    //Atributo que define o status da transacao
    private StatusTransacao idStatus;

    private Date horaOutput;

    //Atributo "autorizador" da Classe CPO_001.
    private String resolutor;

    //Atributo "authSourceCode" da Classe CPO_030.
    private String sourceCode;

    //Atributo "mensagem" da Classe CPO_027.
    private String mensagem = "";

    //Atributo "codigoTerminal" da Classe CPO_013.
    private String terminal;

    //Atributo "transacao" da Classe CPO_006.
    private String idMensagem;

    //Atributo "valorVenda" da Classe CPO_001.
    private double valorVenda;
    
    //Atributo "valorVenda" da Classe CPO_065.
    private double valorCancelamento;
    
    // Numero do Celular cadastrado para envio SMS
    private String numeroCelularSms;
    
    //Atributo "monTecnologia" da Classe CPO_040.
    private String tipoTecnologia;

    //Atributo "numeroEstabelecimento" da Classe CPO_012.
    private String codigoEstabelecimento;

    //Atributo "numeroLoja" da Classe CPO_012.
    private String codigoLoja;

    //Atributo "codigoNoTerminal" da Classe CPO_013.
    private String codigoNo;

    //Atributo "terminalCodigoNoSec" da Classe CPO_040.
    private String codigoNoSecundario;

    //Atributo "numeroMcc" da Classe CPO_012.
    private String mcc;

    //Atributo "uf" da Classe CPO_012.
    private String uf;

    //Atributo "monCidade" da Classe CPO_040.
    private String cidade;

    //Atributo "cep" da Classe CPO_012.
    private String cep;

    //Atributo "observacao" da Classe CPO_027.
    private String observacao;

    //Atributo "versaoTerminal" da Classe CPO_013.
    private String dadosVersaoTerminal;

    //Atributo "bandeira" da Classe CPO_040.
    private String bandeira;

    //Atributo "bancoEmissor" da Classe CPO_040.
    private String banco;

    //Atributo "produto" da Classe CPO_006.
    private String produto;

    //Atributo "produtoSecundario" da Classe CPO_074.
    private String subProduto;

    //Atributo "tipoTransacao" da Classe CPO_006.
    private String tipoTransacao;

    //Atributo "ciersMonitoracao" da Classe CPO_019.
    private String ciersMonitoracao;

    //Atributo "switchVisa" da Classe CPO_019.
    private boolean switchVisa;

    private String dataHoraMinutoStr;

    //Atributo "indicadorSkyline" da Classe CPO_019.
    private boolean indicadorSkyLine;
    
    // Indica se a transacao originou em um Lio. Esse indicador não vem do POS, é enriquecido pelos caches no MDB Stratus.
    
    private boolean indicadorLio;
/**
 *   ?F? ? Conexão com Promo desabilitada
 *   ? ? ? Fora do Filtro
 *   ?N? ? Fora do Filtro
 *   ?*? ? No filtro, mas não enviada para o Promo.
 *   ?T? ? Timeout
 *   ?P? ? No filtro com resposta do Promo COM premiação
 *   ?S? ? No filtro com resposta do Promo SEM premiação
 */
    private String flagCieloPromo;
    
    /*
     * USADO NA ONDA 2.
     */
    //Atributo "modoEntrada" da Classe CPO_032. Item ZZ.
    private String modoConexao;

    //Atributo "codigoResposta" da Classe CPO_027.
    private String codigoErro;

    //Atributo "quemRespondeu" da Classe CPO_027.
    private String quemRespondeu;

    /*
     * Campos responsaveis em registrar os tempos de entrada e saida dos sistemas/processos envolvidos no Stratus (bandeira, banco, HSM, POS, etc).
     */
    //Atributo "dataHoraHost" da Classe CPO_001. Data e hora do sistema operacional de quando a transacao entrou no Stratus.
    private Date dataHoraStratus;

    //TODO Atributo indicador para a "dataHoraStratus", onde eh verificado se a data foi alterada(algum erro de parser oriundo do Stratus).
    private boolean isDataHoraStratusAlterada = false;

    //Atributo "adqEntrada" da Classe CPO_068. Data/hora que a transacao sai do POS e entra no Stratus(Stratus recebe a transacao do POS).	
    private Date dataHoraEntradaStratusSaidaPOS;

    //Atributo "adqSaida" da Classe CPO_068. Data/hora que a transacao sai do Stratus e eh retornado ao POS.
    private Date dataHoraRetornoAoPOS;

    //Atributo "resEntrada" da Classe CPO_068. Data/hora que a transacao sai do Stratus e enviada para a Bandeira/Banco.
    private Date dataHoraSaidaStratusEntradaBandeira;

    //Atributo "resSaida" da Classe CPO_068. Data/hora que a transacao volta da Bandeira/Banco e entra no Stratus novamente.
    private Date dataHoraRetornoBandeira;

    //Atributo "hsmEntrada" da Classe CPO_068. Data/hora que a transacao sai do Stratus e enviada para o HSM.
    private Date dataHoraSaidaStratusEntradaHSM;

    //Atributo "hsmSaida" da Classe CPO_068. Data/hora que a transacao volta do HSM e entra no Stratus novamente.
    private Date dataHoraRetornoHSM;

    //Atributo "codigoOperadora" da Classe CPO_047.
    private String codigoOperadoraGPRS;

    //Atributo "codigoServicoPOS" da Classe CPO_019.
    private String codigoServicoPOS;

    //Efetua verificacao no atributo "tcidPayGateway" da Classe CPO_035.
    private String versaoEcommerce;

    // refere-se a forma de entrada do cartão. Veja metodo get para maiores detalhes. campo CPO_006
    private Character formaDeEntrada;
    
    /*
     * Monitoracao DCC.
     */
    //Atributo responsavel em verificar se a transacao eh do tipo DCC.
    private boolean isDCC;

    //Objeto com informacoes para transacao do tipo DCC;
    private InformacoesDCC informacoesDCC;

    /*
     * Informacoes StandIn.
     */
    //Atributo responsavel em verificar se a transacao eh do tipo StandIn. Atributo "standIn" da Classe CPO_040.
    private boolean isStandIn;

    //Objeto com informacoes para transacao com StandIn.
    private InformacoesStandIn informacoesStandIn;

    /*
     * Informacoes LYNX.
     */
    //Atributo responsavel em verificar se a transacao passou pelo Lynx.
    private boolean isLynx;

    //Objeto com informacoes do Lynx para transacao.
    private InformacoesLynx informacoesLynx;

    //Atributo "transacaoPOS" da Classe CPO_001.
    private String transacaoPOS;

    /*
     * Informacoes BIT47.
     */
    //Substring do Atributo "versaoTerminal" da Classe CPO_013, contendo o numero da release do POS.
    private String releaseEspecificacao;

    //Substring do Atributo "versaoTerminal" da Classe CPO_013, contendo o modelo do Terminal.
    private String modeloTerminal;

    //Substring do Atributo "versaoTerminal" da Classe CPO_013, contendo a versao do aplicativo usado.
    private String versaoAplicativo;

    //Objeto com informacoes do BIT47 para transacao.
    private InformacoesBIT47 informacoesBIT47;

    /*
     * Monitoracao Autorizacao Parcial.
     */
    //Atributo responsavel em verificar se a transacao eh do tipo Autorizacao Parcial.
    private boolean isAutorizacaoParcial;

    //Atributo responsavel em identificar o valor do flag indicativo de autorizacao parcial .
    private String indicativoAutorizacaoParcial;
    private String tipoSolCaptModoEntrada;
    private int quantidadeParcelas;
    private boolean recorrente=false;
	//Idenfica se a transacao eh de TOKEN - CPO-913 - GEN-TOKEN-FLAG - true = S e false <> S
    private boolean indicTransacaoToken = false;

    public boolean isRecorrente() {
        return recorrente;
    }

    public void setRecorrente(boolean recorrente) {
        this.recorrente = recorrente;
    }

    /**
     * Retorna quantidade de parcelas da compra
     * @return quantidade de parcelas da compra
     */
    public int getQuantidadeParcelas() {
        return quantidadeParcelas;
    }
    
     /**
     * Ajusta quantidade de parcelas da compra
     * @param quantidadeParcelas quantidade de parcelas da compra
     */
    public void setQuantidadeParcelas(int quantidadeParcelas) {
        this.quantidadeParcelas = quantidadeParcelas;
    }

    /**
     * Retorna o código de autorização para transações autorizadas
     */
    private String codigoAutorizacao;
    /**
     * Retorna o nr. do cartão mascarado no formato: BBBBBB******NNNN
     */
    private String numCartaoMascarado;
    /**
     * Construtor padrao.
     */
    public MonitoracaoTransacaoAutorizadorVO() {
    }

    /**
     * Retorna  nr do cartão no formato mascarado: BBBBBB******NNNN (ao qual B - dig do bin, e N - dig final)
     * @return nr do cartão no formato mascarado: BBBBBB******NNNN (ao qual B - dig do bin, e N - dig final)
     */
    public String getNumCartaoMascarado() {
        return numCartaoMascarado;
    }
    /**
     * Ajusta nr do cartao mascarado
     * @param numCartaoMascarado nr do cartao mascarado
     */
    public void setNumCartaoMascarado(String numCartaoMascarado) {
        this.numCartaoMascarado = numCartaoMascarado;
    }

    /**
     * Retorna o NSU referente do cancelamento
     * @return 
     */
    public String getNsuCanRef() {
        return nsuCanRef;
    }

    public void setNsuCanRef(String nsuCanRef) {
        this.nsuCanRef = nsuCanRef;
    }

    /**
     * Retorna o NSU de transação anterior aprovada pelo POS (terceira perna)
     * @return o NSU de transação anterior aprovada pelo POS (terceira perna) ou null se não houver referencia
     */
    public String getNsuConfirmacaoAutorizacaoPOS() {
        return nsuConfirmacaoAutorizacaoPOS;
    }

    public void setNsuConfirmacaoAutorizacaoPOS(String nsuConfirmacaoAutorizacaoPOS) {
        this.nsuConfirmacaoAutorizacaoPOS = nsuConfirmacaoAutorizacaoPOS;
    }

    /**
     * Forma de entrada do cartão
     * Válido para canal POS v40:
     * Se for uma transação digitada, atribuir: X
     * Se for uma transação com trilha 1, atribuir: H
     * Se for uma transação com trilha 2, atribuir: D
     * Se for uma transação com CHIP, atribuir: C 
     * @return forma de entrada do cartão.
     */
    public Character getFormaDeEntrada() {
        return formaDeEntrada;
    }

    public void setFormaDeEntrada(Character formaDeEntrada) {
        this.formaDeEntrada = formaDeEntrada;
    }

    
    /**
     * Retorna o código de autorizacao (CPO_027 - codAut) para transações autorizadas
     * @return o código de autorizacao (CPO_027 - codAut) para transações autorizadas
     */
    public String getCodigoAutorizacao() {
        return codigoAutorizacao;
    }

    /**
     * Ajusta o código de autorização
     * @param codigoAutorizacao código de autorização
     */
    public void setCodigoAutorizacao(String codigoAutorizacao) {
        this.codigoAutorizacao = codigoAutorizacao;
    }

    /**
     * Retorna o UUID da mensagem recebida pelo componente
     * Stratus-Monitoracao-Adapter, e enviado ao gerenciador de filas.
     *
     * @return the uuidMessageAdapter
     */
    public String getUuidMessageAdapter() {
        return uuidMessageAdapter;
    }

    /**
     * @param uuidMessageAdapter the uuidMessageAdapter to set
     */
    public void setUuidMessageAdapter(String uuidMessageAdapter) {
        this.uuidMessageAdapter = uuidMessageAdapter;
    }

    /**
     * Retorna o codigo do Grupo EC. Valor nao presente na mensagem original do
     * STRATRUS, o mesmo eh atribuido pelo sistema de cache da aplicacao.
     *
     * @return the codGrupoEC
     */
    public String getCodGrupoEC() {
        return codGrupoEC;
    }

    /**
     * @param codGrupoEC the codGrupoEC to set
     */
    public void setCodGrupoEC(String codGrupoEC) {
        this.codGrupoEC = codGrupoEC;
    }

    /**
     * Retorna o codigo da Localidade. Valor nao presente na mensagem original
     * do STRATRUS, o mesmo eh atribuido pelo sistema de cache da aplicacao.
     *
     * @return the codigoLocalidade
     */
    public String getCodigoLocalidade() {
        return codigoLocalidade;
    }

    /**
     * @param codigoLocalidade
     */
    public void setCodigoLocalidade(String codigoLocalidade) {
        this.codigoLocalidade = codigoLocalidade;
    }

    //Mehtodos incluÃ­dos para atender BIT 47
    /**
     * Retorna o codigo da Localidade da Lista Completa de Localidades. Valor
     * nao presente na mensagem original do STRATUS, o mesmo eh atribuido pelo
     * sistema de cache da aplicacao.
     *
     * @return the codigoCompleteLocalidade
     */
    public String getCodigoCompleteLocalidade() {
        return codigoCompleteLocalidade;
    }

    /**
     * @param codigoCompleteLocalidade
     */
    public void setCodigoCompleteLocalidade(String codigoCompleteLocalidade) {
        this.codigoCompleteLocalidade = codigoCompleteLocalidade;
    }

    /**
     * Retorna o Nome da Operadora GPRS. Valor nao presente na mensagem original
     * do STRATRUS, o mesmo eh atribuido pelo sistema de cache da aplicacao.
     *
     * @return the nomeOperadoraGPRS
     */
    public String getNomeOperadoraGPRS() {
        return nomeOperadoraGPRS;
    }

    /**
     * @param nomeOperadoraGPRS
     */
    public void setNomeOperadoraGPRS(String nomeOperadoraGPRS) {
        this.nomeOperadoraGPRS = nomeOperadoraGPRS;
    }

    /**
     * Retorna o codigo da forma de pagamento, do "produto completo"
     * relacionado. Valor nao presente na mensagem original do STRATRUS, o mesmo
     * eh atribuido pelo sistema de cache da aplicacao.
     *
     * @return the formaPagamento
     */
    public String getFormaPagamento() {
        return formaPagamento;
    }

    /**
     * @param formaPagamento
     */
    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    /**
     * Retorna o numero do NSU da transacao.
     * <br>
     * Campo Stratus: CPO-006 (ACTR-NSU).
     *
     * @return
     */
    public String getNSU() {
        return nsu;
    }

    /**
     * @param nsu
     */
    public void setNSU(String nsu) {
        this.nsu = nsu;
    }

    /**
     * Retorna a informacao da Maquina Stratus que a transacao foi gerada.
     * <br>
     * Campo Stratus: CPO-001 (ACTR-MAQUINA).
     *
     * @return
     */
    public String getChaveMaquina() {
        return chaveMaquina;
    }

    /**
     * @param chaveMaquina
     */
    public void setChaveMaquina(String chaveMaquina) {
        this.chaveMaquina = chaveMaquina;
    }

    /**
     * Retorna a informacao do BIN, que corresponde as 6 primeiras posicoes do
     * nÃºmero do cartao de credito.
     * <br>
     * Campo Stratus: CPO-010 (ACTR-CARTAO-NUM).
     *
     * @return
     */
    public String getBin() {
        return bin;
    }

    /**
     * @param bin
     */
    public void setBin(String bin) {
        this.bin = bin;
    }

    /**
     * Retornar a informacao referente ao tipo de codigo de processamento.
     * <br><br>
     * Campo Stratus: CPO-006 (ACTR-COD-PROC).
     * <br><br>
     * Tendo os seguintes dominios:
     * <DD>003000 - CREDITO - A VISTA <br>
     * <DD>003010 - CREDITO - FINANCIADO ADM <br>
     * <DD>003020 - CREDITO - FINANCIADO LOJA <br>
     * <DD>001010 - DEBITO - CDC <br>
     * <DD>001030 - DEBITO - PRE-DATADO <br>
     * <DD>001000 - DEBITO - A VISTA <br>
     * <DD>380010 - DEBITO - CONSULTA CDC <br>
     * <DD>22XXXX - CANCELAMENTO <br>
     * <DD>920000 - FECHAMENTO DE LOTE <br>
     *
     * @return
     */
    public String getCodigoProcessamento() {
        return codigoProcessamento;
    }

    /**
     * @param codProc
     */
    public void setCodigoProcessamento(String codProc) {
        this.codigoProcessamento = codProc;
    }

    /**
     * Retorna a informacao de data e hora de Input do Stratus, que eh o momento
     * em que a transacao entrou na Cielo.
     * <br><br>
     * Campo Stratus: CPO-001 (ACTR-DATA-INP e ACTR-HORA-INP).
     *
     * @return
     */
    public Date getHoraInput() {
        return horaInput;
    }

    /**
     * @param horaInput
     */
    public void setHoraInput(Date horaInput) {
        this.horaInput = horaInput;
    }

    /**
     * Retorna a informacao de data e hora de Input do Terminal do Stratus, que eh o momento
     * em que a transacao foi registrado no terminal.
     * <br><br>
     * Campo Stratus: CPO-001 (ACTR-DATA-INP-TER e ACTR-HORA-INP-TER).
     * 
     * @return 
     */
    public Date getDataHoraInputTerminal() {
        return dataHoraInputTerminal;
    }

    public void setDataHoraInputTerminal(Date dataHoraInputTerminal) {
        this.dataHoraInputTerminal = dataHoraInputTerminal;
    }

    /**
     * Retorna o Status da Transacao, representada pelo Enumeration:
     * StatusTransacao.
     *
     * <DD>0 - CANCELAMENTO
     * <DD>1 - DESFAZIMENTO
     * <DD>2 - APROVADO
     * <DD>3 - NEGADO
     * <DD>4 - INDEFINIDO
     * <DD>5 - CAPTURADO (*) Usado para eCommerce
     *
     * @return
     */
    public StatusTransacao getIdStatus() {
        return idStatus;
    }

    /**
     * @param idStatus
     */
    public void setIdStatus(StatusTransacao idStatus) {
        this.idStatus = idStatus;
    }

    /**
     * @return
     */
    public Date getHoraOutput() {
        return horaOutput;
    }

    /**
     * @param horaOutput
     */
    public void setHoraOutput(Date horaOutput) {
        this.horaOutput = horaOutput;
    }

    /**
     * Retorna as informacoes referente ao codigo do Autorizador que vai
     * resolver a transacao.
     * <br><br>
     * Campo Stratus: CPO-001 (ACTR-DESTINO-NUM).
     * <br><br>
     * Tendo os seguintes dominios:
     * <DD>029010 - BB
     * <DD>029020 - Bradesco
     * <DD>38800X - Mastercard Credito
     * <DD>38900X - Mastercard Debito
     *
     * @return
     */
    public String getResolutor() {
        return resolutor;
    }

    /**
     * @param resolutor
     */
    public void setResolutor(String resolutor) {
        this.resolutor = resolutor;
    }

    /**
     * Retona as informacoes referente ao detalhamento de como a transacao foi
     * aprovada. Vale para Visa e Mastercard
     * <br><br>
     * Campo Stratus: CPO-030 (ACTR-AUTH-SOURCE-CODE).
     * <br><br>
     * Tendo os seguintes dominios:
     * <DD>1 - PCAS To Emissor
     * <DD>2 - PCAS
     * <DD>3 - PCAS EMIS S.I.M.
     * <DD>4 - PCAS EM.FORA AR
     * <DD>5 - EMISSOR
     * <DD>6 - STAND-IN MC
     *
     * @return
     */
    public String getSourceCode() {
        return sourceCode;
    }

    /**
     * @param sourceCode
     */
    public void setSourceCode(String sourceCode) {
        this.sourceCode = sourceCode;
    }

    /**
     * Retona as informacoes referente a mensagem enviada ao terminal indicando
     * o resultado da transacao.
     * <br><br>
     * Campo Stratus: CPO-027 (ACTR-MSG).
     *
     * @return
     */
    public String getMensagem() {
        return mensagem == null ? "" : mensagem;
    }

    /**
     * @param mensagem
     */
    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    /**
     * Retona as informacoes referente ao numero do equipamento onde a transacao
     * foi executada.
     * <br><br>
     * Campo Stratus: CPO-013 (ACTR-TERMINAL-CODIGO).
     *
     * @return
     */
    public String getTerminal() {
        return terminal;
    }

    /**
     * @param terminal
     */
    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    /**
     * Retona as informacoes referente a identificacao da transacao.
     * <br><br>
     * Campo Stratus: CPO-006 (ACTR-TRANSACAO).
     * <br><br>
     * Tendo os seguintes dominios:
     * <DD>0610 - RESPOSTA DE SONDA
     * <DD>0202 - CONFIRMACAO
     * <DD>0500 - FECHAMENTO DE LOTE
     * <DD>1400 - DESFAZIMENTO
     * <DD>1420 - CANCELAMENTO
     * <DD>1500 - REFERIDA
     * <DD>1500 - REFERIDA
     * <DD>1220 - OFF-LINE
     * <DD>1104 - OFF-LINE EMV CONFIRMACAO ANTERIOR
     * <DD>1204 - OFF-LINE EMV
     * <DD>1224 - OFF-LINE EMV
     * <DD>1120 - OFF-LINE CDC PREAUT
     * <DD>1200 - TRANSACOES FINANCEIRAS
     *
     * @return
     */
    public String getIdMensagem() {
        return idMensagem;
    }

    /**
     * @param idMensagem
     */
    public void setIdMensagem(String idMensagem) {
        this.idMensagem = idMensagem;
    }

    /**
     * Retona as informacoes referente ao valor da venda.
     * <br><br>
     * Campo Stratus: CPO-001 (ACTR-VALOR-VENDA).
     *
     * @return
     */
    public double getValorVenda() {
        return valorVenda;
    }

    /**
     * @param valorVenda
     */
    public void setValorVenda(double valorVenda) {
        this.valorVenda = valorVenda;
    }
    /**
     * Retona as informacoes referente ao valor do cancelamento.
     * <br><br>
     * Campo Stratus: CPO-065 (ACTR-VAL-CANC).
     *
     * @return
     */
    public double getValorCancelamento() {
        return valorCancelamento;
    }

    public void setValorCancelamento(double valorCancelamento) {
        this.valorCancelamento = valorCancelamento;
    }

    /**
     * Retona as informacoes referente ao nr celular registrado para envio de SMS.
     * <br><br>
     * Campo Stratus: CPO-912 (GEN-NUM-CELULAR-SMS).
     *
     * @return
     */
    public String getNumeroCelularSms() {
        return numeroCelularSms;
    }

    public void setNumeroCelularSms(String numeroCelularSms) {
        this.numeroCelularSms = numeroCelularSms;
    }

    
    
    /**
     * Retona o tipo de tecnologia do qual a transacao foi capturada. (Solucao
     * de captura).
     * <br><br>
     * Campo Stratus: CPO-040 (ACTR-MON-TECN).
     * <br><br>
     * Tendo os seguintes dominios:
     * <DD>01	- POS V30
     * <DD>02	- POS V31
     * <DD>03	- POS V32
     * <DD>04	- POS V29
     * <DD>05	- TEF 4.1
     * <DD>06	- TEF 2000
     * <DD>07	- TEF 1998
     * <DD>08	- ECOMMERCE MOSET
     * <DD>09	- ECOMMERCE VBV
     * <DD>10	- URA
     * <DD>11	- EDI
     * <DD>12	- SAV
     * <DD>13	- MOBILE
     * <DD>14	- POS WEB
     * <DD>15	- GDS
     * <DD>16	- POS ETHERNET (BANDA LARGA)
     * <DD>17	- LFIN PLATAFORMA DE FINANCIAMENTO
     *
     * @return
     */
    public String getTipoTecnologia() {
        return tipoTecnologia;
    }

    /**
     * @param tipoTecn
     */
    public void setTipoTecnologia(String tipoTecn) {
        this.tipoTecnologia = tipoTecn;
    }

    /**
     * Retona o codigo do estabelecimento cadastrado na Cielo.
     * <br><br>
     * Campo Stratus: CPO-012 (ACTR-ESTAB-NUM).
     *
     * @return
     */
    public String getCodigoEstabelecimento() {
        return codigoEstabelecimento;
    }

    /**
     * @param codEstab
     */
    public void setCodigoEstabelecimento(String codEstab) {
        this.codigoEstabelecimento = codEstab;
    }

    /**
     * Retona o codigo da loja cadastrado na Cielo.
     * <br><br>
     * Campo Stratus: CPO-012 (ACTR-ESTAB-LOJ).
     *
     * @return the codigoLoja
     */
    public String getCodigoLoja() {
        return codigoLoja;
    }

    /**
     * @param codigoLoja the codigoLoja to set
     */
    public void setCodigoLoja(String codigoLoja) {
        this.codigoLoja = codigoLoja;
    }

    /**
     * Retona o nome do no telefonico associado ao terminal. Este campo indica
     * em que ponto a transacao foi originada.
     * <br><br>
     * Campo Stratus: CPO-013 (ACTR-TERM-COD-NO).
     *
     * @return
     */
    public String getCodigoNo() {
        return codigoNo;
    }

    /**
     * @param codNo
     */
    public void setCodigoNo(String codNo) {
        this.codigoNo = codNo;
    }

    /**
     * Retona o nome do no secundario telefonico associado ao terminal.
     * <br><br>
     * Campo Stratus: CPO-040 (ACTR-TERM-COD-NO-SEC).
     *
     * @return the codigoNoSecundario
     */
    public String getCodigoNoSecundario() {
        return codigoNoSecundario;
    }

    /**
     * @param codigoNoSecundario the codigoNoSecundario to set
     */
    public void setCodigoNoSecundario(String codigoNoSecundario) {
        this.codigoNoSecundario = codigoNoSecundario;
    }

    /**
     * Retona o codigo do ramo de atividade do estabelecimento.
     * <br><br>
     * Campo Stratus: CPO-012 (ACTR-MCC).
     * <br><br>
     * Tendo os seguintes dominios:
     * <DD>xxx - xxxx
     *
     * @return
     */
    public String getMcc() {
        return mcc;
    }

    /**
     * @param mcc
     */
    public void setMcc(String mcc) {
        this.mcc = mcc;
    }

    /**
     * Retona a Unidade Federativa (sigla do Estado).
     * <br><br>
     * Campo Stratus: CPO-012 (ACTR-ESTAB-UF).
     *
     * @return
     */
    public String getUf() {
        return uf;
    }

    /**
     * @param uf
     */
    public void setUf(String uf) {
        this.uf = uf;
    }

    /**
     * Retona o Nome da Cidade.
     * <br><br>
     * Campo Stratus: CPO-040 (ACTR-MON-CIDADE).
     *
     * @return
     */
    public String getCidade() {
        return cidade;
    }

    /**
     * @param cidade
     */
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    /**
     * Retona o CEP do Estabelecimento.
     * <br><br>
     * Campo Stratus: CPO-012 (ACTR-ESTAB-CEP).
     *
     * @return
     */
    public String getCep() {
        return cep == null ? null : ("00000000".substring(0, 8 - cep.length()) + cep);
    }

    /**
     * @param cidade
     */
    public void setCep(String cep) {
        this.cep = cep;
    }

    /**
     * Retorna o codigo do detalhe da transacao negada pelo Stratus.
     * <br><br>
     * Este campo serve para indicar dentro do sistema qual foi a regra de
     * negocio usada para negar a transacao. Na maioria das vezes este campo so
     * eh preenchido se a negativa for gerada dentro da Cielo via Stratus.
     * <br><br>
     * Campo Stratus: CPO-027 (ACTR-OBS).
     *
     * @return
     */
    public String getObservacao() {
        return observacao;
    }

    @Deprecated
    /**
     * @Deprecated: deve ser utilizado getObservacao() nas proximas versoes
     */
    public String getObs() {
        return getObservacao();
    }

    /**
     * @param obs
     */
    public void setObservacao(String obs) {
        this.observacao = obs;
    }

    /**
     * @Deprecated: deve ser usado setObservacao() nas proximas versoes
     * @param obs
     */
    @Deprecated
    public void setObs(String obs) {
        setObservacao(obs);
    }

    /**
     * Retona a versao do aplicativo que esta rodando no terminal.
     * <br><br>
     * Campo Stratus: CPO-013 (ACTR-TERMINAL-VERSAO).
     *
     * @return
     */
    public String getDadosVersaoTerminal() {
        return dadosVersaoTerminal;
    }

    /**
     * @param versao
     */
    public void setDadosVersaoTerminal(String versao) {
        this.dadosVersaoTerminal = versao;
    }

    /**
     * @Deprecated: deve ser usado getDataHoraStratus() nas proximas versoes
     * @return
     */
    @Deprecated
    public Date getTpsDataHoraTrans() {
        return getDataHoraStratus();
    }

    /**
     * @Deprecated: deve ser usado setDataHoraStratus(Date) nas proximas versoes
     * @param tpsDataHoraTrans
     */
    public void setTpsDataHoraTrans(Date tpsDataHoraTrans) {
        setDataHoraStratus(tpsDataHoraTrans);
    }

    /**
     * Retona o codigo da bandeira do cartao.
     * <br><br>
     * Campo Stratus: CPO-040 (ACTR-BANDEIRA).
     *
     * @return
     */
    public String getBandeira() {
        return bandeira;
    }

    /**
     * @param bandeira
     */
    public void setBandeira(String bandeira) {
        this.bandeira = bandeira;
    }

    /**
     * Retona o codigo do banco do cartao usado.
     * <br><br>
     * Campo Stratus: CPO-040 (ACTR-BCO-EMI).
     *
     * @return
     */
    public String getBanco() {
        return banco;
    }

    /**
     * @param banco
     */
    public void setBanco(String banco) {
        this.banco = banco;
    }

    /**
     * Retona o codigo do produto.
     * <br><br>
     * Campo Stratus: CPO-006 (ACTR-PRODUTO).
     *
     * @return
     */
    public String getProduto() {
        return produto;
    }

    /**
     * Retorna o codigo do produto completo
     *
     * @return
     */
    public String getProdutoCompleto() {
        return getProduto() + getSubProduto();
    }

    /**
     * @param produto
     */
    public void setProduto(String produto) {
        this.produto = produto;
    }

    /**
     * Retona o codigo do produto secundario.
     * <br><br>
     * Campo Stratus: CPO-074 (ACTR-PRODUTO-SECUNDARIO).
     *
     * @return
     */
    public String getSubProduto() {
        return subProduto == null ? "0000" : subProduto;
    }

    /**
     * @param subProduto
     */
    public void setSubProduto(String subProduto) {
        this.subProduto = subProduto;
    }

    /**
     * Retona o codigo o tipo da transacao.
     * <br><br>
     * Campo Stratus: CPO-006 (ACTR-TIPTRA).
     *
     * @return
     */
    public String getTipTra() {
        return tipoTransacao;
    }

    /**
     * @param tipTra
     */
    public void setTipTra(String tipTra) {
        this.tipoTransacao = tipTra;
    }

    /**
     * Retona o codigo do ciers usado. Este codigo indica por qual porta
     * IP/PORTA a transacao entrou no nosso ambiente.
     * <br><br>
     * Campo Stratus: CPO-019 (ACTR-CIERS-MONITORACAO).
     *
     * @return
     */
    public String getCiersMonitoracao() {
        return ciersMonitoracao;
    }

    /**
     * @param ciersMonitoracao
     */
    public void setCiersMonitoracao(String ciersEnt) {
        this.ciersMonitoracao = ciersEnt;
    }

    /**
     * Retona se a transacao foi processada pelo Switch Visa.
     * <br><br>
     * Campo Stratus: CPO-019 (ACTR-SWITCH-VISA).
     *
     * @return
     */
    public boolean isSwitchVisa() {
        return switchVisa;
    }

    /**
     * @param switchVisa
     */
    public void setSwitchVisa(boolean switchVisa) {
        this.switchVisa = switchVisa;
    }

    /**
     * @return
     */
    public String getDataHoraMinutoStr() {
        return dataHoraMinutoStr;
    }

    /**
     * @param dataHoraMinutoStr
     */
    public void setDataHoraMinutoStr(String dataHoraMinutoStr) {
        this.dataHoraMinutoStr = dataHoraMinutoStr;
    }

    /**
     * Retona se a transacao foi processada pelo Skyline.
     * <br><br>
     * Campo Stratus: CPO-019 (ACTR-IND-SKYLINE).
     *
     * @return
     */
    public boolean isIndicadorSkyLine() {
        return indicadorSkyLine;
    }

    /**
     * @param indicadorSkyLine
     */
    public void setIndicadorSkyLine(boolean indicadorSkyLine) {
        this.indicadorSkyLine = indicadorSkyLine;
    }

    /**
     * @Deprecated: nao eh populado. Nunca usar esse campo, mantido apenas por
     * compatibilidade
     * @return
     */
    public Integer getCodSolCaptura() {
        return null;
    }

    /**
     * Retorna o modo de conexao vindo do Stratus.
     * <br><br>
     * Campo Stratus: CPO-032 (ACTR-MODENT).
     * <br><br>
     * O valor do atributo "modoEntrada" eh no formato "PLSCXZZYYYYY", utiliza
     * os elementos ZZ desse conteudo.
     * <br><br>
     * Possiveis valores:
     * <DD> 01 - Wi-Fi;
     * <DD>02 - Ethernet;
     * <DD>10 - HDLC;
     * <DD>20 - X.28;
     * <DD>30 - RADIO;
     * <DD>40 - LAN;
     * <DD>50 - VISA II (EXCLUSIVO PARA TEF DIAL E CONEXAO GSM);
     * <DD>60 - CONEXAO PPP (POSWEB);
     * <DD>70 - CONEXAO GPRS / CDMA 1X (WIRE-LESS OUTDOOR);
     * <DD>90 - GSM X.28;
     * <DD>95 - GSM VISA II.
     *
     * @return
     */
    public String getModoConexao() {
        return modoConexao;
    }

    /**
     * Ajusta o Tipo da Solucao de Captura para o Modo de Entrada ( Usado para
     * identificar o Chip&Pin)
     *
     * T = Tipo de Solucao de Captura 0 - POS; 1 - TEF Dedicado; 2 - TEF IP /
     * Discado; 3 - E-Commerce; 4 - Visa Cash em Rede (Pedagio); 5 - Celular; 6
     * - URA; 7 - EDI; 8 - Chamada Externa (Celular).
     *
     * @param substring
     */
    public void setTipoSolucaoCapturaModoEntrada(String tipoSolCaptModoEntrada) {
        this.tipoSolCaptModoEntrada = tipoSolCaptModoEntrada;
    }

    /**
     * Retorna o Tipo da Solucao de Captura para o Modo de Entrada ( Usado para
     * identificar o Chip&Pin)
     *
     * T = Tipo de Solucao de Captura 0 - POS; 1 - TEF Dedicado; 2 - TEF IP /
     * Discado; 3 - E-Commerce; 4 - Visa Cash em Rede (Pedagio); 5 - Celular; 6
     * - URA; 7 - EDI; 8 - Chamada Externa (Celular).
     *
     * @return Retorna o Tipo Solucao de Captura do Modo de Entrada.
     */
    public String getTipoSolucaoCapturaModoEntrada() {
        return this.tipoSolCaptModoEntrada;
    }

    /**
     * @param modoConexao
     */
    public void setModoConexao(String modoConexao) {
        this.modoConexao = "".equals(modoConexao) ? null : modoConexao;
    }

    /**
     * Retorna o codigo de erro, caso ocorra.
     * <br><br>
     * Campo Stratus: CPO-027 (ACTR-CODRES).
     *
     * @return the codigoErro
     */
    public String getCodigoErro() {
        return codigoErro;
    }

    /**
     * @param codigoErro the codigoErro to set
     */
    public void setCodigoErro(String codigoErro) {
        this.codigoErro = codigoErro;
    }

    /**
     * Retorna quem respondeu a transacao.
     * <br><br>
     * Campo Stratus: CPO-027 (ACTR-QUEMRESP).
     *
     * @return the quemRespondeu
     */
    public String getQuemRespondeu() {
        return quemRespondeu;
    }

    /**
     * @param quemRespondeu the quemRespondeu to set
     */
    public void setQuemRespondeu(String quemRespondeu) {
        this.quemRespondeu = quemRespondeu;
    }

    /**
     * Retorna a Data e hora do sistema operacional de quando a transacao entrou
     * no Stratus.
     * <br><br>
     * Campo Stratus: CPO-001 (ACTR-DATA-HOST e ACTR-HORA-HOST).
     *
     * @return
     */
    public Date getDataHoraStratus() {
        return dataHoraStratus;
    }

    /**
     * @param dataHoraStratus
     */
    public void setDataHoraStratus(Date dataHoraStratus) {
        this.dataHoraStratus = dataHoraStratus;
    }

    /**
     * Retorna se o valor da propriedade dataHoraStratus foi altrerado ou nao,
     * ou seja se o mesmo esta com o valor diferente do capturado pelo Stratus.
     *
     * @return the isDataHoraStratusAlterada
     */
    public boolean isDataHoraStratusAlterada() {
        return isDataHoraStratusAlterada;
    }

    /**
     * @param isDataHoraStratusAlterada the isDataHoraStratusAlterada to set
     */
    public void setDataHoraStratusAlterada(boolean isDataHoraStratusAlterada) {
        this.isDataHoraStratusAlterada = isDataHoraStratusAlterada;
    }

    /**
     * Retorna a data/hora que a transacao sai do POS e entra no Stratus(Stratus
     * recebe a transacao do POS).
     * <br><br>
     * Campo Stratus: CPO-068 (ACTR-ADQ-ENT).
     *
     * @return the dataHoraEntradaStratusSaidaPOS
     */
    public Date getDataHoraEntradaStratusSaidaPOS() {
        return dataHoraEntradaStratusSaidaPOS;
    }

    /**
     * @param dataHoraEntradaStratusSaidaPOS the dataHoraEntradaStratusSaidaPOS
     * to set
     */
    public void setDataHoraEntradaStratusSaidaPOS(Date dataHoraEntradaStratusSaidaPOS) {
        this.dataHoraEntradaStratusSaidaPOS = dataHoraEntradaStratusSaidaPOS;
    }

    /**
     * Retorna a data/hora que a transacao sai do Stratus e eh retornado ao POS.
     * <br><br>
     * Campo Stratus: CPO-068 (ACTR-ADQ-SAI).
     *
     * @return the dataHoraRetornoPOS
     */
    public Date getDataHoraRetornoAoPOS() {
        return dataHoraRetornoAoPOS;
    }

    /**
     * @param dataHoraRetornoPOS the dataHoraRetornoPOS to set
     */
    public void setDataHoraRetornoAoPOS(Date dataHoraRetornoPOS) {
        this.dataHoraRetornoAoPOS = dataHoraRetornoPOS;
    }

    /**
     * Retorna a data/hora que a transacao sai do Stratus e enviada para a
     * Bandeira/Banco.
     * <br><br>
     * Campo Stratus: CPO-068 (ACTR-RES-ENT).
     *
     * @return the dataHoraSaidaStratusEntradaBandeira
     */
    public Date getDataHoraSaidaStratusEntradaBandeira() {
        return dataHoraSaidaStratusEntradaBandeira;
    }

    /**
     * @param dataHoraSaidaStratusEntradaBandeira the
     * dataHoraSaidaStratusEntradaBandeira to set
     */
    public void setDataHoraSaidaStratusEntradaBandeira(Date dataHoraSaidaStratusEntradaBandeira) {
        this.dataHoraSaidaStratusEntradaBandeira = dataHoraSaidaStratusEntradaBandeira;
    }

    /**
     * Retorna a data/hora que a transacao volta da Bandeira/Banco e entra no
     * Stratus novamente.
     * <br><br>
     * Campo Stratus: CPO-068 (ACTR-RES-SAI).
     *
     * @return the dataHoraRetornoBandeira
     */
    public Date getDataHoraRetornoBandeira() {
        return dataHoraRetornoBandeira;
    }

    /**
     * @param dataHoraRetornoBandeira the dataHoraRetornoBandeira to set
     */
    public void setDataHoraRetornoBandeira(Date dataHoraRetornoBandeira) {
        this.dataHoraRetornoBandeira = dataHoraRetornoBandeira;
    }

    /**
     * Retorna a data/hora que a transacao sai do Stratus e enviada para o HSM.
     * <br><br>
     * Campo Stratus: CPO-068 (ACTR-HSM-ENT).
     *
     * @return the dataHoraSaidaStratusEntradaHSM
     */
    public Date getDataHoraSaidaStratusEntradaHSM() {
        return dataHoraSaidaStratusEntradaHSM;
    }

    /**
     * @param dataHoraSaidaStratusEntradaHSM the dataHoraSaidaStratusEntradaHSM
     * to set
     */
    public void setDataHoraSaidaStratusEntradaHSM(Date dataHoraSaidaStratusEntradaHSM) {
        this.dataHoraSaidaStratusEntradaHSM = dataHoraSaidaStratusEntradaHSM;
    }

    /**
     * Retorna a data/hora que a transacao volta do HSM e entra no Stratus
     * novamente.
     * <br><br>
     * Campo Stratus: CPO-068 (ACTR-HSM-SAI).
     *
     * @return the dataHoraRetornoHSM
     */
    public Date getDataHoraRetornoHSM() {
        return dataHoraRetornoHSM;
    }

    /**
     * @param dataHoraRetornoHSM the dataHoraRetornoHSM to set
     */
    public void setDataHoraRetornoHSM(Date dataHoraRetornoHSM) {
        this.dataHoraRetornoHSM = dataHoraRetornoHSM;
    }

    /**
     * Retorna o codigo da operadora quando solucao de captura for POS GPRS.
     * <br><br>
     * Campo Stratus: CPO-047 (ACTR-CODIGO-OPERADORA).
     * <br><br>
     * Possiveis valores:
     * <DD>00 - Nao se Aplica
     * <DD>31 - Oi
     * <DD>05 - Claro
     * <DD>01,02,03,04 - Tim
     * <DD>10	- Vivo
     *
     * @return the codigoOperadora
     */
    public String getCodigoOperadoraGPRS() {
        return codigoOperadoraGPRS;
    }

    /**
     * @param codigoOperadora the codigoOperadora to set
     */
    public void setCodigoOperadoraGPRS(String codigoOperadoraGPRS) {
        this.codigoOperadoraGPRS = codigoOperadoraGPRS;
    }

    /**
     * Retorna o codigo de ServiÃ§o do POS.
     * <br><br>
     * Campo Stratus: CPO-019 (ACTR-COD-SERV-POS).
     *
     * @return the codigoServicoPOS
     */
    public String getCodigoServicoPOS() {
        return codigoServicoPOS;
    }

    /**
     * @param codigoServicoPOS the codigoServicoPOS to set
     */
    public void setCodigoServicoPOS(String codigoServicoPOS) {
        this.codigoServicoPOS = codigoServicoPOS;
    }

    /**
     * Retorna versao do ecommerce, caso a transacao seja desse tipo.
     * <br><br>
     * Regra aplicada no Campo Stratus: CPO-035 (ACTR-TCIDPAYGATEWAY).
     * <br><br>
     * Possiveis valores:
     * <DD>- 1.0
     * <DD>- 1.5
     *
     * @return the versaoEcommerce
     */
    public String getVersaoEcommerce() {
        return versaoEcommerce;
    }

    /**
     * @param versaoEcommerce the versaoEcommerce to set
     */
    public void setVersaoEcommerce(String versaoEcommerce) {
        this.versaoEcommerce = versaoEcommerce;
    }

    /**
     * Indica se a transacao eh do tipo DCC.
     *
     * @return the isDCC
     */
    public boolean isDCC() {
        return isDCC;
    }

    /**
     * @param isDCC the isDCC to set
     */
    public void setDCC(boolean isDCC) {
        this.isDCC = isDCC;
    }

    /**
     * Retorno objeto com informacoes para as transacoes do tipo DCC.
     *
     * @return the informacoesDCC
     */
    public InformacoesDCC getInformacoesDCC() {
        return informacoesDCC;
    }

    /**
     * @param informacoesDCC the informacoesDCC to set
     */
    public void setInformacoesDCC(InformacoesDCC informacoesDCC) {
        this.informacoesDCC = informacoesDCC;
    }

    /**
     * Indica se a transacao contem StandIn.
     *
     * @return the isStandIn
     */
    public boolean isStandIn() {
        return isStandIn;
    }

    /**
     * @param isStandIn the isStandIn to set
     */
    public void setStandIn(boolean isStandIn) {
        this.isStandIn = isStandIn;
    }

    /**
     * Retorno objeto com informacoes para as transacoes que contem StandIn.
     *
     * @return the informacoesStandIn
     */
    public InformacoesStandIn getInformacoesStandIn() {
        return informacoesStandIn;
    }

    /**
     * @param informacoesStandIn the informacoesStandIn to set
     */
    public void setInformacoesStandIn(InformacoesStandIn informacoesStandIn) {
        this.informacoesStandIn = informacoesStandIn;
    }

    /**
     * Indica se a transacao passou pelo Lynx.
     *
     * @return the isLynx
     */
    public boolean isLynx() {
        return isLynx;
    }

    /**
     * @param isLynx the isLynx to set
     */
    public void setLynx(boolean isLynx) {
        this.isLynx = isLynx;
    }

    /**
     * Retorno objeto com informacoes para as transacoes que passaram pelo Lynx.
     *
     * @return the informacoesLynx
     */
    public InformacoesLynx getInformacoesLynx() {
        return informacoesLynx;
    }

    /**
     * @param informacoesLynx the informacoesLynx to set
     */
    public void setInformacoesLynx(InformacoesLynx informacoesLynx) {
        this.informacoesLynx = informacoesLynx;
    }

    /**
     * Retorna o codigo original da mensagem vindo da plataforma ou do POS.
     * <br><br>
     * Campo Stratus: CPO-001 (ACTR-TRANSACAO-POS).
     *
     * @return the transacaoPOS
     */
    public String getTransacaoPOS() {
        return transacaoPOS;
    }

    /**
     * @param transacaoPOS the transacaoPOS to set
     */
    public void setTransacaoPOS(String transacaoPOS) {
        this.transacaoPOS = transacaoPOS;
    }

    /**
     * Retorno objeto com informacoes do BIT47.
     *
     * @return the informacoesBIT47
     */
    public InformacoesBIT47 getInformacoesBIT47() {
        return informacoesBIT47;
    }

    /**
     * @param informacoesBIT47 the informacoesBIT47 to set
     */
    public void setInformacoesBIT47(InformacoesBIT47 informacoesBIT47) {
        this.informacoesBIT47 = informacoesBIT47;
    }

    /**
     * Retorna o codigo da release da Especificacao do POS.
     * <br><br>
     * Campo Stratus: CPO-013 (ACTR-TERMINAL-VERSAO).
     * <br><br>
     * O valor do atributo "modoEntrada" eh no formato "CX03WXXXX40S", utiliza
     * o(s) elemento(s) 03 desse conteudo, onde:
     * <DD>C - Rede Cielo;
     * <DD>X - Correcao;
     * <DD>03 - Release da Especificacao;
     * <DD>W - Web;
     * <DD>XXXX - Modelo do terminal;
     * <DD>40 - Versao do aplicativo;
     * <DD>S - Indica a existencia de PIN Pad. Pode variar(6 posicoes).
     * Atualmente todos os terminais tem PIN Pad, leitor para chip e operam sem
     * SAM.
     *
     * @return the releaseEspecificacao
     */
    public String getReleaseEspecificacao() {
        return releaseEspecificacao;
    }

    /**
     * @param releaseEspecificacao the releaseEspecificacao to set
     */
    public void setReleaseEspecificacao(String releaseEspecificacao) {
        this.releaseEspecificacao = releaseEspecificacao;
    }

    /**
     * Retorna o modelo do terminal(POS).
     * <br><br>
     * Campo Stratus: CPO-013 (ACTR-TERMINAL-VERSAO).
     * <br><br>
     * O valor do atributo "modoEntrada" eh no formato "CX03WXXXX40S", utiliza
     * o(s) elemento(s) XXXX desse conteudo, onde:
     * <DD>C - Rede Cielo;
     * <DD>X - Correcao;
     * <DD>03 - Release da Especificacao;
     * <DD>W - Web;
     * <DD>XXXX - Modelo do terminal;
     * <DD>40 - Versao do aplicativo;
     * <DD>S - Indica a existencia de PIN Pad. Pode variar(6 posicoes).
     * Atualmente todos os terminais tem PIN Pad, leitor para chip e operam sem
     * SAM.
     *
     * @return the modeloTerminal
     */
    public String getModeloTerminal() {
        return modeloTerminal;
    }

    /**
     * @param modeloTerminal the modeloTerminal to set
     */
    public void setModeloTerminal(String modeloTerminal) {
        this.modeloTerminal = modeloTerminal;
    }

    /**
     * Retorna a versao do aplicativo.
     * <br><br>
     * Campo Stratus: CPO-013 (ACTR-TERMINAL-VERSAO).
     * <br><br>
     * O valor do atributo "modoEntrada" eh no formato "CX03WXXXX40S", utiliza
     * o(s) elemento(s) 40 desse conteudo, onde:
     * <DD>C - Rede Cielo;
     * <DD>X - Correcao;
     * <DD>03 - Release da Especificacao;
     * <DD>W - Web;
     * <DD>XXXX - Modelo do terminal;
     * <DD>40 - Versao do aplicativo;
     * <DD>S - Indica a existencia de PIN Pad. Pode variar(6 posicoes).
     * Atualmente todos os terminais tem PIN Pad, leitor para chip e operam sem
     * SAM.
     *
     * @return the versaoAplicativo
     */
    public String getVersaoAplicativo() {
        return versaoAplicativo;
    }

    /**
     * @param versaoAplicativo the versaoAplicativo to set
     */
    public void setVersaoAplicativo(String versaoAplicativo) {
        this.versaoAplicativo = versaoAplicativo;
    }

    /**
     * Indica se a transacao eh do tipo Autorizacao Parcial.
     *
     * @return the isAutorizacaoParcial
     */
    public boolean isAutorizacaoParcial() {
        return isAutorizacaoParcial;
    }

    /**
     * @param isAutorizacaoParcial the isAutorizacaoParcial to set
     */
    public void setAutorizacaoParcial(boolean isAutorizacaoParcial) {
        this.isAutorizacaoParcial = isAutorizacaoParcial;
    }

    /**
     * Retorna o Valor do flag indicativo de autorizacao parcial.
     * <br><br>
     * Campo Stratus: CPO-913 (GEN-IND-AUT-PARC).
     * <br><br>
     * Possiveis valores:
     * <DD>E - ElegÃ­vel
     * <DD>N - Nao ElegÃ­vel
     * <DD>P - Aprovada Parcial
     * <DD>D - Desfeita Programada
     *
     * @return the indicativoAutorizacaoParcial
     */
    public String getIndicativoAutorizacaoParcial() {
        return indicativoAutorizacaoParcial;
    }

    /**
     * @param indicativoAutorizacaoParcial the indicativoAutorizacaoParcial to
     * set
     */
    public void setIndicativoAutorizacaoParcial(String indicativoAutorizacaoParcial) {
        this.indicativoAutorizacaoParcial = indicativoAutorizacaoParcial;
    }

    /**
     * Retorna o codigo Multivan.
     *
     * @return codigo multivan
     */
    public String getCodMultivan() {
        return codMultivan;
    }

    public boolean isIndicadorLio() {
        return indicadorLio;
    }

    public void setIndicadorLio(boolean indicadorLio) {
        this.indicadorLio = indicadorLio;
    }

    /**
     * Estabelece regra para contornar problema de mapeamento do Multivan em POS ao qual " " e "000" são referentes a Cielo.<br/>
     * Esses valores sao convertidos para 100.
     * 
     * @param codMultivan codigo Multivan
     */
    public void setCodMultivan(String codMultivan) {
        if (codMultivan == null) {
            this.codMultivan = COD_MULTIVAN_CIELO;
        } else {
            // se o valor da string nao for um inteiro maior que 100, entao multivan eh cielo (100)
            this.codMultivan = (testIsNumberGreaterThen100(codMultivan)) ? codMultivan : COD_MULTIVAN_CIELO;
        }
    }

	/**
	 * Idenfica se a transacao eh de TOKEN.
     * <br><br>
     * Campo Stratus: CPO-913 (GEN-TOKEN-FLAG).
     * <br><br>
	 * 
	 * @return {@code true} para S senao, {@code false}.
	 */
	public boolean isIndicTransacaoToken() {
		return indicTransacaoToken;
	}

	public void setIndicTransacaoToken(boolean indicTransacaoToken) {
		this.indicTransacaoToken = indicTransacaoToken;
	}

    /**
     * Retorna verdadeiro se a string informada eh um numero maior que 100.
     *
     * @param strNumber string que supostamente possui um numero.
     * @return return {@code true} se o valor convertido for maior que 100 e
     * {@code falso} caso nao seja um numero ou se for inferior 100.
     */
    private Boolean testIsNumberGreaterThen100(String strNumber) {
        Boolean result = Boolean.FALSE;
        try {
            Integer value = new Integer(strNumber);
            if (value > 100) {
                result = Boolean.TRUE;
            }
        } catch (NumberFormatException ex) {
        }
        return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    
    public void setFlagCieloPromo(String ppFlag) {
        this.flagCieloPromo = ppFlag;
    }
/**
 *   ?F? ? Conexão com Promo desabilitada
 *   ? ? ? Fora do Filtro
 *   ?N? ? Fora do Filtro
 *   ?*? ? No filtro, mas não enviada para o Promo.
 *   ?T? ? Timeout
 *   ?P? ? No filtro com resposta do Promo COM premiação
 *   ?S? ? No filtro com resposta do Promo SEM premiação
 */
    public String getFlagCieloPromo() {
        return flagCieloPromo;
    }


}
