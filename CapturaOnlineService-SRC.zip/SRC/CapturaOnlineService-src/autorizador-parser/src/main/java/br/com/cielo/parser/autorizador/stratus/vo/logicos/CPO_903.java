package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_903, sobre Dados do xx.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_903 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String bit44MAC;
	
	public CPO_903(){		
	}

	/**
	 * @return the bit44MAC
	 */
	@PositionalField(initialPosition= 1, finalPosition= 8)
	public String getBit44MAC() {
		return bit44MAC;
	}

	/**
	 * @param bit44mac the bit44MAC to set
	 */
	public void setBit44MAC(String bit44mac) {
		bit44MAC = bit44mac;
	}
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
