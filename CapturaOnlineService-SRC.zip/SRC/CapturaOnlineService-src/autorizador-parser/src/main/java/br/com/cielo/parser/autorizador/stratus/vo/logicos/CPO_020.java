package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

import br.com.cielo.parser.autorizador.stratus.vo.logicos.decorator.Double12PosDecorator;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_020, sobre UNICO campo A SUBIR PARA TRANSACAO 0202, utilizado para pegar o Status da Transação 
 * eCommerce (Capturada ou não).
 * 
 * <DL><DT><B>Criada em:</B><DD>18/10/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_020 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	public static Logger logger= LoggerFactory.getLogger(CPO_020.class);
	
	private String terminalCodigo;
	private String lote;
	private String nsu;
	private double valorVenda;
	private String codigoResposta;
	
	public CPO_020(){		
	}
	
	
	/**
	 * Representa o Campo STRATUS: ACTR-CNF-TERMINAL-CODIGO
	 *
	 * @return the terminalCodigo
	 */
	@PositionalField(initialPosition= 1, finalPosition= 8)
	public String getTerminalCodigo() {
		return terminalCodigo;
	}
	/**
	 * @param terminalCodigo the terminalCodigo to set
	 */
	public void setTerminalCodigo(String terminalCodigo) {
		this.terminalCodigo = terminalCodigo;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-CNF-LOTE
	 *
	 * @return the lote
	 */
	@PositionalField(initialPosition= 9, finalPosition= 14)
	public String getLote() {
		return lote;
	}
	/**
	 * @param lote the lote to set
	 */
	public void setLote(String lote) {
		this.lote = lote;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-CNF-NSU
	 *
	 * @return the nsu
	 */
	@PositionalField(initialPosition= 15, finalPosition= 20)
	public String getNsu() {
		return nsu;
	}
	/**
	 * @param nsu the nsu to set
	 */
	public void setNsu(String nsu) {
		this.nsu = nsu;
	}

	/**
	 * Representa o Campo STRATUS: ACTR-CNF-VALOR-VENDA
	 *
	 * @return the valorVenda
	 */
	@PositionalField(initialPosition= 21, finalPosition= 32, decorator= Double12PosDecorator.class)
	public double getValorVenda() {
		return valorVenda;
	}
	/**
	 * @param valorVenda the valorVenda to set
	 */
	public void setValorVenda(double valorVenda) {
		this.valorVenda = valorVenda;
	}
	/**
	 * @param valorVenda the valorVenda to set
	 */
	/*public void setValorVenda(String valorVenda) {		
		String valVenda= valorVenda.substring(0, 10)+"."+valorVenda.substring(10);		
		try {
			this.valorVenda= Double.parseDouble(valVenda);
		} catch (NumberFormatException e) {
			this.valorVenda= 0;
			logger.warn("Erro realizando parser no objeto [CPO_020], em campo numerico[valorVenda]. Valor recebido= '"+valorVenda+"'");			
		}
	}*/

	/**
	 * Representa o Campo STRATUS: ACTR-CNF-CODRES
	 * 
	 *   00 = OK  -- Transação Capturada.
	 *   00 <> não OK
	 *
	 * @return the codigoResposta
	 */
	@PositionalField(initialPosition= 33, finalPosition= 34)
	public String getCodigoResposta() {
		return codigoResposta;
	}
	/**
	 * @param codigoResposta the codigoResposta to set
	 */
	public void setCodigoResposta(String codigoResposta) {
		this.codigoResposta = codigoResposta;
	}

		
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}	
}
