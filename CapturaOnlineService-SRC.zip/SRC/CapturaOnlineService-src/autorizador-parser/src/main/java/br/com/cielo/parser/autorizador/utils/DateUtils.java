package br.com.cielo.parser.autorizador.utils;

import java.util.Date;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;

public class DateUtils {

    public static void main (String args[]) {
        Date d = new Date();
        System.out.println( getDateTimeHour(d) );
        try {
            Integer i = new Integer("ABC");
        } catch (Exception ex) {
            System.out.println("catch");
        } finally {
            System.out.println("finally");
        }
    }
    /**
     * Agrupa da dataTime em minutos passados
     *
     * @param minutesGroup
     * @param date
     * @param dtf
     * @return
     */
    public static String getDateTimeGrouped(int minutesGroup, Date date, DateTimeFormatter dtf) {
        return dtf.print(getDateTimeGrouped(minutesGroup, date));
    }

    public static Long getDateTimeGrouped(int minutesGroup, Date date) {
        return getDateDateTimeGrouped(minutesGroup, date).getTime();
    }

    public static Date getDateDateTimeGrouped(int minutesGroup, Date date) {
        return getDateDateTimeGrouped(minutesGroup, date.getTime());
    }

    public static Date getDateDateTimeGrouped(int minutesGroup, Long time) {
        DateTime dt = new DateTime(time);

        int minute = dt.getMinuteOfHour();
        int minuteNormalized = (minute / minutesGroup) * minutesGroup;
        dt =  dt.withMinuteOfHour(minuteNormalized).withSecondOfMinute(0).withMillisOfSecond(0);
        
        return dt.toDate();
    }

    public static Date getDateTimeHour(Date date) {
        return getDateTimeHour(date.getTime());
    }

    public static Date getDateTimeHour(Long time) {
        DateTime dt = new DateTime(time);
        dt = dt.withMillisOfSecond(0).withSecondOfMinute(0).withMinuteOfHour(0);
        return dt.toDate();
    }

    public static Date getDateTimeHourMinute(Date date) {
        return getDateTimeHourMinute(date.getTime());
    }

    public static Date getDateTimeHourMinute(Long time) {
        DateTime dt = new DateTime(time);
        dt = dt.withMillisOfSecond(0).withSecondOfMinute(0);
        return dt.toDate();
    }

    public static Date getDateTimeHourMinuteWithSecondsFull(Date date) {
        DateTime dt = new DateTime(date.getTime());
        dt = dt.withMillisOfSecond(0).withSecondOfMinute(59);
        return dt.toDate();
    }

    public static Date getDateTimeHourMinuteSecond(Date date) {
        DateTime dt = new DateTime(date.getTime());
        dt = dt.withMillisOfSecond(0);
        return dt.toDate();
    }

    public static int getHourOfDay(Date date) {
        return getHourOfDay(date.getTime());
    }

    public static int getHourOfDay(Long time) {
        return new DateTime(time).getHourOfDay();
    }

    public static String printDateTimeForXML(Date date, DateTimeFormatter dtf) {
        return printDateTimeForXML(date.getTime(), dtf);
    }

    public static String printDateTimeForXML(Long time, DateTimeFormatter dtf) {
        return dtf.print(new DateTime(time)) + ":59";
    }
}
