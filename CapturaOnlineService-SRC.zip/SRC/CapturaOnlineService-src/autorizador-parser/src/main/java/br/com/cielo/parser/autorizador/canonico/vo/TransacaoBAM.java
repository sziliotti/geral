package br.com.cielo.parser.autorizador.canonico.vo;

import java.io.Serializable;

public interface TransacaoBAM extends Serializable {

}
