package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;


/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_004.
 * 
 * <DL><DT><B>Criada em:</B><DD>19/12/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_004 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String ciersPrivate;
	
	
	public CPO_004(){		
	}
	
	/**	 
	 * Representa o Campo STRATUS:  ACTR-CIERS-PRIVATE	 
	 * 
	 * @return the ciersPrivate
	 */
	@PositionalField(initialPosition= 1, finalPosition= 6)
	public String getCiersPrivate() {
		return ciersPrivate;
	}
	


	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
