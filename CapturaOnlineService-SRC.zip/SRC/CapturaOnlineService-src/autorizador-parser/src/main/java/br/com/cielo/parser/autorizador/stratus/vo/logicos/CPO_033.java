package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_033, sobre Dados Data Quality (BIT 22, BIT 43, BIT 60, BIT 126).
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_033 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String bit22POSEntryMode;
	private String bit22PINEntryCpblt;
	private String bit22Filler;
	private String bit43NomeEC;
	private String bit43CidadeEC;
	private String bit43PaisEC;
	private String bit60Filler;
	private String bit60TipoTerminal;
	private String bit60TerminalCPBLT;
	private String bit60Filler2;
	private String bit60IndMotoEcom;
	private String bit126PgtoRecor;
	
	
	public CPO_033(){		
	}


	/**
	 * @return the bit22POSEntryMode
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public String getBit22POSEntryMode() {
		return bit22POSEntryMode;
	}


	/**
	 * @param bit22posEntryMode the bit22POSEntryMode to set
	 */
	public void setBit22POSEntryMode(String bit22posEntryMode) {
		bit22POSEntryMode = bit22posEntryMode;
	}


	/**
	 * @return the bit22PINEntryCpblt
	 */
	@PositionalField(initialPosition= 3, finalPosition= 3)
	public String getBit22PINEntryCpblt() {
		return bit22PINEntryCpblt;
	}


	/**
	 * @param bit22pinEntryCpblt the bit22PINEntryCpblt to set
	 */
	public void setBit22PINEntryCpblt(String bit22pinEntryCpblt) {
		bit22PINEntryCpblt = bit22pinEntryCpblt;
	}


	/**
	 * @return the bit22Filler
	 */
	@PositionalField(initialPosition= 4, finalPosition= 4)
	public String getBit22Filler() {
		return bit22Filler;
	}


	/**
	 * @param bit22Filler the bit22Filler to set
	 */
	public void setBit22Filler(String bit22Filler) {
		this.bit22Filler = bit22Filler;
	}


	/**
	 * @return the bit43NomeEC
	 */
	@PositionalField(initialPosition= 5, finalPosition= 29)
	public String getBit43NomeEC() {
		return bit43NomeEC;
	}


	/**
	 * @param bit43NomeEC the bit43NomeEC to set
	 */
	public void setBit43NomeEC(String bit43NomeEC) {
		this.bit43NomeEC = bit43NomeEC;
	}


	/**
	 * @return the bit43CidadeEC
	 */
	@PositionalField(initialPosition= 30, finalPosition= 42)
	public String getBit43CidadeEC() {
		return bit43CidadeEC;
	}


	/**
	 * @param bit43CidadeEC the bit43CidadeEC to set
	 */
	public void setBit43CidadeEC(String bit43CidadeEC) {
		this.bit43CidadeEC = bit43CidadeEC;
	}


	/**
	 * @return the bit43PaisEC
	 */
	@PositionalField(initialPosition= 43, finalPosition= 44)
	public String getBit43PaisEC() {
		return bit43PaisEC;
	}


	/**
	 * @param bit43PaisEC the bit43PaisEC to set
	 */
	public void setBit43PaisEC(String bit43PaisEC) {
		this.bit43PaisEC = bit43PaisEC;
	}


	/**
	 * @return the bit60Filler
	 */
	@PositionalField(initialPosition= 45, finalPosition= 45)
	public String getBit60Filler() {
		return bit60Filler;
	}


	/**
	 * @param bit60Filler the bit60Filler to set
	 */
	public void setBit60Filler(String bit60Filler) {
		this.bit60Filler = bit60Filler;
	}


	/**
	 * @return the bit60TipoTerminal
	 */
	@PositionalField(initialPosition= 46, finalPosition= 46)
	public String getBit60TipoTerminal() {
		return bit60TipoTerminal;
	}


	/**
	 * @param bit60TipoTerminal the bit60TipoTerminal to set
	 */
	public void setBit60TipoTerminal(String bit60TipoTerminal) {
		this.bit60TipoTerminal = bit60TipoTerminal;
	}


	/**
	 * @return the bit60TerminalCPBLT
	 */
	@PositionalField(initialPosition= 47, finalPosition= 47)
	public String getBit60TerminalCPBLT() {
		return bit60TerminalCPBLT;
	}


	/**
	 * @param bit60TerminalCPBLT the bit60TerminalCPBLT to set
	 */
	public void setBit60TerminalCPBLT(String bit60TerminalCPBLT) {
		this.bit60TerminalCPBLT = bit60TerminalCPBLT;
	}


	/**
	 * @return the bit60Filler2
	 */
	@PositionalField(initialPosition= 48, finalPosition= 53)
	public String getBit60Filler2() {
		return bit60Filler2;
	}


	/**
	 * @param bit60Filler2 the bit60Filler2 to set
	 */
	public void setBit60Filler2(String bit60Filler2) {
		this.bit60Filler2 = bit60Filler2;
	}


	/**
	 * @return the bit60IndMotoEcom
	 */
	@PositionalField(initialPosition= 54, finalPosition= 55)
	public String getBit60IndMotoEcom() {
		return bit60IndMotoEcom;
	}


	/**
	 * @param bit60IndMotoEcom the bit60IndMotoEcom to set
	 */
	public void setBit60IndMotoEcom(String bit60IndMotoEcom) {
		this.bit60IndMotoEcom = bit60IndMotoEcom;
	}


	/**
	 * @return the bit126PgtoRecor
	 */
	@PositionalField(initialPosition= 56, finalPosition= 56)
	public String getBit126PgtoRecor() {
		return bit126PgtoRecor;
	}


	/**
	 * @param bit126PgtoRecor the bit126PgtoRecor to set
	 */
	public void setBit126PgtoRecor(String bit126PgtoRecor) {
		this.bit126PgtoRecor = bit126PgtoRecor;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
        /**
         * Retorna true se a transação for recorrente.
         * @return true se a transação for recorrente.
         */
        public boolean isRecorrente() {
            return "R".equalsIgnoreCase(getBit126PgtoRecor());
        }

}
