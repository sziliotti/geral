package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_909, sobre Dados do BIT47. Utilizado para o Release 6 do POS.
 * 
 * <DL><DT><B>Criada em:</B><DD>09/12/2014</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_909_06 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String bit47Tipo;
	private String bit47NumeroDocumento;
	private String bit47TsSinal;	
	private String bit47SinalBateria;
	private String bit47RUF;
	private String bit47QuantidadeComprovantesImpressos;
	private String bit47Geolocalizacao;	
	private String bit47FallBack;		
	private String bit47RUF2;
	private String bit47CodigoProduto;
	private String bit47NumeroLinhasImpressasNaTransacao;	
	private String bit47Filler;
	
	
	public CPO_909_06(){		
	}
		

	/**
	 *  Representa o Campo STRATUS: ADIC-BRB47-5-TIP
	 *  
	 * @return the bit47Tipo
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public String getBit47Tipo() {
		return bit47Tipo;
	}

	/**
	 * @param bit47Tipo the bit47Tipo to set
	 */
	public void setBit47Tipo(String bit47Tipo) {
		this.bit47Tipo = bit47Tipo;
	}

	/**
	 *  Representa o Campo STRATUS: ADIC-BRB47-5-NDOC
	 *  
	 * @return the bit47NumeroDocumento
	 */
	@PositionalField(initialPosition= 3, finalPosition= 8)
	public String getBit47NumeroDocumento() {
		return bit47NumeroDocumento;
	}

	/**
	 * @param bit47NumeroDocumento the bit47NumeroDocumento to set
	 */
	public void setBit47NumeroDocumento(String bit47NumeroDocumento) {
		this.bit47NumeroDocumento = bit47NumeroDocumento;
	}

	/**
	 *  Representa o Campo STRATUS: ADIC-BRB47-5-TSSINAL
	 *  
	 * @return the bit47TsSinal
	 */
	@PositionalField(initialPosition= 9, finalPosition= 10)
	public String getBit47TsSinal() {
		return bit47TsSinal;
	}

	/**
	 * @param bit47TsSinal the bit47TsSinal to set
	 */
	public void setBit47TsSinal(String bit47TsSinal) {
		this.bit47TsSinal = bit47TsSinal;
	}
		
	/**
	 * Representa o Campo: "Nível de bateria" da Especificação 6(Item bit47-05) do POS.
	 * 
	 * @return the bit47SinalBateria
	 */
	@PositionalField(initialPosition= 11, finalPosition= 12)
	public String getBit47SinalBateria() {
		return bit47SinalBateria;
	}

	/**
	 * @param bit47SinalBateria the bit47SinalBateria to set
	 */
	public void setBit47SinalBateria(String bit47SinalBateria) {
		this.bit47SinalBateria = bit47SinalBateria;
	}
	
	/**
	 * * Representa o Campo: "RUF" da Especificação 6(Item bit47-05) do POS.
	 *
	 * @return the bit47RUF
	 */
	@PositionalField(initialPosition= 13, finalPosition= 16)
	public String getBit47RUF() {
		return bit47RUF;
	}

	/**
	 * @param bit47ruf the bit47RUF to set
	 */
	public void setBit47RUF(String bit47ruf) {
		bit47RUF = bit47ruf;
	}

	/**
	 * Representa o Campo: "Quantidade de Comprovantes Impressos" da Especificação 6(Item bit47-05) do POS.
	 * 
	 * @return the bit47QuantidadeComprovantesImpressos
	 */
	@PositionalField(initialPosition= 17, finalPosition= 18)
	public String getBit47QuantidadeComprovantesImpressos() {
		return bit47QuantidadeComprovantesImpressos;
	}

	/**
	 * @param bit47QuantidadeComprovantesImpressos the bit47QuantidadeComprovantesImpressos to set
	 */
	public void setBit47QuantidadeComprovantesImpressos(
			String bit47QuantidadeComprovantesImpressos) {
		this.bit47QuantidadeComprovantesImpressos = bit47QuantidadeComprovantesImpressos;
	}

	/**
	 * Representa o Campo: "Geo-localização" da Especificação 6(Item bit47-05) do POS.
	 * 
	 * @return the bit47Geolocalizacao
	 */
	@PositionalField(initialPosition= 19, finalPosition= 30)
	public String getBit47Geolocalizacao() {
		return bit47Geolocalizacao;
	}

	/**
	 * @param bit47Geolocalizacao the bit47Geolocalizacao to set
	 */
	public void setBit47Geolocalizacao(String bit47Geolocalizacao) {
		this.bit47Geolocalizacao = bit47Geolocalizacao;
	}
	
	/**
	 *  Representa o Campo STRATUS: ADIC-BRB47-5-FALLBACK
	 *  
	 * @return the bit47FallBack
	 */
	@PositionalField(initialPosition= 31, finalPosition= 31)
	public String getBit47FallBack() {
		return bit47FallBack;
	}

	/**
	 * @param bit47FallBack the bit47FallBack to set
	 */
	public void setBit47FallBack(String bit47FallBack) {
		this.bit47FallBack = bit47FallBack;
	}

	/**
	 * Representa o Campo: "RUF" da Especificação 6(Item bit47-05) do POS.
	 *
	 * @return the bit47RUF2
	 */
	@PositionalField(initialPosition= 32, finalPosition= 33)
	public String getBit47RUF2() {
		return bit47RUF2;
	}

	/**
	 * @param bit47ruf2 the bit47RUF2 to set
	 */
	public void setBit47RUF2(String bit47ruf2) {
		bit47RUF2 = bit47ruf2;
	}

	/**
	 * Representa o Campo: "Código do Produto Matriz mais Secundário ou Código do serviço." da Especificação 6(Item bit47-05) do POS.
	 *
	 * @return the bit47CodigoProduto
	 */
	@PositionalField(initialPosition= 34, finalPosition= 41)
	public String getBit47CodigoProduto() {
		return bit47CodigoProduto;
	}

	/**
	 * @param bit47CodigoProduto the bit47CodigoProduto to set
	 */
	public void setBit47CodigoProduto(String bit47CodigoProduto) {
		this.bit47CodigoProduto = bit47CodigoProduto;
	}

	/**
	 *  Representa o Campo: "Número de linhas impressas na transação" da Especificação 6(Item bit47-05) do POS.
	 *
	 * @return the bit47NumeroLinhasImpressasNaTransacao
	 */
	@PositionalField(initialPosition= 42, finalPosition= 43)
	public String getBit47NumeroLinhasImpressasNaTransacao() {
		return bit47NumeroLinhasImpressasNaTransacao;
	}

	/**
	 * @param bit47NumeroLinhasImpressasNaTransacao the bit47NumeroLinhasImpressasNaTransacao to set
	 */
	public void setBit47NumeroLinhasImpressasNaTransacao(
			String bit47NumeroLinhasImpressasNaTransacao) {
		this.bit47NumeroLinhasImpressasNaTransacao = bit47NumeroLinhasImpressasNaTransacao;
	}	

	/**
	 *  Representa o Campo STRATUS: filler
	 *  
	 * @return the bit47Filler
	 */
	@PositionalField(initialPosition= 44, finalPosition= 76)
	public String getBit47Filler() {		
		return bit47Filler;
	}

	/**
	 * @param bit47Filler the bit47Filler to set
	 */
	public void setBit47Filler(String bit47Filler) {
		this.bit47Filler = bit47Filler;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
