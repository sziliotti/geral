package br.com.cielo.parser.autorizador.distribuidor.canonico.vo;

/**
 * Enumerado que define o status da transação.
 * @author nemer
 */
public enum TransactionStatus {
    /** 
     * Aprovado
     */
    APPROVED(1),
    /**
     * Negado
     */
    DENIED(2),
    /**
     * Capturado 
     */
    CAPTURED(3), 
    /**
     * Desfeito
     */
    UNDONE(4), 
    /**
     * Erro geral
     */
    ERROR(5), 
    /**
     * Timeout de alguma integração (Emissor, Bandeira, Sistemas internos, etc.)
     */
    TIMEOUT(6), 
    /**
     * Autenticado (geralmente somente para Ecommerce)
     */
    AUTHENTICATED(7), 
    /**
     * Cancelado
     */
    CANCELED(8),
    /**
     * Pendente de aprovação: Autorizador aprovou a transação junto ao Emissor, mas ainda precisa ter a aprovação final do POS (validação CHIP).
     */
    PENDING(9),
    /**
     * Indefinido: este só ocorre caso algum estado novo seja criado e não esteja mapeado no sistema
     */
    UNDEFINED(-1);

    private int statusCode;

    /**
     * Construtor.
     *
     * @param statusCode
     */
    TransactionStatus(int statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Retorna o código do status.
     *
     * @return
     */
    public int getStatusCode() {
        return statusCode;
    }

    /**
     * Retorna o enum especifico para o status da transação.
     *
     * @param statusCode
     * @return
     */
    public static TransactionStatus statusOf(int statusCode) {
        return forValue(String.valueOf(statusCode));
    }

    /**
     * Retorna o enum especifico para o status da transação.
     *
     * @param statusCode
     * @return
     */
    public static TransactionStatus forValue(String statusCode) {
        int valueIntStatus = Integer.parseInt(statusCode);
        switch (valueIntStatus) {
            case 1:
                return APPROVED;
            case 2:
                return DENIED;
            case 3:
                return CAPTURED;
            case 4:
                return UNDONE;
            case 5:
                return ERROR;
            case 6:
                return TIMEOUT;
            case 7:
                return AUTHENTICATED;
            case 8:
                return CANCELED;
            case 9:
                return PENDING;
            default:
                return UNDEFINED;
        }
    }
}
