package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

import br.com.cielo.parser.autorizador.stratus.vo.logicos.decorator.Double10PosDecorator;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_065, sobre Dados do xx.
 * 
 * <DL><DT><B>Criada em:</B><DD>04/10/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_065 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	public static Logger logger= LoggerFactory.getLogger(CPO_065.class);
	
	private String nsuCan;
	private String dataCan;
	private double valorCan;
	private String tcb61NrLog9;
	
	
	public CPO_065(){		
	}
	

	/**
	 * Representa o Campo STRATUS: ACTR-NSU-CAN
	 * 
	 * @return the nsuCan
	 */
	@PositionalField(initialPosition= 1, finalPosition= 6)
	public String getNsuCan() {
		return nsuCan;
	}
	/**
	 * @param nsuCan the nsuCan to set
	 */
	public void setNsuCan(String nsuCan) {
		this.nsuCan = nsuCan;
	}


	/**
	 * Representa o Campo STRATUS: ACTR-DATA-CAN
	 * 
	 * @return the dataCan
	 */
	@PositionalField(initialPosition= 7, finalPosition= 12)
	public String getDataCan() {
		return dataCan;
	}
	/**
	 * @param dataCan the dataCan to set
	 */
	public void setDataCan(String dataCan) {
		this.dataCan = dataCan;
	}


	/**
	 * Representa o Campo STRATUS:  ACTR-VAL-CANC
	 * 
	 * @return the valorCan
	 */
	@PositionalField(initialPosition= 13, finalPosition= 22, decorator= Double10PosDecorator.class)
	public double getValorCan() {
		return valorCan;
	}
	/**
	 * @param valorCan the valorCan to set
	 */
	/*public void setValorCan(String valorCan) {		
		String valCan= valorCan.substring(0, 8)+"."+valorCan.substring(8);		
		try {
			this.valorCan = Double.parseDouble(valCan);
		} catch (NumberFormatException e) {
			this.valorCan= 0;
			logger.warn("Erro realizando parser no objeto [CPO_065], em campo numerico[ValorVenda]. Valor recebido= '"+valorCan+"'");			
		}
	}*/
	/**
	 * @param valorCan the valorCan to set
	 */
	public void setValorCan(double valorCan) {
		this.valorCan = valorCan;
	}


	/**
	 * Representa o Campo STRATUS: ACTR-TCB61-NR-LOG-9
	 * 
	 * @return the tcb61NrLog9
	 */
	@PositionalField(initialPosition= 23, finalPosition= 30)
	public String getTcb61NrLog9() {
		return tcb61NrLog9;
	}
	/**
	 * @param tcb61NrLog9 the tcb61NrLog9 to set
	 */
	public void setTcb61NrLog9(String tcb61NrLog9) {
		this.tcb61NrLog9 = tcb61NrLog9;
	}

	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
