package br.com.cielo.parser.autorizador.canonico.vo;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * <br>
 * Objeto responsavel em armazenar as insformações das trasnações do tipo DCC, utilizadas na Monitoração de Negocio.
 * 
 *	 
 * <DL><DT><B>Criada em:</B><DD>14/04/2014</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class InformacoesDCC implements Serializable {
	private static final long serialVersionUID= 1L;
	
	//Atributo que define o status da transação DCC.
	private StatusDCC statusDCC;
	
	//Atributo que define o tipo da transação DCC (C- Consulta, F - Financeira).
	private String tipoTransacao;
	
	//Atributo que define o codigo da Moeda do Portador.
	private String codigoMoedaPortador;
	
	//Atributo que define a descrição do tipo da moeda do Portador.
	private String descricaoMoedaPortador;
	
	//Atributo que define o valor de Markup.
	private double valorMarkup;
	
	//Atributo que define o percentual de Markup da Planet.
	private double percentualMarkup;
	
	//Atributo que define o numero de casas decimais da Transação do Portador.
	private String digitoTransacaoPortador;	
	
	//Atributo que define o valor da transação na moeda do portador.
	private double valorTransacaoMoedaPortador;
	
	//Atributo que define o valor da Transação em dolar.
	private double valorTransacaoDolar;
	
	//Atributo que define o numero de casas decimais da Moeda do Portador.
	private String digitoMoedaPortador;
	
	//Atributo que define a cotação da Moeda do Portador.
	private String cotacaoMoedaPortador;
	
	//Atributo que define o numero de casas decimais da cotação em dolar.
	private String digitoCotacaoDolar;
	
	//Atributo que define a cotação em dolar da Planet.
	private String cotacaoDolarPlanet;
	
	//Atributo que define a data e hora que foi aplicado o cambio na Planet.
	private Date dataHoraCambioPlanet;
	
	//Atributo que define a hora de autorização da transação.
	private String horaAutorizacaoTransacao;
	
	//Atributo que define o tempo de resposta da Planet.
	private long tempoRespostaPlanet;
	
	
	/**
	 * Construtor Padrão.
	 */
	public InformacoesDCC() {
	}
	

	/** 
	 * Retorna o Status DCC da Transação, representada pelo Enumeration: StatusDCC.
	 * 	<br><br>
	 * Possiveis valores: 	
	 * 		<DD>1 - ELEGIVEL
	 * 		<DD>2 - NÃO ELEGIVEL
	 * 		<DD>3 - DCC
	 * 		<DD>4 - NEGADO PELA PLANET
	 * 		<DD>5 - NAO SELECIONADO DCC PELO CLIENTE
	 * 		<DD>6 - TIMEOUT PLANET
	 * 
	 * @return the statusDCC
	 */
	public StatusDCC getStatusDCC() {
		return statusDCC;
	}
	/**
	 * @param statusDCC the statusDCC to set
	 */
	public void setStatusDCC(StatusDCC statusDCC) {
		this.statusDCC = statusDCC;
	}

	/**
	 * Retorna a informação do tipo da transação DCC.
	 * <br><br>
	 * Possiveis valores: 
	 *  	<DD>C - Consulta
	 * 		<DD>F - Financeira
	 * 
	 * @return the tipoTransacao
	 */
	public String getTipoTransacao() {
		return tipoTransacao;
	}
	/**
	 * @param tipoTransacao the tipoTransacao to set
	 */
	public void setTipoTransacao(String tipoTransacao) {
		this.tipoTransacao = tipoTransacao;
	}

	/**
	 * Retorna o codigo da Moeda da transação (Norma ISO, padrão Mundial).
	 * <br><br>
	 * Campo Stratus: CPO-901 (ADIC-DCC-MOEDA-PORT).
	 * 
	 * @return the codigoMoedaPortador
	 */
	public String getCodigoMoedaPortador() {
		return codigoMoedaPortador;
	}
	/**
	 * @param codigoMoedaPortador the codigoMoedaPortador to set
	 */
	public void setCodigoMoedaPortador(String codigoMoedaPortador) {
		this.codigoMoedaPortador = codigoMoedaPortador;
	}

	/**
	 * Retorna a descrição do tipo da moeda do Portador (ISO 4217  Ex.: BRL, USD, EUR).
	 * <br><br>
	 * Campo Stratus: CPO-901 (ADIC-DCC-MOEDA-DESC).
	 * 
	 * @return the descricaoMoedaPortador
	 */
	public String getDescricaoMoedaPortador() {
		return descricaoMoedaPortador;
	}
	/**
	 * @param descricaoMoedaPortador the descricaoMoedaPortador to set
	 */
	public void setDescricaoMoedaPortador(String descricaoMoedaPortador) {
		this.descricaoMoedaPortador = descricaoMoedaPortador;
	}

	/**
	 * Retorna o valor de Markup, que é o valor do serviço cobrado pela Cielo.
	 * <br><br>
	 * Campo Stratus: CPO-901 (ADIC-DCC-VALOR-MARKUP).
	 * 
	 * @return the valorMarkup
	 */
	public double getValorMarkup() {
		return valorMarkup;
	}
	/**
	 * @param valorMarkup the valorMarkup to set
	 */
	public void setValorMarkup(double valorMarkup) {
		this.valorMarkup = valorMarkup;
	}

	/**
	 * Retorna o percentual de Markup. Ex.: 99,99 - Taxa de Serviço cobrado pela Cielo.
	 * <br><br>
	 * Campo Stratus: CPO-901 (ADIC-DCC-PERC-MARKUP-PL).
	 * 
	 * @return the percentualMarkup
	 */
	public double getPercentualMarkup() {
		return percentualMarkup;
	}
	/**
	 * @param percentualMarkup the percentualMarkup to set
	 */
	public void setPercentualMarkup(double percentualMarkupPlanet) {
		this.percentualMarkup = percentualMarkupPlanet;
	}

	/**
	 * Retorna o número de casas Decimais da transação(Varia de 0 até 7).
	 * <br><br>
	 * Campo Stratus: CPO-901 (ADIC-DCC-DIG-TRANS-PORT).
	 * 
	 * @return the digitoTransacaoPortador
	 */
	public String getDigitoTransacaoPortador() {
		return digitoTransacaoPortador;
	}
	/**
	 * @param digitoTransacaoPortador the digitoTransacaoPortador to set
	 */
	public void setDigitoTransacaoPortador(String digitoTransPortador) {
		this.digitoTransacaoPortador = digitoTransPortador;
	}

	/**
	 * Retorna o valor da Transação, na moeda do Portador.
	 * <br><br>
	 * Campo Stratus: CPO-901 (ADIC-DCC-TRANS-MOEDA-PORT-2).
	 * 
	 * @return the valorTransacaoMoedaPortador
	 */
	public double getValorTransacaoMoedaPortador() {
		return valorTransacaoMoedaPortador;
	}
	/**
	 * @param valorTransacaoMoedaPortador the valorTransacaoMoedaPortador to set
	 */
	public void setValorTransacaoMoedaPortador(double transMoedaPortador) {
		this.valorTransacaoMoedaPortador = transMoedaPortador;
	}

	/**
	 * Retorna o valor da Transação, em dolar.
	 * <br><br>
	 * Campo Stratus: CPO-901 (ADIC-DCC-TRANS-MOEDA-DOL).
	 * 
	 * @return the valorTransacaoDolar
	 */
	public double getValorTransacaoDolar() {
		return valorTransacaoDolar;
	}
	/**
	 * @param valorTransacaoDolar the valorTransacaoDolar to set
	 */
	public void setValorTransacaoDolar(double transMoedaDol) {
		this.valorTransacaoDolar = transMoedaDol;
	}

	/**
	 * Retorna o número de casas Decimais - Taxa Portador(Varia de 0 até 7).
	 * <br><br>
	 * Campo Stratus: CPO-901 (ADIC-DCC-DIG-MOEDA-PORT).
	 * 
	 * @return the digitoMoedaPortador
	 */
	public String getDigitoMoedaPortador() {
		return digitoMoedaPortador;
	}
	/**
	 * @param digitoMoedaPortador the digitoMoedaPortador to set
	 */
	public void setDigitoMoedaPortador(String digitoMoedaPortador) {
		this.digitoMoedaPortador = digitoMoedaPortador;
	}

	/**
	 * Retorna a taxa de Conversão da Moeda do Portador.
	 * <br><br>
	 * Campo Stratus: CPO-901 (ADIC-DCC-COT-MOEDA-PORT).
	 * 
	 * @return the cotacaoMoedaPortador
	 */
	public String getCotacaoMoedaPortador() {
		return cotacaoMoedaPortador;
	}
	/**
	 * @param cotacaoMoedaPortador the cotacaoMoedaPortador to set
	 */
	public void setCotacaoMoedaPortador(String cotacaoMoedaPortador) {
		this.cotacaoMoedaPortador = cotacaoMoedaPortador;
	}

	/**
	 * Retorna o número de casas Decimais - Taxa Dolar(Varia de 0 até 7).
	 * <br><br>
	 * Campo Stratus: CPO-901 (ADIC-DCC-DIG-COT-DOL).
	 * 
	 * @return the digitoCotacaoDolar
	 */
	public String getDigitoCotacaoDolar() {
		return digitoCotacaoDolar;
	}
	/**
	 * @param digitoCotacaoDol the digitoCotacaoDol to set
	 */
	public void setDigitoCotacaoDolar(String digitoCotacaoDol) {
		this.digitoCotacaoDolar = digitoCotacaoDol;
	}

	/**
	 * Retorna a taxa de Conversão da Moeda Dolar.
	 * <br><br>
	 * Campo Stratus: CPO-901 (ADIC-DCC-COT-DOL-PL).
	 * 
	 * @return the cotacaoDolarPlanet
	 */
	public String getCotacaoDolarPlanet() {
		return cotacaoDolarPlanet;
	}
	/**
	 * @param cotacaoDolarPlanet the cotacaoDolarPlanet to set
	 */
	public void setCotacaoDolarPlanet(String cotacaoDolPlanet) {
		this.cotacaoDolarPlanet = cotacaoDolPlanet;
	}

	/**
	 * Retorna a data e hora que foi aplicado o cambio na Planet.
	 * <br><br>
	 * Campo Stratus: CPO-901 (ADIC-DCC-DT-CAMBIO-PL e ADIC-DCC-HR-CAMBIO-PL).
	 * 
	 * @return the dataHoraCambioPlanet
	 */
	public Date getDataHoraCambioPlanet() {
		return dataHoraCambioPlanet;
	}
	/**
	 * @param dataHoraCambioPlanet the dataHoraCambioPlanet to set
	 */
	public void setDataHoraCambioPlanet(Date dataHoraCambioPlanet) {
		this.dataHoraCambioPlanet = dataHoraCambioPlanet;
	}

	/**
	 * Retorna a hora de autorização da transação.
	 * <br><br>
	 * Campo Stratus: CPO-901 (ADIC-DCC-HR-AUTOR-TRANS).
	 * 
	 * @return the horaAutorizacaoTransacao
	 */
	public String getHoraAutorizacaoTransacao() {
		return horaAutorizacaoTransacao;
	}
	/**
	 * @param horaAutorizacaoTransacao the horaAutorizacaoTransacao to set
	 */
	public void setHoraAutorizacaoTransacao(String horaAutorizacaoTransacao) {
		this.horaAutorizacaoTransacao = horaAutorizacaoTransacao;
	}

	/**
	 * Retorna o tempo de resposta da Planet.
	 * <br><br>
	 * Campo Stratus: CPO-901 (ADIC-DCC-TEMPO-RESP-PLANET).
	 * 
	 * @return the tempoRespostaPlanet
	 */
	public long getTempoRespostaPlanet() {
		return tempoRespostaPlanet;
	}
	/**
	 * @param tempoRespostaPlanet the tempoRespostaPlanet to set
	 */
	public void setTempoRespostaPlanet(long tempoRespostaPlanet) {
		this.tempoRespostaPlanet = tempoRespostaPlanet;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
