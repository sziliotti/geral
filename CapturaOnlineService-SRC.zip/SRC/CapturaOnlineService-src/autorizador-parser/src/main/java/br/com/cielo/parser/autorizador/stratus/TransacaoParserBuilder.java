package br.com.cielo.parser.autorizador.stratus;

/**
 * <B>Projeto: Autorizador-Stratus-Parser</B><BR>
 * <br><br>
 * Classe estatica responsavel em retornar a instancia do builder correspondente ao parser desejado.
 *
 * <DL><DT><B>Criada em:</B><DD>12/01/2017</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class TransacaoParserBuilder {

    private static TransacaoStratusParser transacaoStratusParserInst = null;
    private static TransacaoMonitoracaoParser transacaoMonitoracaoParserInst = null;
   
    /**
     * Construtor privado.
     */
    private TransacaoParserBuilder() {
    }

    /**
     * Método responsável em retornar a instância do objeto TransacaoStratusParser, responsável em efetuar parser do Stratus.
     * <br><br>
     *
     * @return Objeto TransacaoStratusParser.
     */
    public synchronized static TransacaoStratusParser getTransacaoStratusParser() {
        if (transacaoStratusParserInst == null) {
            transacaoStratusParserInst = new TransacaoStratusParser();
        }
        return transacaoStratusParserInst;
    }

    /**
     * Método responsável em retornar a instância do objeto TransacaoMonitoracaoParser, responsável em efetuar parser da mensagem de
     * Monitoração manipulado pelo CEP e BAM.
     * <br><br>
     *
     * @return Objeto TransacaoMonitoracaoParser.
     */
    public synchronized static TransacaoMonitoracaoParser getTransacaoMonitoracaoParser() {
        if (transacaoMonitoracaoParserInst == null) {
            transacaoMonitoracaoParserInst = new TransacaoMonitoracaoParser();
        }
        return transacaoMonitoracaoParserInst;
    }

}
