package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_037, sobre Dados do xx.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_037 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String TCCODFUN_P24;
	private String filler;
	
	public CPO_037(){		
	}

	/**
	 * @return the tCCODFUN_P24
	 */
	@PositionalField(initialPosition= 1, finalPosition= 3)
	public String getTCCODFUN_P24() {
		return TCCODFUN_P24;
	}

	/**
	 * @param tCCODFUN_P24 the tCCODFUN_P24 to set
	 */
	public void setTCCODFUN_P24(String tCCODFUN_P24) {
		TCCODFUN_P24 = tCCODFUN_P24;
	}

	/**
	 * @return the filler
	 */
	@PositionalField(initialPosition= 4, finalPosition= 4)
	public String getFiller() {
		return filler;
	}

	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		this.filler = filler;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
