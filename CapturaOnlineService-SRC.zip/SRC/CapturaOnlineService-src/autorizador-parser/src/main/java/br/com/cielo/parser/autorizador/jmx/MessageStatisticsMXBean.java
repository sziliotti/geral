package br.com.cielo.parser.autorizador.jmx;

import java.math.BigDecimal;
import java.util.Map;


/**
 * <B>Projeto: autorizador-stratus-parser</B><BR><BR>
 *
 * Interface MXBean de Monitoramento JMX.
 *
 * <DL><DT><B>Criada em:</B><DD>04/12/2017</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public interface MessageStatisticsMXBean {

    static final String KEY_START_TIME = "START_TIME_MILISSECONDS_LAST_TPS";
    static final String KEY_TOTAL_MESSAGES = "TOTAL_MESSAGES";
    static final String KEY_TPS_MIN = "TPS_MIN";
    static final String KEY_TPS_MAX = "TPS_MAX";
    static final String KEY_TPS_LAST = "TPS_LAST";
    static final String KEY_PARSE_LATENCY_MIN = "PARSE_LATENCY_MIN";
    static final String KEY_PARSE_LATENCY_MAX = "PARSE_LATENCY_MAX";
    static final String KEY_PARSE_LATENCY_LAST = "PARSE_LATENCY_LAST";
    static final String KEY_POST_LATENCY_MIN = "POST_LATENCY_MIN";
    static final String KEY_POST_LATENCY_MAX = "POST_LATENCY_MAX";
    static final String KEY_POST_LATENCY_LAST = "POST_LATENCY_LAST";
    static final String KEY_PERSISTENCE_LATENCY_MIN = "PERSISTENCE_LATENCY_MIN";
    static final String KEY_PERSISTENCE_LATENCY_MAX = "PERSISTENCE_LATENCY_MAX";
    static final String KEY_PERSISTENCE_LATENCY_LAST = "PERSISTENCE_LATENCY_LAST";

    public BigDecimal setProperty(String key, BigDecimal value);

    public BigDecimal getProperty(String key);

    public Map<String, BigDecimal> getProperties();

    public Map<String, String> getTimes();

    public String getBeanName();

    public void addMessages(BigDecimal value);

    public void startTimeCount();
}
