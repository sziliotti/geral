package br.com.cielo.parser.autorizador.canonico.vo;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 *<B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 *<br>
 * Objeto responsavel em armazenar as insformações das transações que passaram pelo LYNX, utilizadas na Monitoração de Negocio. 
 * 
 *	 
 *<DL><DT><B>Criada em:</B><DD>17/04/2014</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class InformacoesLynx implements Serializable {
	private static final long serialVersionUID = 1L;
	
	//Atributo "status" da Classe CPO_067.
	private String status;
	
	//Atributo "timeout" da Classe CPO_067.
	private boolean isTimeout;
	
	//Atributo "acao" da Classe CPO_067.
	private String codigoAcao;
	
	//Atributo "regraFiltro" da Classe CPO_067.
	private String regraFiltro;
	
	//Atributo "regraLynx" da Classe CPO_067.
	private String regraLynx;
	
	//Atributo "scoreNeural" da Classe CPO_067.
	private String scoreNeural;
	
	//Atributo "scoreRegra" da Classe CPO_067.
	private String scoreRegra;
	
	//Atributo "behaviour" da Classe CPO_067.
	private String behaviour;
	
	//Atributo "flagCTFTran" da Classe CPO_067.
	private String flagCTF;
	
	
	/**
	 * Construtor padrão.
	 */
	public InformacoesLynx() {	
	}
	
	

	/**
	 * Retorna o status da transação que passou pelo Lynx.
	 * <br><br>
	 * Campo Stratus: CPO-067 (ACTR-LYNX-STATUS).
	 * 
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Retorna  se ocorreu timeout, na transação que passou pelo Lynx.
	 * <br><br>
	 * Campo Stratus: CPO-067 (ACTR-LYNX-TIMEOUT).
	 * 
	 * @return the isTimeout
	 */
	public boolean isTimeout() {
		return isTimeout;
	}
	/**
	 * @param isTimeout the isTimeout to set
	 */
	public void setTimeout(boolean isTimeout) {
		this.isTimeout = isTimeout;
	}

	/**
	 * Retorna o codigo da ação da transação que passou pelo Lynx.
	 * <br><br>
	 * Campo Stratus: CPO-067 (ACTR-LYNX-ACAO).
	 *
	 * @return the codigoAcao
	 */
	public String getCodigoAcao() {
		return codigoAcao;
	}
	/**
	 * @param codigoAcao the codigoAcao to set
	 */
	public void setCodigoAcao(String codigoAcao) {
		this.codigoAcao = codigoAcao;
	}

	/**
	 * Retorna o codigo da regra que passou pelo filtro do Lynx.
	 * <br><br>
	 * Campo Stratus: CPO-067 (ACTR-LYNX-REGRA-FILTRO).
	 *
	 * @return the regraFiltro
	 */
	public String getRegraFiltro() {
		return regraFiltro;
	}
	/**
	 * @param regraFiltro the regraFiltro to set
	 */
	public void setRegraFiltro(String regraFiltro) {
		this.regraFiltro = regraFiltro;
	}

	/**
	 * Retorna a regra especifica do Lynx.
	 * <br><br>
	 * Campo Stratus: CPO-067 (ACTR-LYNX-REGRA-LYNX).
	 *
	 * @return the regraLynx
	 */
	public String getRegraLynx() {
		return regraLynx;
	}
	/**
	 * @param regraLynx the regraLynx to set
	 */
	public void setRegraLynx(String regraLynx) {
		this.regraLynx = regraLynx;
	}

	/**
	 * Retorna o score neural no Lynx.
	 * <br><br>
	 * Campo Stratus: CPO-067 (ACTR-LYNX-SCORE-NEURAL).
	 *
	 * @return the scoreNeural
	 */
	public String getScoreNeural() {
		return scoreNeural;
	}
	/**
	 * @param scoreNeural the scoreNeural to set
	 */
	public void setScoreNeural(String scoreNeural) {
		this.scoreNeural = scoreNeural;
	}

	/**
	 * Retorna o score da regra do Lynx.
	 * <br><br>
	 * Campo Stratus: CPO-067 (ACTR-LYNX-SCORE-REGRA).
	 *
	 * @return the scoreRegra
	 */
	public String getScoreRegra() {
		return scoreRegra;
	}
	/**
	 * @param scoreRegra the scoreRegra to set
	 */
	public void setScoreRegra(String scoreRegra) {
		this.scoreRegra = scoreRegra;
	}

	/**
	 * Retorna o behaviour do Lynx.
	 * <br><br>
	 * Campo Stratus: CPO-067 (ACTR-LYNX-BEHAVIOUR).
	 *
	 * @return the behaviour
	 */
	public String getBehaviour() {
		return behaviour;
	}
	/**
	 * @param behaviour the behaviour to set
	 */
	public void setBehaviour(String behaviour) {
		this.behaviour = behaviour;
	}

	/**
	 * Retorna a flag CTF da transação do Lynx.
	 * <br><br>
	 * Campo Stratus: CPO-067 (ACTR-FLAG-CTF-TRAN).
	 *
	 * @return the flagCTF
	 */
	public String getFlagCTF() {
		return flagCTF;
	}
	/**
	 * @param flagCTF the flagCTF to set
	 */
	public void setFlagCTF(String flagCTF) {
		this.flagCTF = flagCTF;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
