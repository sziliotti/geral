package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_904, sobre Dados do BIT47.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_904 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String numeroDocumento1;
	private String resultadoTransacao1;
	private String tempoConexao1;
	private String tempoComunicacao1;
	private String tempoResposta1;
	
	private String numeroDocumento2;
	private String resultadoTransacao2;
	private String tempoConexao2;
	private String tempoComunicacao2;
	private String tempoResposta2;
	
	private String numeroDocumento3;
	private String resultadoTransacao3;
	private String tempoConexao3;
	private String tempoComunicacao3;
	private String tempoResposta3;
	
	public CPO_904(){		
	}

	/**
	 * Representa o Campo STRATUS: ADIC-BRB47-NR-DOC-1, iteração 1.
	 * 
	 * @return the bit47NumeroDocumento1
	 */
	@PositionalField(initialPosition= 1, finalPosition= 6)
	public String getNumeroDocumento1() {
		return numeroDocumento1;
	}

	/**
	 * @param bit47NumeroDocumento1 the bit47NumeroDocumento1 to set
	 */
	public void setNumeroDocumento1(String bit47NumeroDocumento1) {
		this.numeroDocumento1 = bit47NumeroDocumento1;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-BRB47-RESTRA-1, iteração 1.
	 * 
	 * @return the bit47Restra1
	 */
	@PositionalField(initialPosition= 7, finalPosition= 8)
	public String getResultadoTransacao1() {
		return resultadoTransacao1;
	}

	/**
	 * @param bit47Restra1 the bit47Restra1 to set
	 */
	public void setResultadoTransacao1(String bit47Restra1) {
		this.resultadoTransacao1 = bit47Restra1;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-BRB47-TEMCON-1, iteração 1.
	 * 
	 * @return the bit47Temcon1
	 */
	@PositionalField(initialPosition= 9, finalPosition= 12)
	public String getTempoConexao1() {
		return tempoConexao1;
	}
	/**
	 * @param bit47Temcon1 the bit47Temcon1 to set
	 */
	public void setTempoConexao1(String bit47Temcon1) {
		this.tempoConexao1 = bit47Temcon1;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-BRB47-TEMCOM-1, iteração 1.
	 * 
	 * @return the bit47Temcom1
	 */
	@PositionalField(initialPosition= 13, finalPosition= 16)
	public String getTempoComunicacao1() {
		return tempoComunicacao1;
	}
	/**
	 * @param bit47Temcom1 the bit47Temcom1 to set
	 */
	public void setTempoComunicacao1(String bit47Temcom1) {
		this.tempoComunicacao1 = bit47Temcom1;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-BRB47-TEMRES-1, iteração 1.
	 * 
	 * @return the bit47temres1
	 */
	@PositionalField(initialPosition= 17, finalPosition= 20)
	public String getTempoResposta1() {
		return tempoResposta1;
	}
	/**
	 * @param bit47temres1 the bit47temres1 to set
	 */
	public void setTempoResposta1(String bit47temres1) {
		this.tempoResposta1 = bit47temres1;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-BRB47-NR-DOC-1, iteração 2.
	 * 
	 * @return the bit47NumeroDocumento2
	 */
	@PositionalField(initialPosition= 21, finalPosition= 26)
	public String getNumeroDocumento2() {
		return numeroDocumento2;
	}
	/**
	 * @param bit47NumeroDocumento2 the bit47NumeroDocumento2 to set
	 */
	public void setNumeroDocumento2(String bit47NumeroDocumento2) {
		this.numeroDocumento2 = bit47NumeroDocumento2;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-BRB47-RESTRA-1, iteração 2.
	 * 
	 * @return the bit47Restra2
	 */
	@PositionalField(initialPosition= 27, finalPosition= 28)
	public String getResultadoTransacao2() {
		return resultadoTransacao2;
	}
	/**
	 * @param bit47Restra2 the bit47Restra2 to set
	 */
	public void setResultadoTransacao2(String bit47Restra2) {
		this.resultadoTransacao2 = bit47Restra2;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-BRB47-TEMCON-1, iteração 2.
	 * 
	 * @return the bit47Temcon2
	 */
	@PositionalField(initialPosition= 29, finalPosition= 32)
	public String getTempoConexao2() {
		return tempoConexao2;
	}
	/**
	 * @param bit47Temcon2 the bit47Temcon2 to set
	 */
	public void setTempoConexao2(String bit47Temcon2) {
		this.tempoConexao2 = bit47Temcon2;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-BRB47-TEMCOM-1, iteração 2.
	 * 
	 * @return the bit47Temcom2
	 */
	@PositionalField(initialPosition= 33, finalPosition= 36)
	public String getTempoComunicacao2() {
		return tempoComunicacao2;
	}
	/**
	 * @param bit47Temcom2 the bit47Temcom2 to set
	 */
	public void setTempoComunicacao2(String bit47Temcom2) {
		this.tempoComunicacao2 = bit47Temcom2;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-BRB47-TEMRES-1, iteração 2.
	 * 
	 * @return the bit47temres2
	 */
	@PositionalField(initialPosition= 37, finalPosition= 40)
	public String getTempoResposta2() {
		return tempoResposta2;
	}
	/**
	 * @param bit47temres2 the bit47temres2 to set
	 */
	public void setTempoResposta2(String bit47temres2) {
		this.tempoResposta2 = bit47temres2;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-BRB47-NR-DOC-1, iteração 3.
	 * 
	 * @return the bit47NumeroDocumento3
	 */
	@PositionalField(initialPosition= 41, finalPosition= 46)
	public String getNumeroDocumento3() {
		return numeroDocumento3;
	}
	/**
	 * @param bit47NumeroDocumento3 the bit47NumeroDocumento3 to set
	 */
	public void setNumeroDocumento3(String bit47NumeroDocumento3) {
		this.numeroDocumento3 = bit47NumeroDocumento3;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-BRB47-RESTRA-1, iteração 3.
	 * 
	 * @return the bit47Restra3
	 */
	@PositionalField(initialPosition= 47, finalPosition= 48)
	public String getResultadoTransacao3() {
		return resultadoTransacao3;
	}
	/**
	 * @param bit47Restra3 the bit47Restra3 to set
	 */
	public void setResultadoTransacao3(String bit47Restra3) {
		this.resultadoTransacao3 = bit47Restra3;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-BRB47-TEMCON-1, iteração 3.
	 * 
	 * @return the bit47Temcon3
	 */
	@PositionalField(initialPosition= 49, finalPosition= 52)
	public String getTempoConexao3() {
		return tempoConexao3;
	}
	/**
	 * @param bit47Temcon3 the bit47Temcon3 to set
	 */
	public void setTempoConexao3(String bit47Temcon3) {
		this.tempoConexao3 = bit47Temcon3;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-BRB47-TEMCOM-1, iteração 3.
	 * 
	 * @return the bit47Temcom3
	 */
	@PositionalField(initialPosition= 53, finalPosition= 56)
	public String getTempoComunicacao3() {
		return tempoComunicacao3;
	}
	/**
	 * @param bit47Temcom3 the bit47Temcom3 to set
	 */
	public void setTempoComunicacao3(String bit47Temcom3) {
		this.tempoComunicacao3 = bit47Temcom3;
	}

	/**
	 * Representa o Campo STRATUS: ADIC-BRB47-TEMRES-1, iteração 3.
	 * 
	 * @return the bit47temres3
	 */
	@PositionalField(initialPosition= 57, finalPosition= 60)
	public String getTempoResposta3() {
		return tempoResposta3;
	}
	/**
	 * @param bit47temres3 the bit47temres3 to set
	 */
	public void setTempoResposta3(String bit47temres3) {
		this.tempoResposta3 = bit47temres3;
	}
	
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
