package br.com.cielo.parser.autorizador.stratus.vo.logicos.decorator;

import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.exception.FieldDecoratorException;
import com.github.ffpojo.metadata.FieldDecorator;

/**
 * <B>Projeto: Autorizador-Stratus-Parser</B><BR>
 * <br><br>
 * Classe Decorator para formatos do tipo Data-Hora, do framework FFPOJO.
 * 
 * <DL><DT><B>Criada em:</B><DD>01/12/2017</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class DateHourDecorator implements FieldDecorator<Date> {    
    public static Logger logger= LoggerFactory.getLogger(DateHourDecorator.class);
    
    private static final DateTimeFormatter fmt= DateTimeFormat.forPattern("yyMMddHHmmss");
    
    /* (non-Javadoc)
     * @see org.ffpojo.metadata.FieldDecorator#fromString(java.lang.String)
     */
    public Date fromString(String str) throws FieldDecoratorException {
        try {        	
            Date d= fmt.parseDateTime(str).toDate();
            return d;
            
        } catch (IllegalArgumentException e) {        	
        	//logger.warn("Erro realizando parser no objeto, em campo data. Valor recebido= '"+str+"'", e);
        	return null;            
        }
    }

    /* (non-Javadoc)
     * @see org.ffpojo.metadata.FieldDecorator#toString(java.lang.Object)
     */
    public String toString(Date date) {
        return fmt.print(new DateTime(date.getTime()));
    }
}