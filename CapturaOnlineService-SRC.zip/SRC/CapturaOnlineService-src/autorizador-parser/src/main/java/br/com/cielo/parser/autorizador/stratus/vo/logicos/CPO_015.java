package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * Objeto referente ao campo CPO_015, sobre Dados do xx.
 * 
 * @author ziliotti
 *
 */
@PositionalRecord
public class CPO_015 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	

	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}
}
