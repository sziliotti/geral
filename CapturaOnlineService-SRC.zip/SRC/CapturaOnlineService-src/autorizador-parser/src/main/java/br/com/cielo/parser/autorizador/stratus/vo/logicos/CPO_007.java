package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

import br.com.cielo.parser.autorizador.stratus.vo.logicos.decorator.DateDecorator;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_007, sobre Dados xxx.
 * 
 * <DL><DT><B>Criada em:</B><DD>16/10/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_007 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	public static Logger logger= LoggerFactory.getLogger(CPO_007.class);
	
	/*private SimpleDateFormat dateFormat= new SimpleDateFormat("yyMMdd");*/
	
	private Date dataPre;
	
	
	public CPO_007(){		
	}
	

	/**
	 * Representa o Campo STRATUS: ACTR-DTA-PRE 
	 * 
	 * @return the dataPre
	 */
	@PositionalField(initialPosition= 1, finalPosition= 6, decorator= DateDecorator.class)
	public Date getDataPre() {
		return dataPre;
	}
	/**
	 * @param dataPre the dataPre to set
	 */
	/*public void setDataPre(String dataPre) {				
		try {
			this.dataPre= dateFormat.parse(dataPre);
		} catch (ParseException e) {
			this.dataPre= null;
			logger.warn("Erro realizando parser no objeto [CPO_007], em campo data[dataPre]. Valor recebido= '"+dataPre+"'");			
		}
	}*/
	/**
	 * @param dataPre the dataPre to set
	 */
	public void setDataPre(Date dataPre) {
		this.dataPre = dataPre;
	}

	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
