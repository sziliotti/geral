package br.com.cielo.parser.autorizador.utils;

public class MessageSourceConstants {
	public static final String TYPE_KEY = "TP_MESSAGE";
	public static final String TYPE_VALUE_MOBILE_PGTO_CELULAR="MB_PGTO_CEL";
	public static final String TYPE_VALUE_MOBILE_DE_PARA="MB_DE_PARA";
	public static final String TYPE_VALUE_MOBILE_P2P="MB_P2P"; 
	public static final String TYPE_VALUE_MOBILE_AUTORECARGA="MB_AUTOR";
	public static final String TYPE_VALUE_STRATUS="STRATUS";
	public static final String TYPE_VALUE_PUSH="PUSH";
	public static final String TYPE_VALUE_ARV="ARV"; 
    public static final String TYPE_VALUE_COBAN="COBAN";
    public static final String TYPE_VALUE_ORIZON="ORIZON";        
	public static final String TYPE_VALUE_LCI_CHK = "LCI_CHK";
	public static final String TYPE_VALUE_LCI_REC = "LCI_REC";
	public static final String TYPE_VALUE_LCI_HEC = "LCI_HEC";
	public static final String TYPE_VALUE_LCI_CAD_POR = "LCI_CAD_POR";
	public static final String TYPE_VALUE_LCI_RES = "LCI_RED";
	public static final String TYPE_VALUE_LCI_CAMP = "LCI_CAMP";
	public static final String SITE_SP="SP";
	public static final String SITE_RJ="RJ";
	public static final Integer SITE_SP_VALUE=1;
	public static final Integer SITE_RJ_VALUE=2;
	public static final String SITE_KEY="SITE";
}
