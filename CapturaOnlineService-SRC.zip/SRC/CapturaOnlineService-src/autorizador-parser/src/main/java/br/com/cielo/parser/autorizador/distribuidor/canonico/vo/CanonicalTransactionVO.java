/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.parser.autorizador.distribuidor.canonico.vo;

import java.io.Serializable;

/**
 * Este VO representa o Objeto canônico transacional.
 * Ele é o supertipo que converge as transações Cielo (SKyline, Stratus, etc.) em um único modelo de dados conceitual
 * @author nemer
 */
public class CanonicalTransactionVO implements Serializable {
    static final long serialVersionUID=128192819281928L;
    
    private String dateHourGmt0;
    private String dateHourPOS;
    private String cardNumber;
    private String nsu;
    private String TID;
    private String saleAmount;;
    private String authorizationCode;
    private String issuerCode;
    private String productCode;
    private String merchantId;
    private String associationId;
    private String terminalId;
    private String nsuAuthorization;
    private String nsuPOSConfirmation;
    private String bin;
    private String merchantOwnerId;
    private String captureSolutionId;
    private String captureSolutionDescription;
    private String smsPhoneNumber;
    
 
    /**
     * SINGLE, RECURRING, INSTALLMENT
     */
    private TransactionType transactionType;
    private int installments;
    // Débito à vista, Crédito à vista, Crédito parcelado, Voucher, etc
    private String salesTypeDescription;
    private TransactionStatus Status;

    /**
     * Retorna o NSU da transação confirmada de aprovação pelo POS. Caso a transação não haja transação para se confirmar, este vem nulo.
     * @return o NSU da transação confirmada de aprovação pelo POS. Caso a transação não haja transação para se confirmar, este vem nulo.
     */
    public String getNsuPOSConfirmation() {
        return nsuPOSConfirmation;
    }
    /**
     * Ajusta o NSU da transação confirmada de aprovação pelo POS. Caso a transação não haja transação para se confirmar, este vem nulo.
     * @param nsuPOSConfirmation o NSU da transação confirmada de aprovação pelo POS. Caso a transação não haja transação para se confirmar, este vem nulo.
     */
    public void setNsuPOSConfirmation(String nsuPOSConfirmation) {
        this.nsuPOSConfirmation = nsuPOSConfirmation;
    }
    
    /**
     * Retorna o nr do NSU referente a autorização a qual essse cancelamento aponta. Só vem preenchido quando o status for de cancelamento.
     * @return o nr do NSU referente a autorização a qual essse cancelamento aponta. Só vem preenchido quando o status for de cancelamento.
     */
    public String getNsuAuthorization() {
        return nsuAuthorization;
    }

    /**
     * Austa o nr do NSU referente a autorização a qual essse cancelamento aponta. Só usar quando a transacao for de cancelamento.
     * @param nsuAuthorization o nr do NSU referente a autorização a qual essse cancelamento aponta.
     */
    public void setNsuAuthorization(String nsuAuthorization) {
        this.nsuAuthorization = nsuAuthorization;
    }

    
    /** 
     * Retorna data/hora POS no formato "ddMMyyyyHHmmss" e TZ local do POS.
     * 
     * @return data/hora POS no formato "ddMMyyyyHHmmss" e TZ local do POS.
     */
    public String getDateHourPOS() {
        return dateHourPOS;
    }

    /**
     * Ajusta data/hora POS no formato "ddMMyyyyHHmmss" e TZ local do POS.
     * @param dateHourPOS data/hora POS no formato "ddMMyyyyHHmmss" e TZ local do POS.
     */
    public void setDateHourPOS(String dateHourPOS) {
        this.dateHourPOS = dateHourPOS;
    }

    /**
     * Data/hora no GMT-0, no formato: "ddMMyyyyHHmmssSSS"
     * @return 
     */
    public String getDateHourGmt0() {
        return dateHourGmt0;
    }

    /**
     * Ajusta DataHora no formato enviado:"ddMMyyyyHHmmssSSS"
     * @param dateHourGmt0 
     */
    public void setDateHourGmt0(String dateHourGmt0) {
        this.dateHourGmt0 = dateHourGmt0;
    }

    /**
     * Retorna numero do cartão.
     * @return numero do cartão.
     */
    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    /**
     * Retorna NSU
     * @return NSU
     */
    public String getNsu() {
        return nsu;
    }

    public void setNsu(String nsu) {
        this.nsu = nsu;
    }

    /**
     * Retorna TID
     * @return TID
     */
    public String getTID() {
        return TID;
    }

    public void setTID(String TID) {
        this.TID = TID;
    }

    /**
     * Retorna o Valor total da venda solicitada pelo POS (este nao é o valor da operacao liquidada) no formado "99999999.99" ao qual os dois ultimos digitos são os centavos 
     * @return 
     */
    public String getSaleAmount() {
        return saleAmount;
    }

    /**
     * Ajusta valor total da compra solicitada pelo POS (este nao é o valor da operacao liquidada) no formato "999999999.99".
     * @param saleAmount valor total da compra
     */
    public void setSaleAmount(String saleAmount) {
        this.saleAmount = saleAmount;
    }

    /**
     * Retorna o codigo de autorizacao
     * @return codigo de autorização
     */
    public String getAuthorizationCode() {
        return authorizationCode;
    }

    public void setAuthorizationCode(String authorizationCode) {
        this.authorizationCode = authorizationCode;
    }

    /**
     * Retorna Código do Emissor
     * @return Emissor
     */
    public String getIssuerCode() {
        return issuerCode;
    }

    /**
     * Ajusta o código do emissor
     * @param issuerCode código do emissor
     */
    public void setIssuerCode(String issuerCode) {
        this.issuerCode = issuerCode;
    }

    /**
     * Retorna o código <b>completo</b> do produto (produto+subproduto)
     * @return código <b>completo</b> do produto (produto+subproduto)
     */
    public String getProductCode() {
        return productCode;
    }
    
    /**
     * Ajusta codigo do produto completo (produto + subproduto)
     * @param productCode 
     */
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    /**
     * Retorna o tipo da venda que pode ser: SINGLE (a vista), RECURRING (recorrente) ou INSTALLMENT (parcelada)
     * @return tipo da venda que pode ser: SINGLE (a vista), RECURRING (recorrente) ou INSTALLMENT (parcelada)
     */
    public TransactionType getTransactionType() {
        return transactionType;
    }

    /**
     * Ajusta o tipo da venda
     * @param transactionType tipo da venda
     */
    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = transactionType;
    }

    /**
     * Retorna a quantidade de parcelas da venda. Caso seja a vista, retorna zero
     * @return 
     */
    public int getInstallments() {
        return installments;
    }
    /**
     * Ajusta quantidade de parcelas da venda
     * @param installments 
     */
    public void setInstallments(int installments) {
        this.installments = installments;
    }

    /**
     * Retorna a descrição do tipo da venda (Crédito a Vista, Crédito Parcelado, Voucher, etc.)
     * @return descrição do tipo da venda (Crédito a Vista, Crédito Parcelado, Voucher, etc.)
     */
    public String getSalesTypeDescription() {
        return salesTypeDescription;
    }

    /**
     * Ajusta a descrição do tipo da venda
     * @param salesTypeDescription descrição do tipo da venda (Crédito a Vista, Crédito Parcelado, Voucher, etc.)
     */
    public void setSalesTypeDescription(String salesTypeDescription) {
        // converte private para debito
        if ("private".equalsIgnoreCase(salesTypeDescription == null ? "" : salesTypeDescription.trim())) {
            this.salesTypeDescription="D\u00E9bito";
        }

        this.salesTypeDescription = salesTypeDescription;
    }

    /**
     * Retorna o status da transação (APPROVED, DENIED, etc..)
     * @return o status da transação (APPROVED, DENIED, etc..)
     */
    public TransactionStatus getStatus() {
        return Status;
    }

    public void setStatus(TransactionStatus Status) {
        this.Status = Status;
    }
    /**
     * Retorna o código do estabelecimento que irá faturar a transação. No caso de Multi-EC ou Recarga,
     * é o EC que recebe pela venda/serviço e não o EC dono do POS (ponto de venda).
     * @return código do estabelecimento que irá faturar a transação
     */
    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }
     /**
     * Retorna o código da bandeira
     * @return código da bandeira
     */

    public String getAssociationId() {
        return associationId;
    }

    public void setAssociationId(String associationId) {
        this.associationId = associationId;
    }
    
    /**
     * Retorna o código do terminal que originou a transação
     * @return código do terminal que originou a transação
     */
    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }
    /**
     * Retorna o código BIN do cartão de crédito
     * @return código BIN do cartão de crédito 
     */
    public String getBin() {
        return bin;
    }

    public void setBin(String bin) {
        this.bin = bin;
    }

    /**
     * Ajusta o código do estabelecimento comercial detentor do POS.
     * @return código do estabelecimento comercial detentor do POS.
     */
    public String getMerchantOwnerId() {
        return merchantOwnerId;
    }

    public void setMerchantOwnerId(String merchantOwnerId) {
        this.merchantOwnerId = merchantOwnerId;
    }

    /**
     * Retorna o ID da solução de captura classificada pela monitoração de negócio.
     * @return ID da colução de captura classificada pela monitoração de negócio.
     */
    public String getCaptureSolutionId() {
        return captureSolutionId;
    }

    public void setCaptureSolutionId(String captureSolutionId) {
        this.captureSolutionId = captureSolutionId;
    }
    /** 
     * Retorna a descrição da solução de captura classificada pela monitoração de negócio.
     * @return ID da solução de captura classificada pela monitoração de negócio.
     */
    public String getCaptureSolutionDescription() {
        return captureSolutionDescription;
    }

    public void setCaptureSolutionDescription(String captureSolutionDescription) {
        this.captureSolutionDescription = captureSolutionDescription;
    }

    /**
     * Retorna Numero do telefone registrado para envio de SMS.
     * @return Numero do telefone registrado para envio de SMS. 
     */
    public String getSmsPhoneNumber() {
        return smsPhoneNumber;
    }

    public void setSmsPhoneNumber(String smsPhoneNumber) {
        this.smsPhoneNumber = smsPhoneNumber;
    }
    
    
    
}
