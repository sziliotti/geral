package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_030, sobre Dados do xx.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_030 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String authSourceCode;
	private String caracterIndicator;
	private String transIdentX;
	private String validationCode;
	private String dtid;
	private String validCVV;
	private String layoutBacen;
	
	public CPO_030(){		
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-AUTH-SOURCE-CODE
	 *
	 * @return the authSourceCode
	 */
	@PositionalField(initialPosition= 1, finalPosition= 1)
	public String getAuthSourceCode() {
		return authSourceCode;
	}

	/**
	 * @param authSourceCode the authSourceCode to set
	 */
	public void setAuthSourceCode(String authSourceCode) {
		this.authSourceCode = authSourceCode;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-CARAC-INDICATOR
	 *
	 * @return the caracterIndicator
	 */
	@PositionalField(initialPosition= 2, finalPosition= 2)
	public String getCaracterIndicator() {
		return caracterIndicator;
	}

	/**
	 * @param caracterIndicator the caracterIndicator to set
	 */
	public void setCaracterIndicator(String caracterIndicator) {
		this.caracterIndicator = caracterIndicator;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-TRANS-IDENT-X
	 *
	 * @return the transIdentX
	 */
	@PositionalField(initialPosition= 3, finalPosition= 17)
	public String getTransIdentX() {
		return transIdentX;
	}

	/**
	 * @param transIdentX the transIdentX to set
	 */
	public void setTransIdentX(String transIdentX) {
		this.transIdentX = transIdentX;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-VALIDATION-CODE
	 *
	 * @return the validationCode
	 */
	@PositionalField(initialPosition= 18, finalPosition= 21)
	public String getValidationCode() {
		return validationCode;
	}

	/**
	 * @param validationCode the validationCode to set
	 */
	public void setValidationCode(String validationCode) {
		this.validationCode = validationCode;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-DTID
	 *
	 * @return the dtid
	 */
	@PositionalField(initialPosition= 22, finalPosition= 22)
	public String getDtid() {
		return dtid;
	}

	/**
	 * @param dtid the dtid to set
	 */
	public void setDtid(String dtid) {
		this.dtid = dtid;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-VALID-CVV
	 *
	 * @return the validCVV
	 */
	@PositionalField(initialPosition= 23, finalPosition= 23)
	public String getValidCVV() {
		return validCVV;
	}

	/**
	 * @param validCVV the validCVV to set
	 */
	public void setValidCVV(String validCVV) {
		this.validCVV = validCVV;
	}

	/** 
	 * Representa o Campo STRATUS: ACTR-LAYOUT-BACEN 
	 *
	 * @return the layoutBacen
	 */
	@PositionalField(initialPosition= 24, finalPosition= 24)
	public String getLayoutBacen() {
		return layoutBacen;
	}

	/**
	 * @param layoutBacen the layoutBacen to set
	 */
	public void setLayoutBacen(String layoutBacen) {
		this.layoutBacen = layoutBacen;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
