package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_906, sobre Dados do BIT47.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_906 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String bit47IndSub;
	private String bit47QuantidadeTransacoes;
	private String bit47NumeroDocumento1;
	private String bit47LinImp1;
	private String bit47NumeroDocumento2;
	private String bit47LinImp2;
	private String bit47NumeroDocumento3;
	private String bit47LinImp3;
	private String bit47NumeroDocumento4;
	private String bit47LinImp4;
	private String bit47NumeroDocumento5;
	private String bit47LinImp5;
	
	public CPO_906(){		
	}

	/**
	 * @return the bit47IndSub
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public String getBit47IndSub() {
		return bit47IndSub;
	}

	/**
	 * @param bit47IndSub the bit47IndSub to set
	 */
	public void setBit47IndSub(String bit47IndSub) {
		this.bit47IndSub = bit47IndSub;
	}

	/**
	 * @return the bit47QuantidadeTransacoes
	 */
	@PositionalField(initialPosition= 3, finalPosition= 4)
	public String getBit47QuantidadeTransacoes() {
		return bit47QuantidadeTransacoes;
	}

	/**
	 * @param bit47QuantidadeTransacoes the bit47QuantidadeTransacoes to set
	 */
	public void setBit47QuantidadeTransacoes(String bit47QuantidadeTransacoes) {
		this.bit47QuantidadeTransacoes = bit47QuantidadeTransacoes;
	}

	/**
	 * @return the bit47NumeroDocumento1
	 */
	@PositionalField(initialPosition= 5, finalPosition= 10)
	public String getBit47NumeroDocumento1() {
		return bit47NumeroDocumento1;
	}

	/**
	 * @param bit47NumeroDocumento1 the bit47NumeroDocumento1 to set
	 */
	public void setBit47NumeroDocumento1(String bit47NumeroDocumento1) {
		this.bit47NumeroDocumento1 = bit47NumeroDocumento1;
	}

	/**
	 * @return the bit47LinImp1
	 */
	@PositionalField(initialPosition= 11, finalPosition= 12)
	public String getBit47LinImp1() {
		return bit47LinImp1;
	}

	/**
	 * @param bit47LinImp1 the bit47LinImp1 to set
	 */
	public void setBit47LinImp1(String bit47LinImp1) {
		this.bit47LinImp1 = bit47LinImp1;
	}

	/**
	 * @return the bit47NumeroDocumento2
	 */
	@PositionalField(initialPosition= 13, finalPosition= 18)
	public String getBit47NumeroDocumento2() {
		return bit47NumeroDocumento2;
	}

	/**
	 * @param bit47NumeroDocumento2 the bit47NumeroDocumento2 to set
	 */
	public void setBit47NumeroDocumento2(String bit47NumeroDocumento2) {
		this.bit47NumeroDocumento2 = bit47NumeroDocumento2;
	}

	/**
	 * @return the bit47LinImp2
	 */
	@PositionalField(initialPosition= 19, finalPosition= 20)
	public String getBit47LinImp2() {
		return bit47LinImp2;
	}

	/**
	 * @param bit47LinImp2 the bit47LinImp2 to set
	 */
	public void setBit47LinImp2(String bit47LinImp2) {
		this.bit47LinImp2 = bit47LinImp2;
	}

	/**
	 * @return the bit47NumeroDocumento3
	 */
	@PositionalField(initialPosition= 21, finalPosition= 26)
	public String getBit47NumeroDocumento3() {
		return bit47NumeroDocumento3;
	}

	/**
	 * @param bit47NumeroDocumento3 the bit47NumeroDocumento3 to set
	 */
	public void setBit47NumeroDocumento3(String bit47NumeroDocumento3) {
		this.bit47NumeroDocumento3 = bit47NumeroDocumento3;
	}

	/**
	 * @return the bit47LinImp3
	 */
	@PositionalField(initialPosition= 27, finalPosition= 28)
	public String getBit47LinImp3() {
		return bit47LinImp3;
	}

	/**
	 * @param bit47LinImp3 the bit47LinImp3 to set
	 */
	public void setBit47LinImp3(String bit47LinImp3) {
		this.bit47LinImp3 = bit47LinImp3;
	}

	/**
	 * @return the bit47NumeroDocumento4
	 */
	@PositionalField(initialPosition= 29, finalPosition= 34)
	public String getBit47NumeroDocumento4() {
		return bit47NumeroDocumento4;
	}

	/**
	 * @param bit47NumeroDocumento4 the bit47NumeroDocumento4 to set
	 */
	public void setBit47NumeroDocumento4(String bit47NumeroDocumento4) {
		this.bit47NumeroDocumento4 = bit47NumeroDocumento4;
	}

	/**
	 * @return the bit47LinImp4
	 */
	@PositionalField(initialPosition= 35, finalPosition= 36)
	public String getBit47LinImp4() {
		return bit47LinImp4;
	}

	/**
	 * @param bit47LinImp4 the bit47LinImp4 to set
	 */
	public void setBit47LinImp4(String bit47LinImp4) {
		this.bit47LinImp4 = bit47LinImp4;
	}

	/**
	 * @return the bit47NumeroDocumento5
	 */
	@PositionalField(initialPosition= 37, finalPosition= 42)
	public String getBit47NumeroDocumento5() {
		return bit47NumeroDocumento5;
	}

	/**
	 * @param bit47NumeroDocumento5 the bit47NumeroDocumento5 to set
	 */
	public void setBit47NumeroDocumento5(String bit47NumeroDocumento5) {
		this.bit47NumeroDocumento5 = bit47NumeroDocumento5;
	}

	/**
	 * @return the bit47LinImp5
	 */
	@PositionalField(initialPosition= 43, finalPosition= 44)
	public String getBit47LinImp5() {
		return bit47LinImp5;
	}

	/**
	 * @param bit47LinImp5 the bit47LinImp5 to set
	 */
	public void setBit47LinImp5(String bit47LinImp5) {
		this.bit47LinImp5 = bit47LinImp5;
	}
	
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
