package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_076, sobre DADOS DE TIPO DE CRIPTOGRAFIA E A CHAVE KSN DO DUKPT.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_076 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String tipoCriptografia;
	private String termKSN;
	
	
	public CPO_076(){		
	}


	/**
	 * @return the tipoCriptografia
	 */
	@PositionalField(initialPosition= 1, finalPosition= 2)
	public String getTipoCriptografia() {
		return tipoCriptografia;
	}


	/**
	 * @param tipoCriptografia the tipoCriptografia to set
	 */
	public void setTipoCriptografia(String tipoCriptografia) {
		this.tipoCriptografia = tipoCriptografia;
	}

	/**
	 * @return the termKSN
	 */
	@PositionalField(initialPosition= 3, finalPosition= 12)
	public String getTermKSN() {
		return termKSN;
	}

	/**
	 * @param termKSN the termKSN to set
	 */
	public void setTermKSN(String termKSN) {
		this.termKSN = termKSN;
	}
	
	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
