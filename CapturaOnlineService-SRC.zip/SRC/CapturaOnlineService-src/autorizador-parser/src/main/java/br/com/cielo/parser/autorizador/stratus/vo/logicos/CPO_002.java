package br.com.cielo.parser.autorizador.stratus.vo.logicos;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;


/**
 * <B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 * 
 * Objeto referente ao campo CPO_002.
 * 
 * <DL><DT><B>Criada em:</B><DD>28/09/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@PositionalRecord
public class CPO_002 extends CampoLogicoVO implements Serializable {	
	private static final long serialVersionUID= 1L;
	
	private String flagFallBack;
	private String flagReferida;
	private String flagOffline;
	private String flagLoteDiferenciado;
	
	public CPO_002(){		
	}
	
	/**	 
	 * Representa o Campo STRATUS:  ACTR-FL-FALL-BACK
	 * 
	 * SPACES  = NAO SE APLICA
	 *                  1  = CARTAO COM CODIGO DE SERVICO COMECANDO POR
	 *                       2 OU 6 OU BRZ NA TRILHA 1(CHIP) SEM ERRO
	 *                       DE LEITURA NO CHIP DA TRANSACAO ANTERIOR.
	 *                      (NAO USADO)
	 *                  2  = CARTAO COM CODIGO DE SERVICOCOMECANDO POR
	 *                       2 OU 6 OU BRZ NA TRILA 1(CHIP) COM ERRO DE
	 *                       LEITURA NO CHIP DA TRANSACAO ANTERIOR.
	 * 
	 * @return the flagFallBack
	 */
	@PositionalField(initialPosition= 1, finalPosition= 1)
	public String getFlagFallBack() {
		return flagFallBack;
	}
	/**
	 * @param flagFallBack the flagFallBack to set
	 */
	public void setFlagFallBack(String flagFallBack) {
		this.flagFallBack = flagFallBack;
	}

	/**
	 * Representa o Campo STRATUS:  ACTR-FL-REFERIDA
	 * 
	 * @return the flagReferida
	 */
	@PositionalField(initialPosition= 2, finalPosition= 2)
	public String getFlagReferida() {
		return flagReferida;
	}
	/**
	 * @param flagReferida the flagReferida to set
	 */
	public void setFlagReferida(String flagReferida) {
		this.flagReferida = flagReferida;
	}

	/**
	 * Representa o Campo STRATUS:  ACTR-FL-OFFLINE
	 * 
	 * @return the flagOffline
	 */
	@PositionalField(initialPosition= 3, finalPosition= 3)
	public String getFlagOffline() {
		return flagOffline;
	}



	/**
	 * @param flagOffline the flagOffline to set
	 */
	public void setFlagOffline(String flagOffline) {
		this.flagOffline = flagOffline;
	}
	
	/**
	 * Representa o Campo STRATUS:  ACTR-FL-LOTE-DIF
	 * 
	 * @return the flagLoteDiferenciado
	 */
	@PositionalField(initialPosition= 4, finalPosition= 4)
	public String getFlagLoteDiferenciado() {
		return flagLoteDiferenciado;
	}
	/**
	 * @param flagLoteDiferenciado the flagLoteDiferenciado to set
	 */
	public void setFlagLoteDiferenciado(String flagLoteDiferenciado) {
		this.flagLoteDiferenciado = flagLoteDiferenciado;
	}


	@Override
	public String toString() { 
	    return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE); 
	}

}
