package br.com.cielo.parser.autorizador.stratus;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

import org.reflections.Reflections;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.ffpojo.FFPojoHelper;
import com.github.ffpojo.exception.FFPojoException;

import br.com.cielo.parser.autorizador.stratus.vo.MensagemFisicaCtvVO;
import br.com.cielo.parser.autorizador.stratus.vo.TransacaoStratusVO;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_013;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CampoLogicoVO;

/**
 * <B>Projeto: Autorizador-Stratus-Parser</B><BR>
 *
 * Classe responsavel em efetuar o parser da transacao recebida do Stratus em bytes[], e retornar o objeto TransacaoStratusVO() populado com os campos
 * logicos encontrados na mensagem.
 * <br><br>
 * A mensagem do Stratus e dividida em 2 partes:<br>
 * 		<DD>1a parte - Um cabecalho no formato CTV (Campo, Tamanho e Valor); contendo toda a estrutura e valores dos campos contidos na mensagem.<br>
 * 		<DD>2a parte - Os campos logicos, que estão especificados e recebidos na 1a parte da mensagem principal(CP-001, CP074, etc). Dentro desses campos 
 * 					lógicos, os mesmos contem outros campos especificos e agrupados, do qual cada um contem o seu layout.
 *
 * <DL><DT><B>Criada em:</B><DD>01/12/2017</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
public class TransacaoStratusParser {

    private static Logger logger= LoggerFactory.getLogger(TransacaoStratusParser.class);

    private static ConcurrentHashMap<String, CampoLogicoVO> camposLogicos= new ConcurrentHashMap<String, CampoLogicoVO>();
    private FFPojoHelper ffpojo;

	// Bloco responsável em carregar todos os campos logicos, via reflection, que constam nesse componente para mapeamento posicional; 
    // armazendo-os em um objeto do tipo ConcurrentHashMap, para melhor performance de acesso.
    static {
        String packageName= "br.com.cielo.parser.autorizador.vo.stratus.logicos";
        
        Reflections reflections= new Reflections(packageName);
        for(Class<? extends CampoLogicoVO> c : reflections.getSubTypesOf(CampoLogicoVO.class)) {
        	 try {
        		 camposLogicos.put(c.getSimpleName(), c.newInstance());
        		 
        	 } catch (Exception e) {
                 continue;
             }	 
        }        
    }

    /**
     * Construtor padrão, do qual cria instância do framework FFPOJO, responsável em popular e efetuar o mapeamento posicional dos valores,
     * contidos nos campos Lógicos.
     */
    public TransacaoStratusParser() {
        try {
            //ffpojo = FFPojoHelper.getInstance();
            Constructor<FFPojoHelper> constructor = FFPojoHelper.class.getDeclaredConstructor();
            constructor.setAccessible(true);
            ffpojo = constructor.newInstance();
        
        } catch (Exception ex) {
            logger.error("Erro ao criar instancia do objeto FFPojo: " + ex.getMessage());
        }
    }


    
    /**
     * Método responsável em retornar a instancia do objeto FFPojoHelper, que faz parte do framework FFPOJO(responsavel por fazer o mapeamento 
     * posicional de cada campo lógico das mensagens vindas do Stratus). 
     * 
     * @return A instancia do objeto FFPojoHelper.
     */
    public FFPojoHelper getFFPojoInstance(){
    	return ffpojo;
    }
    
    /**
     * Método responsável em receber a transação no formato de array de bytes do Stratus e objeto TransacaoStratusVO criado externamente; e converter 
     * esse array no objeto TransacaoStratusVO().
     * 
     * @param msgBytes
     * 			Array de bytes vindo do Stratus. Essa mensagem contem as 2 partes da mensagem (Campos de Cabeçalho e Campos Lógicos).
     * 
     * @param transacaoStratusVO  objeto criado externamente que tera seus valores setados e a referencia original retornada. Utilize esse metodo 
     * 			quando deseja-se utilizar um pool de objetos externo. 			
     * 
     * @return	Objeto TransacaoStratusVO que representa a transação vinda do Stratus, conforme os campos identificados e recebidos pelo metodo.
     * 
     * @throws ParserException
     */
    public TransacaoStratusVO converter(byte[] msgBytes, TransacaoStratusVO transacaoStratusVO) throws ParserException {
        // Efetua parser da mensagem recebida do Stratus em bytes, retornando os campos da mensagem Fisica (Cabeçalho).		
        MensagemFisicaCTVStratusParser ctvParser= new MensagemFisicaCTVStratusParser();
        ArrayList<MensagemFisicaCtvVO> camposMensagemFisica= ctvParser.efetuaParserCabecalhoStratus(msgBytes);

        // Efetua parser completo de todos campos, a partir da lista contida no cabeçalho recuperado anteriormente.
        transacaoStratusVO= this.converter(camposMensagemFisica, transacaoStratusVO);

        return transacaoStratusVO;
    }

    /**
     * Método responsável em receber a transação, no formato de array de bytes do Stratus e converter esse array no objeto TransacaoStratusVO().
     * <br><br>
     * Esse método esta sendo utilizado para efetuar o parser do mensagem total(bytes[]) vinda do Stratus. Essa mensagem contem as 2 partes:
     * 		<DD>- Cabeçalho CTV.
     * 		<DD>- Valores e Layout de cada campo contido na 1a parte.
     * <br><br>
     * O método efetua primeiro o parser do array de bytes da mensagem, convertendo-a e identificando o conjunto de campos lógicos(CPO_001,
     * CPO_040, etc), atraves do método efetuaParserCabecalhoStratus(bytes[]) do objeto MensagemFisicaCTVStratusParser. Após recuperar a lista dos campos
     * lógicos, o mesmo chama o método converter(ArrayList<MensagemFisicaCtvVO> camposMensagemFisica) desta classe, para efetuar o parser apenas dos
     * campos lógicos; retornando o objeto TransacaoStratusVO já preenchido.
     * <br><br>
     *
     * @param msgBytes Array de bytes vindo do Stratus. Essa mensagem contem as 2 partes da mensagem (Campos de Cabeçalho e Campos Lógicos)
     * 
     * @return Objeto TransacaoStratusVO que representa a transação vinda do Stratus, conforme os campos identificados e recebidos pelo metodo.
     * 
     * @throws ParserException
     */
    public TransacaoStratusVO converter(byte[] msgBytes) throws ParserException {
        // Efetua parser da mensagem recebida do Stratus em bytes, retornando os campos da mensagem Fisica (Cabeçalho).		
        MensagemFisicaCTVStratusParser ctvParser= new MensagemFisicaCTVStratusParser();
        ArrayList<MensagemFisicaCtvVO> camposMensagemFisica= ctvParser.efetuaParserCabecalhoStratus(msgBytes);

        // Efetua parser completo de todos campos, a partir da lista contida no cabeçalho recuperado anteriormente.
        TransacaoStratusVO transacaoStratusVO= this.converter(camposMensagemFisica);

        return transacaoStratusVO;
    }

    /**
     * Método responsável em receber a lista dos campos lógicos, representando pelo objeto MensagemFisicaCtvVO, já preenchidos com os valores do
     * CTV(Campo, Tamanho e Valor), e efetuar o parser de cada elemento identificado.
     * <br><br>
     * Com a lista de objetos(MensagemFisicaCtvVO), o método utiliza o framework FFPOJO(responsavel por fazer o mapeamento posicional de cada campo lógico
     * das mensagens vindas do Stratus) para preencher e retornar o objeto TransacaoStratusVO completo.
     * <br><br>
     *
     * @param camposMensagemFisica ArrayList contendo os campos lógicos(objeto MensagemFisicaCtvVO), a serem efetuados o parser.
     * 
     * @param transacaoStratusVO objeto criado externamente que tera seus valores setados e a referencia original retornada. Utilize esse metodo 
     * 			quando deseja-se utilizar um pool de objetos externo.
     * @return Objeto TransacaoStratusVO que representa a transacao vinda do Stratus, conforme os campos identificados e recebidos pelo método.
     * 
     * @throws ParserException
     */
    public TransacaoStratusVO converter(ArrayList<MensagemFisicaCtvVO> camposMensagemFisica, TransacaoStratusVO transacaoStratusVO) {
        for (Iterator<MensagemFisicaCtvVO> iterator= camposMensagemFisica.iterator(); iterator.hasNext();) {
            MensagemFisicaCtvVO mensagemFisicaCtvVO= iterator.next();

            //Recupera o nome e valor do campo
            String nomeCampo= mensagemFisicaCtvVO.getNomeCampo();
            
            //Verifica se o campo possui multiplos mapeamento, e renomeia o mesmo conforme a release existente no campo CPO_013.
            if(mensagemFisicaCtvVO.isPossuiMultiplosMapeamento()){
            	nomeCampo= this.retornaNomeCampoConformeRelease(nomeCampo, transacaoStratusVO);
            }

            CampoLogicoVO campoLogico = null;
            try {
                //Atraves do nome do campo, recupera o objeto relacionado ao campo lógico. Ex: CP_001.
                campoLogico = this.carregarVOLogico(nomeCampo);

                if (campoLogico != null) {
                    //Verifica se é um campo binario.
                    if (mensagemFisicaCtvVO.isCampoBinario()) {
                        campoLogico.setValorCampoBinario(mensagemFisicaCtvVO.getValorCampoBinario());

                        //Efetuar parser com o valor binario, caso a classe tenha um implementador.
                        campoLogico.efetuarParserCampoBinario();
                    } else {
                        String valorCampo = mensagemFisicaCtvVO.getValorCampo();

                        // Popula o valor recuperado através do mapeamento posicional dos campos, contidos nos campos Logicos.  
                        campoLogico= (CampoLogicoVO) ffpojo.createFromText(campoLogico.getClass(), valorCampo);
                    }
                    campoLogico.setNomeCampo(nomeCampo);

                } else {
                    throw new ParserException("Campo nao encontrado= " + nomeCampo);
                }
            } catch (FFPojoException e) {
                //logger.info("Erro ao efetuar Parser de campo Logico: " + e.getMessage());
                continue;

            } catch (ParserException e) {
                //logger.info("Erro ao efetuar Parser de campo Logico: " + e.getMessage());
                continue;
            }
            
            //Adiciona objeto populado, referente ao Campo Lógico, no objeto principal TransacaoStratusVO.		
            transacaoStratusVO.addCampoLogico(nomeCampo, campoLogico);
        }
        return transacaoStratusVO;

    }

    /**
     * Subrecarga de converter(ArrayList<MensagemFisicaCtvVO> camposMensagemFisica, TransacaoStratusVO transacaoStratusVO)
     *
     * @param camposMensagemFisica mensagem fisica
     * @return retorna transacao stratus
     */
    public TransacaoStratusVO converter(ArrayList<MensagemFisicaCtvVO> camposMensagemFisica) {
        return converter(camposMensagemFisica, new TransacaoStratusVO());
    }
    
    /**
     * Método responsavel em retornar o nome do campo logico, conforme o numero do release do POS associado. Esse método é invocado somente se o campo
     * ACTR tiver um mapeamento especifico por release.
     * 
     * @param nomeCampo Nome do Campo ACTR com mais de uma mapeamento. 			
     * @param transacaoStratusVO Classe da onde iremos recuperar o campo CP_013, responsavel em armazenar a informação do numero da release.
     * @return retorna o novo nome do campo ACTR.
     */
    private String retornaNomeCampoConformeRelease(String nomeCampo, TransacaoStratusVO transacaoStratusVO){
    	String retorno= nomeCampo;
    	CPO_013 campo013= (CPO_013) transacaoStratusVO.getCampoLogico("CPO_013");
    	
    	if(campo013 != null){
	    	String numeroRelease="";
	    	if(campo013.getVersaoTerminal() != null){
	    		numeroRelease= campo013.getVersaoTerminal().substring(2, 4);
	    		// Inicialmente apenas a release 6 do POS terá uma mapeamento direferenciado.
	    		if("06".equals(numeroRelease))
	    			retorno+= "_"+numeroRelease;
	    	}
    	}    	
    	return retorno;
    }

    /**
     * Método responsável em retornar uma instancia do objeto CampoLogicoVO, atraves do nome do campo desejado, passado como parametro.
     * <br><br>
     *
     * @param nomeCampo Nome do campo, do qual sera criado a instancia da classe.
     * 
     * @return Uma instancia do objeto desejada, representado pela classe pai(CampoLogicoVO).
     * 
     * @throws ParserException
     */
    private CampoLogicoVO carregarVOLogico(String nomeCampo) throws ParserException {
        return camposLogicos.get(nomeCampo);
    }

}
