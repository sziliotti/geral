package br.com.cielo.parser.autorizador.main;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import br.com.cielo.parser.autorizador.stratus.ParserConverterUtils;
import br.com.cielo.parser.autorizador.stratus.ParserException;


public class CompactarMensagem {
	
	/**
	 * @param args
	 */
	public static void main(String[] args)throws Exception {			
		String msgStratus= "00010052c1c3e3d9d9c5e2f3f2f0f2f9f0f2f0f1f3f0f8f2f3f1f6f3f2f1f7d4f4f1f3f0f8f2f3f1f3f0f8f2f3f1f6f3f2f1f0f1f3f0f8f2f3f1f6f3f2f1f7f0f0f0f0f0f0f0f0f0f1f0f0f0f0f0f0f0f0f1f2f0f0e200060028f1f1f0f0f5f0f1f0f0f2f0f0f0f4f0f1f0f0f0f0f1f0f0f0f0f0f1f1f7c3f0f0f0f0f0c4d2d5f0f100080008f0f04040404040d40009000a404040404040404040d5000a001ef1f6f0f7f1f6f4f9f3f1f0f0f4f9f5f0f5f9f5f9f2f4404040e2f0f040f2000b0027f3f7f4f9f3f1f0f0f4f9f5f0f5f9f5f9f2f4c4f1f6f0f7f2f2f6f4f3f9f0f0f0f0f0f0f0f7f0f1000c0020f0f1f0f0f4f3f8f3f1f0f7f0f0f0f1d9d1f2f6f2f1f0f0f1f1f9f8f6f5f5f4f1000d0038f1f2f3f4f5f6f0f9c3c4f0f4e6c9e6f2f5f4f0e34040404040404040e5e7f1c3d3c1e2c3f1f2f0f3f3e6d3f3f9f0f6f6f2f8f2404040404000100014f0f0f1f3f0f8f2f3f1f6f3f2f1f0f1f3f0f8f2f3001100f8f1f1f0f7f5c3f0f0f8f0f3f2f4f6f2f5f2c3f8c6c4c2f3f8c3f4f0f2c6f1f4f0f8f0f0f4f8f0f0f0f0f2f0f0f0f0c1c1f4f3c1f3f6c6c5f0c6f0c5f8f0f0f7f6f0f0f0f6f0f2f0c1f0f3c1f0f2f0f0f0404040404040404040404040404040404040f0f0f0f0404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040400000120178f0f5f5f0f1f0f0f1f1f3f0f8f2f3f1f6f1f5f5f1f0f0f0f4f0f8f0f0f4f8f0f0f0f6f4c2f1f5c2c3f5f4f0c5f6f4f2f5f8f8c6f8c5f9f5c3c5c3c1f0f0f0f0404040404040404040404040f0f0f0f040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040400000130036404040404040404040404040404040404040404040404040404040404040404040f3f0f1f6f3f5d5d5f0f0f0f0f0f0f0f0f0f0f0f0f00019005ef0f0f0f6f0f2f0c1f0f3f6f0f2f4f0f0404040404040404040404040404040404040f0f0f0f04040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040001b0036f0f0f4f0f2c1d7d9d6e5c1c4c140f9f9f1f6f3f240404040404040404040404040404040404040404040404040f9f9f1f6f3f2e2c9f0001e001840404040404040404040404040404040404040404040404000200010f0f0f2f6f0f2f0f1f7f0f0f7f0f0f0d500210038f0f5f1f04040404040404040d7d6e2e3d640d9e4d9c1d340c4c540e2c5e2c5d9d6d7c5c4c9c3c1404040c2d9f5f7f5f0f0f0f0f1f0f0f0400022000cf5f1f0f1f0f1f5f1f4f1f0f600240016f0f3f0f9f9f9f9f9f0f0f4f0c1f2f0f0f0f1c3c5404000250004f1f0f0400028006340404040404040404040f0f3e2c5d9d6d7c5c4c9c3c140404040404040404040404040404040f1f3f0f8f2f3f1f6f3f2f1f7e2c2c4e2f1e7e7e2e2f0f0f0f0f0f0f0f0f0f0f0f0f1f2f3f7c7f2f3f7404040404040d5c3e2c3d3c140f9c6f3f7f0f4d50044003000003f4912c1593d00003f4912c1741400003f4912c16e8f00003f4912c173db00003f4912c15a0800003f4912c15c5c004a0006f0f0f0f0f0f2004c000cf0f3ffffdc0002e5050001c6004d0064f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f8f2f3f1f6f3f2f1f7f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f040f0f0f040404040404040404040404040404040404040404040404040404040404040f0f0f1f0f0f1f0004f0007303630323041300384001af1f2f3f4f5f6f0f9f1f3f0f8f2f3f5f0f1f0f0f240404040404003860070f0f1c3c4f0f4e6c9e6f2f5f4f0e3f0f2f1f5f1f2f0f3f3e6d3f3f9f0f6f6f2f8f24040404040f0f0f0f04040404040404040404040404040404040404040f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f04040404040404040f0f0f0f0f0f0f0f0f1f4f2f0f0f003870008ddfc568a219559d50388003cf5f0f1f0f0f1d6d2f0f0f0f0f0f0f0f7f0f0f0f2f0f0f0f0f0f04040f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f04040f0f0f0f0f0f0f0f0f0f0f0f0038901aef0f4f0f7f0f0f0f1f0f3f7f0c7c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6f1f7f2f0f3f1f2f5f3f0f0f1f3f0f0f7f0f1d6d240404040404040404040404040404040404040404040404040404040404040404040f0f0404040404040404040404040404040404040404040404040404040404040404040404040f0f04040404040404040404040404040404040404040f0f0f0f0f0f0f0f0f0f0f0f0404040404040404040404040404040404040404040404040404040404040404040f0f0404040404040404040404040404040404040404040404040404040404040404040404040f0f0404040404040404040404040404040404040404040404040404040404040404040404040f0f04040404040404040404040404040404040404040f0f0f0f0f0f0f0f0f0f0f0f0404040404040404040404040404040404040404040404040404040404040404040f0f0404040404040404040404040404040404040404040404040404040404040404040404040f0f0404040404040404040404040404040404040404040404040404040404040404040404040f0f0404040404040404040404040404040404040404000038a002cf0f2f0f1f5f0f1f0f0f1f3f2f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0038d004cf0f5f5f0f1f0f0f1f0f0f1f7f2f0f3f1f2f5f3f0f0f1f3f0f0f7f0f0f0f0d5d6d2f0f4f0f7f0f0f0f1f0f3f0f0f0f0f0f0f0f0f0f0f0f0f0f0f04040f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0";
		
		CompactarMensagem compacMsg= new CompactarMensagem();
		
		//Metodo: Compactação Default
		Date dataInicioDefault= new Date();
		byte[] msgCompact= compacMsg.compactaMensagem(msgStratus);
		Date dataFimDefault= new Date();
		System.out.println("MENSAGEM NORMAL: "+msgStratus);
		System.out.println("TAMANHO MENSAGEM NORMAL: "+ParserConverterUtils.hexToBytes(msgStratus).length +" bytes");
		System.out.println("TAMANHO MENSAGEM ZIP (NORMAL COMPRESS): "+msgCompact.length + " bytes");
		System.out.println("TEMPO EXECUCAO: "+(dataFimDefault.getTime()-dataInicioDefault.getTime()) +" ms");
		System.out.println("==================================================================================================");
		
		byte[] msgDescompact= compacMsg.descompactaMensagem(msgCompact);
		System.out.println("TAMANHO MENSAGEM PASSADA COMO PARAMETRO COMPACTADA: "+msgCompact.length + " bytes");
		System.out.println("TAMANHO MENSAGEM DESCOMPACTADA: "+msgDescompact.length + " bytes");
		System.out.println("MENSAGEM DESCOMPACTADA: "+ParserConverterUtils.bytesToHex(msgDescompact));		
		System.out.println("==================================================================================================");
		
		//Metodo: Melhor Compactação
		Date dataInicioBest= new Date();
		byte[] msgCompactBC= compacMsg.compactaMensagem(ParserConverterUtils.ZIP_LEVEL_BEST_COMPRESSION, msgStratus);
		Date dataFimBest= new Date();
		System.out.println("TAMANHO MENSAGEM NORMAL: "+ParserConverterUtils.hexToBytes(msgStratus).length +" bytes");
		System.out.println("TAMANHO MENSAGEM ZIP (BEST COMPRESSION COMPRESS): "+msgCompactBC.length + " bytes");
		System.out.println("TEMPO EXECUCAO: "+(dataFimBest.getTime()-dataInicioBest.getTime()) +" ms");
		System.out.println("==================================================================================================");
		
		
		//Metodo: Melhor Compactação
		Date dataInicioBestSpeed= new Date();
		byte[] msgCompactBS= compacMsg.compactaMensagem(ParserConverterUtils.ZIP_LEVEL_BEST_SPEED, msgStratus);
		Date dataFimBestSpeed= new Date();
		System.out.println("TAMANHO MENSAGEM NORMAL: "+ParserConverterUtils.hexToBytes(msgStratus).length +" bytes");
		System.out.println("TAMANHO MENSAGEM ZIP (BEST SPEED COMPRESS): "+msgCompactBS.length + " bytes");
		System.out.println("TEMPO EXECUCAO: "+(dataFimBestSpeed.getTime()-dataInicioBestSpeed.getTime()) +" ms");
		System.out.println("==================================================================================================");
		
		
		//Usando ZipEntry.
		compacMsg.zipBytes("", ParserConverterUtils.hexToBytes(msgStratus));
	}
	
	public byte[] compactaMensagem(String msg){		
		byte[] msgBytes= ParserConverterUtils.hexToBytes(msg);
		
		byte[] novaMsg= ParserConverterUtils.zipMessage(msgBytes);
		
		return novaMsg;
	}
	
	public byte[] compactaMensagem(int level, String msg){		
		byte[] msgBytes= ParserConverterUtils.hexToBytes(msg);		
		byte[] novaMsg= ParserConverterUtils.zipMessage(level, msgBytes);		
		return novaMsg;
	}
	
	
	public byte[] descompactaMensagem(byte[] msgBytes){
		byte[] novaMsg= null;
		try {
			novaMsg = ParserConverterUtils.unzipMessage(msgBytes);
			
		} catch (ParserException e) {			
			e.printStackTrace();
		}		
		return novaMsg;
	}

        public byte[] zipBytes(String filename, byte[] input) throws IOException {
		ByteArrayOutputStream baos= new ByteArrayOutputStream();
		ZipOutputStream zos= new ZipOutputStream(baos);
		
		ZipEntry entry= new ZipEntry(filename);
		entry.setSize(input.length);
		
		zos.putNextEntry(entry);
		zos.write(input);
		zos.closeEntry();
		zos.close();
		
		System.out.println("TAMANHO MENSAGEM ZIP (Antes COMPRESS): "+entry.getSize() + " bytes");
		System.out.println("TAMANHO MENSAGEM ZIP (NORMAL COMPRESS) metodo("+entry.getMethod()+"): "+entry.getCompressedSize() + " bytes");
		
		
		//entry.setMethod(7);
		System.out.println("TAMANHO MENSAGEM ZIP (+ COMPRESS) metodo("+entry.getMethod()+"): "+entry.getCompressedSize() + " bytes");
		
		return baos.toByteArray();
	}	
	 
}
