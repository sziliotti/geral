package br.com.cielo.parser.autorizador.main;

import java.io.UnsupportedEncodingException;

import br.com.cielo.parser.autorizador.stratus.ParserConverterUtils;

public class ConverterMensagemStratusMain {

private static final String DEFAULT_EBCDIC_ENCODING = "Cp1047";
	
	/**
	 * @param args
	 */
	public static void main(String[] args)throws Exception {			
		String msgBoa= "00010052c1c3e3d9d9c5e2f6f2f3f6f8f0f0f1f1f3f0f9f2f4f1f5f4f5f2f1d4f4f1f3f0f9f2f4f1f3f0f9f2f4f1f5f4f5f1f7f1f3f0f9f2f4f1f5f4f5f2f1f0f0f0f0f0f0f0f0f1f0f0f0f0f0f0f0f0f0f0f4f2f04000060028f1f4f0f0f4f6f6f7f8f2f0f0f0f1f0f0f0f1f0f0f3f0f0f0f0f0f9f9f9e7f0f0f0f040404040f0f100080008f0f04040404040c30009000a40404040404040404040000a001ef1f5f0f8f1f6f4f5f5f1f8f7f0f0f0f0f0f0f0f1f8f3404040f0f0f04040000c0020f0f1f0f0f6f9f9f3f0f6f9f0f0f0f1e2d7f0f4f5f4f3f0f0f0f9f8f6f5f9f6f7000d0038f1f0f1f5f1f8f0f6c5c3d6f2f0f0f0f0f1f0f240f1f0f1f5f1f8f0f6e5d4f7c5c3d6f3f24040404040404040404040404040404040404040000e0002f0f7000f00044040404000130036404040404040404040404040404040404040404040404040404040404040404040f6f2f0f0f1f2d5d5404040f0f0f0f0f0f0f0f0f0f0001b0036f0f0f2f6f940404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040e2f0f0002000104040f2404040404040404040404040d500210038f0f1f0f0c5c3d6d4d4c5d9c3c540e3c5e2e3c540404040404040404040404040404040404040404040404040f5f0f0f0f0f0f6f0f0f0f7400022000cf0f0f0f1f7f0f6f0f4f1f0f60023009a0000202020202020202020202020202020202020202020202020202020202020202000002020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020204131303037202020202020202020202020202020202020202020202020202020202020202020202020202020202000250004f4f0f0400028006340404040404040404040f0f8e2c1d640d7c1e4d3d64040404040404040404040404040404040404040404040404040404040d5c2c4d5d5d5d5d5d5f0f0f0f0f0f0f0f0f0f0f0f0f1f2f3f7c2f2f3f7f0f0f0404040d54040404040f640404040f0f4d500290012f0f1f0f0f6f9f9f3f0f6f9f0f0f0f1d9f6400041001ef4f6f6f7f8f2f1f3f0f9f2f4f0f0f0f0f0f0f1f0f0f040404040404040400044003000003f7337c1ba2f00003f7337c219540000000000000000000000000000000000000000000000000000000000000000";
		
		
		// Campo Date/Time Jiffy
		byte[] valorCampoBinario= {0,0,63,73,18,-63,89,61,0,0,63,73,18,-63,116,20,0,0,63,73,18,-63,110,-113,0,0,63,73,18,-63,115,-37,0,0,63,73,18,-63,90,8,0,0,63,73,18,-63,92,92};
		System.out.println("TAMANHO: "+ valorCampoBinario.length);
		byte[] bTemp1= ParserConverterUtils.subArray(valorCampoBinario, 0, 8);
		System.out.println("VALOR 1: "+ ParserConverterUtils.parseJiffy(bTemp1));
		
		
		byte[] msg= hexToBytes(msgBoa);
		System.out.println("VALOR EBCDIC:'"+ converterString(msg)+"'");
		System.out.println("Tamanho: "+ converterString(msg).length());
		//System.out.println("Mensagem(HEx to Decimal): "+ Integer.parseInt("000a", 16));		
		System.out.println("==================================================================================================");		
	}
	
	
	public static byte[] hexToBytes(String hex) {  
	   return hexToBytes(hex.toCharArray());  
	}
	  
	public static byte[] hexToBytes(char[] hex) {  
		int length = hex.length / 2;  
	    byte[] raw = new byte[length];  
	    for (int i = 0; i < length; i++) {  
	      int high = Character.digit(hex[i * 2], 16);  
	      int low = Character.digit(hex[i * 2 + 1], 16);  
	      int value = (high << 4) | low;  
	      if (value > 127)  
	        value -= 256;  
	      raw[i] = (byte) value;  
	    }  
	    return raw;  
	  }  
	  
	public static String bytesToHex(byte[] bytes) {
        StringBuilder s= new StringBuilder();
        for (int i = 0; i < bytes.length; i++) {
            int parteAlta = ((bytes[i] >> 4) & 0xf) << 4;
            int parteBaixa = bytes[i] & 0xf;
            if (parteAlta == 0) s.append('0');
            	s.append(Integer.toHexString(parteAlta | parteBaixa));
        }
        return s.toString();
    }
	
	public static int hexToDecimal(String hexValue) {
        String digits = "0123456789ABCDEF";
        hexValue = hexValue.toUpperCase();
        int val = 0;
        
        for (int i = 0; i < hexValue.length(); i++) {
            char c = hexValue.charAt(i);
            int d = digits.indexOf(c);
            val = 16*val + d;
        }        
        return val;
    }
	 
	private static String converterString(byte[] buffer) {		
		return converterString(buffer, true);
	}
	
	private static String converterString(byte[] buffer, boolean ebcdicEncoding) {
		String s= null;
		try {		

			if(ebcdicEncoding)
				s= new String(buffer, DEFAULT_EBCDIC_ENCODING);
			else 
				s= new String(buffer);
						
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return s;
	}
	 	 	
}
