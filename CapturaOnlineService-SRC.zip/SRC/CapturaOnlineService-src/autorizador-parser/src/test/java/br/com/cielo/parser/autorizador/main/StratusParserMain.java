package br.com.cielo.parser.autorizador.main;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import br.com.cielo.parser.autorizador.stratus.MensagemFisicaCTVStratusParser;
import br.com.cielo.parser.autorizador.stratus.ParserConverterUtils;
import br.com.cielo.parser.autorizador.stratus.ParserException;
import br.com.cielo.parser.autorizador.stratus.TransacaoParserBuilder;
import br.com.cielo.parser.autorizador.stratus.TransacaoStratusParser;
import br.com.cielo.parser.autorizador.stratus.vo.TransacaoStratusVO;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_068;

/**
 *<B>Projeto: Monitoracao-Parser -- CEP/BAM</B><BR>
 *
 * Classe Main para teste de Parser das transações vindas do Stratus.
 *	 
 *<DL><DT><B>Criada em:</B><DD>28/08/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class StratusParserMain {

	/**
	 * @param args
	 */
	public static void main(String[] args)throws Exception {	
		StratusParserMain simulador= new StratusParserMain();
		
		String nomeArquivo= "/transacoes_07-10_10-10.txt";
		
		//Transacoes DCC
		//nomeArquivo= "/transacoes-DCC.txt";
		
		int i= 1;
		Scanner scanner= new Scanner(simulador.getClass().getResourceAsStream(nomeArquivo));
		long inicio= System.currentTimeMillis();
		while(scanner.hasNext()) {
			String msgLine= scanner.next();
			
			if(msgLine != null && !msgLine.equals("")){
				//Elimina os 4 primeiros caracters, referentes ao tamanho da mensagem.
				String msgStratus= msgLine.substring(4);	
				System.out.println("============================================================================================================================================");
				System.out.println("[TESTE] MENSAGEM ("+i+"): "+msgStratus);
				simulador.montarTransacaoStratus(msgStratus);								
				System.out.println("============================================================================================================================================");
				
				i++;
			}			
		}
		long termino= System.currentTimeMillis();
		long dif= termino - inicio;
		System.out.println("***************************************************************************");		
		System.out.println("TEMPO PROCESSAMENTO: "+ String.format("%02d segundos e %02d milisegundos.", dif/1000, dif%1000));
		System.out.println("***************************************************************************");
	}
	
	
	/**
	 * @param msg
	 */
	public void montarTransacaoStratus(String msg){
		byte[] msgBytes= ParserConverterUtils.hexToBytes(msg);		
		
		TransacaoStratusParser builder= TransacaoParserBuilder.getTransacaoStratusParser();
		try {
			TransacaoStratusVO transacaoStratus= builder.converter(msgBytes);
						
			System.out.println("Campos encontrados Transacao Stratus: "+ transacaoStratus.getNomesCamposLogico());
			System.out.println("Valores Campos Transacao Stratus: \n"+ transacaoStratus.toString());
						
			CPO_068 cpo068= (CPO_068) transacaoStratus.getCampoLogico("CPO_068");
			if(cpo068 != null){
				System.out.println("--------------------------------------------------------------------------------");
				System.out.println("Dados Campo CPO-068: ");			
				SimpleDateFormat formato= new SimpleDateFormat("dd-MM-yyyy HH:mm:ss,SSS");
				System.out.println("Data AdqEntrada: "+ ((cpo068.getAdqEntrada()!=null)?formato.format(cpo068.getAdqEntrada()):"") + "|" +
									"Data AdqSaida: "+  ((cpo068.getAdqSaida()!=null)?formato.format(cpo068.getAdqSaida()):"") + "|" +
									"Data ResEntrada: "+((cpo068.getResEntrada()!=null)?formato.format(cpo068.getResEntrada()):"") + "|" +
									"Data ResSAida: "+  ((cpo068.getResSaida()!=null)?formato.format(cpo068.getResSaida()):"") + "|" +
									"Data HSMEntrada: "+((cpo068.getHsmEntrada()!=null)?formato.format(cpo068.getHsmEntrada()):"") + "|" +
									"Data HSMSaida: "+  ((cpo068.getHsmSaida()!=null)?formato.format(cpo068.getHsmSaida()):""));
				System.out.println("--------------------------------------------------------------------------------");
			}
		} catch (ParserException e) {			
			e.printStackTrace();
		}
		
		// Monta mensagem XML
		MensagemFisicaCTVStratusParser ctvParser= new MensagemFisicaCTVStratusParser();		
		String xml= ctvParser.montarXML(ctvParser.efetuaParserCabecalhoStratus(msgBytes));
		System.out.println("XML Convertido Campos Fisicos: \n" + xml);
		
		/*FileWriter arquivo;         
        try {  
            arquivo= new FileWriter(new File("C:/PROJETOS/CEP-BAM/StratusADAPTER/Arquivo_2.xml"));  
            arquivo.write(xml);  
            arquivo.close();  
        } catch (IOException e) {  
            e.printStackTrace();  
        } catch (Exception e) {  
            e.printStackTrace();  
        } */
				
	}	
}
