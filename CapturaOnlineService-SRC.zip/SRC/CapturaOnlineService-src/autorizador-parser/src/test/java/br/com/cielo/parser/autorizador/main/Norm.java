/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.parser.autorizador.main;

import java.text.Normalizer;
import java.util.Date;

/**
 *
 * @author nemer
 */
public class Norm {

    public static void main(String args[]) {
        String input = "çaláda";
        input = Normalizer.normalize(input, Normalizer.Form.NFD);
        //input = input.replaceAll("[^\\p{ASCII}]", "");
        System.out.println(input);
        
       	
        Long lastTimeStatMsgsNaoElegiveis= System.currentTimeMillis();
        System.out.println(new Date(lastTimeStatMsgsNaoElegiveis));
        while(true){
		    boolean isToReportStatsMensagensNaoElegiveis= false;
		    long startWatchMsStatsMensagensNaoElegiveis= System.currentTimeMillis();
		    
		    // Verifica disponibilidade para gerar relatorio de Estatisticas de mensagens Não Elegiveis (A cada 60segundos).
		    long valor= startWatchMsStatsMensagensNaoElegiveis - lastTimeStatMsgsNaoElegiveis;
		    if( valor >= 10000 ){
		    	isToReportStatsMensagensNaoElegiveis= true;		    	
		    }
		    
		    
		    if(isToReportStatsMensagensNaoElegiveis){
		    	lastTimeStatMsgsNaoElegiveis= System.currentTimeMillis();
		    	System.out.println("HORA DO RELATORIO !!");
		    	System.out.println(new Date());		    	
		    	return;
		    }
        }

    }
}
