package br.com.cielo.capturaonline.services;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.TextMessage;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

import br.com.cielo.parser.autorizador.canonico.vo.MonitoracaoTransacaoAutorizadorVO;
import br.com.cielo.parser.autorizador.stratus.ParserConverterUtils;
import br.com.cielo.parser.autorizador.stratus.ParserException;
import br.com.cielo.parser.autorizador.stratus.TransacaoMonitoracaoParser;
import br.com.cielo.parser.autorizador.stratus.TransacaoParserBuilder;
import br.com.cielo.parser.autorizador.stratus.TransacaoStratusParser;

/**
 * <B>Projeto: CapturaOnlineService</B><BR><BR>
 *
 * xxxxxxxxxxxxxxxxx.
 *
 * <DL><DT><B>Criada em:</B><DD>29/11/2017</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@Component
public class StratusMessageReceiver {	
	static final Logger LOGGER= LoggerFactory.getLogger(StratusMessageReceiver.class);
	
	@Autowired
	DistribuidorMessageSender distribuidorMessageSender;

    /**
     *
     * @param message
     */    
    @JmsListener(destination = "${spring.activemq.queue.name}", containerFactory = "myFactory")
    public void receiveMessage(final Message<?> message) throws JMSException {
    	byte[] payload= null;
    	
    	LOGGER.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
        MessageHeaders headers=  message.getHeaders();
        LOGGER.info("Application : headers received : {}", headers);
        
        String uuidMessage= headers.get("jms_messageId", String.class);
        LOGGER.info("uuidMessage<{}>", uuidMessage);
        
        Object payloadObj= message.getPayload();
        LOGGER.info("Application : Message received : {}", payloadObj);  
        LOGGER.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
        
        //Test - Envia mensagem para Topic de teste Kafka(first_topic_szs)
        LOGGER.info("Enviando Mensagem({}) de uuid:<{}>",  payloadObj, uuidMessage);  
        distribuidorMessageSender.sendMessage(payloadObj.toString());
   
		try {
			//Obtem Payload da mensagem, em bytes[], recuperada da fila do A-MQ.
			payload= this.obterPayload(message);
			 
			//Descompactando a mensagem recebida.
			byte[] xPayloadDescompress= ParserConverterUtils.unzipMessage(payload);
			
			//Aplicando Parser mensagem Stratus.
			MonitoracaoTransacaoAutorizadorVO monTran= this.parserTransacaoStratus(xPayloadDescompress);
			
		
			//TODO Aplica regra de verificação dos tipos de mensagens a serem enviados para o distribuidor. Aplicando as mesmas regras de elegibilidade existente na monitoração de Negocios.    
			
			//TODO Evetua transformação do objeto transação Stratus para JSON do Modelo Canonico do Distribuidor.
			
			//TODO Grava mensagem no repositorio Cassandra
			
			//TODO Aplica regras da transação de captura. Aplicando as mesmas regras de Captura Batch.
			
	        //TODO Envia mensagem JSON para Topic do Kafka do Distribuidor.
	        
		
		
		} catch (ParserException e) {			
			LOGGER.error("Erro realizando parser da mensagem JMS. Erro [" + ExceptionUtils.getStackTrace(e) + "]. "
                    + "Mensagem compactada[" + ParserConverterUtils.bytesToHex(payload) + "]. A mensagem[uuid=" + uuidMessage + "] será descartada.", e);

		} catch (Exception e) {			
			LOGGER.error("Erro realizando leitura da mensagem JMS. A mensagem[uuid=" + uuidMessage + "] será descartada.", e);
		}	
    } 
    
    
    /**
     * Retorna o payload da mensagem como um array de bytes.
     * <br>
     * Suporta mensagem texto, onde o payload deve ser hexadecimal e payload em bytes.
     *
     * @param message Mensagem JMS que pode ser
     * <code>javax.jms.TextMessage</code> ou <code>javax.jms.BytesMessage</code>
     *
     * @return Payload da mensagem como um array de bytes.
     */
    private byte[] obterPayload(Message<?> message) throws JMSException {
        if (message instanceof TextMessage) {
            throw new IllegalArgumentException("Mensagem recebida estah no formato texto. Era esperado no formato binario.");
            
        } else if (message instanceof BytesMessage) {
            BytesMessage bytesMessage= (BytesMessage) message;

            int tamanhoCorpo= (int) bytesMessage.getBodyLength();
            byte[] buffer = new byte[tamanhoCorpo];

            int bytesLidos= bytesMessage.readBytes(buffer);
            if (bytesLidos != tamanhoCorpo) {
                String msgErro= "Leu uma quantidade diferente de bytes [" + bytesLidos + "] do que o esperado [" + tamanhoCorpo + "]";
                LOGGER.error(msgErro);
                
                throw new IllegalArgumentException(msgErro);
            }
            return buffer;

        } else {
            LOGGER.error("Mensagem recebida nao e TextMessage nem BytesMessage, Ignorando. Classe: " + message.getClass() + ". Mensagem: " + message);
            throw new IllegalArgumentException("Mensagem de tipo invalido: " + message);
        }
    }
    
    
    /**
     * Método responsavel em efetuar o parser do array de bytes recebido(representando a transacao do Stratus), no objeto representando a transação MonitoracaoTransacaoAutorizadorVO.
     *
     * @param payload Array de bytes contendo a transacao vinda do Stratus.
     * @return Objeto representando a transação
     * MonitoracaoTransacaoAutorizadorVO.
     */
    private MonitoracaoTransacaoAutorizadorVO parserTransacaoStratus(byte[] payload) throws Exception {
        MonitoracaoTransacaoAutorizadorVO transacaoMonitoracao= null;

        TransacaoStratusParser stratusParser= TransacaoParserBuilder.getTransacaoStratusParser();
        TransacaoMonitoracaoParser monitoracaoParser= TransacaoParserBuilder.getTransacaoMonitoracaoParser();
        
        transacaoMonitoracao= monitoracaoParser.converter(stratusParser.converter(payload));

        return transacaoMonitoracao;
    }

}
