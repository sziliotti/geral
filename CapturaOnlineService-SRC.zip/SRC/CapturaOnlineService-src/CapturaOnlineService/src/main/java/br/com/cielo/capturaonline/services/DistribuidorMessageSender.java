package br.com.cielo.capturaonline.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

/**
 * <B>Projeto: CapturaOnlineService</B><BR><BR>
 *
 * xxxxxxxxxxxxxxxxx.
 *
 * <DL><DT><B>Criada em:</B><DD>04/12/2017</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@Service
public class DistribuidorMessageSender {
	static final Logger LOGGER= LoggerFactory.getLogger(StratusMessageReceiver.class);
	
	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	
	@Value("${distribuidor.kafka.topic}")
	String topicName= "";
	
	
	/**
	 *
	 * @param payload
	 */
	public void sendMessage(String payload) {
		LOGGER.info("Sending payload='{}' to topic='{}'", payload, topicName);	    
	    kafkaTemplate.send(topicName, payload);
	}

}
