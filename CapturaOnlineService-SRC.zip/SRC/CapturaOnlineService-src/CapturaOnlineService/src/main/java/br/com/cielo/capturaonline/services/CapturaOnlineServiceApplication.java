package br.com.cielo.capturaonline.services;

import javax.jms.ConnectionFactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;


/**
 * <B>Projeto: CapturaOnlineService</B><BR><BR>
 *
 * xxxxxxxxxxxxxxxxx.
 *
 * <DL><DT><B>Criada em:</B><DD>29/11/2017</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 *
 */
@SpringBootApplication
@EnableJms
public class CapturaOnlineServiceApplication {
	
	
	/**
	 *
	 * @param connectionFactory
	 * @param configurer
	 * @return
	 */
	@Bean
    public JmsListenerContainerFactory<?> myFactory(ConnectionFactory connectionFactory,
                                                    DefaultJmsListenerContainerFactoryConfigurer configurer) {
        
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        // This provides all boot's default to this factory, including the message converter
        configurer.configure(factory, connectionFactory);
        // You could still override some of Boot's default if necessary.
        
        return factory;
    }

	/**
	 *
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext ctx =  SpringApplication.run(CapturaOnlineServiceApplication.class, args);
	}
	
	/**
	 *
	 * @return
	 */
	/*@Bean
    public Queue queue() {
        return new ActiveMQQueue("br.com.cielo.captura-online.stratus.queue.in");
    }*/
}
