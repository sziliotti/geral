package br.com.cielo.monitoracao.cep.robot;

import java.util.Hashtable;
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import javax.naming.Context;

public class WeblogicUtils {
	
	private JMXConnector getMBeanServerConnector(String jndiName, String host, String port, String user, String passwd) throws Exception {
        Hashtable<String,String> h = new Hashtable<String,String>();
        JMXServiceURL serviceURL = new JMXServiceURL("t3", host, new Integer(port), jndiName);
        h.put(Context.SECURITY_PRINCIPAL, user);
        h.put(Context.SECURITY_CREDENTIALS, passwd);
        h.put(JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES, "weblogic.management.remote");
        JMXConnector connector = JMXConnectorFactory.connect(serviceURL, h);
        return connector;
    }

/*
    private void purge2(String host, String port, String user, String passwd, String JMSServer, String jmsDestination) {
    	try {
            JMXConnector connector = 
              getMBeanServerConnector("/jndi/"+RuntimeServiceMBean.MBEANSERVER_JNDI_NAME, host, port, user, passwd);
            MBeanServerConnection mbeanServerConnection = 
              connector.getMBeanServerConnection();

            ObjectName service = new ObjectName("com.bea:Name=RuntimeService,Type=weblogic.management.mbeanservers.runtime.RuntimeServiceMBean");
            ObjectName serverRuntime = (ObjectName) mbeanServerConnection.getAttribute(service, "ServerRuntime");
            ObjectName jmsRuntime = (ObjectName) mbeanServerConnection.getAttribute(serverRuntime, "JMSRuntime");
            ObjectName[] jmsServers = (ObjectName[]) mbeanServerConnection.getAttribute(jmsRuntime, "JMSServers");
            for (ObjectName jmsServer: jmsServers) {
                if (JMSServer.equals(jmsServer.getKeyProperty("Name"))) {
                    ObjectName[] destinations = (ObjectName[]) mbeanServerConnection.getAttribute(jmsServer, "Destinations");
                    for (ObjectName destination: destinations) {
                        if (destination.getKeyProperty("Name").endsWith("!"+jmsDestination)) {
                            Object o = mbeanServerConnection.invoke(
                                destination,
                                "deleteMessages",
                                new Object[] {""},        // selector expression
                                new String[] {"java.lang.String"});
                            System.out.println("Result: "+o);
                            break;
                        }
                    }
                    break;
                }
            }
            connector.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
*/

        public static void main (String[] args) throws Exception {
		String host = args[0];
		String port = args[1];
		String user = args[2];
		String passwd = args[3];
		String jmsServer = args[4];
		String jmsDestination = args[5];
		WeblogicUtils util = new WeblogicUtils();
		//util.zeraFila(providerURL1, queueName1);
//		util.purge2(host, port, user, passwd, jmsServer, jmsDestination);
		
	}
}
