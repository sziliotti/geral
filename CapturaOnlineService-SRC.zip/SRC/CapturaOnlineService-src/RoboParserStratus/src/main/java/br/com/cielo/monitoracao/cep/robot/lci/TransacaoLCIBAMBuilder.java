package br.com.cielo.monitoracao.cep.robot.lci;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import br.com.cielo.monitoracao.cep.robot.Transacao;
import br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico;
import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;

public class TransacaoLCIBAMBuilder extends TransacaoBuilderGenerico {
	
	
	public TransacaoLCIBAMBuilder(Transacao template, VariaveisGeracao ... variaveis){
	}
	
	public TransacaoGenerica gerarNovaTransacao(Date dataHoraTran){
		TransacaoGenerica t = new TransacaoLCIBAM();
		return t;
	}
		
	public Collection<byte[]> generateMessages(int qtdade) throws Exception {

		List<byte[]> list = new ArrayList<byte[]>();
		
		Date now = new Date();
		for (int i = 0; i < qtdade; i++) {
			list.add(gerarNovaTransacao(now)
					.getTripa().getBytes());
		}
		return list;
	}
	

}
