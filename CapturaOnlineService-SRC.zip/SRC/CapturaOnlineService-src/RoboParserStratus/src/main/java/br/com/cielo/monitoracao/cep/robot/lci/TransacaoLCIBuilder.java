package br.com.cielo.monitoracao.cep.robot.lci;

import java.util.Calendar;
import java.util.Date;

import br.com.cielo.monitoracao.cep.robot.lci.TransacaoLCI.CodigoSite;
import br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico;
import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;

public class TransacaoLCIBuilder extends TransacaoBuilderGenerico {
	
	
	private boolean multiLayouts=false;
	private TransacaoLCI templateLayout;

	public TransacaoLCIBuilder(TransacaoLCI template, VariaveisGeracao ... variaveis){
		templateLayout = template;
		for (int i = 0; i < variaveis.length; i++) {
			switch (variaveis[i]){
			case MULTI_LAYOUTS:
				multiLayouts=true;
				break;
			}	
		}
	}
	
	public TransacaoGenerica gerarNovaTransacao(Date dataHoraTran){
		// escolher a transacao a gerar.
		int layout = multiLayouts ? getAleatorioGenerico(1, 7) : new Integer(templateLayout.getIdTipTransacao());
		TransacaoLCI t = null;
		switch (layout) {
			case 1: t = new TransacaoCheckin(); break;
			case 2: t = new TransacaoRecomendacao(); break;
			case 3: t = new TransacaoHabilitacaoEC(); break;
			case 4: t = new TransacaoCadPortador(); break;
			case 5: t = new TransacaoResgate(); break;
			case 6: t = new TransacaoCampanha(); break;
			case 7: t = new TransacaoCadPortadorInvalida(); break;
		}
		
		if (dataHoraTran == null) {
			dataHoraTran = new Date();
		}
		
		t.setHrInicioFluxo(dataHoraTran);
		setHrFinalFluxo(t,dataHoraTran);
		setStatusFinal(t);
		setSite(t);
		return t;
	}

	private void setStatusFinal(TransacaoLCI t) {
		String[] statuses = t.getStatusFinais();
		
		int x = getAleatorioGenerico(0, 10);
		if (x < 8) {
			t.setStFinalTran(statuses[0]);
		} else {
			t.setStFinalTran(statuses[getAleatorioGenerico(1,
					statuses.length - 1)]);
		}
	}
	
	private void setSite(TransacaoLCI t) {
		t.setCdSite(getAleatorioGenerico(0, 1)==0?CodigoSite.SP:CodigoSite.RJ);
	}

	private void setHrFinalFluxo(TransacaoLCI t, Date dataHoraTran) {
		Calendar c = Calendar.getInstance();
		c.setTime(dataHoraTran);
		c.add(Calendar.MINUTE, getAleatorioGenerico(1, 3));
		c.add(Calendar.SECOND, getAleatorioGenerico(1, 59));
		c.add(Calendar.MILLISECOND, getAleatorioGenerico(0, 1000));
		t.setHrFimFluxo(c.getTime());
	}
		
	private String getSpaces(int i) {
		String spaces = "";
		for (int j = 0; j < i; j++) {
		   spaces += " ";	
		}
		return spaces;
	}

}
