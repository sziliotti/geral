package br.com.cielo.cep.stratus.eventos.ext;

import br.com.cielo.parser.autorizador.canonico.vo.StatusDCC;

@SuppressWarnings("serial")
public class MonitoracaoTransacaoCEP extends
		br.com.cielo.monitoracao.cep.eventos.ext.MonitoracaoTransacaoCEP {

	public static String TIPO_TRANSACAO_DCC_CONSULTA = "C";
	public static String TIPO_TRANSACAO_DCC_FINANCEIRO = "F";
	
	public Integer codDCC;
	public Integer indDcc;
	public long qtdElegivelDCC;
	public long qtdNaoElegivelDCC;
	public long qtdNegadaPlanet;
	public long qtdTimeoutPlanet;
	public long tempoRespostaPlanet;
	
	public void setCodDCC(Integer codDCC) {
		this.codDCC = codDCC;
	}

	public void setQtdElegivelDCC(long qtdElegivelDCC) {
		this.qtdElegivelDCC = qtdElegivelDCC;
	}

	public void setQtdNaoElegivelDCC(long qtdNaoElegivelDCC) {
		this.qtdNaoElegivelDCC = qtdNaoElegivelDCC;
	}

	public void setQtdNegadaPlanet(long qtdNegadaPlanet) {
		this.qtdNegadaPlanet = qtdNegadaPlanet;
	}

	public void setQtdTimeoutPlanet(long qtdTimeoutPlanet) {
		this.qtdTimeoutPlanet = qtdTimeoutPlanet;
	}

	public void setTempoRespostaPlanet(long tempoRespostaPlanet) {
		this.tempoRespostaPlanet = tempoRespostaPlanet;
	}

	public void setIndDcc(Integer indDcc) {
		this.indDcc = indDcc;
	}

	public Integer getIndDcc(){
		return (isDCC()?1:0);
	}
	
	/**
	 * Define o c�digo do DCC baseado no tipo de transa��o no DCC que veio do Stratus.
	 * 
	 * @return
	 */
	public Integer getCodDCC(){
		
		if(!isDCC()) return -1;
		if(getInformacoesDCC()==null) return 1;
		
		if( isTipoTransacaoDccFinanceiroNaoElegivel() ){
			return 4;
		}else if ( isTipoTransacaoDccFinanceiro() ) {
			return 3;
		}else if ( isTipoTransacaoDccConsulta() ) {
			return 2;
		}
				
		return 1;
	}
	
	/**
	 * Retorna se o tipo de transa��o feita pelo DCC � de CONSULTA
	 * @return
	 */
	private boolean isTipoTransacaoDccConsulta(){
		if(getInformacoesDCC()==null) return false;
		return TIPO_TRANSACAO_DCC_CONSULTA.equals(getInformacoesDCC().getTipoTransacao());
	}

	/**
	 * Retorna se o tipo de transa��o feita pelo DCC � FINANCEIRA e o status � NAO_ELEGIVEL
	 * @return
	 */
	private boolean isTipoTransacaoDccFinanceiroNaoElegivel(){
		return (isTipoTransacaoDccFinanceiro() && isStatusDccNaoElegivel());
	}
	
	/**
	 * Retorna se o tipo de transa��o feita pelo DCC � FINANCEIRA
	 * @return
	 */
	private boolean isTipoTransacaoDccFinanceiro(){
		if(getInformacoesDCC()==null) return false;
		return TIPO_TRANSACAO_DCC_FINANCEIRO.equals(getInformacoesDCC().getTipoTransacao());
	}
	
	private boolean isStatusDccElegivel() { return (getInformacoesDCC()!=null&&StatusDCC.ELEGIVEL.equals(getInformacoesDCC().getStatusDCC())); }
	private boolean isStatusDccNaoElegivel() { return (getInformacoesDCC()!=null&&StatusDCC.NAO_ELEGIVEL.equals(getInformacoesDCC().getStatusDCC())); }
	private boolean isStatusDccNegadoPelaPlanet() { return (getInformacoesDCC()!=null&&StatusDCC.NEGADO_PELA_PLANET.equals(getInformacoesDCC().getStatusDCC())); }
	private boolean isStatusDccTimeoutPlanet() { return (getInformacoesDCC()!=null&&StatusDCC.TIMEOUT_PLANET.equals(getInformacoesDCC().getStatusDCC())); }
	
	public long getQtdElegivelDCC(){ return (isTipoTransacaoDccConsulta()&&isStatusDccElegivel())?1L:0L; }
	public long getQtdNaoElegivelDCC(){ return (isStatusDccNaoElegivel())?1L:0L; }
	public long getQtdNegadaPlanet(){ return (isTipoTransacaoDccConsulta()&&isStatusDccNegadoPelaPlanet())?1L:0L; }
	public long getQtdTimeoutPlanet(){ return (isTipoTransacaoDccConsulta()&&isStatusDccTimeoutPlanet())?1L:0L; }
	
	@Override
	public Long getAprovado() { return !isTipoTransacaoDccConsulta()?super.getAprovado():0L; }
	@Override
	public Long getNegado() { return !isTipoTransacaoDccConsulta()?super.getNegado():0L; }
	@Override
	public Long getCancelado() { return !isTipoTransacaoDccConsulta()?super.getCancelado():0L;	}
	@Override
	public Long getDesfazimento() {	return !isTipoTransacaoDccConsulta()?super.getDesfazimento():0L; }

}
