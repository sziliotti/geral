package br.com.cielo.monitoracao.cep.robot;

import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;

public abstract class ProducerGenerico {
	private InitialContext ctx;

	protected Connection cachedConnection = null;
	protected Session cachedSession = null;
	protected MessageProducer cachedProducer;
	protected String queueJndiName;
	protected String urlQueueServer;
	protected String topicJndiName;
	protected String urlTopicServer;
	
	protected String socketAddress;
	protected boolean enviarMsgCompactada = false;
	
	public ProducerGenerico(String socketAddress, boolean enviarMsgCompactada){
		this.socketAddress = socketAddress;
		this.enviarMsgCompactada = enviarMsgCompactada;
	}

	public ProducerGenerico(String queueJndiName, String urlQueueServer,String topicJndiName, String urlTopicServer ) {
		if (queueJndiName == null && topicJndiName == null) {
			throw new IllegalStateException("opcao --queueJndiName ou --topicJndiName eh obrigatorio para mensagens");
		}
		if (queueJndiName != null && topicJndiName != null) {
			throw new IllegalStateException("opcao --queueJndiName e --topicJndiName sao mutualmente exclusivos");
		}
		this.queueJndiName = queueJndiName;
		this.urlQueueServer = urlQueueServer;
		this.topicJndiName = topicJndiName;
		this.urlTopicServer = urlTopicServer;

	}
	
	public abstract void sendMessage(byte[] bytes) throws Exception;

	protected String getUrlQueueServer() {
		if (urlQueueServer == null && urlTopicServer == null) {
			throw new IllegalStateException("opcao --urlQueueServer ou --urlTopicServer eh obrigatorio para mensagens");
		}
		return urlQueueServer == null ? urlTopicServer : urlQueueServer;
	}
	
	protected String getQueueJndiName(){
		return queueJndiName;
	}
	
	protected final void setQueueJndiName(String queueJndiName) {
		this.queueJndiName = queueJndiName;
	}
	
	protected String getUrlTopicServer() {
		return urlTopicServer == null ? "nio://localhost:61616?jms.useAsyncSend=true&jms.optimizeAcknowledge=true" : urlTopicServer;
	}
	
	protected String getTopicJndiName(){
		return topicJndiName;
	}
	
	protected final void setTopicJndiName(String topicJndiName) {
		this.topicJndiName = topicJndiName;
	}
	
	protected Connection getConnection() throws Exception {
		
		String vContext = "org.apache.activemq.jndi.ActiveMQInitialContextFactory";
		String vLookup = "ConnectionFactory";
		
		if (cachedConnection == null) {
			Properties props = new Properties();

			if (RoboCieloCEP.jmsType != null ) {
				if(RoboCieloCEP.jmsType.equals("WLS")){
					vContext = "weblogic.jndi.WLInitialContextFactory";
					vLookup = "jms.AMQMonitoracaoConnectionFactory";
				}
			} 
			
			props.setProperty(Context.INITIAL_CONTEXT_FACTORY, vContext);
					//"org.apache.activemq.jndi.ActiveMQInitialContextFactory");
			props.setProperty(Context.PROVIDER_URL, getUrlQueueServer()==null ? getUrlTopicServer() : getUrlQueueServer() );
			ctx = new InitialContext(props);

			ConnectionFactory connectionFactory = (ConnectionFactory) ctx.lookup(vLookup);
					//.lookup("jms.AMQMonitoracaoConnectionFactory");

			if (RoboCieloCEP.jmsUser != null && RoboCieloCEP.jmsPassword != null) {
				cachedConnection = connectionFactory.createConnection(
						RoboCieloCEP.jmsUser, RoboCieloCEP.jmsPassword);
			} else {
				cachedConnection = connectionFactory.createConnection();
			}					
			
			//cachedConnection = connectionFactory.createConnection();
			cachedConnection.start();
		}

		return cachedConnection;
	}
	
	protected Session getSession() throws Exception {
		
		if (cachedSession == null) {
			cachedSession = getConnection().createSession(false,
					Session.AUTO_ACKNOWLEDGE);
		}

		return cachedSession;
	}
	
	protected MessageProducer getProducer() throws Exception {
/*		if (cachedProducer == null) {
			Destination destination;
			if(getQueueJndiName()!=null){
				destination = getSession().createQueue(
					getQueueJndiName());
			}else{
				destination = getSession().createTopic(
						getTopicJndiName());
			}

			cachedProducer = cachedSession.createProducer(destination);
		}
*/
		Destination destination ; //= (Destination) ctx.lookup(getQueueJndiName());
		
		if (cachedProducer == null) {
			// Novo WLS
			if (RoboCieloCEP.jmsType != null ) {
				
				if(RoboCieloCEP.jmsType.equals("WLS")){
					if(getQueueJndiName()!=null){
						destination = (Destination) ctx.lookup(getQueueJndiName());
					}else{
						destination = (Destination) ctx.lookup(getTopicJndiName());
					}
					
				} else {
					
					if(getQueueJndiName()!=null){
						destination = getSession().createQueue(
							getQueueJndiName());
					}else{
						destination = getSession().createTopic(
								getTopicJndiName());
					}
				}

			} else {
				if(getQueueJndiName()!=null){
					destination = getSession().createQueue(
						getQueueJndiName());
				}else{
					destination = getSession().createTopic(
							getTopicJndiName());
				}
			}

			cachedProducer = cachedSession.createProducer(destination);
		}
		return cachedProducer;
	}

}
