package br.com.cielo.monitoracao.cep.robot;

public class ImprimeTransacao {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Transacao t = new Transacao();
		System.out.println(t.getTripa());
	}

}
