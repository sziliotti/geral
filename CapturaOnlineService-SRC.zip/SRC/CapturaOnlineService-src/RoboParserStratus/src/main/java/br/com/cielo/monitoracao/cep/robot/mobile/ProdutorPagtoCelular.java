package br.com.cielo.monitoracao.cep.robot.mobile;

import java.util.Properties;

import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import br.com.cielo.monitoracao.cep.robot.ProducerGenerico;

public class ProdutorPagtoCelular extends ProducerGenerico{
	public ProdutorPagtoCelular(String queueJndiName, String urlQueueServer,String topicJndiName, String urlTopicServer) {
		super(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		if (queueJndiName == null &&  topicJndiName == null) {
			setQueueJndiName("MonitoracaoIntegracaoPagamentoCelularPOS.hom");
		}
	}

	static long messageOrderId = System.currentTimeMillis();

	@Override
	public void sendMessage(byte[] bytes) throws Exception {
		TextMessage bm = getSession().createTextMessage();
		bm.setText(new String(bytes));
		bm.setLongProperty("MESSAGE_ORDER_ID", messageOrderId++);
		//bm.setText("12/06/2013 10:34:31.00012/06/2013 10:35:10.261PagamentoCelularPOS                               2000000101100992223241000000000010948914000APROVADA 948914                                                                                     Bradesco                                          EM0301Aprovada            ");
		getProducer().send(bm);
		Thread.sleep(1);
	}
}
