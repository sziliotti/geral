package br.com.cielo.monitoracao.cep.robot.coban;

import javax.jms.TextMessage;

import br.com.cielo.monitoracao.cep.robot.ProducerGenerico;

public class ProdutorCoban extends ProducerGenerico{
	public ProdutorCoban(String queueJndiName, String urlQueueServer,String topicJndiName, String urlTopicServer) {
		super(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		if (queueJndiName == null &&  topicJndiName == null) {
			setQueueJndiName("br.com.cielo.monitoracao.coban.topic.in");
		}
	}
	
	static long messageOrderId = System.currentTimeMillis();

	@Override
	public void sendMessage(byte[] bytes) throws Exception {
		TextMessage bm = getSession().createTextMessage();
		bm.setText(new String(bytes));
		bm.setLongProperty("MESSAGE_ORDER_ID", messageOrderId++);
		//bm.setText("12/06/2013 10:34:31.00012/06/2013 10:35:10.261PagamentoCelularPOS                               2000000101100992223241000000000010948914000APROVADA 948914                                                                                     Bradesco                                          EM0301Aprovada            ");
		getProducer().send(bm);
		Thread.sleep(1);
	}	
}

