package br.com.cielo.monitoracao.cep.robot.lci;

import java.text.SimpleDateFormat;
import java.util.Date;

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;


public class TransacaoResgate extends TransacaoLCI{
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmss");
	SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss:SSS");
	SimpleDateFormat sdf3 = new SimpleDateFormat("HH:mm:ss:SSS");
	
	String evento="012345678901234567890123456789";
	String idFacebook="idfacebook-idfacebook-idfacebo";
	String tokenFace= "tokenfacebook-tokenfacebook-to";
	String fluxoEC="0";
	String tmpFluxoEC="00:00:02:000";
	String fluxoCmpRes="0";
	String tmpFluxoCmpRes="00:00:02:000";
		
	static final String[] cdEstabs = new String[] { "1234567890123456", "2222222222222222", "3333333333333333","4444444444444444", "5555555555555555"};

	static final String[] statusFinais = new String[] {"00","01", "02", "03"};
		
	public String getTripa(){
		String tripa = getIdTipTransacao()+
				getCdSite()+
				evento+
				idFacebook+
				tokenFace+
				getFiller()+
				getHrInicioFluxo()+
				fluxoEC+
				tmpFluxoEC+
				fluxoCmpRes+
				tmpFluxoCmpRes+
				getStFinalTran()+
				getHrFimFluxo()+
				getTmpTotalTra();
		
		if (tripa.length() != 281) throw new IllegalArgumentException("tamanho da tripa ["+tripa+"] inválido. Esperado 281, e obtido:"+tripa.length());
		
		return tripa;
	}

	@Override
	public String getIdTipTransacao() {
		return "005";
		
	}

	@Override
	public String[] getStatusFinais() {
		return statusFinais;
	}
}
