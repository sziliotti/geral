package br.com.cielo.monitoracao.cep.robot.cepsim;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;

import br.com.cielo.monitoracao.cep.robot.Transacao;

public class TransacaoTPSBAM extends Transacao{
	protected transient static final SimpleDateFormat sdfData = new SimpleDateFormat("MM/dd/yyyy");
	protected transient static final SimpleDateFormat sdfHrMin = new SimpleDateFormat("HH");

	public String getTripa(){
		
		int qtdTrans = getAleatorioGenerico(1, 10) < 4 ? 3 : (getAleatorioGenerico(1, 10));
		int qtdTps = qtdTrans > 1 ? getAleatorioGenerico(1, qtdTrans) : qtdTrans;
		int residuo = qtdTrans - qtdTps;
		int qtdCred = residuo > 1 ? getAleatorioGenerico(1, residuo) : residuo;
		residuo -= qtdCred;
		int qtdPriv = residuo > 1 ? getAleatorioGenerico(1, residuo) : residuo;
		residuo -= qtdPriv;
		int qtdDeb = residuo;
		
		if (qtdDeb + qtdPriv + qtdCred + qtdTps != qtdTrans)
			throw new IllegalStateException ("Soma diferente...");
		
		return "<Transacao>" + "<Mainframe>" 
	    + nvlTag("ChaveMaquina", this.chaveDaMaquina)
		+ nvlTag("DataAut", sdfData.format(new Date()))
		+ nvlTag("QtdAutorizacao", qtdTrans)
		+ nvlTag("QtdTps", qtdTps)
		+ nvlTag("QtdCredito", qtdCred)
		+ nvlTag("QtdPrivate", qtdPriv)
		+ nvlTag("QtdDebito", qtdDeb)
		+ nvlTag("Hora", String.format("%02d", getAleatorioGenerico(0, 24)))
	    + "</Mainframe>" + "</Transacao>";
	}

	private String nvlTag(String tag, Object valor) {
		return valor == null ? "" : "<" + tag + ">" + valor + "</" + tag + ">";
	}
	protected int getAleatorioGenerico(int min, int max) {
		//int r = min + ((int) (Math.random() * 1000000) % (max - min + 1));
		SecureRandom a = new SecureRandom();
		return a.nextInt(max + 1 - min) + min;
		//return r;
	}

}