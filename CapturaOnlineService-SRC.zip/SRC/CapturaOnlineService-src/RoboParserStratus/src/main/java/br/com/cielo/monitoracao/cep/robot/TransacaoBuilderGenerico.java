package br.com.cielo.monitoracao.cep.robot;


/*
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.BANCO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.BANDEIRA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.BIN;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CHAVE_MAQUINA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CIDADE;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CIERS_ENT;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CODIGO_ERRO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CODIGO_ESTABELECIMENTO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CODIGO_NO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CODIGO_OPERADORA_GPRS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CODIGO_PROCESSAMENTO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CODIGO_SERVICO_POS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.COD_SOL_CAPTURA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_ENTRADA_STRATUS_SAIDA_POS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_MIN_STR;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_RETORNO_AO_POS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_RETORNO_BANDEIRA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_RETORNO_HSM;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_SAIDA_STRATUS_ENTRADA_BANDEIRA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_SAIDA_STRATUS_ENTRADA_HSM;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_STRATUS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.HORA_INPUT;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.HORA_OUTPUT;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.ID_MENSAGEM;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.ID_STATUS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.INDICADOR_SKYLINE;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.MCC;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.MENSAGEM;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.MODO_CONEXAO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.OBS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.PRODUTO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.QUEM_RESPONDEU;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.RESOLUTOR;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.SOURCE_CODE;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.SUBPRODUTO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.SWITCH_VISA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.TERMINAL;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.TIPO_TECNOLOGIA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.TIP_TRA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.TPS_DATA_HORA_TRANS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.UF;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.VALOR_VENDA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.VERSAO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.VERSAO_ECOMMERCE;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.LYNX;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.STANDIN;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.TIPO_TRANSACAO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.COD_RESPOSTA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.MAQUINA_GATEWAY;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.TIPO_TRANSACAO_DCC;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.STATUS_DCC;
*/


import java.io.BufferedReader;
//import java.io.ByteArrayOutputStream;
//import java.io.ObjectOutput;
//import java.io.ObjectOutputStream;
//import java.io.Reader;
//import java.io.StringReader;
import java.security.SecureRandom;
//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

//import br.com.cielo.monitoracao.autorizador.parser.vo.bam.StatusTransacao;
//import br.com.cielo.monitoracao.cep.eventos.ext.MonitoracaoTransacaoCEP;

public abstract class TransacaoBuilderGenerico {
	protected enum VariaveisGeracao {
		BANDEIRA_ALEATORIA,EMISSOR_ALEATORIO, STATUS_ALEATORIO, PRODUTO_E_SUBPRODUTO_ALEATORIO,
		AJUSTAR_DATAHORA_TRAN, VAL_VENDA_ALEATORIO, MAQUINA_ALEATORIO, INDIC_SKYLINE_ALEATORIO, OPERADORA_ALEATORIO, 
		SITE_ALEATORIO, SIGLA_SOL_CAPT_ALEATORIO, MULTI_LAYOUTS, STANDIN, LYNX, TIMEOUTLYNX,
		TIPO_TRANSACAO_ALEATORIO, COD_RESPOSTA_ALEATORIO, MAQUINA_GATEWAY_ALEATORIO,
		RETORNO_CHAMADA_ALEATORIO, PRODUTO_ALEATORIO, COD_PROCESSAMENTO_ALEATORIO, TIPO_PGTO_ALEATORIO, 
		TIPO_CARTAO_ALEATORIO, COD_OBS_ALEATORIO, TIPO_TRANSACAO_DCC, STATUS_DCC}
	
	
	public abstract TransacaoGenerica gerarNovaTransacao(Date dataHoraTran);
	
	public Collection<byte[]> generateMessages(int qtdade) throws Exception {
		List<byte[]> list = new ArrayList<byte[]>();

		if (RoboCieloCEP.getFileSamples() == null) {

			Date now = new Date();
			for (int i = 0; i < qtdade; i++) {
				TransacaoGenerica t = gerarNovaTransacao(now);
				list.add(t.getTripa().getBytes());
			}

		} else {

			// Ler mensagens prontas de arquivo texto tambem e acrescenta a
			// lista de mensagens geradas aleatoriamente.
			if (RoboCieloCEP.getFileSamples() != null) {
				BufferedReader reader = RoboCieloCEP.getFileSamples();
				String line = null;
				while ((line = reader.readLine()) != null) {
					list.add(line.getBytes());
				}
			}
		}
		return list;
	}
	
	protected int getAleatorioGenerico_2(int min, int max) {
		int x = getAleatorioGenerico();
		x ^= (x << 21);
		x ^= (x >>> 35);
		x ^= (x << 4);
		
		int r = min + (x % (max - min + 1));
		return r;
	}
	protected int getAleatorioGenerico_1(int min, int max) {
		int r = min + ((int) (Math.random() * 1000000) % (max - min + 1));
		return r;
	}

	protected static int getAleatorioGenerico(int min, int max) {
		//int r = min + ((int) (Math.random() * 1000000) % (max - min + 1));
		SecureRandom a = new SecureRandom();
		return a.nextInt(max + 1 - min) + min;
		//return r;
	}
	protected int getAleatorioGenerico() {
		//int r = min + ((int) (Math.random() * 1000000) % (max - min + 1));
		SecureRandom a = new SecureRandom();
		return a.nextInt();
		//return r;
	}
	protected String getCharsToFill(int i, String s) {
		String spaces = "";
		for (int j = 0; j < i; j++) {
		   spaces += s;	
		}
		return spaces;
	}
	
}
