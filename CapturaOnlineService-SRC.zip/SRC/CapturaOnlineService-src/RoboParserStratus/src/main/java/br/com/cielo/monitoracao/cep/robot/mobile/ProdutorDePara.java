package br.com.cielo.monitoracao.cep.robot.mobile;

import javax.jms.TextMessage;
import br.com.cielo.monitoracao.cep.robot.ProducerGenerico;

public class ProdutorDePara extends ProducerGenerico{
	public ProdutorDePara(String queueJndiName, String urlQueueServer,String topicJndiName, String urlTopicServer) {
		super(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		if (queueJndiName == null &&  topicJndiName == null) {
			setQueueJndiName("com.cielo.monitoracao.mobile_depara.queue.1.in");
		}
		
	}

	static long messageOrderId = System.currentTimeMillis();

	@Override
	public void sendMessage(byte[] bytes) throws Exception {
		TextMessage bm = getSession().createTextMessage();
		bm.setText(new String(bytes));
		bm.setLongProperty("MESSAGE_ORDER_ID", messageOrderId++);
		getProducer().send(bm);
		Thread.sleep(1);
	}

}
