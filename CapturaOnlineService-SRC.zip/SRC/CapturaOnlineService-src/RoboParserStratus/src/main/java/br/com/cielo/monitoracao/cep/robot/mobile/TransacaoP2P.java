package br.com.cielo.monitoracao.cep.robot.mobile;

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;


public class TransacaoP2P implements TransacaoGenerica{
	String dtInicio="01/01/2013 10:00:00.000";
	String dtFinal="01/01/2013 10:00:00.000";
	String uuid="111111122222233333444455556666777788";
	String nmOperadoraOrigem="CLARO               ";
	String nuCelularOrigem="001196061302";
	String nmOperadoraDestino="VIVO                ";
	String nuCelularDestino="001297214788";
	String vlTransacao="000000125000";
	String tpTransacao="P2P                                               ";
	String nmHost="HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH"; 
	String instanciaJava="JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ";
	String cdErro="                                                                                                    ";
	String mensagemErro="EEEEEEEEEE";
	{
		for (int i = 0; i<99; i++) {
			mensagemErro += "EEEEEEEEEE";
		}
	}

    public static final String[] operadoras = new String[]{"CLARO               ", "VIVO                "
    	                                                   , "TIM                 ", "OI                  "}; 
    
	public String getTripa(){
		return dtInicio+
		dtFinal+
		uuid+
		nmOperadoraOrigem+
		nuCelularOrigem+
		nmOperadoraDestino+
		nuCelularDestino+
		vlTransacao+
		tpTransacao+
		nmHost+
		instanciaJava+
		(!(cdErro == null || "".equals(cdErro.trim())) ? cdErro+
				mensagemErro : "");

	}


	@Override
	public String toString() {
		return "TransacaoP2P [dtInicio=" + dtInicio + ", dtFinal=" + dtFinal
				+ ", uuid=" + uuid + ", nmOperadoraOrigem=" + nmOperadoraOrigem
				+ ", nuCelularOrigem=" + nuCelularOrigem
				+ ", nmOperadoraDestino=" + nmOperadoraDestino
				+ ", nuCelularDestino=" + nuCelularDestino + ", tpTransacao="
				+ tpTransacao + ", nmHost=" + nmHost + ", instanciaJava="
				+ instanciaJava + ", cdErro=" + cdErro + ", mensagemErro="
				+ mensagemErro + "]";
	}


}
