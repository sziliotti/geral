package br.com.cielo.monitoracao.cep.robot.cepsim;


import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import br.com.cielo.monitoracao.cep.robot.Transacao;
import br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico;

import com.ibm.as400.access.AS400PackedDecimal;

public class TransacaoTPSBAMBuilder extends TransacaoBuilderGenerico {
	

	boolean maquinaAleatorio = false;

	private boolean isMaquinaAleatorio() {
		return maquinaAleatorio;
	}
	

	public TransacaoTPSBAMBuilder(Transacao template, VariaveisGeracao ... variaveis){
		for (int i = 0; i < variaveis.length; i++) {
			switch (variaveis[i]){
		
			case MAQUINA_ALEATORIO:
				maquinaAleatorio = true;
				break;
		
			}

		}
	}
	
	public Transacao gerarNovaTransacao(Date dataHoraTran){
		Transacao t = new TransacaoTPSBAM();
		if (dataHoraTran == null) {
			dataHoraTran = new Date();
		}
	
		if (isMaquinaAleatorio()) {
			setMaquina(t);
		}
	
		return t;
	}
	
	
	private  void setDataHoraTran(Transacao t) {
		// pegar de 1 -> 63
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
		t.dtaTran = sdf.format(now);
		t.tpsData = t.dtaTran;
		sdf = new SimpleDateFormat("HHmmss");
		t.horaTran = sdf.format(now);
		t.tpsHora = t.horaTran;
		
		// ajusta timestamp transacao entrada e saida
		long time = +now.getTime();
		t.hrTranInp = ""+time;
		t.hrTranInp = getCharsToFill(15 - t.hrTranInp.length(), "0") + t.hrTranInp;
		// incrementa entre 50 e 500 ms ao tempo de processamento da transacao
		time += getAleatorioGenerico(50,500);
		t.hrTranOut = ""+time;
		t.hrTranOut = getCharsToFill(15 - t.hrTranOut.length(), "0") + t.hrTranOut;

	}
	
	

	private  void setMaquina(Transacao t) {
		t.chaveDaMaquina = Transacao.maquinas[getAleatorioGenerico(0, Transacao.maquinas.length - 1)];
	}
	
	
	public Collection<byte[]> generateMessages(int qtdade) throws Exception {

		List<byte[]> list = new ArrayList<byte[]>();
		
		Date now = new Date();
		for (int i = 0; i < qtdade; i++) {
			list.add(gerarNovaTransacao(now)
					.getTripa().getBytes());
		}
		return list;
	}
	

}
