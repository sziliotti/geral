package br.com.cielo.monitoracao.cep.robot.stratus.cep;

import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.BANCO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.BANDEIRA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.BIN;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CEP;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CHAVE_MAQUINA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CIDADE;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CODIGO_ERRO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CODIGO_ESTABELECIMENTO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CODIGO_NO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CODIGO_OPERADORA_GPRS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CODIGO_PROCESSAMENTO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.CODIGO_SERVICO_POS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_ENTRADA_STRATUS_SAIDA_POS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_MIN_STR;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_RETORNO_AO_POS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_RETORNO_BANDEIRA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_RETORNO_HSM;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_SAIDA_STRATUS_ENTRADA_BANDEIRA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_SAIDA_STRATUS_ENTRADA_HSM;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.DATA_HORA_STRATUS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.HORA_INPUT;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.HORA_OUTPUT;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.ID_MENSAGEM;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.ID_STATUS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.INDICADOR_SKYLINE;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.MCC;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.MENSAGEM;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.MODO_CONEXAO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.OBS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.PRODUTO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.QUEM_RESPONDEU;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.RESOLUTOR;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.SOURCE_CODE;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.SUBPRODUTO;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.SWITCH_VISA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.TERMINAL;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.TIPO_TECNOLOGIA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.TIP_TRA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.TPS_DATA_HORA_TRANS;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.UF;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.VALOR_VENDA;
import static br.com.cielo.monitoracao.cep.robot.stratus.cep.LayoutTransacaoCep.VERSAO_ECOMMERCE;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;

//import br.com.cielo.monitoracao.cep.eventos.ext.MonitoracaoTransacaoCEP; // alterado por causa do DCC.
import br.com.cielo.cep.stratus.eventos.ext.MonitoracaoTransacaoCEP;
import br.com.cielo.monitoracao.cep.robot.RoboCieloCEP;
import br.com.cielo.monitoracao.cep.robot.Transacao;
import br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico;
import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;
import br.com.cielo.monitoracao.cep.robot.stratus.TransacaoStratus;
import br.com.cielo.parser.autorizador.canonico.vo.StatusTransacao;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_001;

public class TransacaoCepStratusBuilder extends TransacaoBuilderGenerico {
	boolean bandeiraAleatoria= false;
	boolean emissorAleatorio= false;
	boolean statusAleatorio= false;
	boolean produtoESubProdutoAleatorio= false;
	boolean ajustarDataHoraTran= false;		
	boolean valVendaAleatorio= false;
	boolean maquinaAleatorio= false;
	boolean indicSkylineAleatorio= false;	
	boolean siglaSolCapturaAleatorio= false;
	
	/**
	 * Construtor responsavel em definir os campos que serao gerados aleatoriamente.
	 * 
	 * @param template
	 * 
	 * @param variaveis
	 *			Classe contendo as informacoes dos atributos que serao gerados aleatoriamente.	  
	 */
	public TransacaoCepStratusBuilder(Transacao template, VariaveisGeracao... variaveis){
		for(int i = 0; i < variaveis.length; i++) {
			switch(variaveis[i]){
				case BANDEIRA_ALEATORIA:
					bandeiraAleatoria= true;
					break;
				case EMISSOR_ALEATORIO:
					emissorAleatorio= true;
					break;
				case STATUS_ALEATORIO:
					statusAleatorio= true;
					break;
				case PRODUTO_E_SUBPRODUTO_ALEATORIO:
					produtoESubProdutoAleatorio= true;
					break;
				case AJUSTAR_DATAHORA_TRAN:
					ajustarDataHoraTran= true;
					break;
				case VAL_VENDA_ALEATORIO:
					valVendaAleatorio= true;
					break;
				case MAQUINA_ALEATORIO:
					maquinaAleatorio= true;
					break;
				case INDIC_SKYLINE_ALEATORIO:
					indicSkylineAleatorio= true;
					break;				
				case SIGLA_SOL_CAPT_ALEATORIO:
					siglaSolCapturaAleatorio= true;
					break;	
				
			}
		}
	}
	
	/* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico#gerarNovaTransacao(java.util.Date)
	 */
	public TransacaoGenerica gerarNovaTransacao(Date dataHoraTran){
		TransacaoStratus trans= new TransacaoStratus();
		
		if (isAjustarDataHoraTran()){
			if (dataHoraTran == null) {
				setDataHoraTran(trans);		
			} else {
				setDataHoraTran(trans, dataHoraTran);
			}
		}
		return trans;
	}
		

	private void setBin(TransacaoStratus trans) {
		String numCar = trans.cpo010.getNumeroCartao();
		String bin = ""+getAleatorioGenerico(1, 999999);
		String zeros = "000000";
		numCar = zeros.substring(0,bin.length())+bin+numCar.substring(6);
		trans.cpo010.setNumeroCartao(numCar);
	}

	/* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico#generateMessages(int)
	 */
	public Collection<byte[]> generateMessages(int qtdade) throws Exception {
		List<byte[]> list = new ArrayList<byte[]>();
		int l = 0;
		// Ler mensagens prontas de arquivo texto tambem e acrescenta a lista de mensagens geradas aleatoriamente.
		if(RoboCieloCEP.getFileSamples() != null){
			BufferedReader reader= RoboCieloCEP.getFileSamples();
			SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM d H:mm:ss z yyyy",Locale.US);
			String line= null;		
			while((line=reader.readLine()) != null){
				if (++l > qtdade) break;
				MonitoracaoTransacaoCEP t = new MonitoracaoTransacaoCEP();
				String[] cols = line.split(";");
				DateFormat df = new SimpleDateFormat();
				t.setChaveMaquina(nvlString(CHAVE_MAQUINA,cols));
				t.setBin(nvlString(BIN,cols));
				t.setCodigoProcessamento(nvlString(CODIGO_PROCESSAMENTO,cols));
				t.setHoraInput(nvlDate(HORA_INPUT,sdf,cols));
				t.setIdStatus(StatusTransacao.valueOf(nvlString(ID_STATUS,cols)));
				t.setHoraOutput(nvlDate(HORA_OUTPUT,sdf,cols));
				t.setResolutor(nvlString(RESOLUTOR,cols));
				t.setSourceCode(nvlString(SOURCE_CODE,cols));
				t.setMensagem(nvlString(MENSAGEM,cols));
				t.setTerminal(nvlString(TERMINAL,cols));
				t.setIdMensagem(nvlString(ID_MENSAGEM,cols));
				t.setValorVenda(nvlDouble(VALOR_VENDA,cols));
				t.setTipoTecnologia(nvlString(TIPO_TECNOLOGIA,cols));
				t.setCodigoEstabelecimento(nvlString(CODIGO_ESTABELECIMENTO,cols));
				t.setCodigoNo(nvlString(CODIGO_NO,cols));
				t.setMcc(nvlString(MCC,cols));
				t.setUf(nvlString(UF,cols));
				t.setCidade(nvlString(CIDADE,cols));
				t.setObs(nvlString(OBS,cols));
				//t.setVersao(nvlString(VERSAO,cols));
				t.setTpsDataHoraTrans(nvlDate(TPS_DATA_HORA_TRANS, sdf, cols));
				t.setBandeira(nvlString(BANDEIRA, cols));
				t.setBanco(nvlString(BANCO,cols));
				t.setProduto(nvlString(PRODUTO,cols));
				t.setSubProduto(nvlString(SUBPRODUTO,cols));
				t.setTipTra(nvlString(TIP_TRA,cols));
				//t.setCiersEnt(nvlString(CIERS_ENT,cols));
				t.setSwitchVisa("true".equals(cols[SWITCH_VISA.value()]) ? true : false);
				t.setDataHoraMinutoStr(nvlString(DATA_HORA_MIN_STR,cols));
				t.setIndicadorSkyLine("true".equals(cols[INDICADOR_SKYLINE.value()]) ? true : false);
			//	t.setCodSolCaptura(nvlInt(COD_SOL_CAPTURA, cols)); // Comentado por Priscila em 29/07/2014
				t.setModoConexao(nvlString(MODO_CONEXAO,cols));
				t.setCodigoErro(nvlString(CODIGO_ERRO,cols));
				t.setQuemRespondeu(nvlString(QUEM_RESPONDEU, cols));
				t.setDataHoraStratus(nvlDate(DATA_HORA_STRATUS, sdf, cols));
				t.setDataHoraEntradaStratusSaidaPOS(nvlDate(DATA_HORA_ENTRADA_STRATUS_SAIDA_POS, sdf, cols));
				t.setDataHoraRetornoAoPOS(nvlDate(DATA_HORA_RETORNO_AO_POS,sdf,cols));
				t.setDataHoraSaidaStratusEntradaBandeira(nvlDate(DATA_HORA_SAIDA_STRATUS_ENTRADA_BANDEIRA, sdf, cols));
				t.setDataHoraRetornoBandeira(nvlDate(DATA_HORA_RETORNO_BANDEIRA,sdf,cols));
				t.setDataHoraSaidaStratusEntradaHSM(nvlDate(DATA_HORA_SAIDA_STRATUS_ENTRADA_HSM,sdf,cols));
				t.setDataHoraRetornoHSM(nvlDate(DATA_HORA_RETORNO_HSM,sdf,cols));
				t.setCodigoOperadoraGPRS(nvlString(CODIGO_OPERADORA_GPRS, cols));
				t.setCodigoServicoPOS(nvlString(CODIGO_SERVICO_POS,cols));
				t.setVersaoEcommerce(nvlString(VERSAO_ECOMMERCE,cols));
				t.setCep(nvlString(CEP,cols));
				
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				ObjectOutput out = null;
				try {
				  out = new ObjectOutputStream(bos);   
				  out.writeObject(t);
				  byte[] bytes = bos.toByteArray();
				  list.add(bytes);
				} finally {
				    if (out != null) {
				      out.close();
				    }
				    bos.close();
				}
				
			}
		}
		return list;
	}
	
	private String nvlString(LayoutTransacaoCep col, String[] cols) {
		if ("null".equals(cols[col.value()])) {
			return null;
		}
		return cols[col.value()];
	}
	
	private Date nvlDate(LayoutTransacaoCep col, DateFormat df, String[] cols) throws ParseException {
		if ("null".equals(cols[col.value()])) {
			return null;
		}
		return df.parse(cols[col.value()]);
	}
	private Double nvlDouble(LayoutTransacaoCep col, String[] cols) throws ParseException {
		if ("null".equals(cols[col.value()])) {
			return null;
		}
		return new Double(cols[col.value()]);
	}
	private Long nvlLong(LayoutTransacaoCep col, String[] cols) throws ParseException {
		if ("null".equals(cols[col.value()])) {
			return null;
		}
		return new Long(cols[col.value()]);
	}
	private Integer nvlInt(LayoutTransacaoCep col, String[] cols) throws ParseException {
		if ("null".equals(cols[col.value()])) {
			return null;
		}
		return new Integer(cols[col.value()]);
	}
		
	private boolean isAjustarDataHoraTran() {
		return ajustarDataHoraTran;
	}
	
	/**
	 * Metodo responsavel em definir um valor aleatoprio para data da transacao. 
	 * 
	 * @param trans
	 * 			Transacao Stratus.
	 */
	private  void setDataHoraTran(TransacaoStratus t) {
		Date now= new Date();
		setDataHoraTran(t, now);
	}	
	
	private  void setDataHoraTran(TransacaoStratus t, Date d) {		
		CPO_001 cpo1= t.cpo001;
		cpo1.setDataHoraInput(d);
				
		// Incrementa entre 50 e 500 ms ao tempo de processamento da transacao
		//time+= getAleatorioGenerico(50, 500);		
		cpo1.setDataHoraHost(d);
	}	
	

}
