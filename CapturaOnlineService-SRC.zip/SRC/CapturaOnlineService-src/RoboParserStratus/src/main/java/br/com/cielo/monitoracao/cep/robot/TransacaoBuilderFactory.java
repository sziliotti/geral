package br.com.cielo.monitoracao.cep.robot;

import br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico.VariaveisGeracao;
import br.com.cielo.monitoracao.cep.robot.arv.TransacaoArvBuilder;
import br.com.cielo.monitoracao.cep.robot.cepsim.TransacaoBAMBuilder;
import br.com.cielo.monitoracao.cep.robot.cepsim.TransacaoTPSBAMBuilder;
import br.com.cielo.monitoracao.cep.robot.lci.TransacaoCadPortador;
import br.com.cielo.monitoracao.cep.robot.lci.TransacaoCadPortadorInvalida;
import br.com.cielo.monitoracao.cep.robot.lci.TransacaoCampanha;
import br.com.cielo.monitoracao.cep.robot.lci.TransacaoCheckin;
import br.com.cielo.monitoracao.cep.robot.lci.TransacaoHabilitacaoEC;
import br.com.cielo.monitoracao.cep.robot.lci.TransacaoLCIBAMBuilder;
import br.com.cielo.monitoracao.cep.robot.lci.TransacaoLCIBuilder;
import br.com.cielo.monitoracao.cep.robot.lci.TransacaoRecomendacao;
import br.com.cielo.monitoracao.cep.robot.lci.TransacaoResgate;
import br.com.cielo.monitoracao.cep.robot.mobile.TransacaoAutorrecargaBuilder;
import br.com.cielo.monitoracao.cep.robot.mobile.TransacaoDeParaBuilder;
import br.com.cielo.monitoracao.cep.robot.mobile.TransacaoP2PBuilder;
import br.com.cielo.monitoracao.cep.robot.mobile.TransacaoPgtoCelularBuilder;
import br.com.cielo.monitoracao.cep.robot.push.TransacaoPushBuilder;
import br.com.cielo.monitoracao.cep.robot.orizon.TransacaoOrizonBuilder;
import br.com.cielo.monitoracao.cep.robot.coban.TransacaoCobanBuilder;
import br.com.cielo.monitoracao.cep.robot.stratus.TransacaoStratusBuilder;
import br.com.cielo.monitoracao.cep.robot.stratus.cep.TransacaoCepStratusBuilder;
import br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico.VariaveisGeracao;


public class TransacaoBuilderFactory {
	
	public static TransacaoBuilderGenerico getBuilder(String type) {
		
		if (type.equals("linkci-bam")) {
			return new TransacaoLCIBAMBuilder(null,
					VariaveisGeracao.MULTI_LAYOUTS);
		} else if (type.equals("linkci-checkin")) {
			return new TransacaoLCIBuilder(new TransacaoCheckin());
		} else if (type.equals("linkci-rec")) {
			return new TransacaoLCIBuilder(new TransacaoRecomendacao());
		} else if (type.equals("linkci-hec")) {
			return new TransacaoLCIBuilder(new TransacaoHabilitacaoEC());
		} else if (type.equals("linkci-cadpor")) {
			return new TransacaoLCIBuilder(new TransacaoCadPortador());
		} else if (type.equals("linkci-cadpor-invalida")) {
			return new TransacaoLCIBuilder(new TransacaoCadPortadorInvalida());
		} else if (type.equals("linkci-res")) {
			return new TransacaoLCIBuilder(new TransacaoResgate());
		} else if (type.equals("linkci-camp")) {
			return new TransacaoLCIBuilder(new TransacaoCampanha());
		}

		if (type.equals("mainframe-bam")|| type.equals("mainframe-bam-hist")) {
			return new TransacaoBAMBuilder(null,
					VariaveisGeracao.BANDEIRA_ALEATORIA, 
					VariaveisGeracao.EMISSOR_ALEATORIO, 
					VariaveisGeracao.STATUS_ALEATORIO,
					VariaveisGeracao.PRODUTO_E_SUBPRODUTO_ALEATORIO, 
					VariaveisGeracao.AJUSTAR_DATAHORA_TRAN,
					VariaveisGeracao.VAL_VENDA_ALEATORIO, 
					VariaveisGeracao.MAQUINA_ALEATORIO, 
					VariaveisGeracao.INDIC_SKYLINE_ALEATORIO);
		
		}
		if (type.equals("tps-bam")||type.equals("tps-bam-hist")) { 
			return new TransacaoTPSBAMBuilder(null,			
					VariaveisGeracao.MAQUINA_ALEATORIO);
		}
		if (type.equals("mainframe")) {
			return new TransacaoBuilder(null,
					VariaveisGeracao.BANDEIRA_ALEATORIA, 
					VariaveisGeracao.EMISSOR_ALEATORIO, 
					VariaveisGeracao.STATUS_ALEATORIO,
					VariaveisGeracao.PRODUTO_E_SUBPRODUTO_ALEATORIO, 
					VariaveisGeracao.AJUSTAR_DATAHORA_TRAN,
					VariaveisGeracao.VAL_VENDA_ALEATORIO, 
					VariaveisGeracao.MAQUINA_ALEATORIO, 
					VariaveisGeracao.INDIC_SKYLINE_ALEATORIO);
		} else if (type.equals("floridaPgtoCelular")) {
			return new TransacaoPgtoCelularBuilder(null,
					VariaveisGeracao.BANDEIRA_ALEATORIA, VariaveisGeracao.EMISSOR_ALEATORIO, VariaveisGeracao.STATUS_ALEATORIO,
					VariaveisGeracao.PRODUTO_E_SUBPRODUTO_ALEATORIO, VariaveisGeracao.AJUSTAR_DATAHORA_TRAN,
					VariaveisGeracao.VAL_VENDA_ALEATORIO, VariaveisGeracao.MAQUINA_ALEATORIO, VariaveisGeracao.INDIC_SKYLINE_ALEATORIO);
		} else if (type.equals("dePara")) {
			return new TransacaoDeParaBuilder(null,
					VariaveisGeracao.EMISSOR_ALEATORIO, VariaveisGeracao.STATUS_ALEATORIO,
					VariaveisGeracao.AJUSTAR_DATAHORA_TRAN);
		} else if (type.equals("autorrecarga")) {
			return new TransacaoAutorrecargaBuilder(null,
					VariaveisGeracao.STATUS_ALEATORIO,
					VariaveisGeracao.AJUSTAR_DATAHORA_TRAN);
		} else if (type.equals("p2p")) {
			return new TransacaoP2PBuilder(null,
					VariaveisGeracao.STATUS_ALEATORIO,
					VariaveisGeracao.AJUSTAR_DATAHORA_TRAN,
					VariaveisGeracao.OPERADORA_ALEATORIO);
		} else if (type.equals("push")) {
			return new TransacaoPushBuilder(null,
					VariaveisGeracao.EMISSOR_ALEATORIO,
					VariaveisGeracao.AJUSTAR_DATAHORA_TRAN,
					VariaveisGeracao.PRODUTO_E_SUBPRODUTO_ALEATORIO,
					VariaveisGeracao.SIGLA_SOL_CAPT_ALEATORIO,
					VariaveisGeracao.SITE_ALEATORIO,
					VariaveisGeracao.STATUS_ALEATORIO);
		} else if (type.equals("stratus")) {
			return new TransacaoStratusBuilder(null, VariaveisGeracao.BANDEIRA_ALEATORIA, 
					VariaveisGeracao.EMISSOR_ALEATORIO, 
					VariaveisGeracao.STATUS_ALEATORIO,
					VariaveisGeracao.PRODUTO_E_SUBPRODUTO_ALEATORIO, 
					VariaveisGeracao.AJUSTAR_DATAHORA_TRAN,
					VariaveisGeracao.VAL_VENDA_ALEATORIO, 
					VariaveisGeracao.MAQUINA_ALEATORIO, 
					VariaveisGeracao.INDIC_SKYLINE_ALEATORIO);
		} else if (type.equals("stratus-parseado")) {
			return new TransacaoCepStratusBuilder(null, VariaveisGeracao.BANDEIRA_ALEATORIA, 
					VariaveisGeracao.EMISSOR_ALEATORIO, 
					VariaveisGeracao.STATUS_ALEATORIO,
					VariaveisGeracao.PRODUTO_E_SUBPRODUTO_ALEATORIO, 
					VariaveisGeracao.AJUSTAR_DATAHORA_TRAN,
					VariaveisGeracao.VAL_VENDA_ALEATORIO, 
					VariaveisGeracao.MAQUINA_ALEATORIO, 
					VariaveisGeracao.INDIC_SKYLINE_ALEATORIO);
		} else if (type.equals("orizon")) {
			return new TransacaoOrizonBuilder(null,
					VariaveisGeracao.TIPO_TRANSACAO_ALEATORIO,
					VariaveisGeracao.COD_RESPOSTA_ALEATORIO,
					VariaveisGeracao.MAQUINA_GATEWAY_ALEATORIO);
		} else if (type.equals("coban")) {
			return new TransacaoCobanBuilder(null,
					VariaveisGeracao.TIPO_TRANSACAO_ALEATORIO,
					VariaveisGeracao.COD_RESPOSTA_ALEATORIO,
					VariaveisGeracao.MAQUINA_GATEWAY_ALEATORIO,
					VariaveisGeracao.RETORNO_CHAMADA_ALEATORIO,
					VariaveisGeracao.PRODUTO_ALEATORIO,
					VariaveisGeracao.COD_PROCESSAMENTO_ALEATORIO,
					VariaveisGeracao.TIPO_PGTO_ALEATORIO,
					VariaveisGeracao.TIPO_CARTAO_ALEATORIO,
					VariaveisGeracao.EMISSOR_ALEATORIO,
					VariaveisGeracao.COD_OBS_ALEATORIO);
		} else if (type.equals("arv")) {
			return new TransacaoArvBuilder(null,
					VariaveisGeracao.EMISSOR_ALEATORIO,
					VariaveisGeracao.STATUS_ALEATORIO,
					VariaveisGeracao.PRODUTO_ALEATORIO,
					VariaveisGeracao.AJUSTAR_DATAHORA_TRAN,
					VariaveisGeracao.SITE_ALEATORIO,
					VariaveisGeracao.SIGLA_SOL_CAPT_ALEATORIO);					
		}

		
		throw new UnsupportedOperationException("tipo de builder invalido:"+type);
		
	}
	
}
