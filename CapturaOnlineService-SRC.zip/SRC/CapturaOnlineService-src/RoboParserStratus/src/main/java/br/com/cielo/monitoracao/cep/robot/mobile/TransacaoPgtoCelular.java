package br.com.cielo.monitoracao.cep.robot.mobile;

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;


public class TransacaoPgtoCelular implements TransacaoGenerica{
	String dtInicio="01/01/2013 10:00:00.000";
	String dtFinal="01/01/2013 10:00:00.000";
	String tpTransacao="PagamentoCelularPOS                               ";
	String cdProdPrimario="0001";
	String cdProdSecundario="0001";
	String dddCelular="011";
	String nuCelular="00096061302";
	String vlTransacao="000000120000";
	String cdAutorizacao="000001";
	String cdResposta="001";
	String descricaoResposta="XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
	String nmEmissor="EM01   Banco do Brasil                            ";
	String cdEmissor="EM01";
	String cdStatus="01";
	String descricaoStatus="Aprovada            ";
	String nmHost="HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH"; 
	String instanciaJava="JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ";
	String cdErro="                                                                                                    ";
	String mensagemErro="EEEEEEEEEE";
	{
		for (int i = 0; i<99; i++) {
			mensagemErro += "EEEEEEEEEE";
		}
	}
	static final String[] idEmissores = new String[] { "EM01", "EM02", "EM03" };

	static final String[] idProdutos = new String[] { "1000", "2000" };

	static final String[] subProdutos = new String[] { "0324", "0325", "0326","0327", "0328", "0329","0345","0361" };

	
	public String getTripa(){
		return dtInicio+
		dtFinal+
		tpTransacao+
		cdProdPrimario+
		cdProdSecundario+
		dddCelular+
		nuCelular+
		vlTransacao+
		cdAutorizacao+
		cdResposta+
		descricaoResposta+
		nmEmissor+
		cdEmissor+
		cdStatus+
		descricaoStatus+
		(cdStatus.trim().equals("05") ? (nmHost+
		instanciaJava+
		cdErro+
		mensagemErro) : "");
		
	}


	@Override
	public String toString() {
		return "TransacaoFlorida [dtInicio=" + dtInicio + ", dtFinal="
				+ dtFinal + ", tpTransacao=" + tpTransacao
				+ ", cdProdPrimario=" + cdProdPrimario + ", cdProdSecundario="
				+ cdProdSecundario + ", dddCelular=" + dddCelular
				+ ", nuCelular=" + nuCelular + ", vlTransacao=" + vlTransacao
				+ ", cdResposta=" + cdResposta + ", descricaoResposta="
				+ descricaoResposta + ", nmEmissor=" + nmEmissor
				+ ", cdEmissor=" + cdEmissor + ", cdStatus=" + cdStatus
				+ ", descricaoStatus=" + descricaoStatus + ", nmHost=" + nmHost
				+ ", instanciaJava=" + instanciaJava + ", cdErro=" + cdErro
				+ ", mensagemErro=" + mensagemErro + "]";
	}

}
