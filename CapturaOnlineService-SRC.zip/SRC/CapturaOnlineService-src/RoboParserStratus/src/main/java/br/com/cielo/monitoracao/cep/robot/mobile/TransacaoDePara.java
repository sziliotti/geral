package br.com.cielo.monitoracao.cep.robot.mobile;

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;


public class TransacaoDePara implements TransacaoGenerica{
	String dtInicio="01/01/2013 10:00:00.000";
	String dtFinal="01/01/2013 10:00:00.000";
	String tpTransacao="ConsultaCartaoPorCelular                          ";
	String dddCelular="011";
	String nuCelular="00096061302";
	String nmEmissor="EM01   Banco do Brasil                            ";
	String cdEmissor="EM01";
	String cdStatus="01";
	String descricaoStatus="Aprovada            ";

	static final String[] idEmissores = new String[] { "EM01", "EM02", "EM03" };

		
	public String getTripa(){
		return dtInicio+
		dtFinal+
		tpTransacao+
		dddCelular+
		nuCelular+
		nmEmissor+
		cdEmissor+
		cdStatus+
		descricaoStatus;
		
	}


	@Override
	public String toString() {
		return "TransacaoDePara [dtInicio=" + dtInicio + ", dtFinal=" + dtFinal
				+ ", tpTransacao=" + tpTransacao + ", dddCelular=" + dddCelular
				+ ", nuCelular=" + nuCelular + ", nmEmissor=" + nmEmissor
				+ ", cdEmissor=" + cdEmissor + ", cdStatus=" + cdStatus
				+ ", descricaoStatus=" + descricaoStatus + "]";
	}



}
