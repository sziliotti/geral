package br.com.cielo.monitoracao.cep.robot.mobile;

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;


public class TransacaoAutorecarga implements TransacaoGenerica{
	String dtInicio="01/01/2013 10:00:00.000";
	String dtFinal="01/01/2013 10:00:00.000";
	String uuid="111111122222233333444455556666777788";
	String tid="11111111111111111111";
	String tpTransacao="Autorrecarga                                      ";
	String dddCelular="011";
	String nuCelular="00096061302";
	String vlTransacao="000000120000";
	String cdAutorizacao="000001";
	String nmHost="HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH"; 
	String instanciaJava="JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ";
	String cdErro="                                                                                                    ";
	String mensagemErro="EEEEEEEEEE";
	{
		for (int i = 0; i<99; i++) {
			mensagemErro += "EEEEEEEEEE";
		}
	}

		
	public String getTripa(){
		return dtInicio+
		dtFinal+
		uuid+
		tid+
		tpTransacao+
		dddCelular+
		nuCelular+
		vlTransacao+
		cdAutorizacao+
		nmHost+
		instanciaJava+
		(!(cdErro == null || "".equals(cdErro.trim())) ? cdErro+
		mensagemErro : "");
	}


	@Override
	public String toString() {
		return "TransacaoAutorecarga [dtInicio=" + dtInicio + ", dtFinal="
				+ dtFinal + ", uuid=" + uuid + ", tid=" + tid
				+ ", tpTransacao=" + tpTransacao + ", dddCelular=" + dddCelular
				+ ", nuCelular=" + nuCelular + ", vlTransacao=" + vlTransacao
				+ ", cdAutorizacao=" + cdAutorizacao + ", nmHost=" + nmHost
				+ ", instanciaJava=" + instanciaJava + ", cdErro=" + cdErro
				+ ", mensagemErro=" + mensagemErro + "]";
	}


}
