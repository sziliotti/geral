package br.com.cielo.monitoracao.cep.robot.mobile;

import java.util.Properties;

import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import br.com.cielo.monitoracao.cep.robot.ProducerGenerico;

public class ProdutorP2P extends ProducerGenerico{
	public ProdutorP2P(String queueJndiName, String urlQueueServer,String topicJndiName, String urlTopicServer) {
		super(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		if (queueJndiName == null &&  topicJndiName == null) {
			setQueueJndiName("com.cielo.monitoracao.mobile_P2P.queue.1.in");
		}
		
	}

	static long messageOrderId = System.currentTimeMillis();

	@Override
	public void sendMessage(byte[] bytes) throws Exception {
		TextMessage bm = getSession().createTextMessage();
		bm.setText(new String(bytes));
		bm.setLongProperty("MESSAGE_ORDER_ID", messageOrderId++);
		getProducer().send(bm);
		Thread.sleep(1);
	}
}
