package br.com.cielo.monitoracao.cep.robot.lci;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;

public class TransacaoLCIBAM implements TransacaoGenerica {
	protected transient static final SimpleDateFormat sdfDataHoraMinuto = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

	public String getTripa(){
		Date dtTrans = new Date();
		int qtdTrans = getAleatorioGenerico(1, 10) < 4 ? 1 : (getAleatorioGenerico(1, 5));
		int qtdTransErro = getAleatorioGenerico(1, 3);
		boolean indicErro = getAleatorioGenerico(0, 1) == 0 ? false : true;
		int tpLinksy = getAleatorioGenerico(1,6);
		String codSite = getAleatorioGenerico(0, 1) == 0 ? "SP" : "RJ";
		Integer codErro = null;
		if (tpLinksy == 1) {
			codErro = getAleatorioGenerico(1, 8);
		} else if (tpLinksy == 2) {
			codErro = getAleatorioGenerico(1, 6);
		} else if (tpLinksy == 5) {
			codErro = getAleatorioGenerico(1, 3);
		} else {
			codErro = getAleatorioGenerico(1, 2);
		}
		
		Date dataHoraAut = new Date();
		
		return "<Transacao>" + "<LinkCi>" 
		+ nvlTag("TipoProduto", tpLinksy)
        + nvlTag("IsTransacaoErro", indicErro)
		+ (indicErro ? ( nvlTag("CodErro", codErro)
		                 + nvlTag("QtdTransacoesErro", qtdTransErro ) )
		             : nvlTag("QtdTransacoesOK", qtdTrans))
		+ nvlTag("DataProcessamento", sdfDataHoraMinuto.format(dtTrans))
		+ nvlTag("CodSite", codSite)
        + "</LinkCi>"
		+ "</Transacao>";
	}

	private String nvlTag(String tag, Object valor) {
		return valor == null ? "" : "<" + tag + ">" + valor + "</" + tag + ">";
	}
	protected int getAleatorioGenerico(int min, int max) {
		//int r = min + ((int) (Math.random() * 1000000) % (max - min + 1));
		SecureRandom a = new SecureRandom();
		return a.nextInt(max + 1 - min) + min;
		//return r;
	}
	
}