package br.com.cielo.monitoracao.cep.robot.orizon;

import java.text.SimpleDateFormat;
import java.util.Date;

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;

public class TransacaoOrizon implements TransacaoGenerica{
	SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmss");
	String dataHoraAut=sdf.format(new Date());
	String tipoTransacao = "1400";
	String codResposta   = "0";
	String maquinaGateway="G1";
	
	static final String[] tiposTransacao = new String[] { "1100", "1110", "1200", "1202", "1210", "1400"
														, "1410", "1420", "1430", "1600","1610" };

	static final String[] codsResposta = new String[] { "0","1","2","3" };
	
	static final String[] maquinasGateway = new String[] {"G1", "G2", "G3", "G4"};

	public String getTripa(){
/*		return dataHoraAut+
		tipoTransacao+
		codResposta+
		maquinaGateway;*/
		String xmlTransacao = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
					          "<Log_Saude>"+
					          "<dh_transacao>"+dataHoraAut+"</dh_transacao>"+
					          "<cod_processamento>"+tipoTransacao+"</cod_processamento>"+
					          "<cod_resposta>"+codResposta+"</cod_resposta>"+
					          "<site>"+maquinaGateway+"</site>"+
					          "</Log_Saude>" ;
		return xmlTransacao;		
	}
	
	public void setDataHoraAut(String dataHoraAut) {
		this.dataHoraAut = dataHoraAut;
	}
	public void setTipoTransacao(String tipoTransacao) {
		this.tipoTransacao = tipoTransacao;
	}
	public void setCodResposta(String codResposta) {
		this.codResposta = codResposta;
	}
	public void setMaquinaGateway(String maquinaGateway) {
		this.maquinaGateway = maquinaGateway;
	}

	@Override
	public String toString() {
		return "TransacaoOrizon [sdf=" + sdf + ", dataHoraAut=" + dataHoraAut + ", tipoTransacao="
				+ tipoTransacao + ", codResposta=" + codResposta + ", maquinaGateway="
				+ maquinaGateway +  "]";
	}


}


