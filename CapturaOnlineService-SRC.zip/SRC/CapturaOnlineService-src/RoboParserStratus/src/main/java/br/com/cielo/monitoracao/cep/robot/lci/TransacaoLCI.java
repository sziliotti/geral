package br.com.cielo.monitoracao.cep.robot.lci;

import java.text.SimpleDateFormat;
import java.util.Date; 

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;

public abstract class TransacaoLCI implements TransacaoGenerica {

	public enum CodigoSite { SP, RJ };
	
	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss:SSS");
	private String cdSite="SP";
	private String hrInicioFluxo=sdf.format(new Date());
	private String stFinalTran="00";
	private String hrFimFluxo=sdf.format(new Date());
    private String tmpTotalTra="00:00:05:000";	

    
	public abstract String getIdTipTransacao();
	
	public String getFiller() {
		return "                                                                                                    ";
	}
	public void setCdSite(CodigoSite site) {
		this.cdSite = site.toString();
	}

	public abstract String[] getStatusFinais();
	
	protected String getCdSite() {
		return cdSite;
	}

	protected String getHrInicioFluxo() {
		return hrInicioFluxo;
	}

	public void setHrInicioFluxo(Date hrInicioFluxo) {
		this.hrInicioFluxo = sdf.format(hrInicioFluxo);
	}

	protected String getStFinalTran() {
		return stFinalTran;
	}

	public void setStFinalTran(String stFinalTran) {
		this.stFinalTran = stFinalTran;
	}

	protected String getHrFimFluxo() {
		return hrFimFluxo;
	}

	public void setHrFimFluxo(Date hrFimFluxo) {
		this.hrFimFluxo = sdf.format(hrFimFluxo);
	}

	protected String getTmpTotalTra() {
		return tmpTotalTra;
	}

	public void setTmpTotalTra(String tmpTotalTra) {
		this.tmpTotalTra = tmpTotalTra;
	}
	
}
