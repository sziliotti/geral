package br.com.cielo.monitoracao.cep.robot.coban;

import java.text.SimpleDateFormat;
import java.util.Date;

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;

public class TransacaoCoban implements TransacaoGenerica{
	SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmss");
	String dataHoraAut=sdf.format(new Date());  // idXml = 4
	String codProduto 		= "5000";			// idXml = 15
	String tipoTransacao 	= "1400";			// idXml = 18
	String codProcessamento = "002100";			// idXml = 19
	String codEmissor 		= "001";			// idXml = 21
	String tipoPgto  		= "00"; 			// idXml = 23
	String codResposta      = "999";			// idXml = 27
	String tipoCartao 		= "BA";				// idXml = 31
	String codObs	        = "000";			// idXml = 76
	String maquinaGateway	= "G1";				// idXml = 69
	String codSubProduto 	= "0007";			// idXml = 92
	String nuTerminal 	    = "28000066";		// idXml = 3
	
	
	static final int DATA_HORA_TRANSACAO = 4;
	static final int COD_PRODUTO = 15;
	static final int TIPO_TRANSACAO = 18;
	static final int COD_PROCESSAMENTO = 19;
	static final int COD_EMISSOR = 21;
	static final int TIPO_PGTO = 23;
	static final int COD_RESPOSTA = 27;
	static final int TIPO_CARTAO = 31;
	static final int COD_OBS = 76;
	static final int MAQUINA_GATEWAY = 69;
	static final int COD_SUB_PRODUTO = 92;
	static final int NU_TERMINAL = 3;
	
	
	static final String[] codsProduto 		= new String[] { "1000", "2000", "3000", "4000", "5000",
															 "6000", "7000", "8000", "9000" };
	static final String[] tiposTransacao 	= new String[] { "1100", "1110", "1200", "1202", "1210", "1400",
															 "1410", "1420", "1430", "1600","1610" };
	static final String[] codsProcessamento = new String[] { "002100" }; //????
	static final String[] codsEmissor 		= new String[] { "0001","0001","0001", "0353", "0241", 
															 "0424", "0237", "0237" };
	static final String[] tiposPgto 		= new String[] { "00", "01", "02"};
	static final String[] codsResposta 		= new String[] { "999" }; // ?????
	static final String[] tiposCartao 		= new String[] { "BA", "VE" }; 
	
	static final String[] codsObs	 		= new String[] { "706", "707", "708", "709" }; //????
	
	static final String[] maquinasGateway = new String[] {"G1", "G2", "G3", "G4"};
	
	static final String[] codsSubProduto = new String[] {"0001", "0002", "0003", "0004", 
														 "0005", "0006", "0007", "0008"};
	static final String[] nusTerminal = new String[] {"28000066", "28000061", "28000062", "28000063", 
		 "28000064", "28000065", "28000067", "28000068"};
	
	
	public void setDataHoraAut(String dataHoraAut) {
		this.dataHoraAut = dataHoraAut;
	}
	public void setCodProduto(String codProduto) {
		this.codProduto = codProduto;
	}
	public void setTipoTransacao(String tipoTransacao) {
		this.tipoTransacao = tipoTransacao;
	}
	public void setCodProcessamento(String codProcessamento) {
		this.codProcessamento = codProcessamento;
	}
	public void setCodEmissor(String codEmissor) {
		this.codEmissor = codEmissor;
	}
	public void setTipoPgto(String tipoPgto) {
		this.tipoPgto = tipoPgto;
	}
	public void setCodResposta(String codResposta) {
		this.codResposta = codResposta;
	}
	public void setTipoCartao(String tipoCartao) {
		this.tipoCartao = tipoCartao;
	}
	public void setCodObs(String codObs) {
		this.codObs = codObs;
	}
	public void setMaquinaGateway(String maquinaGateway) {
		this.maquinaGateway = maquinaGateway;
	}
	public void setCodSubProduto(String codSubProduto) {
		this.codSubProduto = codSubProduto;
	}
	public void setNuTerminal(String nuTerminal) {
		this.nuTerminal = nuTerminal;
	}	

	
	public String getTripa(){
		String xmlTransacao = " <?xml version=\"1.0\" encoding=\"UTF-8\"?> " +
							  " <ns:iso xmlns:ns=\"http://roteador.gs.visanet.com/Isomsg\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"+
        					  "	<ns:isomsg>"+
        					  " <ns:field id='3' value='"+nuTerminal+"'/>"+
        					  " <ns:field id='4' value='"+dataHoraAut+"'/>"+
        					  " <ns:field id='15' value='"+codProduto+"'/>"+
        					  " <ns:field id='18' value='"+tipoTransacao+"'/>"+
        					  " <ns:field id='19' value='"+codProcessamento+"'/>"+
        					  " <ns:field id='21' value='"+codEmissor+"'/>"+
        					  " <ns:field id='23' value='"+tipoPgto+"'/>"+
        					  " <ns:field id='27' value='"+codResposta+"'/>"+
        					  " <ns:field id='31' value='"+tipoCartao+"'/>"+
        					  " <ns:field id='69' value='"+maquinaGateway+"'/>"+
        					  " <ns:field id='76' value='"+codObs+"'/>"+
        					  " <ns:field id='92' value='"+codSubProduto+"'/>"+
        					  " </ns:isomsg>"+
        					  "	</ns:iso>";	
		return xmlTransacao;

		
	}
	@Override
	public String toString() {
		return "TransacaoCoban [sdf=" + sdf + 
							 ", dataHoraAut=" + dataHoraAut + 
							 ", nuTerminal="+ nuTerminal+
							 ", codProduto=" + codProduto +
							 ", tipoTransacao=" + tipoTransacao +
							 ", codProcessamento=" + codProcessamento +
							 ", codEmissor=" + codEmissor +
							 ", tipoPgto=" + tipoPgto +
							 ", codResposta=" + codResposta +
							 ", tipoCartao=" + tipoCartao +
							 ", maquinaGateway=" + maquinaGateway +  
							 ", codObs=" + codObs +  
							 ", codSubProduto=" + codSubProduto +  
							 "]";
	}


}


