package br.com.cielo.monitoracao.cep.robot.arv;

import java.io.BufferedReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import br.com.cielo.monitoracao.cep.robot.RoboCieloCEP;
import br.com.cielo.monitoracao.cep.robot.Transacao;
import br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico;
import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;

public class TransacaoArvBuilder extends TransacaoBuilderGenerico {
	SimpleDateFormat sdfDtHora = new SimpleDateFormat("yyMMddHHmmss");
	SimpleDateFormat sdfDtCred = new SimpleDateFormat("ddMMyy");
	
	boolean emissorAleatorio = false;
	boolean statusAleatorio = false;
	boolean produtoAleatorio = false;
	boolean ajustarDataHoraTran = false;
	boolean siteAleatorio = false;
	boolean siglaSolCapturaAleatorio = false;
	
	private boolean isStatusAleatorio() {
		return statusAleatorio; 
	}
	private boolean isProdutoAleatorio() {
		return produtoAleatorio;
	}
	private boolean isAjustarDataHoraTran() {
		return ajustarDataHoraTran;
	}
	
	public boolean isSiteAleatorio() {
		return siteAleatorio;
	}

	public boolean isSiglaSolCaptAleatorio() {
		return siglaSolCapturaAleatorio;
	} 
	
	public TransacaoArvBuilder(Transacao template, VariaveisGeracao ... variaveis){
		for (int i = 0; i < variaveis.length; i++) {
			switch (variaveis[i]){
			case EMISSOR_ALEATORIO:
				emissorAleatorio=true;break;
			case STATUS_ALEATORIO:
				statusAleatorio=true;break;
			case PRODUTO_ALEATORIO:
				produtoAleatorio = true;
				break;
			case SIGLA_SOL_CAPT_ALEATORIO:
				siglaSolCapturaAleatorio = true;
				break;
			case AJUSTAR_DATAHORA_TRAN:
				ajustarDataHoraTran = true;
				break;
			}
		}
	}
	
	public TransacaoGenerica gerarNovaTransacao(Date dataHoraTran){
		TransacaoArv t = new TransacaoArv();
		if (dataHoraTran == null) {
			dataHoraTran = new Date();
		}
		if (isAjustarDataHoraTran()){
			setInicioTermino(t);		
		}
		if (isStatusAleatorio()) {
			setStatusAleatorio(t);
		}
		if (isProdutoAleatorio()) {
			setProduto(t);
		}
		
		return t;
	}

	private void setInicioTermino(TransacaoArv t) {
		// tiro 15 segundos para simular a latencia do autorizador 
		Date now = new Date(System.currentTimeMillis()-15000);
		t.dataHoraAcao = sdfDtHora.format(now);
	}


	private  void setProduto(TransacaoArv t) {
		
		t.codFluxoAntecipado = TransacaoArv.cdFluxosAtentecipados[getAleatorioGenerico(0, TransacaoArv.cdFluxosAtentecipados.length - 1)];
	}
	
	public String lpad(String valueToPad, String filler, int size) {  
        while (valueToPad.length() < size) {  
            valueToPad = filler + valueToPad;  
        }  
        return valueToPad;  
    }  	

	private  void setStatusAleatorio(TransacaoArv t) {
		// tenho 4 status: 1 e 2 - Cancelamento, 2 - Desfazimento, 3 - Aprovado,
		// 4 - Negado
		int statusId = getAleatorioGenerico_2(1, 6);
		Integer valor = getAleatorioGenerico(1,999);
		String codResp = this.lpad(valor.toString(), "0", 3);
		switch (statusId) {
		case 1:
		case 2:
		case 3:
		case 4:
			// Aprovado
			t.descTpAcao = TransacaoArv.dsTipoAcao[3]; // tipo acao 4
			t.codResposta = "000";
			break;
		case 5:
			// Erro
			t.descTpAcao = TransacaoArv.dsTipoAcao[getAleatorioGenerico(0, 2)]; // tipo acao <> 4
			//t.codResposta = ""+getAleatorioGenerico(1,999);
			t.codResposta = codResp;
			break;
		case 6:
			// Negado
			t.descTpAcao = TransacaoArv.dsTipoAcao[3]; // tipo acao 4 e cod resposta <> 100
			//t.codResposta = ""+getAleatorioGenerico(1,999);
			t.codResposta = codResp;
			break;
		}

		
	}
	
	private String getSpaces(int i) {
		String spaces = "";
		for (int j = 0; j < i; j++) {
		   spaces += " ";	
		}
		return spaces;
	}

/*
 * (non-Javadoc)
 * @see br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico#generateMessages(int)
 * Metodo para ser usada pelo Robot para leitura de arquivo ou gera��o de mensagens aleat�rias
 */
	public Collection<byte[]> generateMessages(int qtdade) throws Exception {

		List<byte[]> list = new ArrayList<byte[]>();
		
		if (RoboCieloCEP.getFileSamples() == null) {
			return super.generateMessages(qtdade);
		} else {
			if (RoboCieloCEP.getFileSamples() != null) {
				BufferedReader reader = RoboCieloCEP.getFileSamples();
				String line = null;
				while ((line = reader.readLine()) != null) {
					//byte[] lineBytes = ParserConverterUtils.hexToBytes(line);
					byte[] lineBytes = line.getBytes();
					list.add(lineBytes);
				}
			}
		}		
		return list;
	}	

}
