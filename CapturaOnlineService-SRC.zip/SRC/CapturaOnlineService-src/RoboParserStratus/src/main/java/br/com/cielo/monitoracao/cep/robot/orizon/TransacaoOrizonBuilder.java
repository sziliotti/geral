package br.com.cielo.monitoracao.cep.robot.orizon;


import java.util.Date;

import br.com.cielo.monitoracao.cep.robot.Transacao;
import br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico;
import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;

public class TransacaoOrizonBuilder extends TransacaoBuilderGenerico {
	
	boolean tipoTransacaoAleatorio = false;
	boolean codRespostaAleatorio = false;
	boolean maquinaGatewayAleatorio = false;
	boolean ajustarDataHoraTran = false;
	
	private boolean isTipoTransacaoAleatorio() {
		return tipoTransacaoAleatorio;
	}
	private boolean isCodRespostaAleatorio() {
		return codRespostaAleatorio; 
	}
	private boolean isMaquinaGatewayAleatorio() {
		return maquinaGatewayAleatorio;
	}

	/*private boolean isAjustarDataHoraTran() {
		return ajustarDataHoraTran;
	}
	*/

	
	public TransacaoOrizonBuilder(Transacao template, VariaveisGeracao ... variaveis){
		for (int i = 0; i < variaveis.length; i++) {
			switch (variaveis[i]){
			case TIPO_TRANSACAO_ALEATORIO:
				tipoTransacaoAleatorio=true;
				break;
			case COD_RESPOSTA_ALEATORIO:
				codRespostaAleatorio=true;
				break;
			case MAQUINA_GATEWAY_ALEATORIO:
				maquinaGatewayAleatorio = true;
				break;
			case AJUSTAR_DATAHORA_TRAN:
				ajustarDataHoraTran = true;
				break;
			}
		}
	}
	
	public TransacaoGenerica gerarNovaTransacao(Date dataHoraTran){
		TransacaoOrizon t = new TransacaoOrizon();
		if (dataHoraTran == null) {
			dataHoraTran = new Date();
		}
		if (isTipoTransacaoAleatorio()) {
			setTipoTransacaoAleatorio(t);
		}
		if (isCodRespostaAleatorio()) {
			setCodRespostaAleatorio(t);
		}
		if (isMaquinaGatewayAleatorio()) {
			setMaquinaGatewayAleatorio(t);
		}
		return t;
	}
	
	private void setTipoTransacaoAleatorio(TransacaoOrizon t) {
		int indice = getAleatorioGenerico(0, t.tiposTransacao.length-1);
		t.tipoTransacao = TransacaoOrizon.tiposTransacao[indice];
	}
	private void setCodRespostaAleatorio(TransacaoOrizon t) {
		int indice = getAleatorioGenerico(0, t.codsResposta.length-1);
		t.codResposta = TransacaoOrizon.codsResposta[indice];
	}
	private  void setMaquinaGatewayAleatorio(TransacaoOrizon t) {
		int indice = getAleatorioGenerico(0, t.maquinasGateway.length - 1);
		t.maquinaGateway = TransacaoOrizon.maquinasGateway[indice];
	}

	private String getSpaces(int i) {
		String spaces = "";
		for (int j = 0; j < i; j++) {
		   spaces += " ";	
		}
		return spaces;
	}


}
