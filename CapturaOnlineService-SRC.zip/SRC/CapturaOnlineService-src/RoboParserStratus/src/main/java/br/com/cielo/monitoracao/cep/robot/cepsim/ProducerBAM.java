package br.com.cielo.monitoracao.cep.robot.cepsim;

import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import br.com.cielo.monitoracao.cep.robot.ProducerGenerico;

public class ProducerBAM extends ProducerGenerico {
	private InitialContext ctx;
	public ProducerBAM(String queueJndiName, String urlQueueServer,String topicJndiName, String urlTopicServer) {
		super(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		if (queueJndiName == null &&  topicJndiName == null) {
			setQueueJndiName("jms.QueueMainframeBAMCielo");
		}
	}

	
	
	static long messageOrderId = System.currentTimeMillis();
	
	@Override
	public void sendMessage(byte[] bytes) throws Exception {
        TextMessage bm = getSession().createTextMessage();
        String mensagem = new String(bytes);
        bm.setText(mensagem);
        bm.setLongProperty("MESSAGE_ORDER_ID", messageOrderId++ );
        // Here we are sending the message!
        getProducer().send(bm);
		Thread.sleep(1);
    }
	protected Connection getConnection() throws Exception {
		if (cachedConnection == null){
			Properties props = new Properties();
			props.setProperty(Context.INITIAL_CONTEXT_FACTORY,"weblogic.jndi.WLInitialContextFactory");
			props.setProperty(Context.PROVIDER_URL,getUrlQueueServer());
			ctx = new InitialContext(props);
			ConnectionFactory connectionFactory = 
				(ConnectionFactory) ctx.lookup("jms.ConnectionFactoryBAMCielo");
			cachedConnection = connectionFactory.createConnection();
			cachedConnection.start();	
		}
		
		return cachedConnection;
	}
	protected MessageProducer getProducer() throws Exception {
		if (cachedProducer == null) {
			Destination destination = (Destination) ctx.lookup(getQueueJndiName());

			cachedProducer = cachedSession.createProducer(destination);
		}
		return cachedProducer;
	}
		
	
}