/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.monitoracao.cep.robot;



import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author nemer
 */
public class RoboCieloBAM {
	
	static Long delayMsEntreMensagens = 0L;
	private static String jmsQueueURL;
	/**
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String[] args) throws Exception {
		Map<String,String> params = new HashMap<String,String>(); 
		for (int i = 0; i < args.length; i++) {
			String[] param = args[i].split("=",2);
			params.put(param[0], param[1]);
		}
		String value;
		if (null != (value=params.get("--jmsQueueURL"))) {
			jmsQueueURL = value;
			Consumer.URL_QUEUE_SERVER=jmsQueueURL;
		}
		RoboCieloBAM robo = new RoboCieloBAM();
		robo.runRobot();

	}

	
	private void runRobot() throws Exception {
		Consumer c = new Consumer();
		long count=0;
		long lastEstat=System.currentTimeMillis();
		while (true) {
			String xml = c.getMessage();
			if (xml != null) count++;
			if (lastEstat+1000 < System.currentTimeMillis()) {
				System.out.println("Throughput (m/s):"+count);
				lastEstat = System.currentTimeMillis();
				count = 0;
			}
			
		}

	}

}
