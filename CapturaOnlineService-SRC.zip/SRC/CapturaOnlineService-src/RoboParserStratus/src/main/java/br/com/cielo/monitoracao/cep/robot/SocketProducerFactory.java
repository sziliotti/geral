package br.com.cielo.monitoracao.cep.robot;

import br.com.cielo.monitoracao.cep.robot.stratus.ProdutorStratusSocket;


public class SocketProducerFactory { 

	public static ProducerGenerico getProducer(String type, String socketAddress, Boolean msgCompactada) {
		if (type.equals("stratus")) {
			return new ProdutorStratusSocket(socketAddress, msgCompactada);
		}
		throw new UnsupportedOperationException("tipo de producer invalido:"+type);
	}
}
