package br.com.cielo.monitoracao.cep.robot.arv;

import java.text.SimpleDateFormat;
import java.util.Date;

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;
import br.com.cielo.monitoracao.cep.robot.util.RandomString;


public class TransacaoArv implements TransacaoGenerica{
	private static final RandomString randomString = new RandomString(1048);
	SimpleDateFormat sdfDtHora = new SimpleDateFormat("yyMMddHHmmss");
	SimpleDateFormat sdfDtCred = new SimpleDateFormat("ddMMyy");
	String codEstab = "1234567890123456";
	String numTerm = "28000066";
	String NSU = "12345678";
	String dataHora = sdfDtHora.format(new Date());
	String codTpDoc = "00"; // 00 - CNPJ; 01 - CPF
	String nrDoc = "12345678901234";
	String codBanco = "0001";
	String nrAgencia = "123456";
	String nrCC = "12345678901234";
	String MCC = "1234"; // Priscila alterou
	String codSolAutorizadora = "1234";
	String codEstabFisico = "1234567890123456";
	String codFluxoAntecipado = "01";
	String codProcessamento = "123456";
	String vlBruto = "12345678901";
	String vlDesc = "12345678901";
	String vlLiq = "12345678901";
	String dtCredito = sdfDtCred.format(new Date());
	String nrOperacao = "1234567890";
	String cdOpcao = "00";
	String tpAntecipacaoAutomatica = "00";
	String diaDaSemana = "00";
	String diaMesParaAntecipacao = "011530"; // XXNNZZ - XX: primeiro dia para antecipacao, NN:segundo e ZZ: terceiro
	String codResposta = "123"; // cod resposta recebido do SEC
	String descResposta = "RESPOSTA SEC 80 POSICOES_RESPOSTA SEC 80 POSICOES_RESPOSTA SEC 80 POSICOES_12345";//"RESPOSTA SEC 80 POSICOES____RESPOSTA SEC 80 POSICOES____RESPOSTA SEC 80 POSICOES";
	String codSeguranca = "1234567890123456";
	String codReferencia = "1234567";
	String ocerrencias = "1";
	//String dadoAcao = randomString.nextString();
	String descTpAcao = "1 - Mensagem recebida do POS                      ";//"DESCRICAO TIPO ACAO______DESCRICAO TIPO ACAO__";
	String dataHoraAcao = sdfDtHora.format(new Date());
	String descErroProcessamento = "DESCRICAO_ERRO_1PROCESSAMENTO_DESCRICAO_ERRO_2PROCESSAMENTO_DESCRICAO_ERRO_3PROCESSAMENTO_DESCRICAO_ERRO_4PROCESSAMENTO_DESCRICAO_ERRO_5PROCESSAMENTO_DESCRICAO_ERRO_6PROCESSAMENTO_DESCRICAO_ERRO_PROCE";
	String codSite = "SP";
	
	
	static final String[] diasDaSemana = new String [] {"00" /*Nao ha*/,"01"/*Seg*/,"02"/*Ter*/,"03"/*Qua*/,"04"/*Qui*/,"05"/*Sex*/};
	static final String[] cdOpcoes = new String [] {"00" /*CadastroAntecipado*/,"01"/*Descadastro Antecipado*/};
	static final String[] tpAntecipacaoAutomaticas = new String [] {"00" /*Diaria*/,"01"/*Semanal*/,"02"/*Personalizado*/};
	static final String[] cdFluxosAtentecipados = new String[] {"00","01","02","03","04","05","06","07"}; 
	static final String[] idEmissores = new String[] { "0001","0001","0001", "0353", "0241", "0424", "0237", "0237" };
	static final String[] dsTipoAcao = new String[] { "Mensagem recebida do POS                          ","Mensagem enviado ao SEC                           ","Mensagem recebida do SEC                          ","Mensagem enviada ao POS                           "};
	static final String[] codSites = new String[] {"SP","RJ"};
	
	public String getTripa(){
		String transacaoArv = codEstab +
				numTerm +
				NSU +
				dataHora +
				codTpDoc +
				nrDoc +
				codBanco +
				nrAgencia +
				nrCC +
				MCC +
				codSolAutorizadora +
				codEstabFisico +
				codFluxoAntecipado +
				codProcessamento +
				vlBruto +
				vlDesc +
				vlLiq +
				dtCredito +
				nrOperacao +
				cdOpcao +
				tpAntecipacaoAutomatica +
				diaDaSemana +
				diaMesParaAntecipacao +
				codResposta +
				descResposta +
				codSeguranca +
				codReferencia +
				ocerrencias +
			//	dadoAcao +
				descTpAcao +
				dataHoraAcao +
				descErroProcessamento+
				codSite;
		return transacaoArv;
		
	}


	@Override
	public String toString() {
		String transacao = "TransacaoArv [codEstab=" + codEstab + ", numTerm=" + numTerm
				+ ", NSU=" + NSU + ", dataHora=" + dataHora + ", codTpDoc="
				+ codTpDoc + ", nrDoc=" + nrDoc + ", codBanco=" + codBanco
				+ ", nrAgencia=" + nrAgencia + ", nrCC=" + nrCC + ", MCC="
				+ MCC + ", codSolAutorizadora=" + codSolAutorizadora
				+ ", codEstabFisico=" + codEstabFisico
				+ ", codFluxoAntecipado=" + codFluxoAntecipado
				+ ", codProcessamento=" + codProcessamento + ", vlBruto="
				+ vlBruto + ", vlDesc=" + vlDesc + ", vlLiq=" + vlLiq
				+ ", dtCredito=" + dtCredito + ", nrOperacao=" + nrOperacao
				+ ", cdOpcao=" + cdOpcao + ", tpAntecipacaoAutomatica="
				+ tpAntecipacaoAutomatica + ", diaDaSemana=" + diaDaSemana
				+ ", diaMesParaAntecipacao=" + diaMesParaAntecipacao
				+ ", codResposta=" + codResposta + ", descResposta="
				+ descResposta + ", codSeguranca=" + codSeguranca
				+ ", codReferencia=" + codReferencia + ", ocerrencias="
				+ ocerrencias + ", "// dadoAcao=" + dadoAcao + ", " +
				+ "descTpAcao=" + descTpAcao + ", dataHoraAcao=" + dataHoraAcao
				+ ", descErroProcessamento=" + descErroProcessamento 
				+ ", codSite=" + codSite + "]";
		System.out.println("TRANSACAO ARV STRING: "+transacao);
		return transacao;
	}

}
