package br.com.cielo.monitoracao.cep.robot.stratus;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.github.ffpojo.FFPojoHelper;

import br.com.cielo.monitoracao.cep.robot.RoboCieloCEP;
import br.com.cielo.monitoracao.cep.robot.Transacao;
import br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico;
import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;
import br.com.cielo.parser.autorizador.stratus.ParserConverterUtils;
import br.com.cielo.parser.autorizador.stratus.TransacaoParserBuilder;
import br.com.cielo.parser.autorizador.stratus.TransacaoStratusParser;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_001;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_006;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_012;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_013;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_019;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_020;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_027;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_032;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_040;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_047;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_067;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_073;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_074;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_905;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_905_06;

public class TransacaoStratusBuilder extends TransacaoBuilderGenerico {

    boolean bandeiraAleatoria = false;
    boolean emissorAleatorio = false;
    boolean statusAleatorio = false;
    boolean produtoESubProdutoAleatorio = false;
    boolean ajustarDataHoraTran = false;
    boolean valVendaAleatorio = false;
    boolean maquinaAleatorio = false;
    boolean indicSkylineAleatorio = false;
    boolean siglaSolCapturaAleatorio = false;
    boolean standinAleatorio = false;
    boolean lynxAleatorio = false;
    boolean tipoTranDCCAleatorio = false;
    boolean statusDCCAleatorio = false;

    /**
     * Construtor responsavel em definir os campos que serao gerados
     * aleatoriamente.
     *
     * @param template
     *
     * @param variaveis Classe contendo as informacoes dos atributos que serao
     * gerados aleatoriamente.
     */
    public TransacaoStratusBuilder(Transacao template, VariaveisGeracao... variaveis) {
        for (int i = 0; i < variaveis.length; i++) {
            switch (variaveis[i]) {
                case BANDEIRA_ALEATORIA:
                    bandeiraAleatoria = true;
                    break;
                case EMISSOR_ALEATORIO:
                    emissorAleatorio = true;
                    break;
                case STATUS_ALEATORIO:
                    statusAleatorio = true;
                    break;
                case PRODUTO_E_SUBPRODUTO_ALEATORIO:
                    produtoESubProdutoAleatorio = true;
                    break;
                case AJUSTAR_DATAHORA_TRAN:
                    ajustarDataHoraTran = true;
                    break;
                case VAL_VENDA_ALEATORIO:
                    valVendaAleatorio = true;
                    break;
                case MAQUINA_ALEATORIO:
                    maquinaAleatorio = true;
                    break;
                case INDIC_SKYLINE_ALEATORIO:
                    indicSkylineAleatorio = true;
                    break;
                case SIGLA_SOL_CAPT_ALEATORIO:
                    siglaSolCapturaAleatorio = true;
                    break;
                case STANDIN:
                    standinAleatorio = true;
                    break;
                case LYNX:
                    lynxAleatorio = true;
                    break;
                case TIPO_TRANSACAO_DCC:
                    tipoTranDCCAleatorio = true;
                    break;
                case STATUS_DCC:
                    statusDCCAleatorio = true;
                    break;

            }
        }
    }

    /* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico#gerarNovaTransacao(java.util.Date)
     */
    public TransacaoGenerica gerarNovaTransacao(Date dataHoraTran) {
        //int indice= getAleatorioGenerico(0, 1);
        TransacaoStratus trans = new TransacaoStratus();
        if (isAjustarDataHoraTran()) {
            if (dataHoraTran == null) {
                setDataHoraTran(trans);
            } else {
                setDataHoraTran(trans, dataHoraTran);
            }
        }
        if (isBandeiraAleatoria()) {
            setBandeiraAleatoria(trans);
        }
        if (isEmissorAleatorio()) {
            setEmissorAleatorio(trans);
        }
        if (isMaquinaAleatorio()) {
            setMaquina(trans);
        }
        if (isProdutoESubProdutoAleatorio()) {
            setProdutoESubProduto(trans);
        }
        if (isValVendaAleatorio()) {
            setValVenda(trans);
        }
        if (isIndicSkylineAleatorio()) {
            setIndicSkyline(trans);
        }
        if (isSiglaSolCapturaAleatorio()) {
            setSiglaSolCaptura(trans);
        }
        setTipoTecnologia(trans);
        if (isStatusAleatorio()) {
            setStatusAleatorio(trans);
            setQuemRest(trans);
        }
        setNumTerminal(trans);
        setBin(trans);
        setCodigoEstabelecimento(trans);
        setCodigoErro(trans);
        setDataHoraTran(trans);
        setCep(trans);
        setStandin(trans);
        setLynx(trans);
        setStatusDCC(trans);
        setTipoTransacaoDCC(trans);

        return trans;
    }

    private void setBin(TransacaoStratus trans) {
        String numCar = trans.cpo010.getNumeroCartao();
        String bin = "" + getAleatorioGenerico(1, 999999);
        String zeros = "000000";
        numCar = zeros.substring(0, bin.length()) + bin + numCar.substring(6);
        trans.cpo010.setNumeroCartao(numCar);
    }

    /* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico#generateMessages(int)
     */
    public Collection<byte[]> generateMessages(int qtdade) throws Exception {
        List<byte[]> list = new ArrayList<byte[]>();

        Date now = new Date();
        if (RoboCieloCEP.getFileSamples() == null) {
            for (int i = 0; i < qtdade; i++) {
                byte[] msgBytes = ParserConverterUtils
                        .hexToBytes(gerarNovaTransacao(now).getTripa());
                if (msgBytes != null) {
                    list.add(msgBytes);
                } else {
                    i--;
                }
            }
        } else // Ler mensagens prontas de arquivo texto tambem e acrescenta a
        // lista de mensagens geradas aleatoriamente.
         if (RoboCieloCEP.getFileSamples() != null) {
                BufferedReader reader = RoboCieloCEP.getFileSamples();

                int count = RoboCieloCEP.fileCacheSize - 1;

                String line = null;
                while ((line = reader.readLine()) != null) {
                    byte[] lineBytes;
                    if ("COMPACTADA1".equals(RoboCieloCEP.fileFormat)) {
                        //-- Linha a linha completa
                        lineBytes = ParserConverterUtils.unzipMessage(
                                ParserConverterUtils.hexToBytes(line));
                    } else if ("COMPACTADA2".equals(RoboCieloCEP.fileFormat)) {
                        //-- Separado por ";", mensagem na ultima coluna
                        String[] splifile = line.split(";");
                        String content = (splifile[splifile.length - 1]);
                        lineBytes = ParserConverterUtils.unzipMessage(
                                ParserConverterUtils.hexToBytes(content));
                    } else if ("SPLIT1".equals(RoboCieloCEP.fileFormat)) {
                        //-- Separado por ":", mensagem na ultima coluna
                        String[] splifile = line.split(":");
                        String content = (splifile[splifile.length - 1]);
                        lineBytes = ParserConverterUtils.hexToBytes(content);
                    } else {
                        //-- Sem compacta��o, linha a linha
                        lineBytes = ParserConverterUtils.hexToBytes(line);
                    }
                    // ajusta data/hora caso seja necessario
                    lineBytes = adjustStratusDateTimeIfNecessary(lineBytes);
                    list.add(lineBytes);
                    if (RoboCieloCEP.isFileCachedEnabled() && count <= 0) {
                        break;
                    }
                    count--;
                    if (qtdade > 0 && qtdade <= RoboCieloCEP.countMessagesOUT.intValue()) {
                        line = null;
                        RoboCieloCEP.clearFilesReaderQueue(); // Zera caso tenha mais arquivos
                        break; // Se atingiu o limite setado para o buffer, p�ra
                    }
                }
                if (line == null) {
                    RoboCieloCEP.setAllCacheLoaded(true);

                }
            }
        return list;
    }

    private boolean isBandeiraAleatoria() {
        return bandeiraAleatoria;
    }

    private boolean isEmissorAleatorio() {
        return emissorAleatorio;
    }

    private boolean isStatusAleatorio() {
        return statusAleatorio;
    }

    private boolean isProdutoESubProdutoAleatorio() {
        return produtoESubProdutoAleatorio;
    }

    private boolean isAjustarDataHoraTran() {
        return ajustarDataHoraTran;
    }

    private boolean isValVendaAleatorio() {
        return valVendaAleatorio;
    }

    private boolean isMaquinaAleatorio() {
        return maquinaAleatorio;
    }

    private boolean isIndicSkylineAleatorio() {
        return indicSkylineAleatorio;
    }

    private boolean isSiglaSolCapturaAleatorio() {
        return siglaSolCapturaAleatorio;
    }

    private boolean isStandinAleatorio() {
        return standinAleatorio;
    }

    private boolean isLynxAleatorio() {
        return lynxAleatorio;
    }

    /**
     * Metodo responsovel em definir um valor aleatorio para Terminal.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setNumTerminal(TransacaoStratus trans) {
        int term_nu = getAleatorioGenerico(0, 299);

        CPO_013 cpo013 = trans.cpo013;
        cpo013.setCodigoTerminal(TransacaoStratus.terminais[term_nu]);
    }

    /**
     * Metodo responsavel em definir um valor aleatorio para Estabelecimento.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setCodigoEstabelecimento(TransacaoStratus trans) {
        int codEstab = getAleatorioGenerico(0, TransacaoStratus.idCodigoEstabelecimento.length - 1);

        CPO_012 cpo012 = trans.cpo012;
        cpo012.setNumeroEstabelecimento(TransacaoStratus.idCodigoEstabelecimento[codEstab]);
    }

    /**
     * Metodo responsovel em definir um valor aleatorio para CEP.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setCep(TransacaoStratus trans) {
        int cep = getAleatorioGenerico(0, TransacaoStratus.cep.length - 1);

        CPO_012 cpo012 = trans.cpo012;
        cpo012.setCep(TransacaoStratus.cep[cep]);
    }

    /**
     * Metodo responsovel em definir um valor aleatorio para Estabelecimento.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setCodigoMensagemErro(TransacaoStratus trans) {
        int codErro = getAleatorioGenerico(1, 2);

        CPO_027 cpo_027 = trans.cpo027;
        cpo_027.setCodigoResposta("" + codErro);
    }

    /**
     * Metodo responsovel em definir um valor aleatorio para Quem Responde.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setQuemRest(TransacaoStratus t) {
        int codResp = getAleatorioGenerico(0, TransacaoStratus.quemResps.length - 1);

        CPO_027 cpo027 = t.cpo027;
        cpo027.setQuemRespondeu(TransacaoStratus.quemResps[codResp]);
    }

    /**
     * Metodo responsovel em definir um valor aleatorio para data da transacaoo.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setDataHoraTran(TransacaoStratus t) {
        Date now = new Date();
        setDataHoraTran(t, now);
    }

    private void setDataHoraTran(TransacaoStratus t, Date d) {
        CPO_001 cpo1 = t.cpo001;
        cpo1.setDataHoraInput(d);

        // Incrementa entre 50 e 500 ms ao tempo de processamento da transacao
        //time+= getAleatorioGenerico(50, 500);		
        cpo1.setDataHoraHost(d);
    }

    /**
     * Metodo responsovel em definir um valor aleatorio para Bandeira.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setBandeiraAleatoria(TransacaoStratus t) {
        int indice = getAleatorioGenerico(0, TransacaoStratus.bandeira.length - 1);

        CPO_040 cpo040 = t.cpo040;
        cpo040.setBandeira(TransacaoStratus.bandeira[indice]);
    }

    /**
     * Metodo responsovel em definir um valor aleatorio para Banco Emissor.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setEmissorAleatorio(TransacaoStratus trans) {
        int indice = getAleatorioGenerico(0, TransacaoStratus.idEmissor.length - 1);

        CPO_040 cp040 = trans.cpo040;
        cp040.setBancoEmissor(TransacaoStratus.idEmissor[indice]);
    }

    /**
     * Metodo responsovel em definir um valor de venda.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setValVenda(TransacaoStratus trans) {
        CPO_001 cpo001 = trans.cpo001;
        cpo001.setValorVenda(103.75);
    }

    /**
     * Metodo responsovel em definir um valor aleatorio para Indicador Skyline e
     * Ciers.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setIndicSkyline(TransacaoStratus trans) {
        // mais nao skiline do que skyline
        int x = getAleatorioGenerico(0, 2);
        String indic = x == 0 || x == 1 ? "N" : "S";

        CPO_019 cpo019 = trans.cpo019;
        cpo019.setIndicadorSkyline(indic);
        if (indic == "S") {
            int tpSky = getAleatorioGenerico(0, TransacaoStratus.tipoSkyline.length - 1);
            cpo019.setIndicadorSkyline(TransacaoStratus.tipoSkyline[tpSky]);
            cpo019.setCiersMonitoracao(TransacaoStratus.ciersEnts[getAleatorioGenerico(0, TransacaoStratus.ciersEnts.length - 1)]);
        }
    }

    /**
     * Metodo responsovel em definir um valor aleatorio para maquina.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setMaquina(TransacaoStratus trans) {
        CPO_001 cpo001 = trans.cpo001;
        cpo001.setMaquina(TransacaoStratus.maquinas[getAleatorioGenerico(0, TransacaoStratus.maquinas.length - 1)]);
    }

    /**
     * Metodo responsovel em definir um valor aleatorio para produto e produto
     * secundario.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setProdutoESubProduto(TransacaoStratus trans) {
        int indice = getAleatorioGenerico(0, TransacaoStratus.idProdutos.length - 1);
        String produtoCompleto = TransacaoStratus.idProdutos[indice];

        CPO_006 cpo006 = trans.cpo006;
        cpo006.setProduto(produtoCompleto.substring(0, 4));

        CPO_074 cpo074 = trans.cpo074;
        cpo074.setProdutoSecundario(produtoCompleto.substring(4));
    }

    /**
     * Metodo responsovel em definir um valor aleatorio para Status, de acordo
     * com as combinacaoes.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setStatusAleatorio(TransacaoStratus trans) {
        CPO_006 cpo006 = trans.cpo006;
        CPO_027 cpo027 = trans.cpo027;
        CPO_020 cpo020 = trans.cpo020;
        CPO_040 cpo040 = trans.cpo040;

        // tenho 5 status: 1 e 2 - Cancelamento, 2 - Desfazimento, 3 - Aprovado, 4 - Negado, 5 - Capturado
        int statusId = getAleatorioGenerico(1, 20);
        switch (statusId) {
            case 1:
                cpo006.setTipoTransacao("103"); // Cancelamento
                cpo027.setMensagem("");
                this.setCodigoErro(trans);
                break;
            case 2:
                cpo006.setTipoTransacao("117"); // Desfazimento
                cpo006.setTransacao("1100"); // desfazimento parcial
                cpo027.setMensagem("TEMPO EXCEDIDO  "); // completa o desfazimento.
                this.setCodigoErro(trans);
                break;
            case 3:
                cpo006.setTipoTransacao("999"); // Desfazimento
                cpo027.setMensagem("");
                this.setCodigoErro(trans);
                break;
            case 4:
                cpo006.setTipoTransacao("607"); // Desfazimento
                cpo027.setMensagem("");
                this.setCodigoErro(trans);
                break;
            case 5:
                cpo006.setTipoTransacao("007"); // Desfazimento
                cpo027.setMensagem("");
                this.setCodigoErro(trans);
                break;
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
//				cpo040.setMonTecnologia("0"+getAleatorioGenerico(8, 9));
//				cpo006.setTransacao("0202"); // Confirmacaoo
//				cpo020.setCodigoResposta("00"); // CAPTURADO
//				cpo027.setMensagem("");
//				break;					
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
                cpo006.setTransacao("1120");  // Aprovado parcial
                cpo027.setMensagem("APROVADO        ");
                break;
            case 16:
                cpo006.setTransacao("1100");  // Aprovado parcial
                cpo027.setMensagem("00APROVADO      ");
                break;
            case 17:
            case 18:
            case 19:
            case 20: // Negado.
                cpo006.setTipoTransacao("117");
                cpo006.setTransacao("1222");  // Passa por todos;
                cpo027.setMensagem("XXXqualquercoisa");
                this.setCodigoErro(trans);
                break;
            default:
                cpo006.setTransacao("1100");  // Aprovado parcial
                cpo027.setMensagem("00APROVADO      ");
        }
    }

    /**
     * Metodo responsavel em definir um valor aleatorio para o Codigo de Erro.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setCodigoErro(TransacaoStratus trans) {
        CPO_027 cpo027 = trans.cpo027;
        cpo027.setCodigoResposta(TransacaoStratus.idCodigoErro[getAleatorioGenerico(0, TransacaoStratus.idCodigoErro.length - 1)]);
    }

    /**
     * Metodo responsovel em definir um valor aleatorio para Tipo de Tecnologia.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setTipoTecnologia(TransacaoStratus trans) {
        int pos = getAleatorioGenerico(0, TransacaoStratus.tipoTecnologia.length - 1);

        CPO_040 cpo040 = trans.cpo040;
        cpo040.setMonTecnologia(TransacaoStratus.tipoTecnologia[pos]);
    }

    /**
     * Metodo responsovel em definir um valor aleatorio para Indicador Standin.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setStandin(TransacaoStratus trans) {
        int indice = getAleatorioGenerico(0, 1);
        CPO_040 cpo040 = trans.cpo040;
        cpo040.setStandIn(TransacaoStratus.standin[indice]);

    }

    /**
     * Metodo responsovel em definir um valor aleatorio para Indicador Standin.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setLynx(TransacaoStratus trans) {
        int indice = getAleatorioGenerico(0, 1);
        String pStatus = TransacaoStratus.lynx[indice];
        int indiceTimeout = getAleatorioGenerico(0, 1);
        String pStatusTimout = TransacaoStratus.timeoutLynx[indiceTimeout];
        pStatusTimout = pStatus == "N" ? "N" : pStatusTimout;
        if (pStatus == "S") {
            CPO_067 cpo067 = trans.carregaCPO_067();
            cpo067.setTimeout(pStatusTimout);
            trans.transacaoStratus.addCampoLogico("CPO_067", cpo067);
        }

    }

    /**
     * Metodo responsovel em definir um valor aleatorio para Indicador DCC.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setStatusDCC(TransacaoStratus trans) {
        int indice = getAleatorioGenerico(0, TransacaoStratus.statusDCC.length - 1);
        String pStatus = TransacaoStratus.statusDCC[indice];
        CPO_073 cpo073 = new CPO_073();
        cpo073.setFlagDCC(pStatus);
        trans.transacaoStratus.addCampoLogico("CPO_073", cpo073);
    }

    /**
     * Metodo responsovel em definir um valor aleatorio para Tipo de Transacao
     * DCC.
     *
     * @param trans Transacao Stratus.
     */
    private void setTipoTransacaoDCC(TransacaoStratus trans) {
        int indice = getAleatorioGenerico(0, TransacaoStratus.tipoTransacaoDCC.length - 1);
        String pStatus = TransacaoStratus.tipoTransacaoDCC[indice];
        CPO_027 cpo027 = new CPO_027();
        cpo027.setObservacao(pStatus);
        trans.transacaoStratus.addCampoLogico("CPO_027", cpo027);
    }

    /**
     * Metodo responsavel em definir um valor aleatorio para solucaoo de
     * captura, de acordo com as combinacaoes.
     *
     * @param trans Transacaoo Stratus.
     */
    private void setSiglaSolCaptura(TransacaoStratus trans) {
        CPO_032 cpo032 = trans.cpo032;
        CPO_040 cpo040 = trans.cpo040;
        CPO_047 cpo047 = trans.cpo047;

        int solucaoCapId = getAleatorioGenerico(1, 11);
        switch (solucaoCapId) {
            case 1:
            case 2: // POS Banda Larga
                cpo040.setMonTecnologia(TransacaoStratus.tipoTecnologia[15]);

                int indice = getAleatorioGenerico(0, TransacaoStratus.idModoConexao.length - 1);
                String idModConexao = TransacaoStratus.idModoConexao[indice];
                cpo032.setModoEntrada("PLSCX" + idModConexao + "YYYYY");
                break;
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9: // Demais solucaoes
                int pos = getAleatorioGenerico(0, TransacaoStratus.tipoTecnologia.length - 1);
                String strTpTec = TransacaoStratus.tipoTecnologia[pos];
                while (strTpTec.equals("15")) {// Verifica se o diferente de POS Banda Larga. 
                    strTpTec = TransacaoStratus.tipoTecnologia[getAleatorioGenerico(0, TransacaoStratus.tipoTecnologia.length - 1)];
                }
                cpo040.setMonTecnologia(TransacaoStratus.tipoTecnologia[pos]);

                indice = getAleatorioGenerico(0, TransacaoStratus.idModoConexao.length - 1);
                idModConexao = TransacaoStratus.idModoConexao[indice];
                cpo032.setModoEntrada("PLSCX" + idModConexao + "YYYYY");
                break;
            case 10:
            case 11: // POS GPRS
                pos = getAleatorioGenerico(0, TransacaoStratus.tipoTecnologia.length - 1);
                strTpTec = TransacaoStratus.tipoTecnologia[pos];
                while (!strTpTec.equals("01") && !strTpTec.equals("02") && !strTpTec.equals("03") && !strTpTec.equals("04")) { // Verifica Opcaoes de POS
                    strTpTec = TransacaoStratus.tipoTecnologia[getAleatorioGenerico(0, TransacaoStratus.tipoTecnologia.length - 1)];
                }
                cpo040.setMonTecnologia(strTpTec);

                idModConexao = TransacaoStratus.idModoConexao[8]; // Seta para 70 - CONEXAO GPRS / CDMA 1X (WIRE-LESS OUTDOOR);
                cpo032.setModoEntrada("PLSCX" + idModConexao + "YYYYY");

                int indiceOpe = getAleatorioGenerico(0, TransacaoStratus.operadora.length - 1);
                cpo047.setCodigoOperadora(TransacaoStratus.operadora[indiceOpe]);
                break;
            default:
                pos = getAleatorioGenerico(0, TransacaoStratus.tipoTecnologia.length - 1);
                cpo040.setMonTecnologia(TransacaoStratus.tipoTecnologia[pos]);

                indice = getAleatorioGenerico(0, TransacaoStratus.idModoConexao.length - 1);
                idModConexao = TransacaoStratus.idModoConexao[indice];
                cpo032.setModoEntrada("PLSCX" + idModConexao + "YYYYY");
        }
    }

    public static byte[] adjustStratusDateTimeIfNecessary(byte[] lineBytes) {
        if (RoboCieloCEP.isAdjustStratusDate) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DateTimeFormatter fmt = DateTimeFormat.forPattern("yyMMddHHmmss");
            try {
                int idx = 0;
                String release = "";
                TransacaoStratusParser builder = TransacaoParserBuilder.getTransacaoStratusParser();
                FFPojoHelper ffpojo = builder.getFFPojoInstance();
                while (idx < lineBytes.length) {
                    // Recupera o nome do campo fisico nos 2 primeiros bytes.
                    byte[] campoNome = ParserConverterUtils.subArray(lineBytes, idx, 2);
                    int nrCampoStratus = ParserConverterUtils.hexToDecimal(ParserConverterUtils.bytesToHex(campoNome));
                    idx += 2;

                    //Analise e recupera o tamanho do campo fisico nos 2 bytes seguintes.
                    byte[] campoTamanho = ParserConverterUtils.subArray(lineBytes, idx, 2);
                    int valueTam = ParserConverterUtils.hexToDecimal(ParserConverterUtils.bytesToHex(campoTamanho));
                    idx += 2;

                    // Recupera o conjunto de bytes correspondete ao valor do campo fisico. Esse campo contem a string dos campos logicos.
                    byte[] campoValor = ParserConverterUtils.subArray(lineBytes, idx, valueTam);
                    String valorCampoStr = ParserConverterUtils.hexToString(campoValor);

                    // Move index para o proximo campo(no array de bytes) da mensagem fisica recebida.
                    idx += valueTam;

                    // Preenche novo array de bytes
                    baos.write(campoNome);
                    baos.write(campoTamanho);

                    // Verifica a release
                    if (nrCampoStratus == 13) {
                        CPO_013 cpo013 = (CPO_013) ffpojo.createFromText(CPO_013.class, valorCampoStr);
                        release = cpo013.getVersaoTerminal().substring(2, 4);
                    }
                    String novoValorCampoStr;
                    if (nrCampoStratus == 905) {
                        CPO_905_06 campo905_06 = null;
                        CPO_905 cpo905 = null;
                        
                        Date dtHoraBit47 = null;
                        String dataHora = null;
// Verifica o release da especifica��o POS.
                        if ("06".equals(release)) {
                            campo905_06 = (CPO_905_06) ffpojo.createFromText(CPO_905_06.class, valorCampoStr);

                            try {
                                dataHora = campo905_06.getBit47Pref_1().substring(0, campo905_06.getBit47Pref_1().indexOf("FFFF"));
                                dtHoraBit47 = fmt.parseDateTime(dataHora).toDate();
                            } catch (Exception ex) {
                                System.out.println("Erro ajustando data Bit47. Considerando informa��o nulla.");
                            }
                            if (dtHoraBit47 != null) {
                                // ajusta para hr corrente.
                                Date newDtHoraBit47 = new Date();
                                System.out.println(">>> ajusta hora bit47 de [" + dtHoraBit47 + "] para [" + newDtHoraBit47);
                                String newDtHoraBit47Str = fmt.print(new DateTime(newDtHoraBit47));
                                campo905_06.setBit47Pref_1(campo905_06.getBit47Pref_1().replace(dataHora, newDtHoraBit47Str));
                            }
                            novoValorCampoStr = ffpojo.parseToText(campo905_06);
                        } else {
                            cpo905 = (CPO_905) ffpojo.createFromText(CPO_905.class, valorCampoStr);

                            try {
                                dataHora = cpo905.getBit47Pref_1().substring(0, cpo905.getBit47Pref_1().indexOf("FFFF"));
                                dtHoraBit47 = fmt.parseDateTime(dataHora).toDate();
                            } catch (Exception ex) {
                                System.out.println("Erro ajustando data Bit47. Considerando informa��o nulla.");
                            }

                            if (dtHoraBit47 != null) {
                                // ajusta para hr corrente.
                                Date newDtHoraBit47 = new Date();
                                System.out.println(">>> ajusta hora bit47 de [" + dtHoraBit47 + "] para [" + newDtHoraBit47);
                                String newDtHoraBit47Str = fmt.print(new DateTime(newDtHoraBit47));
                                cpo905.setBit47Pref_1(cpo905.getBit47Pref_1().replace(dataHora, newDtHoraBit47Str));
                            }
                            novoValorCampoStr = ffpojo.parseToText(cpo905);

                        }

                        byte[] novoValorCampo905 = novoValorCampoStr.getBytes("CP1047");

                        // Preenche o novo array de bytes com o valor do novo campo010, e do restante dos bytes da transa��o original.
                        baos.write(novoValorCampo905);
                        //baos.write(lineBytes, idx, (lineBytes.length - idx));

                    } else if (nrCampoStratus == 1) {
                        CPO_001 cp0_001 = (CPO_001) ffpojo.createFromText(CPO_001.class, valorCampoStr);
                        cp0_001.setDataHoraHost(new Date());
                        novoValorCampoStr = ffpojo.parseToText(cp0_001);
                        byte[] novoValorCampo001 = novoValorCampoStr.getBytes("CP1047");
                        baos.write(novoValorCampo001);
                    }   else {
                        baos.write(campoValor);
                    }
                }
                return baos.toByteArray();
            } catch (Exception e) {
                System.err.println("Erro processando mensagem original para alterar data bit47");
                e.printStackTrace();
                return lineBytes;
            }

        } else {
            return lineBytes;
        }
    }

}
