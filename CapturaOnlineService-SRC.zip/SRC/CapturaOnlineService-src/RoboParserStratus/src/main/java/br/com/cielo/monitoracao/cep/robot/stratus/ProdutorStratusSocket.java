package br.com.cielo.monitoracao.cep.robot.stratus;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import br.com.cielo.monitoracao.cep.robot.ProducerGenerico;
import br.com.cielo.parser.autorizador.stratus.ParserConverterUtils;

public class ProdutorStratusSocket extends ProducerGenerico {

    private static OutputStream outputStream;
    private static Socket socket;
    private static boolean iniciando = false;

    public static void closeSocket() {
        if (socket != null && !socket.isClosed()) {
            try {
                System.out.println("Encerrando o scoket...");
                outputStream.close();
                socket.close();
            } catch (Exception e) {
            }
        }
    }

    public ProdutorStratusSocket(String socketAddress, boolean enviarMsgCompactada) {
        super(socketAddress, enviarMsgCompactada);
    }

    private synchronized Socket getSocket() {
        // Se ja tiver alguma thread inicializando o socket, aguarda...
        if (iniciando) {
            while (iniciando) {
                try {
                    System.out.println("Thread aguardando conex�o socket...");
                    Thread.sleep(1000);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        if (socket == null) {
            iniciando = true;
            try {

                String[] addressSplit = socketAddress.split(":");
                String hostname = addressSplit[0];
                int porta = Integer.parseInt(addressSplit[1]);

                SocketAddress adddr = new InetSocketAddress(hostname, porta); // initialization not shown
                socket = new Socket();
                socket.setReuseAddress(true);
                socket.bind(null);
                socket.connect(adddr);

            } catch (IOException e) {
                throw new RuntimeException("N�o foi poss�vel criar o Socket", e);
            }
            iniciando = false;
        }
        return socket;
    }

    private synchronized OutputStream getOutputStream() {
        if (outputStream == null) {
            try {
                outputStream = getSocket().getOutputStream();
            } catch (IOException e) {
                throw new RuntimeException("N�o foi poss�vel criar o outputStream no socket", e);
            }
        }
        return outputStream;
    }

    private void send(byte[] bytes) {
        try {
            OutputStream st = getOutputStream();
            synchronized (st) {
                st.write(bytes);
                st.flush();
            }
        } catch (IOException e) {
            throw new RuntimeException("N�o foi poss�vel enviar a mensagem", e);
        }
    }

    @Override
    public void sendMessage(byte[] bytes) throws Exception {
        byte[] msgEmBytes;
        
        TransacaoStratusBuilder.adjustStratusDateTimeIfNecessary(bytes);
        // Descompacta mensagem recebida de arquivo compactado
        if (enviarMsgCompactada) {
            msgEmBytes = ParserConverterUtils.unzipMessage(bytes);
        } else {
            msgEmBytes = bytes;
        }
        //Acrescentar tamanho na mensagem a ser enviada ao stratus.
        String tamanhoHex = String.format("%1$4s", Integer.toString(msgEmBytes.length, 16)).replace(' ', '0');
        String msgOrig = ParserConverterUtils.bytesToHex(msgEmBytes);
        String msgHexFinal = tamanhoHex + msgOrig;
        byte[] tripaFinal = ParserConverterUtils.hexToBytes(msgHexFinal);
        send(tripaFinal);
        Thread.sleep(1);
    }
}
