package br.com.cielo.monitoracao.cep.robot;

import br.com.cielo.monitoracao.cep.robot.arv.ProdutorArv;
import br.com.cielo.monitoracao.cep.robot.cepsim.ProducerBAM;
import br.com.cielo.monitoracao.cep.robot.lci.ProducerLCIBAM;
import br.com.cielo.monitoracao.cep.robot.lci.ProdutorLCI;
import br.com.cielo.monitoracao.cep.robot.mobile.ProdutorAutorecarga;
import br.com.cielo.monitoracao.cep.robot.mobile.ProdutorDePara;
import br.com.cielo.monitoracao.cep.robot.mobile.ProdutorP2P;
import br.com.cielo.monitoracao.cep.robot.mobile.ProdutorPagtoCelular;
import br.com.cielo.monitoracao.cep.robot.push.ProdutorPush;
import br.com.cielo.monitoracao.cep.robot.stratus.ProdutorStratus;
import br.com.cielo.monitoracao.cep.robot.stratus.cep.ProdutorCepTopicStratus;
import br.com.cielo.monitoracao.cep.robot.orizon.ProdutorOrizon;
import br.com.cielo.monitoracao.cep.robot.coban.ProdutorCoban;


public class JmsProducerFactory { 

	public static ProducerGenerico getProducer(String type, String queueJndiName, String urlQueueServer, String topicJndiName, String urlTopicServer) {
		if (type.equals("linkci-bam")) {
			return new ProducerLCIBAM(queueJndiName, urlQueueServer,topicJndiName, urlTopicServer);
		} else if (type.equals("linkci-checkin")) {
			return new ProdutorLCI(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		} else if (type.equals("linkci-rec")) {
			return new ProdutorLCI(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		} else if (type.equals("linkci-hec")) {
			return new ProdutorLCI(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		} else if (type.equals("linkci-cadpor")) {
			return new ProdutorLCI(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		}else if (type.equals("linkci-cadpor-invalida")) {
			return new ProdutorLCI(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		} else if (type.equals("linkci-res")) {
			return new ProdutorLCI(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		} else if (type.equals("linkci-camp")) {
			return new ProdutorLCI(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		} else if (type.equals("mainframe-bam") || type.equals("tps-bam") || type.equals("mainframe-bam-hist") || type.equals("tps-bam-hist")) {
			return new ProducerBAM(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		} else if (type.equals("mainframe")) {
			return new Producer(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		} else if (type.equals("floridaPgtoCelular")) {
			return new ProdutorPagtoCelular(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		} else if (type.equals("dePara")) {
			return new ProdutorDePara(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		} else if (type.equals("p2p")) {
			return new ProdutorP2P(queueJndiName, urlQueueServer ,topicJndiName, urlTopicServer);
		} else if (type.equals("autorrecarga")) {
			return new ProdutorAutorecarga(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		} else if (type.equals("push")) {
			return new ProdutorPush(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		} else if (type.equals("stratus")) {
			return new ProdutorStratus(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		} else if (type.equals("stratus-parseado")) {
			return new ProdutorCepTopicStratus(queueJndiName, urlQueueServer ,topicJndiName, urlTopicServer);
		} else if (type.equals("orizon")) {
			return new ProdutorOrizon(queueJndiName, urlQueueServer ,topicJndiName, urlTopicServer);
		} else if (type.equals("coban")) {
			return new ProdutorCoban(queueJndiName, urlQueueServer ,topicJndiName, urlTopicServer);
		} else if (type.equals("arv")) {
			return new ProdutorArv(queueJndiName, urlQueueServer ,topicJndiName, urlTopicServer);
		}
		throw new UnsupportedOperationException("tipo de producer invalido:"+type);
	}
}
