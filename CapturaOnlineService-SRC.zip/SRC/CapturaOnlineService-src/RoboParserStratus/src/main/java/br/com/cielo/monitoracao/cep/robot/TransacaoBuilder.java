package br.com.cielo.monitoracao.cep.robot;


import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.ibm.as400.access.AS400PackedDecimal;

public class TransacaoBuilder extends TransacaoBuilderGenerico {
	
	boolean bandeiraAleatoria = false;
	boolean emissorAleatorio = false;
	boolean statusAleatorio = false;
	boolean produtoESubProdutoAleatorio = false;
	boolean ajustarDataHoraTran = false;
	boolean valVendaAleatorio = false;
	boolean maquinaAleatorio = false;
	boolean indicSkylineAleatorio = false;
	
	private boolean isBandeiraAleatoria() {
		return bandeiraAleatoria;
	}
	private boolean isEmissorAleatorio() {
		return emissorAleatorio;
	}
	private boolean isStatusAleatorio() {
		return statusAleatorio;
	}
	private boolean isProdutoESubProdutoAleatorio() {
		return produtoESubProdutoAleatorio;
	}
	private boolean isAjustarDataHoraTran() {
		return ajustarDataHoraTran;
	}
	private boolean isValVendaAleatorio() {
		return valVendaAleatorio;
	}
	private boolean isMaquinaAleatorio() {
		return maquinaAleatorio;
	}
	
	private boolean isIndicSkylineAleatorio() {
		return indicSkylineAleatorio;
	}
	
	TransacaoBuilder(Transacao template, VariaveisGeracao ... variaveis){
		for (int i = 0; i < variaveis.length; i++) {
			switch (variaveis[i]){
			case BANDEIRA_ALEATORIA:
				bandeiraAleatoria=true;break;
			case EMISSOR_ALEATORIO:
				emissorAleatorio=true;break;
			case STATUS_ALEATORIO:
				statusAleatorio=true;break;
			case PRODUTO_E_SUBPRODUTO_ALEATORIO:
				produtoESubProdutoAleatorio = true;
				break;
			case AJUSTAR_DATAHORA_TRAN:
				ajustarDataHoraTran = true;
				break;
			case VAL_VENDA_ALEATORIO:
				valVendaAleatorio = true;
				break;
			case MAQUINA_ALEATORIO:
				maquinaAleatorio = true;
				break;
			case INDIC_SKYLINE_ALEATORIO:
				indicSkylineAleatorio = true;
				break;
			}

		}
	}
	
	public Transacao gerarNovaTransacao(Date dataHoraTran){
		Transacao t = new Transacao();
		if (dataHoraTran == null) {
			dataHoraTran = new Date();
		}
		if (isAjustarDataHoraTran()){
			setDataHoraTran(t);		
		}
		if (isBandeiraAleatoria()){
			setBandeiraAleatoria(t);
		}
		if (isEmissorAleatorio()) {
			setEmissorAleatorio(t);
		}
		if (isMaquinaAleatorio()) {
			setMaquina(t);
		}
		if (isProdutoESubProdutoAleatorio()) {
			setProdutoESubProduto(t);
		}
		if (isStatusAleatorio()) {
			setStatusAleatorio(t);
			setQuemRest(t);
		}
		if (isValVendaAleatorio()){
			setValVenda(t);
		}
		if (isIndicSkylineAleatorio()){
			setIndicSkyline(t);
		}
		setNumTerminal(t);
		setTpTecn(t);
		return t;
	}
	private void setTpTecn(Transacao t) {
		int pos=getAleatorioGenerico(0, Transacao.tpTecns.length-1);
		t.tipoTecn = Transacao.tpTecns[pos];
		
	}
	private void setNumTerminal(Transacao t) {
		int term_nu = getAleatorioGenerico(0, 299);
		t.terminal = Transacao.terminais[term_nu];
	}
	
	private void setQuemRest(Transacao t) {
		int codResp = getAleatorioGenerico(0, Transacao.quemResps.length-1);
		t.quemResp = Transacao.quemResps[codResp];
	}
	
	private  void setDataHoraTran(Transacao t) {
		// pegar de 1 -> 63
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
		t.dtaTran = sdf.format(now);
		t.tpsData = t.dtaTran;
		sdf = new SimpleDateFormat("HHmmss");
		t.horaTran = sdf.format(now);
		t.tpsHora = t.horaTran;
		
		// ajusta timestamp transacao entrada e saida
		long time = +now.getTime();
		t.hrTranInp = ""+time;
		t.hrTranInp = getCharsToFill(15 - t.hrTranInp.length(), "0") + t.hrTranInp;
		// incrementa entre 50 e 500 ms ao tempo de processamento da transacao
		time += getAleatorioGenerico(50,500);
		t.hrTranOut = ""+time;
		t.hrTranOut = getCharsToFill(15 - t.hrTranOut.length(), "0") + t.hrTranOut;

	}
	
	
	private  void setBandeiraAleatoria(Transacao t) {
		// pegar de 1 -> 63

		String num = "" + getAleatorioGenerico(1, 63);
		t.bandeira = "000".substring(0, 3 - num.length()) + num;
	}

	private  void setEmissorAleatorio(Transacao t) {
		int indice = getAleatorioGenerico(0, Transacao.idEmissor.length - 1);
		t.banco = Transacao.idEmissor[indice];
	}

	private  void setValVenda(Transacao t) {
		t.valVenda = new String(convertAS400(103.75));
	}
	public void setIndicSkyline(Transacao t) {
		// mais nao skiline do que skyline
		int x = getAleatorioGenerico(0, 2);
		String indic = x==0 || x == 1 ? "N" : "S";
		t.indicSkyline = indic;
		if (indic == "S") {
			int tpSky = getAleatorioGenerico(0, t.tiposSkyline.length-1);
			t.indicSkyline = t.tiposSkyline[tpSky];
			t.ciersEnt = t.ciersEnts[getAleatorioGenerico(0, t.ciersEnts.length-1)];
		}
	}
	private  void setMaquina(Transacao t) {
		t.chaveDaMaquina = Transacao.maquinas[getAleatorioGenerico(0, Transacao.maquinas.length - 1)];
	}
	private  void setProdutoESubProduto(Transacao t) {
		int indice = getAleatorioGenerico(0, Transacao.idProdutos.length - 1);
		String produtoCompleto = Transacao.idProdutos[indice];
		t.produto = produtoCompleto.substring(0, 3);
		t.subProduto = produtoCompleto.substring(3);
	}

	private  byte[] convertAS400(double valor) {
		AS400PackedDecimal as400PackedDecimal = new AS400PackedDecimal(12, 2);
		byte[] packed = new byte[7];
		as400PackedDecimal.toBytes(valor, packed);
		return packed;
	}
	private  void setStatusAleatorio(Transacao t) {
		// tenho 4 status: 1 e 2 - Cancelamento, 2 - Desfazimento, 3 - Aprovado,
		// 4 - Negado
		int statusId = getAleatorioGenerico_2(1, 20);
		switch (statusId) {
		case 1:
			t.tipTra = "103";
			break;
		case 2:
			t.tipTra = "117"; // OK
			t.idMens = "1100"; // desfazimento parcial
			t.mensagem = "TEMPO EXCEDIDO  "; // completa o desfazimento.
			break;
		case 3:
			t.tipTra = "999"; // Desfazimento
			break;
		case 4:
			t.tipTra = "607"; // Desfazimento
			break;
		case 5:
			t.tipTra = "007"; // Desfazimento
			break;
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
			t.tipTra = "0202"; // capturado
			t.mensagem = "CAPTURADA        ";
			break;
		case 11:
		case 12:
		case 13:
		case 14:
		case 15:
			t.idMens = "1120"; // aprovado parcial
			t.mensagem = "APROVADO        ";
			break;
		case 16:
			t.idMens = "1100"; // aprovado parcial
			t.mensagem = "00APROVADO      ";
			break;
		case 20: // Negado.
			t.idMens = "1222"; // passa por todos;
			t.tipTra = "117"; //
			t.mensagem = "XXXqualquercoisa";
			break;
		default:
			t.idMens = "1100"; // aprovado parcial
			t.mensagem = "00APROVADO      ";

		}
	}
	
	public Collection<byte[]> generateMessages(int qtdade) throws Exception {

		List<byte[]> list = new ArrayList<byte[]>();
		
		Date now = new Date();
		for (int i = 0; i < qtdade; i++) {
			list.add(getABCDICFromAscII(gerarNovaTransacao(now)
					.getTripa()));
		}
		return list;
	}

	private byte[] getABCDICFromAscII(String ascii)
			throws UnsupportedEncodingException {
		return ascii.getBytes("Cp1047");
	}	
	

}
