package br.com.cielo.monitoracao.cep.robot.stratus.cep;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.naming.Context;
import javax.naming.InitialContext;

import br.com.cielo.monitoracao.cep.robot.ProducerGenerico;

/**
 *<B>Projeto: RoboCEP</B><BR>
 *
 * Classe responsavel em enviar a mensagem, no formato do Stratus, para a fila do ActiveMQ correspondente.
 *	 
 *<DL><DT><B>Criada em:</B><DD>23/10/2013</DD></DL>
 *
 * @author Nemer Daud.
 * @version 1.0
 */
public class ProdutorCepTopicStratus extends ProducerGenerico{
	private String queueName= "bam_monitoracao_stratus.queue.1.in";
	private Context ctx;
	/**
	 * Construtor definindo o endereco do server MQ, e nome da fila a ser enviado.
	 * 
	 * @param queueJndiName
	 * 			Nome da fila a ser enviado
	 * @param urlQueueServer
	 * 			URL do Server MQ.
	 */
	public ProdutorCepTopicStratus(String queueJndiName, String urlQueueServer,String topicJndiName, String urlTopicServer) {
		super(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		if (queueJndiName == null &&  topicJndiName == null) {
			setQueueJndiName(queueName);
		}
	}

	static long messageOrderId= System.currentTimeMillis();

	/* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.cep.robot.ProducerGenerico#sendMessage(byte[])
	 */
	@Override
	public void sendMessage(byte[] bytes) throws Exception {		
        ObjectMessage om= getSession().createObjectMessage();
        ByteArrayInputStream bos = new ByteArrayInputStream(bytes);
		ObjectInputStream oi = new ObjectInputStream(bos);
        Serializable o = (Serializable) oi.readObject();
        om.setObject(o);
        om.setLongProperty("MESSAGE_ORDER_ID", messageOrderId++);
        
        // Enviando a mensagem ao AcitveMQ.
        getProducer().send(om);
        
		Thread.sleep(1);
	}
	
	protected Connection getConnection() throws Exception {
		if (cachedConnection == null){
			Properties props = new Properties();
			props.setProperty(Context.INITIAL_CONTEXT_FACTORY,"weblogic.jndi.WLInitialContextFactory");
			props.setProperty(Context.PROVIDER_URL,getUrlQueueServer());
			ctx = new InitialContext(props);
			TopicConnectionFactory connectionFactory = 
				(TopicConnectionFactory) ctx.lookup("jms.MonitoracaoProducerConnFactory");
			cachedConnection = connectionFactory.createTopicConnection();
			cachedConnection.start();	
		}
		
		return cachedConnection;
	}
	protected Session getSession() throws Exception {
		if (cachedSession == null) {
			cachedSession = ((TopicConnection)getConnection()).createTopicSession(false,
					Session.AUTO_ACKNOWLEDGE);
		}
		return cachedSession;
	}
	protected MessageProducer getProducer() throws Exception {
		if (cachedProducer == null) {
			Topic destination = (Topic) ctx.lookup(getTopicJndiName());

			cachedProducer = ((TopicSession)cachedSession).createPublisher(destination);
		}
		return cachedProducer;
	}
	
	
}
