package br.com.cielo.monitoracao.cep.robot.stratus;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;

import com.github.ffpojo.FFPojoHelper;
import com.github.ffpojo.exception.FFPojoException;

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;
import br.com.cielo.parser.autorizador.canonico.vo.InformacoesDCC;
import br.com.cielo.parser.autorizador.canonico.vo.StatusDCC;
import br.com.cielo.parser.autorizador.stratus.ParserConverterUtils;
import br.com.cielo.parser.autorizador.stratus.vo.TransacaoStratusVO;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_001;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_006;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_010;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_012;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_013;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_019;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_020;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_027;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_030;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_032;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_040;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_047;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_067;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_068;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_074;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CPO_901;
import br.com.cielo.parser.autorizador.stratus.vo.logicos.CampoLogicoVO;

/**
 *<B>Projeto: RoboCEP</B><BR>
 *
 * Classe responsavel em gerar transacoes, simulando dados vindo do Stratus.
 *	 
 *<DL><DT><B>Criada em:</B><DD>28/10/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class TransacaoStratus implements TransacaoGenerica{
	public TransacaoStratusVO transacaoStratus= new TransacaoStratusVO();
	public CPO_001 cpo001;
	public CPO_006 cpo006;
	public CPO_010 cpo010;
	public CPO_012 cpo012;
	public CPO_013 cpo013;
	public CPO_019 cpo019;
	public CPO_020 cpo020;	
	public CPO_027 cpo027;
	public CPO_030 cpo030;
	public CPO_032 cpo032;
	public CPO_040 cpo040;
	public CPO_047 cpo047;
	public CPO_067 cpo067;
	public CPO_068 cpo068;
	public CPO_074 cpo074;
	public CPO_901 cpo901;
	
	
	
	/**
	 * Construtor padrao, responsavel em gerar e popular os campos CPO da transacao vinda do Stratus.
	 */
	public TransacaoStratus() {
		cpo001= this.carregaCPO_001();
		transacaoStratus.addCampoLogico("CPO_001", cpo001);
		
		cpo006= this.carregaCPO_006();
		transacaoStratus.addCampoLogico("CPO_006", cpo006);
		
		cpo010= this.carregaCPO_010();
		transacaoStratus.addCampoLogico("CPO_010", cpo010);
		
		cpo012= this.carregaCPO_012();
		transacaoStratus.addCampoLogico("CPO_012", cpo012);
		
		cpo013= this.carregaCPO_013();
		transacaoStratus.addCampoLogico("CPO_013", cpo013);
		
		cpo019= this.carregaCPO_019();
		transacaoStratus.addCampoLogico("CPO_019", cpo019);
		
		cpo020= this.carregaCPO_020();
		transacaoStratus.addCampoLogico("CPO_020", cpo020);
		
		cpo027= this.carregaCPO_027();
		transacaoStratus.addCampoLogico("CPO_027", cpo027);
		
		cpo030= this.carregaCPO_030();
		transacaoStratus.addCampoLogico("CPO_030", cpo030);
		
		cpo032= this.carregaCPO_032();
		transacaoStratus.addCampoLogico("CPO_032", cpo032);
		
		cpo040= this.carregaCPO_040();
		transacaoStratus.addCampoLogico("CPO_040", cpo040);
		
		cpo047= this.carregaCPO_047();
		transacaoStratus.addCampoLogico("CPO_047", cpo047);

		/* Simula��o para n�o ter valor para Lynx
			cpo067= this.carregaCPO_067();
			transacaoStratus.addCampoLogico("CPO_067", cpo067);
		*/
		cpo068= this.carregaCPO_068();
		transacaoStratus.addCampoLogico("CPO_068", cpo068);
		
		cpo074= this.carregaCPO_074();
		transacaoStratus.addCampoLogico("CPO_074", cpo074);
		
		cpo901= this.carregaCPO_901();
		transacaoStratus.addCampoLogico("CPO_901", cpo901);		
		
	}

	/* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.cep.robot.TransacaoGenerica#getTripa()
	 */
	public String getTripa(){
		StringBuilder tripaStratus= new StringBuilder();
		
		//Monta string de retorno do Stratus, utilizando o framework FFPojo para cada CPO.
		try {
			FFPojoHelper ffpojo= FFPojoHelper.getInstance();
				
			ArrayList<String> camposCPO= transacaoStratus.getNomesCamposLogico();
			Collections.sort(camposCPO);
			
			for(Iterator<String> iterator= camposCPO.iterator(); iterator.hasNext();) {
				String nomeCampo= iterator.next();
				CampoLogicoVO cpo= transacaoStratus.getCampoLogico(nomeCampo);
				
				nomeCampo= nomeCampo.substring("CPO_".length());
				String campoHex= String.format("%1$4s", Integer.toString(Integer.parseInt(nomeCampo), 16)).replace(' ', '0');
								
				String tripaValorCampo= null;
				String tripaValorCampoHex= null;
				String tamanhoHex= null;
				if(nomeCampo.equals("068")){
					//Converte valores binarios na tripa convertida.
					CPO_068 cpo068= (CPO_068) cpo;
					cpo068.carregaCampoBinario();
					byte[] cpoBin= cpo068.getValorCampoBinario();
					
					tripaValorCampo= ParserConverterUtils.stringToHex(new String(cpoBin));
					
					tamanhoHex= String.format("%1$4s", Integer.toString(tripaValorCampo.length() / 2, 16)).replace(' ', '0');
					tripaValorCampoHex= tripaValorCampo;
				}else{
					//Converte a string usando framework FFPojo
					tripaValorCampo= ffpojo.parseToText(cpo);
										
					tamanhoHex= String.format("%1$4s", Integer.toString(tripaValorCampo.length(), 16)).replace(' ', '0');						
					tripaValorCampoHex= ParserConverterUtils.bytesToHex(tripaValorCampo.getBytes("Cp1047"));
				}
				
				tripaStratus.append(campoHex + tamanhoHex + tripaValorCampoHex);
			}			
		} catch (FFPojoException e) {			
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {			
			e.printStackTrace();
		}
	
		return tripaStratus.toString();		
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */	
	public String toString() {
		return transacaoStratus.toString();
	}
	
	/**
	 * Carrega informacoes iniciais para o CPO-001.
	 * 
	 * @return
	 */
	private CPO_001 carregaCPO_001(){
		CPO_001 cpo001= new CPO_001();
		cpo001.setMaquina("MB");
		cpo001.setDataHoraInput(new Date());			
		cpo001.setValorVenda(5100.1);
		cpo001.setDataHoraHost(new Date());
		cpo001.setAutorizador("369027");
		
		return cpo001;
	}
	
	/**
	 * Carrega informacoes iniciais para o CPO-006.
	 * 
	 * @return
	 */
	private CPO_006 carregaCPO_006(){
		CPO_006 cpo006= new CPO_006();
		cpo006.setTransacao("1100");
		cpo006.setCodigoProcessamento("001000");
		cpo006.setProduto("0006");
		cpo006.setTipoTransacao("117");
		
		return cpo006;
	}
	
	/**
	 * Carrega informacoes iniciais para o CPO-010.
	 * 
	 * @return
	 */
	private CPO_010 carregaCPO_010(){
		CPO_010 cpo010= new CPO_010();
		cpo010.setNumeroCartao("4058860000000000000");
		
		return cpo010;
	}
	
	/**
	 * Carrega informacoes iniciais para o CPO-012.
	 * 
	 * @return
	 */
	private CPO_012 carregaCPO_012(){
		CPO_012 cpo012= new CPO_012();
		cpo012.setNumeroEstabelecimento("1033460351");
		cpo012.setNumeroMcc(5300);
		cpo012.setUf("GO");
		cpo012.setCep("04297000");
		
		return cpo012;
	}
	
	/**
	 * Carrega informacoes iniciais para o CPO-013.
	 * 
	 * @return
	 */
	private CPO_013 carregaCPO_013(){
		CPO_013 cpo013= new CPO_013();
		cpo013.setCodigoTerminal("42190165");
		cpo013.setCodigoNoTerminal("PD41A");
		cpo013.setVersaoTerminal("CD02SOFMU41");
		
		return cpo013;
	}
	
	/**
	 * Carrega informacoes iniciais para o CPO-019.
	 * 
	 * @return
	 */
	private CPO_019 carregaCPO_019(){
		CPO_019 cpo019= new CPO_019();
		cpo019.setCiersMonitoracao("622695");
		cpo019.setSwitchVisa(" ");
		cpo019.setIndicadorSkyline("N");
		cpo019.setCodigoServicoPOS("666");
		
		return cpo019;
	}
	
	/**
	 * Carrega informacoes iniciais para o CPO-020.
	 * 
	 * @return
	 */
	private CPO_020 carregaCPO_020() {
		CPO_020 cpo020= new CPO_020();
		
		return cpo020;
	}
	
	/**
	 * Carrega informacoes iniciais para o CPO-027.
	 * 
	 * @return
	 */
	private CPO_027 carregaCPO_027(){
		CPO_027 cpo027= new CPO_027();
		cpo027.setObservacao("000");
		cpo027.setQuemRespondeu("VV");
		cpo027.setMensagem("51NAO#AUTORIZADA");
		cpo027.setCodigoResposta("00");
		
		return cpo027;
	}
	
	/**
	 * Carrega informacoes iniciais para o CPO-030.
	 * 
	 * @return
	 */
	private CPO_030 carregaCPO_030(){
		CPO_030 cpo030= new CPO_030();
		cpo030.setAuthSourceCode(" ");
		
		return cpo030;
	}
	
	/**
	 * Carrega informacoes iniciais para o CPO-032.
	 * 
	 * @return
	 */
	private CPO_032 carregaCPO_032(){
		CPO_032 cpo032= new CPO_032();
		cpo032.setModoEntrada("PLSCX40YYYYY");
		
		return cpo032;
	}
	
	/**
	 * Carrega informacoes iniciais para o CPO-040.
	 * 
	 * @return
	 */
	private CPO_040 carregaCPO_040(){
		CPO_040 cpo040= new CPO_040();
		cpo040.setMonTecnologia("04");
		cpo040.setMonCidade("ALPHAVILE      ");
		cpo040.setBandeira("001");
		cpo040.setBancoEmissor("898");
		cpo040.setStandIn("N");
		
		return cpo040;
	}
	
	/**
	 * Carrega informacoes iniciais para o CPO-047.
	 * 
	 * @return
	 */
	private CPO_047 carregaCPO_047(){
		CPO_047 cpo047= new CPO_047();
		if(cpo032.getModoEntrada().substring(5, 7).equals("70"))
			cpo047.setCodigoOperadora("01");
		
		return cpo047;
	}
	
	/**
	 * Carrega informacoes iniciais para o CPO-067.
	 * 
	 * @return
	 */
	public CPO_067 carregaCPO_067(){
		CPO_067 cpo067= new CPO_067();
		return cpo067;
	}

	/**
	 * Carrega informacoes iniciais para o CPO-068.
	 * 
	 * @return
	 */
	private CPO_068 carregaCPO_068(){
		// Tempo em milesegundos que ser� diminuido do tempo da transacao. 
		long vlTempo= 500;
		
		// Tempo da transacao.
		long time= cpo001.getDataHoraHost().getTime();						
		CPO_068 cpo068= new CPO_068();
		
		//dataHoraRetornoAoPOS
		cpo068.setAdqSaida(cpo001.getDataHoraHost());
		
		time-= vlTempo;
		//dataHoraRetornoHSM
		cpo068.setHsmSaida(new Date(time));
		time-= vlTempo;
		//dataHoraSaidaStratusEntradaHSM		
		cpo068.setHsmEntrada(new Date(time));
		
		time-= vlTempo;		
		//dataHoraRetornoBandeira
		cpo068.setResSaida(new Date(time));
		time-= vlTempo;
		//dataHoraSaidaStratusEntradaBandeira
		cpo068.setResEntrada(new Date(time));
				
		time-= vlTempo;		
		//dataHoraEntradaStratusSaidaPOS
		cpo068.setAdqEntrada(new Date(time));
		
		return cpo068;
	}
	
	/**
	 * Carrega informacoes iniciais para o CPO-074.
	 * 
	 * @return
	 */
	private CPO_074 carregaCPO_074(){
		CPO_074 cpo074= new CPO_074();
		cpo074.setProdutoSecundario("0000");
		
		return cpo074;
	}
	
	/**
	 * Carrega informacoes iniciais para o CPO-901 / DCC.
	 * 
	 * @return
	 */
	private CPO_901 carregaCPO_901(){
		InformacoesDCC info = new InformacoesDCC();
		info.setStatusDCC(StatusDCC.DCC);
		info.setTipoTransacao("C");
		CPO_901 cpo_901 = new CPO_901();
		return cpo_901;
	}	
	
	
	public static final String[] ciersEnts = new String[]{"303787","303786","305787","305786","302787","302786",
		"306787","306786","302793","302792","306793","306792","303793","303792","305793","305792",
		"203787","203786","205787","205786","202787","202786","206787","206786","202793","202792","206793","206792","203793","203792","205793","205792",
		"203787","203786","205787","205786","202787","202786","206787","206786","202793","202792","206793","206792","203793","203792","205793","205792",
		"203787","203786","205787","205786","202787","202786","206787","206786","202793","202792","206793","206792","203793","203792","205793","205792",
		"203787","203786","205787","205786","202787","202786","206787","206786","202793","202792","206793","206792","203793","203792","205793","205792"};
	
	public static final String[] idEmissor = new String[] { "001", "003", "004", "019", "021",
			"022", "024", "028", "029", "031", "033", "038", "041", "047",
			"048", "062", "063", "065", "070", "104", "116", "151", "204",
			"212", "214", "218", "224", "229", "230", "231", "233", "237",
			"238", "244", "249", "250", "252", "254", "263", "265", "275",
			"291", "294", "318", "320", "341", "346", "351", "353", "356",
			"389", "392", "399", "409", "422", "424", "453", "477", "479",
			"600", "604", "623", "633", "634", "637", "638", "641", "643",
			"655", "702", "707", "719", "721", "745", "748", "749", "752",
			"753", "756", "800", "801", "802", "803", "804", "805", "806",
			"807", "808", "809", "810", "811", "812", "813", "814", "815",
			"816", "817", "818", "819", "820", "821", "821", "822", "822",
			"823", "823", "824", "824", "825", "825", "826", "826", "890",
			"890", "892", "892", "895", "895", "896", "896", "897", "897",
			"898", "899", "899", "900", "900", "980", "980", "984", "984",
			"985", "985", "986", "986", "987", "987", "988", "988", "989",
			"989", "990", "990", "991", "991", "992", "992", "993", "993",
			"994", "994", "996", "996", "997", "997", "998", "998", "999" };
	
	public static final String[] tipoTecnologia = new String[]  
		{"01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","20","21","22","23"};
	
	public static final String[] quemResps = new String[]
			{"BT","CB","CD","CE","CF","CS","CT","CZ","DN","DP","EL","EO","ES","FV","GC","GR","GS","HS","IB","LD","LE","LX","MC","MF","NC",
			 "PC","PT","RU","SA","SC","SD","SF","SH","SI","SP","SR","SX","S0","TB","TK","UB","VC","VD","VI","VP","VR","AB","AG","AL","AM",
			 "BA","BB","BC","BD","BE","BF","BM","BN","BR","BS" };
	
	public static final String[] idProdutos = new String[] { "00800000", "02000001", "07110000",
			"05000028", "00490000", "00480000", "05000014", "07120000",
			"05000029", "00370000", "05000027", "07150000", "05000032",
			"07200000", "05000033", "00620000", "01000009", "01000007",
			"00270000", "01000008", "00650000", "01000012", "00760000",
			"01000013", "00470000", "05000013", "00440000", "05000016",
			"00580000", "05000018", "07060000", "05000024", "00510000",
			"05000009", "00390000", "05000012", "05000003", "00520000",
			"05000010", "07030000", "05000021", "07080000", "00690000",
			"05000005", "07040000", "05000022", "07140000", "05000031",
			"07050000", "05000023", "07090000", "00260000", "00630000",
			"01000010", "07010000", "05000019", "05000017", "00570000",
			"05000007", "07020000", "05000020", "07070000", "05000025",
			"05000026", "07130000", "05000030", "05000002", "00640000",
			"01000011", "00060000", "00820000", "03000001", "00350000",
			"03100001", "00670000", "03200001", "00680000", "03250001",
			"00280000", "04080001", "00610000", "04290001", "00430000",
			"04380001", "07100000", "04580001", "00860000", "05500001",
			"00800000", "02000003", "00820000", "03000002", "00350000",
			"03100003", "00670000", "03200002", "00280000", "04080003",
			"00610000", "04290002", "00430000", "04380002", "07100000",
			"04580002", "00860000", "05500002", "00820000", "03000003",
			"00860000", "05500003", "00810000", "02000002", "00360000",
			"03100002", "00290000", "04080002", "00790000", "07000005",
			"01000014", "00050000", "05000001", "00560000", "06000002",
			"06000003", "06000004", "06000005", "06000006", "06000007",
			"06000008", "05000006", "00870000", "05000008", "00380000" };
	
	public static final String[] maquinas = new String[]{"MB", "MA", "MC", "ME"};
	
	public static final String[] terminais = new String[]{"00000003","00000005","00000010","00000017","00000023","00000100",
		"00000149","00000150","00000162","00000249","00000275","00000287",
		"00000300","00000313","00000373","00000384","00000387","00000392",
		"00000434","00000447","00000448","00000454","00000456","00000463",
		"00000465","00000486","00000488","00000489","00000491","00000492",
		"00000493","00000496","00000500","00000501","00000508","00000509",
		"00000510","00000511","00000513","00000528","00000541","00000543",
		"00000544","00000551","00000568","00000569","00000571","00000572",
		"00000573","00000574","00000575","00000577","00000578","00000614",
		"00000616","00000617","00000619","00000620","00000622","00000626",
		"00000627","00000633","00000635","00000638","00000647","00000648",
		"00000649","00000650","00000651","00000652","00000653","00000654",
		"00000656","00000657","00000658","00000659","00000665","00000666",
		"00000668","00000669","00000670","00000673","00000675","00000688",
		"00000698","00000699","00000700","00000719","00000720","00000724",
		"00000725","00000726","00000727","00000729","00000730","00000731",
		"00000733","00000734","00000735","00000738","00000741","00000749",
		"00000751","00000753","00000764","00000771","00000776","00000780",
		"00000781","00000783","00000784","00000785","00000787","00000788",
		"00000790","00000791","00000795","00000796","00000799","00000800",
		"00000805","00000806","00000810","00000811","00000812","00000813",
		"00000815","00000816","00000817","00000819","00000821","00000822",
		"00000823","00000826","00000841","00000855","00000865","00000866",
		"00000867","00000868","00000869","00000870","00000871","00000872",
		"00000873","00000874","00000876","00000880","00000883","00000885",
		"00000903","00000904","00000905","00000907","00000908","00000909",
		"00000910","00000911","00000912","00000913","00000914","00000915",
		"00000916","00000917","00000918","00000920","00000921","00000922",
		"00000923","00000924","00000925","00000927","00000928","00000929",
		"00000930","00000931","00000975","00000976","00000977","00000979",
		"00000980","00000981","00000982","00000984","00000985","00000986",
		"00000990","00000991","00001000","00001001","00001017","00001060",
		"00001061","00001062","00001066","00001083","00001088","00001110",
		"00001115","00001116","00001119","00001123","00001124","00001125",
		"00001126","00001127","00001128","00001129","00001130","00001131",
		"00001132","00001133","00001134","00001136","00001140","00001157",
		"00001160","00001167","00001209","00001287","00001288","00001289",
		"00001315","00001328","00001382","00001383","00001475","00001513",
		"00001550","00001551","00001681","00001696","00001697","00001750",
		"00001753","00001754","00001756","00001768","00001775","00001834",
		"00001903","00001937","00001953","00001956","00001957","00001958",
		"00001961","00001962","00001963","00001964","00001974","00001975",
		"00001977","00001978","00001979","00001980","00001981","00001982",
		"00002018","00002019","00002021","00002022","00002023","00002024",
		"00002025","00002032","00002033","00002034","00002035","00002036",
		"00002037","00002039","00002040","00002043","00002072","00002097",
		"00002100","00002113","00002129","00002141","00002154","00002165",
		"00002187","00002201","00002202","00002214","00002245","00002257",
		"00002270","00002286","00002298","00002311","00002331","00002344",
		"00002358","00002377","00002396","00002398","00002399","00002400"};
	
	public static final String[] tipoSkyline = new String[]{"K","S","W","X","Y","Z"};
	
	public static final String[] site = new String[]{"X", "Y"};
	
	public static final String[] idModoConexao = new String[]{"01", "02", "10", "20", "30", "40", "50", "60", "70", "90", "95"};
	
	public static final String[] operadora = new String[]{"31", "05", "01", "02", "03", "04", "10"};
	
//	public static final String[] bandeira = new String[]  
//			{"001","002","003","004","005","006","007","008","009","010","011","013","014","015","016","017","018","019","021","022","023",
//		     "024","025","026","027","028","029","030","031","032","033","034","035","036","037","038","039","012","040","041","042","043",
//		     "044","045","046","047","048","049","050","051","052","053","054","055","056","057","058","059","060","061","062","063","998",
//		     "020","066"};
	//diminuir o universo de bandeiras para encontrar um cen?rio mais real
	public static final String[] bandeira = new String[]  
	                                       			{"001","002","003","004","005","006","007"};

	public static final String[] idCodigoErro = new String[]
			{"04", "05", "06", "07", "08", "12", "13", "14", "15", "19", "21", "22", "23", "24", "25", "28", "39", "41", "43", "51", "52", 
			 "53", "54", "55", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "69", "70", "74", "75", "76", "77", "78", 
			 "79", "80", "82", "83", "91", "92", "93", "96", "97", "AA", "AG", "B4", "B9", "BE", "BK", "BQ", "BS", "BT", "BV", "CA", "CB", 
			 "CC", "CD", "CE", "CF", "CG", "CH", "DM", "DW", "EE", "ER", "FA", "FB", "FK", "Z1", "Z3"};
	
	public static final String[] idCodigoEstabelecimento = new String[]{"1004238670", "1044567179", "1044004808", "1025011160", "1040438056", "1040112762", "1043664499", "1033460351"};

	public static final String[] cep = new String[]{"04297000", "01226031","03168009","03712004","01420005","03812215"};
	
	public static final String[] standin = new String[]{"N", "S"};
	
	public static final String[] lynx = new String[]{"N", "S"};
	
	public static final String[] timeoutLynx = new String[]{"N", "S"};
	
	public static final String[] tipoTransacaoDCC = new String[]{"285", "471", "473", "476","100","200","300","400","500", null}; //{"C", "F"};

	public static final String[] statusDCC = new String[]{"E", "N", "D", "P", "O", "T", "F", " ", null};
	
	
	
}