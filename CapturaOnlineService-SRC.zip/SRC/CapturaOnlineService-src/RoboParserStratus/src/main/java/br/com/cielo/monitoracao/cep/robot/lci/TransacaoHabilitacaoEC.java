package br.com.cielo.monitoracao.cep.robot.lci;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;


public class TransacaoHabilitacaoEC extends TransacaoLCI{
	SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmss");
	SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss:SSS");
	SimpleDateFormat sdf3 = new SimpleDateFormat("HH:mm:ss:SSS");
	String cdEstab="1234567890123456";
	String cnpj="06060606000110";
	String banco="0001";
	String agencia="000100";
	String contacorrente="00010000200123";
	String idFacebook="idfacebook-idfacebook-idfacebo";
	String tpServico=geraTipoOperacao();
	String dataHora=sdf.format(new Date());
	String nmDocEC="06060606000110";
	String mcc="1234";
	String fluxoEC="0";
	String tmpFluxoEC="00:00:02:000";
	String fluxoM100="0";
	String tmpFluxoM100="00:00:02:000";
	String tmpFluxoCadReduzidoEC="00:00:02:000";
		
	static final String[] cdEstabs = new String[] { "1234567890123456", "2222222222222222", "3333333333333333","4444444444444444", "5555555555555555"};

	static final String[] statusFinais = new String[] {"00","01", "02"};
	
	static final String[] tiposServico = new String[] {"H", "D", "C"};

	public static final String[] idEmissor = new String[] { "0001", "0003", "0004", "0019", "0021",
		"0022", "0024", "0028", "0029", "0031", "0033", "0038", "0041", "0047"};

	
	public String getTripa(){
		String tripa = getIdTipTransacao()+
				getCdSite()+
				cdEstab+
				cnpj+
				banco+
				agencia+
				contacorrente+
				idFacebook+
				tpServico+
				getFiller()+
				getHrInicioFluxo()+
				fluxoEC+
				tmpFluxoEC+
				fluxoM100+
				tmpFluxoM100+
				tmpFluxoCadReduzidoEC+
				getStFinalTran()+
				getHrFimFluxo()+
				getTmpTotalTra();
		if (tripa.length() != 288) throw new IllegalArgumentException("tamanho da tripa ["+tripa+"] inválido. Esperado 288, e obtido:"+tripa.length());
		
		return tripa;
		
	}


	@Override
	public String getIdTipTransacao() {
		// TODO Auto-generated method stub
		return "003";
	}


	@Override
	public String[] getStatusFinais() {
		// TODO Auto-generated method stub
		return statusFinais;
	}
	
	/**
	 * @return
	 */
	public static String geraTipoOperacao(){
		String tpOperacao = "";
		Random rand = new Random();
	    int randomNum = rand.nextInt(3);
	    if(randomNum == 0){
	    	tpOperacao = "H";
	    }else if(randomNum == 1){
	    	tpOperacao = "D";
	    }else {
	    	tpOperacao = "C";
	    }
		return tpOperacao;
	}

}
