package br.com.cielo.monitoracao.cep.robot.lci;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;


public class TransacaoCampanha extends TransacaoLCI{
	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss:SSS");
	SimpleDateFormat sdf3 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	SimpleDateFormat sdf4 = new SimpleDateFormat("HH:mm:ss");
	String idFacebook="idfacebook-idfacebook-idfacebo";
	String tokenFace= "tokenfacebook-tokenfacebook-to";
	String cdEstab="123456789012345678901234567890";
	String tpCampanha=geraTipoOperacao();
	String nome="NM-PORTADOR NM-PORTADOR NM-PORTADOR NM-PORTADOR NM-PORTADOR NM-PORTADOR NM-PORTADOR NM-PORTADOR NM-P";
	String tel="12345678901";
	String email="email@email.com, email@email.com,  email@email.com";
	String premio="premio premio premio premio premio  premio  premio";
	String qtdPremio="   ";
	String dtInicio = sdf.format(new Date());
	String dtFim = sdf.format(new Date());
	String dtValidade = sdf3.format(new Date());
	String hrInicioCamp = sdf4.format(new Date());
	String hrFimCamp = sdf4.format(new Date());
	String opTransacao = "T";
	String diasTransacao = "   ";
	String fluxoEC="0";
	String tmpFluxoEC="00:00:02:000";
	String fluxoComRes="0";
	String tmpFluxoConRes="00:00:02:000";
		
	static final String[] cdEstabs = new String[] { "1234567890123456", "2222222222222222", "3333333333333333","4444444444444444", "5555555555555555"};

	static final String[] statusFinais = new String[] {"00","01", "02"};
	static final String[] tiposCampanha = new String[] {"R","C"};
	static final String[] opTransacoes = new String[]{"T", "P", "Q"};	
	public String getTripa(){
		
		String tripa =getIdTipTransacao()+
				getCdSite()+
				idFacebook+
				tokenFace+
				cdEstab+
				tpCampanha+
				nome+
				tel+
				email+
				premio+
				qtdPremio+
				dtInicio +
				dtFim +
				dtValidade +
				hrInicioCamp +
				hrFimCamp +
				opTransacao +
				diasTransacao +
				getFiller()+
				getHrInicioFluxo()+
				fluxoEC+
				tmpFluxoEC+
				fluxoComRes+
				tmpFluxoConRes+
				getStFinalTran()+
				getHrFimFluxo()+
				getTmpTotalTra();
 
		
		if (tripa.length() != 555) throw new IllegalArgumentException("tamanho da tripa ["+tripa+"] inválido. Esperado 555, e obtido:"+tripa.length());
		
		return tripa;
	}
	@Override
	public String getIdTipTransacao() {
		// TODO Auto-generated method stub
		return "006";
	}
	@Override
	public String[] getStatusFinais() {
		// TODO Auto-generated method stub
		return statusFinais;
	}
	
	/**
	 * @return
	 */
	public static String geraTipoOperacao(){
		String tpOperacao = "";
		Random rand = new Random();
	    int randomNum = rand.nextInt(2);
	    if(randomNum == 0){
	    	tpOperacao = "R";
	    }else if(randomNum == 1){
	    	tpOperacao = "C";
	    }
		return tpOperacao;
	}
}
