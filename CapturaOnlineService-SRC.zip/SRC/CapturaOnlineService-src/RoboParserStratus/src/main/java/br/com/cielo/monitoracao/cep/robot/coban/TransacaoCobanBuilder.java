package br.com.cielo.monitoracao.cep.robot.coban;

import java.io.BufferedReader;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import br.com.cielo.monitoracao.cep.robot.RoboCieloCEP;
import br.com.cielo.monitoracao.cep.robot.Transacao;
import br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico;
import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;

public class TransacaoCobanBuilder extends TransacaoBuilderGenerico {
	

	static final String[] codsProduto 		= new String[] { "1000", "2000", "3000", "4000", "5000",
															 "6000", "7000", "8000", "9000" };
	static final String[] tiposTransacao 	= new String[] { "1100", "1110", "1200", "1202", "1210", "1400",
															 "1410", "1420", "1430", "1600","1610" };
	static final String[] codsProcessamento = new String[] { "002100" }; //????
	static final String[] codsEmissor 		= new String[] { "0001","0001","0001", "0353", "0241", 
															 "0424", "0237", "0237" };
	static final String[] tiposPgto 		= new String[] { "00", "01", "02"};
	static final String[] codsResposta 		= new String[] { "999" }; // ?????
	static final String[] tiposCartao 		= new String[] { "BA", "VE" }; 
	
	static final String[] maquinasGateway   = new String[] {"G1", "G2", "G3", "G4"};
	
	static final String[] codsObs	 		= new String[] { "706", "707", "708", "709" }; //????

	static final String[] codsSubProduto 	= new String[] {"0001", "0002", "0003", "0004", 
															"0005", "0006", "0007", "0008"};
	
	
	
	boolean codSubProdutoAleatorio 	= false;
	boolean codProdutoAleatorio 	= false;
	boolean tipoTransacaoAleatorio 	= false; 
	boolean codProcessamentoAleatorio = false;
	boolean codEmissorAleatorio 	= false;
	boolean tipoPgtoAleatorio 		= false;
	boolean codRespostaAleatorio 	= false; 
	boolean tipoCartaoAleatorio 	= false;	
	boolean maquinaGatewayAleatorio = false;
	boolean codObsAleatorio			= false;
	
	boolean ajustarDataHoraTran 	= false;
	
	private boolean isCodSubProdutoAleatorio() {
		return codSubProdutoAleatorio;
	}
	private boolean isCodProdutoAleatorio() {
		return codProdutoAleatorio;
	}
	private boolean isTipoTransacaoAleatorio() {
		return tipoTransacaoAleatorio;
	}
	private boolean isCodProcessamentoAleatorio() {
		return codProcessamentoAleatorio; 
	}
	private boolean isCodEmissorAleatorio() {
		return codEmissorAleatorio; 
	}
	private boolean isTipoPgtoAleatorio() {
		return tipoPgtoAleatorio; 
	}
	private boolean isCodRespostaAleatorio() {
		return codRespostaAleatorio; 
	}
	private boolean isTipoCartaoAleatorio() {
		return tipoCartaoAleatorio; 
	}
	private boolean isMaquinaGatewayAleatorio() {
		return maquinaGatewayAleatorio;
	}
	private boolean isCodObsAleatorio() {
		return codObsAleatorio;
	}

	
	/*private boolean isAjustarDataHoraTran() {
		return ajustarDataHoraTran;
	}
	*/

	public TransacaoCobanBuilder(Transacao template, VariaveisGeracao ... variaveis){
		for (int i = 0; i < variaveis.length; i++) {
			switch (variaveis[i]){
			case TIPO_TRANSACAO_ALEATORIO:
				tipoTransacaoAleatorio=true;
				break;
			case COD_RESPOSTA_ALEATORIO:
				codRespostaAleatorio=true;
				break;
			case MAQUINA_GATEWAY_ALEATORIO:
				maquinaGatewayAleatorio = true;
				break;
			case RETORNO_CHAMADA_ALEATORIO:
				codSubProdutoAleatorio = true;
				break;
			case PRODUTO_ALEATORIO:
				codProdutoAleatorio = true;
				break;
			case COD_PROCESSAMENTO_ALEATORIO:
				codProcessamentoAleatorio = true;
				break;
			case TIPO_PGTO_ALEATORIO:
				tipoPgtoAleatorio = true;
				break;
			case TIPO_CARTAO_ALEATORIO:
				tipoCartaoAleatorio = true;
				break;
			case EMISSOR_ALEATORIO:
				codEmissorAleatorio = true;
				break;
			case COD_OBS_ALEATORIO:
				codObsAleatorio = true;
				break;
			}
		}
	}
	
	public TransacaoGenerica gerarNovaTransacao(Date dataHoraTran){
		TransacaoCoban t = new TransacaoCoban();
		if (dataHoraTran == null) {
			dataHoraTran = new Date();
		}
		if (isCodSubProdutoAleatorio()) {
			setCodSubProdutoAleatorio(t);
		}
		if (isCodProdutoAleatorio()) {
			setCodProdutoAleatorio(t);
		}
		if (isTipoTransacaoAleatorio()) {
			setTipoTransacaoAleatorio(t);
		}
		if (isCodProcessamentoAleatorio()) {
			setCodProcessamentoAleatorio(t); 
		}
		if (isCodEmissorAleatorio()) {
			setCodEmissorAleatorio(t); 
		}
		if (isTipoPgtoAleatorio()) {
			setTipoPgtoAleatorio(t); 
		}
		if (isCodRespostaAleatorio()) {
			setCodRespostaAleatorio(t); 
		}
		if (isTipoCartaoAleatorio()) {
			setTipoCartaoAleatorio(t); 
		}
		if (isMaquinaGatewayAleatorio()) {
			setMaquinaGatewayAleatorio(t);
		}
		if (isCodObsAleatorio()) {
			setCodObsAleatorio(t);
		}
		return t;
	}
	
	private void setCodSubProdutoAleatorio(TransacaoCoban t) {
		int indice = getAleatorioGenerico(0, t.codsSubProduto.length-1);
		t.codSubProduto = TransacaoCoban.codsSubProduto[indice];
	}
	private void setCodProdutoAleatorio(TransacaoCoban t) {
		int indice = getAleatorioGenerico(0, t.codsProduto.length-1);
		t.codProduto = TransacaoCoban.codsProduto[indice];
	}
	private void setTipoTransacaoAleatorio(TransacaoCoban t) {
		int indice = getAleatorioGenerico(0, t.tiposTransacao.length-1);
		t.tipoTransacao = TransacaoCoban.tiposTransacao[indice];
	}
	private void setCodProcessamentoAleatorio(TransacaoCoban t) {
		int indice = getAleatorioGenerico(0, t.codsProcessamento.length-1);
		t.codProcessamento = TransacaoCoban.codsProcessamento[indice];
	}
	private void setCodEmissorAleatorio(TransacaoCoban t) {
		int indice = getAleatorioGenerico(0, t.codsEmissor.length-1);
		t.codEmissor = TransacaoCoban.codsEmissor[indice];
	}
	private void setTipoPgtoAleatorio(TransacaoCoban t) {
		int indice = getAleatorioGenerico(0, t.tiposPgto.length-1);
		t.tipoPgto = TransacaoCoban.tiposPgto[indice];
	}
	private void setCodRespostaAleatorio(TransacaoCoban t) {
		int indice = getAleatorioGenerico(0, t.codsResposta.length-1);
		t.codResposta = TransacaoCoban.codsResposta[indice];
	}
	private void setTipoCartaoAleatorio(TransacaoCoban t) {
		int indice = getAleatorioGenerico(0, t.tiposCartao.length-1);
		t.tipoCartao = TransacaoCoban.tiposCartao[indice];
	}
	private  void setMaquinaGatewayAleatorio(TransacaoCoban t) {
		int indice = getAleatorioGenerico(0, t.maquinasGateway.length - 1);
		t.maquinaGateway = TransacaoCoban.maquinasGateway[indice];
	}
	private  void setCodObsAleatorio(TransacaoCoban t) {
		int indice = getAleatorioGenerico(0, t.codsObs.length - 1);
		t.codObs = TransacaoCoban.codsObs[indice];
	}	

	private String getSpaces(int i) {
		String spaces = "";
		for (int j = 0; j < i; j++) {
		   spaces += " ";	
		}
		return spaces;
	}
	
	@Override
	public Collection<byte[]> generateMessages(int qtdade) throws Exception {
		List<byte[]> list = new ArrayList<byte[]>();
		if (RoboCieloCEP.getFileSamples() == null) {
			return super.generateMessages(qtdade);
		} else {
			if (RoboCieloCEP.getFileSamples() != null) {
				NodeList nList = loadNodeListFromXML(RoboCieloCEP.getFileSamplesAsFile());
				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);
					TransacaoCoban t = new TransacaoCoban();
					t.setNuTerminal( getElementAttributeValue(nNode, TransacaoCoban.NU_TERMINAL) );
					t.setDataHoraAut( getElementAttributeValue(nNode, TransacaoCoban.DATA_HORA_TRANSACAO) );
					t.setCodProduto( getElementAttributeValue(nNode, TransacaoCoban.COD_PRODUTO) );
					t.setTipoTransacao( getElementAttributeValue(nNode, TransacaoCoban.TIPO_TRANSACAO) );
					t.setCodProcessamento( getElementAttributeValue(nNode, TransacaoCoban.COD_PROCESSAMENTO) );
					t.setCodEmissor( getElementAttributeValue(nNode, TransacaoCoban.COD_EMISSOR) );
					t.setTipoPgto( getElementAttributeValue(nNode, TransacaoCoban.TIPO_PGTO) );
					t.setCodResposta( getElementAttributeValue(nNode, TransacaoCoban.COD_RESPOSTA) );
					t.setTipoCartao( getElementAttributeValue(nNode, TransacaoCoban.TIPO_CARTAO) );
					t.setCodObs( getElementAttributeValue(nNode, TransacaoCoban.COD_OBS) );
					t.setMaquinaGateway( getElementAttributeValue(nNode, TransacaoCoban.MAQUINA_GATEWAY) );
					t.setCodSubProduto( getElementAttributeValue(nNode, TransacaoCoban.COD_SUB_PRODUTO) );
					list.add(t.getTripa().getBytes());
				}
				
			}
		}
		return list;
	}
	
	/**
	 * Carrega a lista de n�s ns:isomsg que est�o dentro do arquivo XML
	 * 
	 * @param fXmlFile referencia File do arquivo
	 * @return
	 */
	private NodeList loadNodeListFromXML(File fXmlFile){
		try{
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("ns:isomsg");
			return nList;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Retorna o conteudo do atributo VALUE dentro do n� ns:field
	 * 
	 * @param nNode
	 * @param index
	 * @return
	 */
	private String getElementAttributeValue(Node nNode, int index){
		if (nNode.getNodeType() == Node.ELEMENT_NODE) {
			Element eElement = (Element) nNode;
			String _value = ((Element)eElement.getElementsByTagName("ns:field").item(index)).getAttribute("value");
			return _value;
		}
		return null;
	}
	
	public TransacaoCobanBuilder(){
		
	}
	
	public static void main (String args[]){
		
		TransacaoCobanBuilder t = new TransacaoCobanBuilder();
		
		try{
			File fXmlFile = new File("D:/Projetos/Cielo/temp/Fase 3/COBAN_MSG/COBAN_MSG.xml");
			NodeList nList = t.loadNodeListFromXML(fXmlFile);
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				TransacaoCoban tr = new TransacaoCoban();
				tr.setDataHoraAut( t.getElementAttributeValue(nNode, TransacaoCoban.DATA_HORA_TRANSACAO) );
				tr.setCodProduto( t.getElementAttributeValue(nNode, TransacaoCoban.COD_PRODUTO) );
				tr.setTipoTransacao( t.getElementAttributeValue(nNode, TransacaoCoban.TIPO_TRANSACAO) );
				tr.setCodProcessamento( t.getElementAttributeValue(nNode, TransacaoCoban.COD_PROCESSAMENTO) );
				tr.setCodEmissor( t.getElementAttributeValue(nNode, TransacaoCoban.COD_EMISSOR) );
				tr.setTipoPgto( t.getElementAttributeValue(nNode, TransacaoCoban.TIPO_PGTO) );
				tr.setCodResposta( t.getElementAttributeValue(nNode, TransacaoCoban.COD_RESPOSTA) );
				tr.setTipoCartao( t.getElementAttributeValue(nNode, TransacaoCoban.TIPO_CARTAO) );
				tr.setCodObs( t.getElementAttributeValue(nNode, TransacaoCoban.COD_OBS) );
				tr.setMaquinaGateway( t.getElementAttributeValue(nNode, TransacaoCoban.MAQUINA_GATEWAY) );
				tr.setCodSubProduto( t.getElementAttributeValue(nNode, TransacaoCoban.COD_SUB_PRODUTO) );
				System.out.println(tr.getTripa());
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
