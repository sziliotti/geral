package br.com.cielo.monitoracao.cep.robot;

import javax.jms.BytesMessage;

public class Producer extends ProducerGenerico {
	public Producer(String queueJndiName, String urlQueueServer,String topicJndiName, String urlTopicServer) {
		super(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		if (queueJndiName == null &&  topicJndiName == null) {
			setQueueJndiName("br.com.cielo.monitoracao.financeiro.queue.1.in");
		}
	}

	static long messageOrderId = System.currentTimeMillis();
	
	@Override
	public void sendMessage(byte[] bytes) throws Exception {
		        
        // We will send a small text message saying 'Hello' in Japanese
        BytesMessage bm = getSession().createBytesMessage();
         
        bm.writeBytes(bytes);
        bm.setLongProperty("MESSAGE_ORDER_ID", messageOrderId++ );
        // Here we are sending the message!
        getProducer().send(bm);
		Thread.sleep(1);
    }
	
}