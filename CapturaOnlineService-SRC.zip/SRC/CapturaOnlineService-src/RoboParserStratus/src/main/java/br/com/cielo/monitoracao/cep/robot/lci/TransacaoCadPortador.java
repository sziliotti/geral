package br.com.cielo.monitoracao.cep.robot.lci;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;


public class TransacaoCadPortador extends TransacaoLCI{
	SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmss");
	SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss:SSS");
	SimpleDateFormat sdf3 = new SimpleDateFormat("HH:mm:ss:SSS");
	String cpf="00252525252";
	String idFacebook="idfacebook-idfacebook-idfacebo";
	String tokenFace= "tokenfacebook-tokenfacebook-to";
	String nmPortador="NM-PORTADOR NM-PORTADOR NM-PORTADOR NM-PORTADOR NM-PORTADOR NM-PORTADOR NM-PORTADOR NM-PORTADOR NM-P";
	String dddCel="011";
	String cel="123456789";
	String email="email@email.com, email@email.com,  email@email.com";
	String tipoOperacao = geraTipoOperacao(); 
	String filler="                                                                                                   ";
	String fluxoEC="0";
	String tmpFluxoEC="00:00:02:000";
	String fluxoCadPor="0";
	String tmpFluxoCadPor="00:00:02:000";
		
	static final String[] cdEstabs = new String[] { "1234567890123456", "2222222222222222", "3333333333333333","4444444444444444", "5555555555555555"};

	static final String[] statusFinais = new String[] {"00","01", "02"};
		
	public String getTripa(){
		String tripa = getIdTipTransacao()+
				getCdSite()+
				cpf+
				idFacebook+
				tokenFace+
				nmPortador+
				dddCel+
				cel+
				email+
				tipoOperacao+
				filler+
				getHrInicioFluxo()+
				fluxoEC+
				tmpFluxoEC+
				fluxoCadPor+
				tmpFluxoCadPor+
				getStFinalTran()+
				getHrFimFluxo()+
				getTmpTotalTra();
		
		if (tripa.length() != 424) throw new IllegalArgumentException("tamanho da tripa ["+tripa+"] inválido. Esperado 424, e obtido:"+tripa.length());
		
		return tripa;
	}

	@Override
	public String getIdTipTransacao() {
		return "004";
	}

	@Override
	public String[] getStatusFinais() {
		return statusFinais;
	}
	
	/**
	 * @return
	 */
	public static String geraTipoOperacao(){
		String tpOperacao = "";
		Random rand = new Random();
	    int randomNum = rand.nextInt(4);
	    if(randomNum == 0){
	    	tpOperacao = "C";
	    }else if(randomNum == 1){
	    	tpOperacao = "R";
	    }else if(randomNum == 2){
	    	tpOperacao = "U";
	    }else{
	    	tpOperacao = "D";
	    }
		return tpOperacao;
	}

}
