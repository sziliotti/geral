package br.com.cielo.monitoracao.cep.robot.mobile;

import java.text.SimpleDateFormat;
import java.util.Date;
import br.com.cielo.monitoracao.cep.robot.Transacao;
import br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico;
import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;

public class TransacaoPgtoCelularBuilder extends TransacaoBuilderGenerico {

	boolean emissorAleatorio = false;
	boolean statusAleatorio = false;
	boolean produtoESubProdutoAleatorio = false;
	boolean ajustarDataHoraTran = false;
	boolean valVendaAleatorio = false;
	
	private boolean isEmissorAleatorio() {
		return emissorAleatorio;
	}
	private boolean isStatusAleatorio() {
		return statusAleatorio; 
	}
	private boolean isProdutoESubProdutoAleatorio() {
		return produtoESubProdutoAleatorio;
	}
	private boolean isAjustarDataHoraTran() {
		return ajustarDataHoraTran;
	}
	private boolean isValVendaAleatorio() {
		return valVendaAleatorio;
	}
	
	
	public TransacaoPgtoCelularBuilder(Transacao template, VariaveisGeracao ... variaveis){
		for (int i = 0; i < variaveis.length; i++) {
			switch (variaveis[i]){
			case EMISSOR_ALEATORIO:
				emissorAleatorio=true;break;
			case STATUS_ALEATORIO:
				statusAleatorio=true;break;
			case PRODUTO_E_SUBPRODUTO_ALEATORIO:
				produtoESubProdutoAleatorio = true;
				break;
			case AJUSTAR_DATAHORA_TRAN:
				ajustarDataHoraTran = true;
				break;
			}
		}
	}
	
	public TransacaoGenerica gerarNovaTransacao(Date dataHoraTran){
		TransacaoPgtoCelular t = new TransacaoPgtoCelular();
		if (dataHoraTran == null) {
			dataHoraTran = new Date(System.currentTimeMillis());
		}
		if (isAjustarDataHoraTran()){
			setInicioTermino(t);		
		}
		if (isEmissorAleatorio()) {
			setEmissorAleatorio(t);
		}
		if (isProdutoESubProdutoAleatorio()) {
			setProdutoESubProduto(t);
		}
		if (isStatusAleatorio()) {
			setStatusAleatorio(t);
		}
		
		return t;
	}
	
	private void setInicioTermino(TransacaoPgtoCelular t) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS");
		// tiro 15 segundos para simular a latencia do autorizador 
		Date now = new Date(System.currentTimeMillis()-15000);
		t.dtInicio = sdf.format(now);
		t.dtFinal = sdf.format(new Date(now.getTime() + getAleatorioGenerico(100, 500)));
	}

	private  void setBandeiraAleatoria(Transacao t) {
		// pegar de 1 -> 63

		String num = "" + getAleatorioGenerico(1, 63);
		t.bandeira = "000".substring(0, 3 - num.length()) + num;
	}

	private  void setEmissorAleatorio(TransacaoPgtoCelular t) {
		int indice = getAleatorioGenerico(0, t.idEmissores.length - 1);
		t.cdEmissor = t.idEmissores[indice];
	}

	private  void setProdutoESubProduto(TransacaoPgtoCelular t) {
		int indice = getAleatorioGenerico(0, t.idProdutos.length - 1);
		String produto = t.idProdutos[indice];
		t.cdProdPrimario = produto;
		indice = getAleatorioGenerico(0, t.subProdutos.length - 1);
		String produtoSecundario = t.subProdutos[indice];
		t.cdProdSecundario = produtoSecundario;
	}

	private  void setStatusAleatorio(TransacaoPgtoCelular t) {
		// tenho 4 status: 1 e 2 - Cancelamento, 2 - Desfazimento, 3 - Aprovado,
		// 4 - Negado
		int statusId = getAleatorioGenerico_2(1, 20);
		switch (statusId) {
		case 1:
			t.cdStatus = "01";
			t.descricaoStatus = "APROVADA            ";
			break;
		case 2:
			t.cdStatus = "02"; // OK
			t.descricaoStatus = "NEGADA              ";
			break;
		case 3:
			t.cdStatus = "03"; // OK
			t.descricaoStatus = "CANCELADA           ";
			break;
		case 4:
			t.cdStatus = "04"; // OK
			t.descricaoStatus = "DESFEITA            ";
			break;
		case 5:
			t.cdStatus = "05"; // ERRO, gerar codigo de erro
			t.cdErro = "FA0"+getAleatorioGenerico(0,8);
			t.descricaoStatus = "REJEITADA           ";
			t.cdErro = t.cdErro + getSpaces(100 - t.cdErro.length());
			break;
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
		case 11:
		case 12:
		case 13:
		case 14:
		case 15:
			t.cdStatus = "01"; // OK
			t.descricaoStatus = "APROVADA            ";
			break;
		case 16:
			t.cdStatus = "02"; // OK
			t.descricaoStatus = "NEGADA              ";
			break;
		case 20: // Negado.
			t.cdStatus = "03"; // OK
			t.descricaoStatus = "CANCELADA           ";
			break;
		}
	}
	
	private String getSpaces(int i) {
		String spaces = "";
		for (int j = 0; j < i; j++) {
		   spaces += " ";	
		}
		return spaces;
	}


}
