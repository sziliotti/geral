package br.com.cielo.monitoracao.cep.robot.stratus;

import javax.jms.BytesMessage;

import br.com.cielo.monitoracao.cep.robot.ProducerGenerico;
import br.com.cielo.parser.autorizador.stratus.ParserConverterUtils;
import br.com.cielo.parser.autorizador.stratus.ParserException;

/**
 *<B>Projeto: RoboCEP</B><BR>
 *
 * Classe responsavel em enviar a mensagem, no formato do Stratus, para a fila do ActiveMQ correspondente.
 *	 
 *<DL><DT><B>Criada em:</B><DD>23/10/2013</DD></DL>
 *
 * @author Sergio Ziliotti da Silva - Cielo S.A.
 * @version 1.0
 */
public class ProdutorStratus extends ProducerGenerico{
	private String queueName= "bam_monitoracao_stratus.queue.1.in";
		
	/**
	 * Construtor definindo o endereco do server MQ, e nome da fila a ser enviado.
	 * 
	 * @param queueJndiName
	 * 			Nome da fila a ser enviado
	 * @param urlQueueServer
	 * 			URL do Server MQ.
	 */
	public ProdutorStratus(String queueJndiName, String urlQueueServer,String topicJndiName, String urlTopicServer) {
		super(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		if (queueJndiName == null && topicJndiName == null) {
			setQueueJndiName(queueName);
		}
	}

	static long messageOrderId= System.currentTimeMillis();

	/* (non-Javadoc)
	 * @see br.com.cielo.monitoracao.cep.robot.ProducerGenerico#sendMessage(byte[])
	 */
	@Override
	public void sendMessage(byte[] bytes) throws Exception {		
        BytesMessage bm= getSession().createBytesMessage();
        
        //Compacta mensagem bytes a ser enviada.
        byte[] compressPayload= ParserConverterUtils.zipMessage(bytes);
        
        //Imprime na tela para testes.
    //    this.printMessage(compressPayload);

        bm.writeBytes(compressPayload);
        bm.setLongProperty("MESSAGE_ORDER_ID", messageOrderId++);
        
//			try {
//				MonitoracaoTransacaoAutorizadorVO transacaoMonitoracao= TransacaoParserBuilder.getTransacaoMonitoracaoParser().converter(
//																TransacaoParserBuilder.getTransacaoStratusParser().converter(bytes));
//				System.out.println("===============================================================");		
//				System.out.println("[ROBO] TRANSACAO MONITORACAO {MESSAGE_ORDER_ID("+messageOrderId+")}: \n"+ transacaoMonitoracao.toString());			
//			} catch (ParserException e) {
//				e.printStackTrace();
//			}
        
        // Enviando a mensagem ao AcitveMQ.
        bm.setJMSTimestamp(System.currentTimeMillis());
        getProducer().send(bm);
        
		Thread.sleep(1);
	}
	
	/**
	 * M�todo responsavel em imprimir na tela a mensagem enviada, tanto a compactada como a mensagem original.
	 * 
	 * @param bytes
	 * 			Array de bytes contendo a mensagem compactada.
	 */
	private void printMessage(byte[] bytes){		
		try {
			System.out.println("===========================================================================================================");
			System.out.println("{MENSAGEM COMPACTADA ENVIADA}: "+ParserConverterUtils.bytesToHex(bytes));
			System.out.println("{MENSAGEM ORIGINAL ENVIADA}: "+ParserConverterUtils.bytesToHex(ParserConverterUtils.unzipMessage(bytes)));
			System.out.println("===========================================================================================================");
			
		} catch (ParserException e) {			
			e.printStackTrace();
		}
	}
}
