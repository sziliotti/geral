package br.com.cielo.monitoracao.cep.robot.mobile;

import java.text.SimpleDateFormat;
import java.util.Date;

import br.com.cielo.monitoracao.cep.robot.Transacao;
import br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico;
import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;

public class TransacaoDeParaBuilder extends TransacaoBuilderGenerico {

	boolean emissorAleatorio = false;
	boolean statusAleatorio = false;
	boolean produtoESubProdutoAleatorio = false;
	boolean ajustarDataHoraTran = false;
	boolean valVendaAleatorio = false;
	
	private boolean isEmissorAleatorio() {
		return emissorAleatorio;
	}
	private boolean isStatusAleatorio() {
		return statusAleatorio; 
	}
	private boolean isAjustarDataHoraTran() {
		return ajustarDataHoraTran;
	}
	
	
	public TransacaoDeParaBuilder(Transacao template, VariaveisGeracao ... variaveis){
		for (int i = 0; i < variaveis.length; i++) {
			switch (variaveis[i]){
			case EMISSOR_ALEATORIO:
				emissorAleatorio=true;break;
			case STATUS_ALEATORIO:
				statusAleatorio=true;break;
			case AJUSTAR_DATAHORA_TRAN:
				ajustarDataHoraTran = true;
				break;
			}
		}
	}
	
	public TransacaoGenerica gerarNovaTransacao(Date dataHoraTran){
		TransacaoDePara t = new TransacaoDePara();
		if (dataHoraTran == null) {
			dataHoraTran = new Date();
		}
		if (isAjustarDataHoraTran()){
			setInicioTermino(t);		
		}
		if (isEmissorAleatorio()) {
			setEmissorAleatorio(t);
		}
		if (isStatusAleatorio()) {
			setStatusAleatorio(t);
		}
		
		return t;
	}
	
	private void setInicioTermino(TransacaoDePara t) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS");
		// tiro 15 segundos para simular a latencia do autorizador 
		Date now = new Date(System.currentTimeMillis()-15000);
		t.dtInicio = sdf.format(now);
		t.dtFinal = sdf.format(new Date(now.getTime() + getAleatorioGenerico(100, 500)));
	}
	
	private  void setEmissorAleatorio(TransacaoDePara t) {
		int indice = getAleatorioGenerico(0, t.idEmissores.length - 1);
		t.cdEmissor = t.idEmissores[indice];
	}

	private  void setStatusAleatorio(TransacaoDePara t) {
		// tenho 4 status: 1 e 2 - Cancelamento, 2 - Desfazimento, 3 - Aprovado,
		// 4 - Negado
		int statusId = getAleatorioGenerico_2(1, 20);
		switch (statusId) {
		case 1:
			t.cdStatus = "01";
			t.descricaoStatus = "SUCESSO             ";
			break;
		case 2:
			t.cdStatus = "02"; // OK
			t.descricaoStatus = "INSUCESSO           ";
			break;
		case 3:
			t.cdStatus = "01"; // OK
			t.descricaoStatus = "SUCESSO             ";
			break;
		case 4:
			t.cdStatus = "01"; // OK
			t.descricaoStatus = "SUCESSO             ";
			break;
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
		case 11:
		case 12:
		case 13:
		case 14:
		case 15:
			t.cdStatus = "01";
			t.descricaoStatus = "SUCESSO             ";
			break;
		case 16:
			t.cdStatus = "02"; // OK
			t.descricaoStatus = "INSUCESSO           ";
			break;
		case 20: // Negado.
			t.cdStatus = "02"; // OK
			t.descricaoStatus = "INSUCESSO           ";
			break;
		}
	}


}
