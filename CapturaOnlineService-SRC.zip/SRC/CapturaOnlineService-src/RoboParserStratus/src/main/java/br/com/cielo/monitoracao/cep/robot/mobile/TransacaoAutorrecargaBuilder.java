package br.com.cielo.monitoracao.cep.robot.mobile;

import java.text.SimpleDateFormat;
import java.util.Date;


import br.com.cielo.monitoracao.cep.robot.Transacao;
import br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico;
import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;

public class TransacaoAutorrecargaBuilder extends TransacaoBuilderGenerico {


	boolean statusAleatorio = false;
	boolean ajustarDataHoraTran = false;
	boolean valVendaAleatorio = false;
	private static final String cdErroVazio="                                                                                                    ";
	private static String mensagemErroVazio="          ";
	static {
		for (int i = 0; i<99; i++) {
			mensagemErroVazio += "          ";
		}
	}	

	private boolean isStatusAleatorio() {
		return statusAleatorio; 
	}
	
	private boolean isAjustarDataHoraTran() {
		return ajustarDataHoraTran;
	}
	
	
	public TransacaoAutorrecargaBuilder(Transacao template, VariaveisGeracao ... variaveis){
		for (int i = 0; i < variaveis.length; i++) {
			switch (variaveis[i]){
		
			case STATUS_ALEATORIO:
				statusAleatorio=true;break;
			case AJUSTAR_DATAHORA_TRAN:
				ajustarDataHoraTran = true;
				break;
			}
		}
	}
	
	public TransacaoGenerica gerarNovaTransacao(Date dataHoraTran){
		TransacaoAutorecarga t = new TransacaoAutorecarga();
		if (dataHoraTran == null) {
			dataHoraTran = new Date(System.currentTimeMillis()-3600000);
		}
		if (isAjustarDataHoraTran()){
			setInicioTermino(t);		
		}
		if (isStatusAleatorio()) {
			setCodErroAleatorio(t);
		}
		
		return t;
	}
	
	private void setInicioTermino(TransacaoAutorecarga t) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS");
		// tiro 15 segundos para simular a latencia do autorizador 
		Date now = new Date(System.currentTimeMillis()-15000);
		t.dtInicio = sdf.format(now);
		t.dtFinal = sdf.format(new Date(now.getTime() + getAleatorioGenerico(100, 500)));
	}
	
	private  void setCodErroAleatorio(TransacaoAutorecarga t) {
		int statusId = getAleatorioGenerico_2(1, 20);
		switch (statusId) {
		case 1:
		case 2:
		case 3:
		case 4:
			t.cdErro = cdErroVazio;
			t.mensagemErro = mensagemErroVazio;
			break;
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
			t.cdErro = "FA0"+getAleatorioGenerico(0,8);
			t.cdErro = t.cdErro + getSpaces(100 - t.cdErro.length());
			break;
		case 10:
		case 11:
		case 12:
		case 13:
		case 14:
		case 15:
		case 16:
		case 20: 
			t.cdErro = cdErroVazio; // OK
			t.mensagemErro = mensagemErroVazio;
			break;
		}
	}
	
	private String getSpaces(int i) {
		String spaces = "";
		for (int j = 0; j < i; j++) {
		   spaces += " ";	
		}
		return spaces;
	}



}
