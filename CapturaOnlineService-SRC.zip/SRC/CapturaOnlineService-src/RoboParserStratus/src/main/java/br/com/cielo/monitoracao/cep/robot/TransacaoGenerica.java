package br.com.cielo.monitoracao.cep.robot;

public interface TransacaoGenerica {

	public String getTripa();
}
