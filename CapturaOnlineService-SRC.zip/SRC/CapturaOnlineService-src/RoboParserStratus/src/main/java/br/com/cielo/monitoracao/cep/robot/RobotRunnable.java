package br.com.cielo.monitoracao.cep.robot;

import java.util.Collection;
import java.util.Date;
import java.util.concurrent.ConcurrentLinkedQueue;

class RobotRunnable implements Runnable {
	private static String xlock = "XLOCK";
	private static String ylock = "YLOCK";
	private static long mensPostadasGeral = 0L;
	private static long tempoInicioColetaEstat = 0L;
	private static long lastStatistics = 0L;
	private static long totalStatistics = 0L;
	private static long iterationsStats = 0;
	private static Boolean queueEmpty = false;
	private static final ConcurrentLinkedQueue<byte[]> messageQueue = new ConcurrentLinkedQueue<byte[]>();
	private static Date dataAutorizacao;
	private ProducerGenerico producer;
	private long periodoMsParaEstatistica;
	private Long nrMensagensPorSegundoTarget;
	
	RobotRunnable(
			Long periodoMsParaEstatistica, Long nrMensagensPorSegundo, String messageType, String queueJndiName, 
			String urlQueueServer, String topicJndiName, String urlTopicServer,
			String socketAddress, boolean msgCompactada) {
		this.periodoMsParaEstatistica = periodoMsParaEstatistica;
		this.nrMensagensPorSegundoTarget = nrMensagensPorSegundo;
		
		if(socketAddress!=null && !socketAddress.isEmpty() && socketAddress.length() > 0){
			this.producer = SocketProducerFactory.getProducer(messageType,
					socketAddress, msgCompactada);
		}else{
			this.producer = JmsProducerFactory.getProducer(messageType,
					queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		}
		synchronized (xlock) {
			if (dataAutorizacao == null) {
				RobotRunnable.dataAutorizacao = RoboCieloCEP.initialDate;
			}
		}
	}

	public void run() {
		synchronized (xlock) {
			if (tempoInicioColetaEstat == 0) {
				tempoInicioColetaEstat = System.currentTimeMillis();
			}
		}
		while (true) {
			// retira uma mensagem da fila

			byte[] message;
			message = getNextTripa();
			if (message == null) {
				// acabou o pool de mensagens. esperar at� a thread principal gerar mais dados.
				synchronized (ylock){
//					tempoInicioColetaEstat = 0L;
					queueEmpty = true;
					try {
						Thread.sleep(1);
						continue;
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}

			try {
				enviaMensagemJMS(message);
			} catch (Exception e) {
				throw new RuntimeException("Erro executando thread", e);
			}

			synchronized (xlock) {
				mensPostadasGeral++;
				long now = System.currentTimeMillis();
				long tempoAAlcancar = tempoInicioColetaEstat
						+ periodoMsParaEstatistica;
				if (mensPostadasGeral==nrMensagensPorSegundoTarget
						&& tempoAAlcancar > now) {
					// espera terminar o tempo para o proximo periodo de
					// estatistica
					try {
						Thread.sleep(tempoAAlcancar - now);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				now = System.currentTimeMillis();
				if (tempoAAlcancar <= now) {
					lastStatistics = mensPostadasGeral;
					iterationsStats++;
					totalStatistics += mensPostadasGeral;
					tempoInicioColetaEstat = now;
					System.out.println("[" + Thread.currentThread().getId()
							+ "] Estatistica de Envio de mensagens:"
							+ (mensPostadasGeral) + " mens/"
							+ periodoMsParaEstatistica + "ms");
					mensPostadasGeral = 0L;
				
				}
			}

		}
	}

	public static boolean isQueueEmpty() {
		synchronized (queueEmpty) {
			return queueEmpty;
		}
	}

	public byte[] getNextTripa() {
		synchronized (messageQueue) {
			return messageQueue.poll();
		}
	}
	
	public static Long getLastStat() {
			return new Long(lastStatistics);

	}

	public static Double getAvgStat() {
		synchronized (xlock) {
			if (iterationsStats == 0)
				return 0.0;
			Double avg = ((double) totalStatistics) / iterationsStats;
			//totalStatistics = 0L;
			//iterationsStats = 0;
			return avg;
		}

	}
	public static void carregaTripas(Collection<byte[]> tripas) {
		synchronized (messageQueue) {
			messageQueue.addAll(tripas);
			queueEmpty = false;
		}
	}
	private void enviaMensagemJMS(byte[] tripa) throws Exception {
		// nao manda, mas finge que manda
		producer.sendMessage(tripa);
		try{
			//Thread.sleep(RandomUtils.nextInt(10));// Simula a demora da mensagem, para criar mais threads
            RoboCieloCEP.countMessagesOUT.addAndGet(1);
        }catch(Exception e){
            e.printStackTrace();
        }
	}
	
}
