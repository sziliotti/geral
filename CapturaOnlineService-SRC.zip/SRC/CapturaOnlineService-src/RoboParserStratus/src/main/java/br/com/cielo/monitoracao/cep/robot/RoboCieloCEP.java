/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cielo.monitoracao.cep.robot;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.GZIPInputStream;

import org.apache.commons.lang.ArrayUtils;

import br.com.cielo.monitoracao.cep.robot.stratus.ProdutorStratusSocket;

/**
 *
 * @author nemer
 */
public class RoboCieloCEP {

    // entende-se por enviar 2000 mensagens por segundo. Entao elas deve ser
    // geradas no mesmo tempo.
    static int qtdMessagesInCache = 10000;
    static String messageType = "mainframe"; // mainframe / floridaPgtoCelular / floridaDePara

    static final int corePoolSize = 10;
    static final int maximumPoolSize = 100;
    public static boolean isAdjustStratusDate = false;
    static final long keepAliveTime = 10000;
    // define se deve regerar o cache de mesagens infinitamente ap�s o t�rmino
    static boolean infinite = true;
    static TimeUnit unit = TimeUnit.MINUTES;

    static Long delayMsEntreMensagens = 0L;
    static int maxThreads = 50;
    static Long periodoMsParaEstatistica = 1000L;
    static Long sobrecargaThreadsParaConsiderarStall = 100L;
    static Long nrMensagensPorSegundo = 2000L;

    static String jmsQueueURL;
    private static String queueJndiName;
    private static String urlQueueServer;
    static String jmsTopicURL;
    private static String topicJndiName;
    private static String urlTopicServer;
    private static String fileSamples;
    public static Date finalDate;
    public static Date initialDate;
    public static String jmsUser;
    public static String jmsPassword;
    public static String jmsType;
    public static int fileCacheSize = -1;
    public static String fileDirSample = null;
    public static String fileFormat = null;
    public static Boolean isGZIPFile = false;
    private static String tempGzipDir = null;
    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

    private static Properties propertiFileConfig = null;

    static String socketAddress;
    static boolean msgCompactada = false;

    public static AtomicInteger countMessagesOUT = new AtomicInteger(0);
    private static boolean counterStarted = false;

    private static boolean allCacheLoaded = true;

    public static boolean isAllCacheLoaded() {
        return allCacheLoaded;
    }

    public static void setAllCacheLoaded(boolean param) {
        allCacheLoaded = param;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {

        String propertyFileNameAsString = "";
        if ((args != null && args.length == 1)) {
            String[] param = args[0].split("=", 2);
            String name = param[0];
            String value = param[1];
            if ("--props".equals(name)) {
                propertyFileNameAsString = value;
                File propFile = new File(value);
                if (propFile.exists()) {
                    propertiFileConfig = new Properties();
                    InputStream in = new FileInputStream(propFile);
                    propertiFileConfig.load(in);
                    in.close();
                }
            }
        }

        if (propertiFileConfig == null && (args == null || args.length < 2)) {
            System.out.println(" -------------------------------------------- ");
            System.out.println(" ::: Robo Helper ::: ");
            System.out.println(" ");
            System.out.println(" Parametros do Rob�: ");
            System.out.println(" [messagesInCache]: tamanho do cache de mensagens (default:10,000)");
            System.out.println(" [type]: configura��o do rob�. (default: mainframe)");
            System.out.println(" [infinite]: looping infinito (default: true)");
            System.out.println(" [messageDelay]");
            System.out.println(" [messagesPerSecond]: volume de TPS (default: 2,000)");
            System.out.println(" [iniDate] e [endDate]");
            System.out.println(" [adjustStratusDate]: true se deseja ajustar a data/hora do stratus para data atual (soh tem efeito caso seja realizado carga de massa de dados). O padr�o � falso");
            System.out.println(" [threads]: m�ximo de threads");
            System.out.println(" [retryStatUntilConsiderStall]: sobrecarga threads para considerar Stall");
            System.out.println(" ");
            System.out.println(" Socket | [socketAddress]");
            System.out.println(" ");
            System.out.println(" TOPIC | [jmsTopicJndiName] e [jmsTopicURL]");
            System.out.println(" QUEUE | [jmsQueueJndiName] e [jmsQueueURL]");
            System.out.println(" [jmsUser] e [jmsPassword]: Autentica��o. Somente usando quando informado.");
            System.out.println(" [jmsType]: quando WLS, ajusta para filas do WebLogic");
            System.out.println(" ");
            System.out.println(" [fileSamples]: Diret�rio do arquivo a ser carregado.");
            System.out.println(" [fileCacheSize]: Se informado, carrega por partes um arquivo ao inv�s de carregar ele todo.");
            System.out.println(" [fileDirSample]: Se informado, carrega todos os arquivos do diret�rio.");
            System.out.println(" [fileFormat]: Formato do arquivo a ser carregado. ");
            System.out.println(" [msgCompactada]: indica que a mensagem � compactada");
            System.out.println(" [gzip]: indica que o arquivo est� compactado no padr�o GZIP");
            System.out.println(" [tempGzipDir]: diret�rio tempor�rio para descompactar arquivo(s) compactados com GZIP");
            System.out.println(" ");
            System.out.println(" Exemplo: ");
            System.out.println(" --messagesInCache=0 --infinite=true --messageDelay=0  --messagesPerSecond=1 --jmsQueueURL=nio://10.64.102.41:60721 --jmsQueueJndiName=br.com.cielo.monitoracao.stratus.queue.In.SP --jmsUser=bamusermq --jmsPassword=bamusermq --type=stratus --fileSamples=C:/Users/eyvd21/Documents/massa/teste_stratus_compactada.log ");
            System.out.println(" -------------------------------------------- ");
            System.exit(0);
        }

        System.out.println("-------------------------------------------- ");
        System.out.println("Iniciando o robot... ");
        System.out.println("Robo Version = 2015-01-15");
        System.out.println("Java Version = " + System.getProperty("java.version"));
        System.out.println("Java Home = " + System.getProperty("java.home"));
        System.out.println("");
        if (propertiFileConfig != null) {
            System.out.println("Props = " + propertyFileNameAsString);
            System.out.println(propertiFileConfig.getProperty("descricao"));
        } else {
            System.out.println("Args = " + ArrayUtils.toString(args));
        }
        System.out.println("");

        Map<String, String> params = new HashMap<String, String>();
        if (propertiFileConfig != null) {
            // Carrega do propeties
            for (Object str : propertiFileConfig.keySet().toArray()) {
                params.put(str.toString(), propertiFileConfig.getProperty(str.toString()));
            }
        } else {
            // Carrega da linha de comando
            for (int i = 0; i < args.length; i++) {
                String[] param = args[i].split("=", 2);
                params.put(param[0], param[1]);
            }
        }
        String value;
        if (null != (value = params.get("--messagesInCache"))) {
            System.out.println("--messagesInCache = " + value);
            qtdMessagesInCache = Integer.valueOf(value);
        }
        if (null != (value = params.get("--threads"))) {
            System.out.println("--threads = " + value);
            maxThreads = Integer.parseInt(value);
        }
        if (null != (value = params.get("--type"))) {
            System.out.println("--type = " + value);
            messageType = value;
        }
        if (null != (value = params.get("--infinite"))) {
            System.out.println("--infinite = " + value);
            infinite = Boolean.valueOf(value);
        }
        if (null != (value = params.get("--messageDelay"))) {
            System.out.println("--messageDelay = " + value);
            delayMsEntreMensagens = Long.valueOf(value);
        }
        // if (null != (value=params.get("--statisticBandMs"))) {
        // periodoMsParaEstatistica=Long.valueOf(value);
        // }
        if (null != (value = params.get("--retryStatUntilConsiderStall"))) {
            System.out.println("--retryStatUntilConsiderStall = " + value);
            sobrecargaThreadsParaConsiderarStall = Long.valueOf(value);
        }
        if (null != (value = params.get("--messagesPerSecond"))) {
            System.out.println("--messagesPerSecond = " + value);
            nrMensagensPorSegundo = Long.valueOf(value);
        }
        if (null != (value = params.get("--jmsQueueURL"))) {
            System.out.println("--jmsQueueURL = " + value);
            jmsQueueURL = value;
            urlQueueServer = jmsQueueURL;
        }
        if (null != (value = params.get("--jmsQueueJndiName"))) {
            System.out.println("--jmsQueueJndiName = " + value);
            queueJndiName = value;
        }
        if (null != (value = params.get("--jmsTopicURL"))) {
            System.out.println("--jmsTopicURL = " + value);
            jmsTopicURL = value;
            urlTopicServer = jmsTopicURL;
        }
        if (null != (value = params.get("--jmsTopicJndiName"))) {
            System.out.println("--jmsTopicJndiName = " + value);
            topicJndiName = value;
        }
        if (null != (value = params.get("--fileSamples"))) {
            System.out.println("--fileSamples = " + value);
            fileSamples = value;
        }
        if (null != (value = params.get("--iniDate"))) {
            System.out.println("--iniDate = " + value);
            initialDate = sdf.parse(value);
        }
        if (null != (value = params.get("--endDate"))) {
            System.out.println("--endDate = " + value);
            finalDate = sdf.parse(value);
        }
        if (null != (value = params.get("--jmsUser"))) {
            System.out.println("--jmsUser = " + value);
            jmsUser = value;
        }
        if (null != (value = params.get("--jmsPassword"))) {
            System.out.println("--jmsPassword = " + value);
            jmsPassword = value;
        }
        if (null != (value = params.get("--adjustStratusDate"))) {
            System.out.println("--adjustStratusDate = " + value);
            isAdjustStratusDate = new Boolean(value).booleanValue();
        }
        if (null != (value = params.get("--jmsType"))) {
            System.out.println("--jmsType = " + value);
            jmsType = value;
        }
        if (null != (value = params.get("--fileCacheSize"))) {
            try {
                fileCacheSize = Integer.parseInt(value);
            } catch (Exception e) {
                System.out.println("O par�metro --fileCacheSize n�o foi informado corretamente.");
                System.out.println("O valor para --fileCacheSize deve ser um n�mero inteiro (valor informado[" + value + "])");
                System.exit(0);
            }
            setAllCacheLoaded(false);
            System.out.println("--fileCacheSize = " + fileCacheSize);
        }
        if (null != (value = params.get("--fileDirSample"))) {
            fileDirSample = value;
            System.out.println("--fileDirSample = " + fileDirSample);
        }
        if (null != (value = params.get("--fileFormat"))) {
            //--
            // Op��es de File Format:
            // TransacaoStratusBuilder: COMPACTADA1, COMPACTADA2
            //--
            fileFormat = value;
            System.out.println("--fileFormat = " + fileFormat);
        }

        //-- Verifica se envia mensagem via Socket. (Simular Adapter)
        if (null != (value = params.get("--socketAddress"))) {
            System.out.println("--socketAddress = " + value);
            socketAddress = value;
        }
        if (null != (value = params.get("--msgCompactada"))) {
            System.out.println("--msgCompactada = " + value);
            msgCompactada = Boolean.valueOf(value);
        }
        if (null != (value = params.get("--gzip"))) {
            System.out.println("--gzip = " + value);
            isGZIPFile = Boolean.valueOf(value);
        }
        if (null != (value = params.get("--tempGzipDir"))) {
            System.out.println("--tempGzipDir = " + value);
            tempGzipDir = value;
        }

        System.out.println("-------------------------------------------- ");
        System.out.println("");

        RoboCieloCEP robo = new RoboCieloCEP();
        robo.runRobot();

    }

    public static File getFileSamplesAsFile() {
        File fXmlFile = null;
        try {
            fXmlFile = new File(fileSamples);
        } catch (Exception e) {
            System.out.println("N�o � poss�vel abrir o arquivo: " + fileSamples);
            e.printStackTrace();
        }
        return fXmlFile;
    }

    private static BufferedReader reader;
    private static ConcurrentLinkedQueue<File> filesReaderQueue;

    /**
     * Retorna um Reader de um arquivo. Se informado um diretorio, deve retornar
     * um reader at� acabar o arquivo e depois ir para o proximo, at� acabar os
     * arquivos do diret�rio.
     *
     * @return
     */
    public static BufferedReader getFileSamples() {
        try {
            if (reader == null && fileSamples != null) {
                openFile(fileSamples);
            } else if (reader == null && fileDirSample != null) {
                // Carrega a lista de arquivos do diretorio para marcar quem ja foi lido
                // Abre o primeiro arquivo do diretorio e marca como lido.
                openNextFile();
            } else // Verificar se carregou todo o arquivo, e se for diretorio, ir para o proximo arquivo
            if (isAllCacheLoaded()) {
                if (fileDirSample != null) {
                    // tem mais arquivos pra ler?
                    openNextFile();
                } else if (fileSamples != null && infinite) {
                    System.out.println("");
                    System.out.println(" +++++++++++++++++++++++++++++++++NOVO CICLO+++++++++++++++++++++++++++++++++");
                    openFile(fileSamples); // Abre de novo, � infinito e acabou
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(0);
        }
        return reader;
    }

    private static void unzipGzFile(String compressedFile, String decompressedFile) throws RuntimeException {
        byte[] buffer = new byte[1024];
        try {
            System.out.print("--GZIP--:");
            //System.out.println(" Arquivo Origem:  " + compressedFile);
            //System.out.println(" Arquivo Destino: " + decompressedFile);
            //System.out.println("");
            System.out.print(" Descompactando........");

            FileInputStream fileIn = new FileInputStream(compressedFile); // Destino
            GZIPInputStream gZIPInputStream = new GZIPInputStream(fileIn);
            FileOutputStream fileOutputStream = new FileOutputStream(decompressedFile); // Origem
            int bytes_read;
            while ((bytes_read = gZIPInputStream.read(buffer)) > 0) {
                fileOutputStream.write(buffer, 0, bytes_read);
            }
            gZIPInputStream.close();
            fileOutputStream.close();

            System.out.println("Pronto!");
            //System.out.println("---------------------------");
        } catch (IOException ex) {
            //ex.printStackTrace();
            throw new RuntimeException("Problemas ao descompactar o arquivo", ex);
        }
    }

    private static File temporaryUnzippedFile = null;

    private static void removeTempUnzippedFile() {
        if (temporaryUnzippedFile != null) {
            if (temporaryUnzippedFile.exists()) {
                //System.out.println(" Removendo o arquivo " + temporaryUnzippedFile.getAbsolutePath());
                //System.out.println("");
                temporaryUnzippedFile.delete();
            }
        }
    }

    /**
     * Abre o arquivo
     *
     * @throws RuntimeException
     */
    private static void openFile(String fileName) throws RuntimeException {
        try {

            if (isGZIPFile) {
                // Tentar abrir GZIP
                // Descompactar em um arquivo
                File file = new File(fileName);
                String localTempGzipDir = tempGzipDir;
                if (tempGzipDir == null) {
                    localTempGzipDir = file.getParent() + "/tmp";
                }
                File tempDir = new File(localTempGzipDir);
                tempDir.mkdir();
                String tempFileName = localTempGzipDir + "/temporary.unzip.file";
                temporaryUnzippedFile = new File(tempFileName);
                removeTempUnzippedFile();
                unzipGzFile(fileName, tempFileName);
                reader = new BufferedReader(new FileReader(tempFileName));
            } else {
                reader = new BufferedReader(new FileReader(fileName));
            }

            setAllCacheLoaded(false);

        } catch (Exception e) {
            throw new RuntimeException("Arquivo nao pode ser aberto.", e);
        }
    }

    /**
     * Carrega os arquivos do diretorio no fila.
     */
    private static void loadFilesToReaderQueue() {
        filesReaderQueue = new ConcurrentLinkedQueue<File>();
        File f = new File(fileDirSample);
        if (!f.exists()) {
            throw new RuntimeException("O diret�rio [" + fileDirSample + "] n�o � v�lido ou n�o existe.");
        } else {
            File files[] = f.listFiles();
            for (File file : files) {
                if (file.isFile()) {
                    filesReaderQueue.add(file);
                }
            }
        }
        if (filesReaderQueue.isEmpty()) {
            throw new RuntimeException("O diret�rio [" + fileDirSample + "] n�o possui arquivos.");
        }
    }

    /**
     * Abrir o pr�ximo arquivo do diret�rio da lista de arquivos carregados
     *
     * @return
     */
    private static void openNextFile() {
        if (fileDirSample != null) {
            if (filesReaderQueue == null) {
                // Limpa o arquivo temporario gerado pelo zip, caso existe
                removeTempUnzippedFile();
                // N�o foi carregado ainda, carrega a lista dos arquivos
                loadFilesToReaderQueue();
            }
            // Carregado os arquivos, abre o proximo
            if (!filesReaderQueue.isEmpty()) {
                try {
                    if (reader != null) {
                        reader.close();
                    }
                    File f = filesReaderQueue.poll();
                    //System.out.println("");
                    System.out.println("Abrindo o proximo arquivo: " + f.getName());
                    allCacheLoaded = false;
                    openFile(f.getAbsolutePath());
                } catch (Exception e) {
                    throw new RuntimeException("Erro ao tentar abrir o arquivo", e);
                }
            } else // N�o est� nulo, mas est� empty: carregou todos j�
            if (infinite) {
                System.out.println("");
                System.out.println(" +++++++++++++++++++++++++++++++++NOVO CICLO+++++++++++++++++++++++++++++++++");
                // Zera a lista a carrega tudo de novo
                filesReaderQueue = null;
                openNextFile();
            }
        }
    }

    public static void clearFilesReaderQueue() {
        if (filesReaderQueue != null) {
            filesReaderQueue.clear();
        }
    }

    public static boolean isFileCachedEnabled() {
        return RoboCieloCEP.fileCacheSize > 0;
    }

    private TransacaoBuilderGenerico transacaoBuilder;

    private TransacaoBuilderGenerico getBuilder() {
        if (transacaoBuilder == null) {
            transacaoBuilder = TransacaoBuilderFactory.getBuilder(messageType);
        }
        return transacaoBuilder;
    }

    private void runRobot() throws Exception {

        if (!counterStarted) {
            counterStarted = true;
            new Thread() {
                @Override
                public void run() {
                    int lastCountOUT = 0;
                    while (true) {
                        try {
                            if (lastCountOUT != countMessagesOUT.intValue()) {
                                System.out.println(" Contador de Mensagens : OUT [" + countMessagesOUT.intValue() + "] ");
                                lastCountOUT = countMessagesOUT.intValue();
                            }
                            Thread.sleep(10000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }.start();
        }

        Collection<byte[]> tripas = getBuilder().generateMessages(qtdMessagesInCache);
        System.out.println("Carregando buffer de mensagens {" + tripas.size() + "}");
        System.out.println("");
        RobotRunnable.carregaTripas(tripas);

        ThreadPoolExecutor tpe
                = new ThreadPoolExecutor(
                        corePoolSize,
                        maximumPoolSize,
                        keepAliveTime,
                        unit,
                        new ArrayBlockingQueue<Runnable>(corePoolSize * 2));

        // escala ate encontrar a quantida maxima aceita
        boolean escalar = false;
        while (true) {
            if (escalar) {
                // o ultimo aumento aumentou as estatisticas, entao adiciono
                // mais um robot
                Runnable r = new RobotRunnable(
                        periodoMsParaEstatistica, nrMensagensPorSegundo, messageType,
                        queueJndiName, urlQueueServer, topicJndiName, urlTopicServer,
                        socketAddress, msgCompactada);
                tpe.execute(r);
                escalar = false;
                System.out.println("Adicionado novo robot... total: ["
                        + (tpe.getActiveCount() + 1) + "]");
            }
            // espera por estatisticas do robot de threads para iniciar a nova
            // analise de escalabilidade.
            Thread.sleep(periodoMsParaEstatistica * 2);

            if (RobotRunnable.getLastStat() < nrMensagensPorSegundo * 0.9
                    && tpe.getActiveCount() < maxThreads) {
                escalar = true;
            }

            if (RobotRunnable.isQueueEmpty()) {
                if ((isFileCachedEnabled() && (!isAllCacheLoaded()) || (filesReaderQueue != null && !filesReaderQueue.isEmpty())) || infinite) {
                    tripas = getBuilder().generateMessages(qtdMessagesInCache);
                    System.out.println("Carregando mais mensagens {" + tripas.size() + "}");
                    RobotRunnable.carregaTripas(tripas);
                } else {
                    System.out
                            .println("Termino massa de dados. Finalizando robot...");
                    System.out.println(" Total Enviados : OUT [" + countMessagesOUT.intValue() + "] ");
                    ProdutorStratusSocket.closeSocket();
                    System.exit(0);
                }
            }
        }
    }

}
