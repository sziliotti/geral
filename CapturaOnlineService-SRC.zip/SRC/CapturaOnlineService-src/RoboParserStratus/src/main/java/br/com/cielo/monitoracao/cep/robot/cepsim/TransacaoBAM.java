package br.com.cielo.monitoracao.cep.robot.cepsim;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import br.com.cielo.monitoracao.cep.robot.Transacao;

public class TransacaoBAM extends Transacao{
	protected transient static final SimpleDateFormat sdfDataHoraMinuto = new SimpleDateFormat("MM/dd/yyyy HH:mm");
	protected transient static final SimpleDateFormat sdfHrMin = new SimpleDateFormat("HH:mm");
	private static final List<String> codProdutoPay = Arrays.asList(new String[]{"00260000","00270000","00620000","00630000","00640000","00650000","00760000","01000007","01000008",
			"01000009","01000010","01000011","01000012","01000013","03100007","03100008","03100009","03100010",
			"03100011","03100017","07300000","07310000","07320000","07330000","07340000","07380000","07390000",
			"07400000","60000001","60000002","60000003","60000006","60000007","60000008","70000001","70000002",
			"70000003","70000004","70000005"});
	public String getTripa(){
		
		int qtdTrans = getAleatorioGenerico(1, 10) < 4 ? 3 : (getAleatorioGenerico(1, 10));
		int qtdApro = qtdTrans > 1 ? getAleatorioGenerico(1, qtdTrans) : qtdTrans;
		int residuo = qtdTrans - qtdApro;
		int qtdNeg = residuo > 1 ? getAleatorioGenerico(1, residuo) : residuo;
		residuo -= qtdNeg;
		int qtdCanc = residuo > 1 ? getAleatorioGenerico(1, residuo) : residuo;
		residuo -= qtdCanc;
		int qtdDesf = residuo;
		
		if (qtdDesf + qtdNeg + qtdCanc + qtdApro != qtdTrans)
			throw new IllegalStateException ("Soma diferente...");
		Date dataHoraAut = new Date();
		String produtoCompleto = produto+subProduto;
		TransacaoBAMBuilder.setIndicSkyline(this);
		String tpSkyline = this.indicSkyline;
		
		return "<Transacao>" + "<Mainframe>" 
		+ nvlTag("CodProdutoCompleto", produtoCompleto)
		+ nvlTag("CodSubProduto", getAleatorioGenerico(10, 20))
        + nvlTag("ChaveMaquina", this.chaveDaMaquina)
		+ nvlTag("CodBandeira", this.bandeira)
		+ nvlTag("CodBanco", this.banco)
		+ nvlTag("CodSolCapt", this.tipoTecn)
		+ nvlTag("DataHoraAut", sdfDataHoraMinuto.format(new Date())+":59")
		+ nvlTag("CodSite", getAleatorioGenerico(1, 2))
		+ nvlTag("QtdAutorizacao", qtdTrans)
		+ nvlTag("QtdAprovadas", qtdApro)
		+ nvlTag("QtdNegadas", qtdNeg)
		+ nvlTag("IndicSkyline", "N".equals(tpSkyline) ? "N" : "S")
		+ nvlTag("TipoSkyline", tpSkyline)
		+ nvlTag("TempoMedioTranSeg", new BigDecimal(getAleatorioGenerico(1, 3)).divide(new BigDecimal(getAleatorioGenerico(1, 10))
																						,2,BigDecimal.ROUND_UP))
		+ nvlTag("QtdDesfazimento", qtdDesf)
		+ nvlTag("TipoTransacao", codProdutoPay.contains(produtoCompleto) ? "PAY" : "MAINFRAME")
		+ nvlTag("QtdCanceladas", qtdCanc)
		// s� vai fazer sentido enviar mensagem e quemResp se for negada. Para as demais qtdade de estado, ignorar
		+ (qtdNeg == 0 ? "" : nvlTag("Mensagem", "XXXQualquerCoisa")
		                             + nvlTag("QuemResp", this.quemResps[getAleatorioGenerico(0, this.quemResps.length -1)])
		   )
		+ nvlTag("HoraMinAgrupado", getDateTimeGrouped(5,dataHoraAut,sdfHrMin)) + "</Mainframe>"
		+ "</Transacao>";
	}

	private String nvlTag(String tag, Object valor) {
		return valor == null ? "" : "<" + tag + ">" + valor + "</" + tag + ">";
	}
	protected int getAleatorioGenerico(int min, int max) {
		//int r = min + ((int) (Math.random() * 1000000) % (max - min + 1));
		SecureRandom a = new SecureRandom();
		return a.nextInt(max + 1 - min) + min;
		//return r;
	}
	public static String getDateTimeGrouped(int minutesGroup, Date date, DateFormat sdf) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		
		int minute = Integer.valueOf(c.get(Calendar.MINUTE));
		int minuteNormalized = (minute / minutesGroup) * minutesGroup;
		c.set(Calendar.MINUTE, minuteNormalized);
		return sdf.format(c.getTime());
	}
}