package br.com.cielo.monitoracao.cep.robot.push;

import java.text.SimpleDateFormat;
import java.util.Date;

import br.com.cielo.monitoracao.cep.robot.Transacao;
import br.com.cielo.monitoracao.cep.robot.TransacaoBuilderGenerico;
import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;

public class TransacaoPushBuilder extends TransacaoBuilderGenerico {
	
	boolean emissorAleatorio = false;
	boolean statusAleatorio = false;
	boolean produtoESubProdutoAleatorio = false;
	boolean ajustarDataHoraTran = false;
	boolean siteAleatorio = false;
	boolean siglaSolCapturaAleatorio = false;
	
	private boolean isEmissorAleatorio() {
		return emissorAleatorio;
	}
	private boolean isStatusAleatorio() {
		return statusAleatorio; 
	}
	private boolean isProdutoESubProdutoAleatorio() {
		return produtoESubProdutoAleatorio;
	}
	private boolean isAjustarDataHoraTran() {
		return ajustarDataHoraTran;
	}
	
	public boolean isSiteAleatorio() {
		return siteAleatorio;
	}

	public boolean isSiglaSolCaptAleatorio() {
		return siglaSolCapturaAleatorio;
	} 
	
	public TransacaoPushBuilder(Transacao template, VariaveisGeracao ... variaveis){
		for (int i = 0; i < variaveis.length; i++) {
			switch (variaveis[i]){
			case EMISSOR_ALEATORIO:
				emissorAleatorio=true;break;
			case STATUS_ALEATORIO:
				statusAleatorio=true;break;
			case PRODUTO_E_SUBPRODUTO_ALEATORIO:
				produtoESubProdutoAleatorio = true;
				break;
			case SIGLA_SOL_CAPT_ALEATORIO:
				siglaSolCapturaAleatorio = true;
				break;
			case SITE_ALEATORIO:
				siteAleatorio = true;
				break;
			case AJUSTAR_DATAHORA_TRAN:
				ajustarDataHoraTran = true;
				break;
			}
		}
	}
	
	public TransacaoGenerica gerarNovaTransacao(Date dataHoraTran){
		TransacaoPush t = new TransacaoPush();
		if (dataHoraTran == null) {
			dataHoraTran = new Date();
		}
		if (isAjustarDataHoraTran()){
			setInicioTermino(t);		
		}
		if (isEmissorAleatorio()) {
			setEmissorAleatorio(t);
		}
		if (isProdutoESubProdutoAleatorio()) {
			setProdutoESubProduto(t);
		}
		if (isStatusAleatorio()) {
			setStatusAleatorio(t);
		}
		if (isSiteAleatorio()) {
			setSiteAleatorio(t);
		}
		if (isSiglaSolCaptAleatorio()) {
			setSiglaSolCaptAleatorio(t);
		}
		
		return t;
	}
	
	private void setSiglaSolCaptAleatorio(TransacaoPush t) {
		int indice = getAleatorioGenerico(0, t.sgSolCapts.length-1);
		t.sgSolCapt = t.sgSolCapts[indice];
	}
	private void setSiteAleatorio(TransacaoPush t) {
		int indice = getAleatorioGenerico(0, t.sites.length-1);
		t.cdSite = t.sites[indice];
	}
	private void setInicioTermino(TransacaoPush t) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		// tiro 15 segundos para simular a latencia do autorizador 
		Date now = new Date(System.currentTimeMillis()-15000);
		t.dhAcao = sdf.format(now);
	}

	private  void setEmissorAleatorio(TransacaoPush t) {
		int indice = getAleatorioGenerico(0, t.idEmissores.length - 1);
		t.cdEmissor = t.idEmissores[indice];
	}

	private  void setProdutoESubProduto(TransacaoPush t) {
		int indice = getAleatorioGenerico(0, t.idProdutoCompletos.length - 1);
		String produtoMtz = t.idProdutoCompletos[indice].substring(0,4);
		String produtoSec = t.idProdutoCompletos[indice].substring(4);
		t.cdProdutoMtz = produtoMtz;
		t.cdProdutoSec = produtoSec;

		indice = getAleatorioGenerico(0, t.subProdutos.length - 1);
		String produtoSecundario = t.subProdutos[indice];
		t.cdSubProd = produtoSecundario;
	}

	private  void setStatusAleatorio(TransacaoPush t) {
		// tenho 4 status: 1 e 2 - Cancelamento, 2 - Desfazimento, 3 - Aprovado,
		// 4 - Negado
		int statusId = getAleatorioGenerico_2(1, 5);
		switch (statusId) {
		case 1:
		case 2:
		case 3:
		case 4:
			t.cdTipoAcao = "14";
			t.dcTipoAcao = "Aprovado                                          ";
			break;
		case 5:
			int statusErro = getAleatorioGenerico(0, t.cdTipoAcoes.length-1);
			t.cdTipoAcao = t.cdTipoAcoes[statusErro];
			t.dcTipoAcao = t.dcTipoAcoes[statusErro];
		}
		
		statusId = getAleatorioGenerico_2(1, 5);
		switch (statusId) {
		case 1:
		case 2:
		case 3:
		case 4:
			t.cdStatusNegocio = "020"; // aprovado
			break;
		case 5:
			int statusErro = getAleatorioGenerico(0, t.cdStatusNegocios.length-1);
			t.cdStatusNegocio = t.cdStatusNegocios[statusErro];
		}

		
	}
	
	private String getSpaces(int i) {
		String spaces = "";
		for (int j = 0; j < i; j++) {
		   spaces += " ";	
		}
		return spaces;
	}


}
