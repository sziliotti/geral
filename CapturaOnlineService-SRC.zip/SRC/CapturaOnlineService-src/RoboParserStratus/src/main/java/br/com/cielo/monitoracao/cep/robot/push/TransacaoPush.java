package br.com.cielo.monitoracao.cep.robot.push;

import java.text.SimpleDateFormat;
import java.util.Date;

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;


public class TransacaoPush implements TransacaoGenerica{
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	String nuTID="12345678901234567890";
	String cdTipoOp="1"; //PUSH
	String cdEmissor="0001";
	String nmEmissor="BANCO DO BRASIL     ";
	String cdProdutoMtz="0500";
	String cdProdutoSec="0014";
	String cdSubProd="0010";
	String sgSolCapt="WAP";
	String dhAcao=sdf.format(new Date());
	String cdTipoAcao="14";
	String dcTipoAcao="Aprovado                                          ";
	String cdStatusNegocio="030";
	String dcStatusNegocio="XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
	String cdSite="SP";
	
	static final String[] idEmissores = new String[] { "0001","0001","0001", "0353", "0241", "0424", "0237", "0237" };

	static final String[] sites = new String[] {"SP", "RJ", "RJ"};
	static final String[] sgSolCapts = new String[] { "WAP", "SMC", "VOL","POS"};
	static final String[] cdTipoAcoes = new String[] { "11", "12", "13","14","21", "22", "23","24"};
	static final String[] dcTipoAcoes = new String[] { "Erro                                              ",
		"Erro                                              ", 
		"Aprovado                                          ", 
		"Erro                                              ",
		"Erro                                              ", 
		"Erro                                              ", 
		"Erro                                              ",
		"Erro                                              " };
	static final String[] subProdutos = new String[] { "0010", "0011", "0012","0013", "0014", "0015","0016","0017","0018","0019","0020" };
	static final String[] cdStatusNegocios = new String[] {"010", "020", "030", "040", "042", "043", "044", "049", "050", "070", "180", "196"
		, "201", "213", "214", "255"};
	
	static final String[] idProdutoCompletos = new String[] { "00800000", "02000001", "07110000",
		"05000028", "00490000", "00480000", "05000014", "07120000",
		"05000029", "00370000", "05000027", "07150000", "05000032",
		"07200000", "05000033", "00620000", "01000009", "01000007",
		"00270000", "01000008", "00650000", "01000012", "00760000",
		"01000013", "00470000", "05000013", "00440000", "05000016",
		"00580000", "05000018", "07060000", "05000024", "00510000",
		"05000009", "00390000", "05000012", "05000003", "00520000",
		"05000010", "07030000", "05000021", "07080000", "00690000",
		"05000005", "07040000", "05000022", "07140000", "05000031",
		"07050000", "05000023", "07090000", "00260000", "00630000",
		"01000010", "07010000", "05000019", "05000017", "00570000",
		"05000007", "07020000", "05000020", "07070000", "05000025",
		"05000026", "07130000", "05000030", "05000002", "00640000",
		"01000011", "00060000", "00820000", "03000001", "00350000",
		"03100001", "00670000", "03200001", "00680000", "03250001",
		"00280000", "04080001", "00610000", "04290001", "00430000",
		"04380001", "07100000", "04580001", "00860000", "05500001",
		"00800000", "02000003", "00820000", "03000002", "00350000",
		"03100003", "00670000", "03200002", "00280000", "04080003",
		"00610000", "04290002", "00430000", "04380002", "07100000",
		"04580002", "00860000", "05500002", "00820000", "03000003",
		"00860000", "05500003", "00810000", "02000002", "00360000",
		"03100002", "00290000", "04080002", "00790000", "07000005",
		"01000014", "00050000", "05000001", "00560000", "06000002",
		"06000003", "06000004", "06000005", "06000006", "06000007",
		"06000008", "05000006", "00870000", "05000008", "00380000" };
	
	String getNmProdMtz() {
		return "Produto MTZ  Nr."+cdProdutoMtz;
	}
	public String getTripa(){
		return nuTID+
		cdTipoOp+
		cdEmissor+
		nmEmissor+
		cdProdutoMtz+
		getNmProdMtz()+
		cdProdutoSec+
		cdSubProd+
		sgSolCapt+
		dhAcao+
		cdTipoAcao+
		dcTipoAcao+
		cdStatusNegocio+
		dcStatusNegocio+
		cdSite;
		
	}
	@Override
	public String toString() {
		return "TransacaoPush [sdf=" + sdf + ", nuTID=" + nuTID + ", cdTipoOp="
				+ cdTipoOp + ", cdEmissor=" + cdEmissor + ", nmEmissor="
				+ nmEmissor + ", cdProdutoMtz=" + cdProdutoMtz
				+ ", cdProdutoSec=" + cdProdutoSec + ", cdSubProd=" + cdSubProd
				+ ", sgSolCapt=" + sgSolCapt + ", dhAcao=" + dhAcao
				+ ", cdTipoAcao=" + cdTipoAcao + ", dcTipoAcao=" + dcTipoAcao
				+ ", cdStatusNegocio=" + cdStatusNegocio + ", dcStatusNegocio="
				+ dcStatusNegocio + ", cdSite=" + cdSite + "]";
	}




}
