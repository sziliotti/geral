package br.com.cielo.monitoracao.cep.robot.arv;

import java.security.SecureRandom;
/*
import java.util.Properties;

import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
*/
import javax.jms.TextMessage;
import javax.jms.Message;


import br.com.cielo.monitoracao.cep.robot.ProducerGenerico;

public class ProdutorArv extends ProducerGenerico{

	static final String[] codSites = new String[] {"SP","RJ"};
	
	public ProdutorArv(String queueJndiName, String urlQueueServer,String topicJndiName, String urlTopicServer) {
		super(queueJndiName, urlQueueServer, topicJndiName, urlTopicServer);
		if (queueJndiName == null &&  topicJndiName == null) {
			setTopicJndiName("br.com.cielo.monitoracao.arv.topic.in.rj");
		}
	}

	static long messageOrderId = System.currentTimeMillis();

	@Override
	public void sendMessage(byte[] bytes) throws Exception {
		TextMessage bm = getSession().createTextMessage();
		String mensagem = new String(bytes);
		bm.setText(mensagem);
		// C�digo Inserido para simular envio de informa��o de Site
		int i = getAleatorioGenerico(0, 1);
		String codSite = codSites[i];
		// Property inserida ap�s altera��o de defini��o de diferentes filas por Site
		bm.setStringProperty("SITE_ORIGEM",codSite);
		bm.setLongProperty("MESSAGE_ORDER_ID", messageOrderId++);
		//bm.setText("12/06/2013 10:34:31.00012/06/2013 10:35:10.261PagamentoCelularPOS                               2000000101100992223241000000000010948914000APROVADA 948914                                                                                     Bradesco                                          EM0301Aprovada            ");
		
		Message msgTmp = bm;
		getProducer().send(bm);
		Thread.sleep(1);
	}
	
	protected static int getAleatorioGenerico(int min, int max) {
		SecureRandom a = new SecureRandom();
		return a.nextInt(max + 1 - min) + min;
	}		
}
