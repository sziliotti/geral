package br.com.cielo.monitoracao.cep.robot.lci;

import java.text.SimpleDateFormat;
import java.util.Date;

import br.com.cielo.monitoracao.cep.robot.TransacaoGenerica;


public class TransacaoRecomendacao extends TransacaoLCI{
	SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmss");
	SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss:SSS");
	SimpleDateFormat sdf3 = new SimpleDateFormat("HH:mm:ss:SSS");
	String cdEstab="1234567890123456";
	String nmTerm="12345678";
	String nsu="12345678";
	String dataHora=sdf.format(new Date());
	String nmDocEC="06060606000110";
	String mcc="1234";
	String fluxoCompRec="0";
	String tmpFluxoCompRec=sdf3.format(new Date(2000));
	String fluxoEC="0";
	String tmpFluxoEC="00:00:02:000";
	String fluxoHSM="0";
	String tmpFluxoHSM="00:00:02:000";
	String fluxoDePara="0";
	String tmpFluxoDePara="00:00:02:000";
	String fluxoPremia="0";
	String tmpFluxoPremia="00:00:02:000";
	String fluxoPublicador="0";
	String tmpFluxoPublicador="00:00:02:000";
		
	static final String[] cdEstabs = new String[] { "1234567890123456", "2222222222222222", "3333333333333333","4444444444444444", "5555555555555555"};

	static final String[] statusFinais = new String[] {"00","01", "02", "03", "04", "05", "06"};

	public String getTripa(){
		String tripa = getIdTipTransacao()+
				getCdSite() +
				cdEstab+
				nmTerm+
				nsu+
				dataHora+
				nmDocEC+
				mcc+
				getFiller()+
				getHrInicioFluxo()+
				fluxoCompRec+
				tmpFluxoCompRec+
				fluxoEC+
				tmpFluxoEC+
				fluxoHSM+
				tmpFluxoHSM+
				fluxoDePara+
				tmpFluxoDePara+
				fluxoPremia+
				tmpFluxoPremia+
				fluxoPublicador+
				tmpFluxoPublicador+
				getStFinalTran()+
				getHrFimFluxo()+
				getTmpTotalTra();
		if (tripa.length() != 305) throw new IllegalArgumentException("tamanho da tripa ["+tripa+"] inválido. Esperado 305, e obtido:"+tripa.length());
		
		return tripa;
		
	}

	@Override
	public String getIdTipTransacao() {
		return "002";
	}

	@Override
	public String[] getStatusFinais() {
		return statusFinais;
	}


}
