package br.com.cielo.monitoracao.cep.robot;

import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

public class Consumer {
	// URL of the JMS server. DEFAULT_BROKER_URL will just mean
	// that JMS server is on localhost

	static String URL_QUEUE_SERVER = "t3://SPOA26135-D:9001";

	private String STATIC_QUEUE_JNDI_NAME = "jms.QueueBAMCielo";

	private Connection cachedConnection=null;
	private Session cachedSession=null;
	private Context ctx;
	private Connection getConnection() throws Exception {
		if (cachedConnection == null){
			Properties props = new Properties();
			props.setProperty(Context.INITIAL_CONTEXT_FACTORY,"weblogic.jndi.WLInitialContextFactory");
			props.setProperty(Context.PROVIDER_URL,URL_QUEUE_SERVER);
			ctx = new InitialContext(props);
			ConnectionFactory connectionFactory = 
				(ConnectionFactory) ctx.lookup("jms.MonitoracaoProducerConnFactory");
			cachedConnection = connectionFactory.createConnection();
			cachedConnection.start();	
		}
		
		return cachedConnection;
	}

	private Session getSession() throws Exception{
		if (cachedSession == null) {
		   cachedSession = getConnection().createSession(false,
                Session.AUTO_ACKNOWLEDGE);
		}
		return cachedSession;
	}


 
	private MessageConsumer cachedConsumer;
	
	private MessageConsumer getConsumer() throws Exception {
		if (cachedConsumer == null) {
			getSession();
			Destination destination = (Destination) ctx.lookup(STATIC_QUEUE_JNDI_NAME);

	        // MessageProducer is used for sending messages (as opposed
	        // to MessageConsumer which is used for receiving them)
	        cachedConsumer = getSession().createConsumer(destination);
		}
		return cachedConsumer;
	}
	
	
	
	public String getMessage() throws Exception {

		Message m = getConsumer().receive(1);
		return m==null ? null : ((TextMessage) m).getText();
    }
}
